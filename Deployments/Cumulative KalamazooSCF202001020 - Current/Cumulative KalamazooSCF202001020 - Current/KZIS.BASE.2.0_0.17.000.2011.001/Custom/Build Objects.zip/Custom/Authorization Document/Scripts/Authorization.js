﻿
// Added By Ankesh
//function AddEventHandlers() {
//    try {
//        if ($('[id$=DropDownList_CustomAuthorizationDocuments_Assigned]')[0].value == 0) {
//            ShowHideErrorMessage("Please select a Program", "true");
//            return false;
//        }
//    }
//    catch (err) {
//        LogClientSideException(err,'Authorization'); //Code added by Devinder 
//    }
//}
function AddEventHandlers() {
 try {
     $("#Span_CustomAuthorizationDocuments_DocumentName").html(screenName);
 }
 catch (err) {
        LogClientSideException(err,'Authorization');  
    }
}

// Added By Mohit Madaan
// This function is used to get the unit value.
function GetUnitsString(obj) {
 try
 {

    $.ajax({
        type: "POST",
        url: "../Custom/Authorization Document/WebPages/AuthorizationDocumentsAjaxScript.aspx?functionName=GetUnitsString",
        data: 'procedureId=' + obj.value,
        success: fillUnitString
    });
  }
  catch (err)
  {
   LogClientSideException(err,'Authorization');//Code added by Devinder 
  }

}
//Added By Mohit Madaan
//This function is used to Fill the Units Value According to Seleced Procedure
function fillUnitString(result) {
 try 
 {
    $('[id=Span_TPProcedures_TextUnts]')[0].innerHTML = result;
    if (checkForBlankValues()) {
        calculateTotalUnits()
    }
 }
 catch (err)
  {
   LogClientSideException(err,'Authorization');//Code added by Devinder 
  }
}
//Added By Mohit Madaan
//This function is used to Calculate the Total Units Based on Requested value
function calculateTotalUnits() {
 try {
    
     var units = $('[id=TextBox_TPProcedures_Units]')[0].value;
     
     if (isNaN(parseInt(units))) {
         $("#TextBox_TPProcedures_Units").val('');
         units = '';
     }
     
    if (checkForBlankValues()) {
        var fromDate = $('[id=TextBox_TPProcedures_StartDate]')[0].value;
        var toDate = $('[id=TextBox_TPProcedures_EndDate]')[0].value;
         units = $('[id=TextBox_TPProcedures_Units]')[0].value;
        var frequencyType = $('[id$=DropDownList_TPProcedures_FrequencyType]')[0].value;
        
        PopupProcessing();
        $.ajax({
            type: "POST",
            url: "../Custom/Authorization Document/WebPages/AuthorizationDocumentsAjaxScript.aspx?functionName=CalculateTotalUnitsForAuthorizationDocument",
            data: 'FromDate=' + fromDate + '&ToDate=' + toDate + '&Units=' + units + '&FrequencyRequested=' + frequencyType,
            success: fillTotalUnits           
           ,error: function () {
            HidePopupProcessing();
        }
        });
    }
  }
  catch (err)
  {
      HidePopupProcessing();
   LogClientSideException(err,'Authorization');//Code added by Devinder 
  }
}
//Added By Mohit Madaan
//This function is used to Fill the Total Units in the Text box
function fillTotalUnits(result) {
 try 
 {
     HidePopupProcessing();
//    $("#ButtonInsert").val('Insert');
//    $("#ButtonInsert")[0].disabled = false;
     if (result == '' || result == null) {
         calculateTotalUnits();
     }
     else {
         $('[id=TextBox_TPProcedures_TotalUnits]')[0].value = result;
     }
  }
  catch (err)
  {
   LogClientSideException(err,'Authorization');//Code added by Devinder 
  }
}
//Added By Mohit Madaan
//This function is used to check blank values for Total Units to be calculate.
function checkForBlankValues() {
 try 
  {
    if ($('[id=TextBox_TPProcedures_Units]')[0].value != '' &&
    $('[id=TextBox_TPProcedures_StartDate]')[0].value != '' &&
    $('[id=TextBox_TPProcedures_EndDate]')[0].value != '' &&
    $('[id$=DropDownList_TPProcedures_FrequencyType]')[0].value > 0 &&
    $('[id$=DropDownList_TPProcedures_AuthorizationCodeId]')[0].value > 0) {
        return true;
    }
    else {
        return false;
    }
 }
 catch (err)
  {
   LogClientSideException(err,'Authorization');//Code added by Devinder 
  }   
}

function ClearTPProcedureDate() {
try {
    ClearTable('TableChildControl_ClientContacts', 'TableChildControl_TPProcedures_ButtonInsert', false);


 
    $("[Id$=DropDownList_TPProcedures_ProviderIdSiteId]").val('');
    $("[Id$=DropDownList_TPProcedures_AuthorizationCodeId]").val('0');
    $("[Id$=DropDownList_TPProcedures_FrequencyType]").val('0');
    $("#TextBox_TPProcedures_Units").val('');
    $("#TextBox_TPProcedures_StartDate").val('');
    $("#TextBox_TPProcedures_EndDate").val('');
    $("#TextBox_TPProcedures_TotalUnits").val('');    
    $("#Span_TPProcedures_TextUnts")[0].innerHTML = '';
    $("#Span_TPProcedures_ApprovedAuthorizationCode")[0].innerHTML = '';
    $("#Span_TPProcedures_UnitsApproved")[0].innerHTML = '';
    $("#Span_TPProcedures_StartDateApproved")[0].innerHTML = '';
    $("#Span_TPProcedures_EndDateApproved")[0].innerHTML = '';
    $("#Span_TPProcedures_FrequencyApproved")[0].innerHTML = '';
    $("#Span_TPProcedures_TotalUnitsApproved")[0].innerHTML = '';
    $("#Span_TPProcedures_AuthorizationNumber")[0].innerHTML = '';
    $("#TextBox_TPProcedures_TotalUnits").val('');
    $("#ButtonInsert").val('Insert');   

    $("[id$=GridViewInsert] input[type=radio]:checked").removeAttr("checked");

    //Clear the Primary key Value
    $("#HiddenField_TPProcedures_TPProcedureId").val('');
    
 }
 catch (err)
  {
   LogClientSideException(err,'Authorization');//Code added by Devinder 
  }
}

//function AddParentChildEventHandler() {
//    return AddParentChildEventHandler1();
//       // $("select[id$=DropDownList_TPProcedures_ProviderId]").val("-1");
//}


var n = 0;
// Function Added By Damanpreet Kaur
function InsertAuthorizationDocumentsGridData(TableChildControl_TPProcedures, InsertGrid, dataGridId, buttonCtrl) {
   //Modified by Gayathri Naik on 25th Jan for Task #206
    OnFromToDateValidation();
    if (n == 1) {
        return false;
    }
    else {
        InsertGridData(TableChildControl_TPProcedures, InsertGrid, dataGridId, buttonCtrl);

        if ($("#imageErrorMessage").css("display") == 'none')
            ClearTPProcedureDate(); //Call the funtion after Insert operation.
    }
}


//Added By Gayathri Naik on 25th Jan,2012
//Task #206
function OnFromToDateValidation() {
    var fromdate, Todate;
    fromdate = $("#TextBox_TPProcedures_StartDate").val();
    Todate = $("#TextBox_TPProcedures_EndDate").val();

    if (Date.parse(fromdate) > Date.parse(Todate)) {
        ShowHideErrorMessage("Date From cannot be greater than Date To", 'true');
        $("#TextBox_TPProcedures_StartDate").focus();
        n = 1;
        return false;
    }
    else {
        ShowHideErrorMessage("", 'false');
        n = 0;
        return true;
    }
}