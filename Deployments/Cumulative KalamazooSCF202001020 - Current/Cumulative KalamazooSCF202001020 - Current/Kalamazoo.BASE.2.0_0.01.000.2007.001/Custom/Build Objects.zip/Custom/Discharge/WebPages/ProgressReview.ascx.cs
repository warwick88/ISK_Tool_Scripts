﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SHS.BaseLayer;
using System.Data;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using SHS.DataServices; 

public partial class Custom_Discharge_WebPages_ProgressReview : SHS.BaseLayer.ActivityPages.DataActivityTab
{
    public override string[] TablesUsedInTab
    {
        get
        {
            return new string[] { "CustomDocumentDischarges"};
        }
    }

    public override void BindControls()
    {
        //DataSet dsGoals = new DataSet();
        //SqlParameter[] _objectSqlParmeters = null;
        //_objectSqlParmeters = new SqlParameter[3];
        //_objectSqlParmeters[0] = new SqlParameter("@ClientId", SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId);
        //_objectSqlParmeters[1] = new SqlParameter("@StaffId", SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId);
        //_objectSqlParmeters[2] = new SqlParameter("@CustomParameters", string.Empty);
        //SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "csp_ObjectiveProgressGoals", dsGoals, new string[] { "CustomDischargeCarePlanGoalReviews" }, _objectSqlParmeters);
        //String res = dsGoals.Tables["CustomDischargeCarePlanGoalReviews"].Rows[0]["Goals"].ToString();        
        //TextAreaGoals.InnerHtml = res;
        //Nothing

        DropDownList_CustomDocumentDischarges_TreatmentCompletion.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_CustomDocumentDischarges_TreatmentCompletion.FillDropDownDropGlobalCodes();
    }
}
