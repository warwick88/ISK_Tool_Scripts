﻿var ListCount = 0;
var dropdownProviderCssClass = 'form_dropdown';


//This function is used to Site Bind the dropdown on change Referred by dropdown
function BindDropdownListSites() {
    //Below code Changes made by Rakesh with ref to task 2318 Discharge Event - Authorization tab changes (2) as dropdown Id not found and after saving sites dropdown not bind 
    var ProviderId = $('[id$=DropDownList_CustomEventAuthorizationDocuments_ProviderId]').val()
    //var ProviderId = $('#DropDownList_CustomEventAuthorizationDocuments_ProviderId').val();
    if (ProviderId != 0) {
        $.ajax({
            type: "POST",
            url: GetRelativePath() + "AjaxScript.aspx?functionName=BindDropdownListSites",
            data: 'Providers=' + ProviderId,
            success: BindSites
        });
    }
    else {
        $("select[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId] > option").remove();
    }
    PopupProcessing();
}

function BindSites(result) {
    try {
        var pageResponse = result;
        var start = pageResponse.indexOf("##STARTPAGERESPONSEVALUE##") + 26;
        var end = pageResponse.indexOf("##ENDPAGERESPONSEVALUE##");
        pageResponse = pageResponse.substr(start, end - start);
        if (pageResponse != undefined) {
            $("[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId]").html(pageResponse);
            HidePopupProcessing();
        }


    }
    catch (err) {
        LogClientSideException(err, 'AuthorizationDocuments');
    }
}


function ShowAuthorizationsPopUp(RelativePath) {
    try {

        //Modified By Priya due to Changes in Screen Id
        OpenPage(5761, 24, '', 1, RelativePath, 'T');
    }

    catch (err) {
        LogClientSideException(err, 'NewAuthorization');
    }
}

function SetScreenSpecificValues(dom, action) {
    try {
        if (action == pageActionEnum.Update) {
            RefreshPageData();
        }
        getMedicationData(dom);
        //Added by sourabh with ref to task#2533(CM Support)
        //get rediobuttonlist from custom medication tab
        if ($("#RadioButtonContainer")[0] != null) {
            $("#RadioButtonContainer").find('input[type=radio]').attr('bindautosaveevents', 'False').attr('parentchildcontrols', 'True');
        }
        //end here
        // Added by Jitender on 17 June 2010 for Authorization tab on Discharge Event page.
        $("#HiddenField_CustomEventAuthorizationDocumentAuthorizations_ClientId").val($("input[id $= HiddenField_Clients_ClientId]").val());
        //added by shifali on 7march,2011 ref task# 873 under streamline testing
        SetDiagnosisIAndIIHiddenOrderField(dom);

        //Added by sourabh on 22 Sep,2011 ref to task#2464
        SetNumberOfDaysSetting(dom);

        $('#TextBox_CustomEventAuthorizationDocumentAuthorizations_StartDate').unbind("blur");
        $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_StartDate").blur(function() {
            BindBillingCodeDropdown();
        });
        
        $('#TextBox_CustomEventAuthorizationDocumentAuthorizations_EndDate').unbind("blur");
        $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_EndDate").blur(function() {
            BindBillingCodeDropdown();
        });
    }
    catch (err) {
        LogClientSideException(err, 'NewAuthorization');
    }
}

//Author : Chandan
//Purpose : This function will be used to refresh the Parent Grid shown on Disclosure Detail Page.
//Date:     15 Jan,2010
function RefreshPageData() {
    try {
        var gridDatatable = "TableChildControl_CustomEventAuthorizationDocumentAuthorizations";
        var gridDivName = "InsertGrid";
        var pageValidated = false;
        var PageXMLDom = "";
        if ($("#HiddenFieldPageName").length > 0) {
            RefreshParentChildGrid('EventAuthorizationDocumentAuthorizationId', gridDivName, 'CustomGrid', 'CustomEventAuthorizationDocumentAuthorizations', gridDatatable);
        }
    }
    catch (err) {
        LogClientSideException(err, 'NewAuthorization');
    }
}

//CreatedOn:5th March-2010
//This function is used to Bind the Site dropdown on Based on Provider dropdown
//Added By Priya
function BindSiteDropdown(ProviderId) {
    try {

        var ProviderId = ProviderId;

        $.ajax({
            type: "POST",
            url: GetRelativePath() + "ActivityPages/Client/CMDocuments/AjaxPage.aspx?functionName=BindSiteDropdown",
            data: 'ProviderId=' + ProviderId,
            success: RenderDropDownSiteSuccess
        });
    }
    catch (err) {
        LogClientSideException(err, 'NewAuthorization'); //Code added by Priya 
    }
}
function RenderDropDownSiteSuccess(result) {
    try {
        var pageResponse = result;
        var start = pageResponse.indexOf("##STARTPAGERESPONSEVALUE##") + 26;
        var end = pageResponse.indexOf("##ENDPAGERESPONSEVALUE##");
        pageResponse = pageResponse.substr(start, end - start);
        if (pageResponse != undefined) {
            //$("span[id*=DropDownList_Sites]").html(pageResponse)
            //$("select[id*=DropDownList_Sites]")[0].innerHTML = pageResponse;
            $("[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId]").html(pageResponse);

            //$('[id=DropDownList_Sites]')[0].innerHTML = pageResponse;
        }
        //$('[id=DropDownList_Sites]')[0].style.visibility = "hidden";



    }
    catch (err) {
        LogClientSideException(err, 'NewAuthorization'); //Code added by Ankesh 
    }
}
//CreatedOn:5th March-2010
//This function is used to Bind the Billing Code Dropdown on Based on Provider dropdown
//Added By Priya
function BindBillingCodeDropdown(key) {
    try {

        if (AutoSaveXMLDom[0] != undefined) {
            if (AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomEventAuthorizationDocuments")[0] != null) {

                // Below statement commented by Rakesh w.r f to task 2498 in Care management support as this field is not used any where and getting javascript error
                //var CustomEventAuthorizationDocumentsDocumentVersionId = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomEventAuthorizationDocuments")[0].selectSingleNode("DocumentVersionId").nodeTypedValue;
                var ProviderId = $('[id$=DropDownList_CustomEventAuthorizationDocuments_ProviderId]').val();
                var InsurerId = $("[id$=DropDownList_CustomEventAuthorizationDocuments_InsurerId]").val();
                var EffectiveFrom = $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_StartDate").val();
                var EffectiveTo = $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_EndDate").val();
                //                var AuthId = -1;
                //                if (key != undefined)
                //                    AuthId = key;

                if (ProviderId != 0 && ProviderId != undefined && InsurerId != undefined && InsurerId != 0 && EffectiveFrom != '' && EffectiveTo != '') {
                    $.ajax({
                        type: "POST",
                        url: GetRelativePath() + "ActivityPages/Client/CMDocuments/AjaxPage.aspx?functionName=BindBillingCodeDropdown",
                        data: 'ProviderId=' + ProviderId + '&InsurerId=' + InsurerId + '&EffectiveFrom=' + EffectiveFrom + '&EffectiveTo=' + EffectiveTo,
                        success: function(result) { RenderDropDownBillingCodeSuccess(result, key); }
                    });
                }

            }
        }
    }
    catch (err) {
        LogClientSideException(err, 'NewAuthorization'); //Code added by Priya 
    }
}

function RenderDropDownBillingCodeSuccess(result, key) {
    try {
        var pageResponse = result;
        var start = pageResponse.indexOf("##STARTPAGERESPONSEVALUE##") + 26;
        var end = pageResponse.indexOf("##ENDPAGERESPONSEVALUE##");
        pageResponse = pageResponse.substr(start, end - start);
        if (pageResponse != undefined) {
            //Added by sourabh with ref to task#2454 : To maintain billing code value
            var seletcedVal = $("[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_BillingCodeId]").val();
            $("[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_BillingCodeId]").html(pageResponse);
            $("[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_BillingCodeId]").val(seletcedVal);

            if (key != undefined)
                SetCodeName(key);
            else {
                SetBillingUnits();
            }

        }
    }
    catch (err) {
        LogClientSideException(err, 'NewAuthorization');
    }
}


function ValidateDateAuthorization(input) {
    try {
        return ValidateDate(input); //added by priya

    }
    catch (err) {
        LogClientSideException(err, 'Authorization');
    }

}

function GetXMLParentNodeByColname(colname, xmlDom) {

    var expression = colname;
    return $(expression, xmlDom).parent();
}

function FromDateEndDateValidation(control, rowIndex) {
    try {
        var textBoxProviderAuthorizationsStartDate = $('[id$=TextBox_CustomEventAuthorizationDocumentAuthorizations_StartDate]');
        var textBoxProviderAuthorizationsEndDate = $('[id$=TextBox_CustomEventAuthorizationDocumentAuthorizations_EndDate]');
        if (control.value == "") {
            return false;
        }
        if (control.id == textBoxProviderAuthorizationsStartDate[0].id) {

            if (ValidateDateAuthorization(textBoxProviderAuthorizationsStartDate[0]) == false) {
                ShowMsgBox('Please enter valid Start Date.', ConfirmationMessageCaption, MessageBoxButton.OK, MessageBoxIcon.Information, '', '', '');

                textBoxProviderAuthorizationsStartDate[0].value = '';
                return false;
            }
        }
        else if (control.id == textBoxProviderAuthorizationsEndDate[0].id) {
            if (ValidateDateAuthorization(textBoxProviderAuthorizationsEndDate[0]) == false) {
                var height = 180;
                var width = 400;
                ShowMsgBox('Please enter valid End Date.', ConfirmationMessageCaption, MessageBoxButton.OK, MessageBoxIcon.Information, '', '', '');

                textBoxProviderAuthorizationsEndDate[0].value = '';
                return false;
            }
        }

        if (textBoxProviderAuthorizationsStartDate[0].value != "" && textBoxProviderAuthorizationsEndDate[0].value != "") {
            var date1 = new Date(textBoxProviderAuthorizationsStartDate[0].value);
            var date2 = new Date(textBoxProviderAuthorizationsEndDate[0].value);
            if (date1 > date2) {
                var height = 60;
                var width = 180;
                ShowMsgBox('End Date can not be less then the From Date.', ConfirmationMessageCaption, MessageBoxButton.OK, MessageBoxIcon.Information, '', '', '');
                textBoxProviderAuthorizationsEndDate[0].value = '';
                return false;
            }
        }

        return true;
    }
    catch (err) {

        LogClientSideException(err, 'Authorization');
    }
}
function SetCodeName(key) {

    $.ajax({
        type: "POST",
        url: GetRelativePath() + "ActivityPages/Client/CMDocuments/AjaxPage.aspx?functionName=FindBillingCodeName",
        data: 'KeyId=' + key,
        success: function (result) { onSuccessSetCodeName(result); }
    });
}

function onSuccessSetCodeName(result) {
    if (result != "") {
        $("[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_BillingCodeId]").val(result);

    }
}

function MessageBoxConfirmContinueonProviderChange(confirmResult) {
    switch (confirmResult) {
        case 'yes':
            //Changes Made by Rakesh With ref to task 2318 to  save value on varialbe as when user change provider on prompt comes and On prompt when user click no then previous value not set drodown
            _PreviousProviderDropDownValue = $("[id$=DropDownList_CustomEventAuthorizationDocuments_ProviderId]").val();
            // Added by sourabh with ref to task#2472, To clear table data
            ClearAuthorizationEvent();
            //BindBillingCodeDropdown();
            BindDropdownListSites();
            $.ajax({
                type: "POST",
                url: GetRelativePath() + "ActivityPages/Client/CMDocuments/AjaxPage.aspx?functionName=ResetSite/CodeForDischarge",
                success: function(result) { onSuccessSetAllSiteCode(result); }
            });
            break;
        case 'no':
            //Added by sourabh to reatin Provider dropdown value after save when we change provider with ref to task#6(CM-Warranty)
            CreateAutoSaveXml('CustomEventAuthorizationDocuments', 'ProviderId', _PreviousProviderDropDownValue);
            //end here
            $('[id$=DropDownList_CustomEventAuthorizationDocuments_ProviderId]').val(_PreviousProviderDropDownValue);
            break;
    }
}

function onSuccessSetAllSiteCode(result) {
    var gridDatatable = "TableChildControl_CustomEventAuthorizationDocumentAuthorizations";
    var gridDivName = "InsertGridAuth";
    RefreshParentChildGrid('EventAuthorizationDocumentAuthorizationId', gridDivName, 'CustomGrid', 'CustomEventAuthorizationDocumentAuthorizations', gridDatatable);

}

//This function is used to Get unit by billing code
//Added By sourabh with ref to task#2454
function SetBillingUnits() {
    try {
        var BillingCodeId = $("[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_BillingCodeId]").val();
        var EffectiveFrom = $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_StartDate").val();
        var EffectiveTo = $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_EndDate").val();
        if (BillingCodeId != 0 && EffectiveFrom != "" && EffectiveTo != "" && BillingCodeId != null) {
            $.ajax({
                type: "POST",
                url: GetRelativePath() + "ActivityPages/Client/CMDocuments/AjaxPage.aspx?functionName=CheckAuthorizationUnitType",
                data: 'BillingCodeId=' + BillingCodeId,
                success: function(result) { AuthorizationUnitSuccess(result); }
            });
        }
        else {
            $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_TotalUnits").val("");
        }

    }
    catch (err) {
        LogClientSideException(err, 'AuthorizationEvent');
    }
}

function AuthorizationUnitSuccess(result) {
    //var PreviousUnit = $("#Hidden_CustomEventAuthorizationDocumentAuthorizations_Unit").val();
    if (result == "Y") {
        var EffectiveFrom = $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_StartDate").val();
        var EffectiveTo = $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_EndDate").val();
        var CalculatedUnit = 0;
        var FromDate = new Date(EffectiveFrom);
        var ToDate = new Date(EffectiveTo);

        var utcFromDate = Date.UTC(FromDate.getFullYear(), FromDate.getMonth(), FromDate.getDate());
        var utcToDate = Date.UTC(ToDate.getFullYear(), ToDate.getMonth(), ToDate.getDate());

        CalculatedUnit = parseInt((utcToDate - utcFromDate) / (24 * 3600 * 1000)) + 1;       
        if (CalculatedUnit > 0) {
            $("#TextBox_CustomEventAuthorizationDocumentAuthorizations_TotalUnits").val(CalculatedUnit);
        }

    }
}


function BindProviderDropdown(key) {
    try {
        var InsurerId = $("[id$=DropDownList_CustomEventAuthorizationDocuments_InsurerId]").val();
        if (InsurerId != 0) {
            CreateAutoSaveXml('CustomEventAuthorizationDocuments', 'InsurerId', InsurerId);
            $.ajax({
                type: "POST",
                url: GetRelativePath() + "ActivityPages/Client/CMDocuments/AjaxPage.aspx?functionName=BindProviderDropdown",
                data: 'InsurerId=' + InsurerId,
                success: function(result) { RenderDropDownSuccess(result); }
            });
        }
        else {
            $("select[id$=DropDownList_CustomEventAuthorizationDocuments_ProviderId] > option").remove();
            $("select[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId] > option").remove();
        }
    }
    catch (err) {
        LogClientSideException(err, 'AuthorizationDocuments');
    }
}
//Fill the Provider DropDown based on the Result set 
function RenderDropDownSuccess(result) {
    try {
        $("select[id$=DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId] > option").remove();
        var pageResponse = result;
        var start = pageResponse.indexOf("##STARTPAGERESPONSEVALUE##") + 26;
        var end = pageResponse.indexOf("##ENDPAGERESPONSEVALUE##");
        pageResponse = pageResponse.substr(start, end - start);
        if (pageResponse != undefined) {

            $("[id$=DropDownList_CustomEventAuthorizationDocuments_ProviderId]").html(pageResponse);
            $("[id$=DropDownList_CustomEventAuthorizationDocuments_ProviderId]").addClass(dropdownProviderCssClass);
            BindBillingCodeDropdown();
        }
    }
    catch (err) {
        LogClientSideException(err, 'AuthorizationDocuments');
    }
}
function MessageBoxConfirmContinue(confirmResult) {

    switch (confirmResult) {
        case 'yes':
            // Added by sourabh with ref to task#2472, To clear table data
            ClearAuthorizationEvent();
            BindProviderDropdown();
            $.ajax({
                type: "POST",
                url: GetRelativePath() + "ActivityPages/Client/CMDocuments/AjaxPage.aspx?functionName=ResetSite/Code",
                success: function(result) { onSuccessSetAllSiteCode(result); }
            });
            break;
        case 'no':
            $('[id$=DropDownList_CustomEventAuthorizationDocuments_InsurerId]').val(parseInt(_PreviousInsurerDropDownValue));
            break;
    }
}
function onSuccessSetAllSiteCode(result) {
    var gridDatatable = "TableChildControl_CustomEventAuthorizationDocumentAuthorizations";
    var gridDivName = "InsertGridAuth";
    RefreshParentChildGrid('EventAuthorizationDocumentAuthorizationId', gridDivName, 'CustomGrid', 'CustomEventAuthorizationDocumentAuthorizations', gridDatatable);

}
//Commented by sourabh with ref to task#2472, to clear grid when change provider and insurer
//function AfterParentChildGridRefresh() {
//    if ($("input#Hidden_Field_EventAuthorizationDocumentAuthorizationId").length > 0) {
//        var authId = $("input#Hidden_Field_EventAuthorizationDocumentAuthorizationId").val().trim();
//        if (authId != "") {
//            SelectAuthorizationId(authId);

//        }
//    }
//}
//function SelectAuthorizationId(authId) {
//    if ($('div#InsertGridAuth table[id$=CustomGrid_GridViewInsert_DXMainTable] > tbody > tr').length > 1) {
//        var arrTR = $('div#InsertGridAuth table[id$=CustomGrid_GridViewInsert_DXMainTable] > tbody > tr')
//        $("input#HiddenField_CustomEventAuthorizationDocumentAuthorizations_EventAuthorizationDocumentAuthorizationId").val(authId);
//        for (var i = 1; i < arrTR.length; i++) {
//            var cnt = ($(arrTR[i]).children()).length;
//            var foundAuthID = $(arrTR[i]).children()[7].innerText;
//            if (foundAuthID == authId) {
//                var radioBtn = $(arrTR[i]).children()[1].childNodes[0];
//                $(radioBtn).attr('checked', true);
//                $(radioBtn).trigger('click');
//                break;
//            }

//        }
//    }
//}

//Added by sourabh on 22 Sep,2011 ref to task#2464
function SetNumberOfDaysSetting(_dom) {

    var admissionDate = "";
    var eventDate = "";
    var days = "";
    try {


        if (_dom[0].childNodes[0].selectNodes("CustomDischargeEvents") != null && _dom[0].childNodes[0].selectNodes("CustomDischargeEvents").length > 0) {
            if (_dom[0].childNodes[0].selectNodes("CustomDischargeEvents")[0].selectSingleNode("AdmissionDate") != null) {


                admissionDate = (_dom[0].childNodes[0].selectNodes("CustomDischargeEvents")[0].selectSingleNode("AdmissionDate").nodeTypedValue).trim();
            }
        }
        if (_dom[0].childNodes[0].selectNodes("Events") != null && _dom[0].childNodes[0].selectNodes("Events").length > 0) {
            if (_dom[0].childNodes[0].selectNodes("Events")[0].selectSingleNode("EventDateTime") != null) {
                eventDate = (_dom[0].childNodes[0].selectNodes("Events")[0].selectSingleNode("EventDateTime").nodeTypedValue).trim();
            }
        }
        if (admissionDate != "" && eventDate != "") {
            //            admissionDate = new Date(Date.parse(admissionDate.replace(/\-/ig, '/').split('.')[0]));//Commented by Pradeep as ir throw exception
            admissionDate = new Date(Date.parse(admissionDate.replace(/\-/ig, '/').substring(0, 10)));
            eventDate = new Date(Date.parse(eventDate.replace(/\-/ig, '/').substring(0, 10)));
            var days = parseInt((eventDate - admissionDate) / (24 * 3600 * 1000));
            $("#Span_CustomDischargeEvents_NumberOfDaysInSetting").html(days);

        }
    }
    catch (err) {
        LogClientSideException(err, 'DischargeDocument');
    }
}

