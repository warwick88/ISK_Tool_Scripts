﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;
using SHS.UserBusinessServices;
using System.Collections.Generic;
namespace SHS.SmartCare
{

    public partial class ActivityPages_Client_CMDocuments_Authorizations : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        protected string DocumentVersionId;

        public override void BindControls()
        {
            if (BaseCommonFunctions.CheckRowExists(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet, "CustomEventAuthorizationDocuments", 0))
            {
                DocumentVersionId = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CustomEventAuthorizationDocuments"].Rows[0]["DocumentVersionId"].ToString();
            }


            //This Code is used to bind the Status DropDown
            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("PROVIDERAUTHSTATUS", true, "", "CodeName", true))
            {

                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Status.DataTextField = "CodeName";
                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Status.DataValueField = "GlobalCodeId";
                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Status.DataSource = DataViewGlobalCodes;
                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Status.DataBind();
            }

            //This Code is used to bind the Reason DropDown
            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("AUTHORIZATIONREASON", true, "", "CodeName", true))
            {

                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Reason.DataTextField = "CodeName";
                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Reason.DataValueField = "GlobalCodeId";
                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Reason.DataSource = DataViewGlobalCodes;
                DropDownList_CustomEventAuthorizationDocumentAuthorizations_Reason.DataBind();
            }
            //added by Priya to Bind site if tab is first time selected and if Provider is selected
            if (BaseCommonFunctions.CheckRowExists(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet, "CustomEventAuthorizationDocuments", 0))
            {
                // dataSetObject.Tables["ProviderAuthorizationDocuments"].Rows[0]["InsurerId"] = dataSetObject.Tables["Events"].Rows[0]["InsurerId"];
                if (!BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CustomEventAuthorizationDocuments"].Rows[0]["ProviderId"].ToString().IsNullOrEmpty())
                {
                    int ProviderId = Convert.ToInt32(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CustomEventAuthorizationDocuments"].Rows[0]["ProviderId"]);
                    FillSiteDropDown(ProviderId);
                }

            }

            #region Bind Insurer DropDownList
            HiddenFieldRelativePath.Value = Page.ResolveUrl("~/");
            AuthorizationEvent objAuthorizationEvent = new AuthorizationEvent();
            DataSet objDataSet = null;
            try
            {
                // Commented by sourabh with ref to task#2458
                //objDataSet = objAuthorizationEvent.GetInsurers(BaseCommonFunctions.ApplicationInfo.LoggedInUser.LoggedinUserId);
                objDataSet = objAuthorizationEvent.GetAuthorizationEventInsurers(BaseCommonFunctions.ApplicationInfo.LoggedInUser.LoggedinUserId);
                foreach (DataRow drInsurer in objDataSet.Tables[0].Rows)
                {
                    ListItem lstInsurer = new ListItem();
                    lstInsurer.Text = Convert.ToString(drInsurer["InsurerName"]);
                    lstInsurer.Value = Convert.ToString(drInsurer["InsurerId"]);
                    lstInsurer.Attributes.Add("title", Convert.ToString(drInsurer["InsurerName"]));
                    DropDownList_CustomEventAuthorizationDocuments_InsurerId.Items.Add(lstInsurer);

                }
                DropDownList_CustomEventAuthorizationDocuments_InsurerId.InsertEmptyItem();
            }

            finally
            {
                if (objDataSet != null)
                    objDataSet.Dispose();
            }
            #endregion



            #region Bind Provider DropDownList

            //Modified by sourabh with ref to task#2458 
            DataSet currentDataset = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            int InsurerId = 0;
            if (currentDataset.Tables["CustomEventAuthorizationDocuments"].Rows.Count > 0)
            {
                //Bind the Provider DropDown
                if (currentDataset.Tables["CustomEventAuthorizationDocuments"].Rows[0]["InsurerId"].ToString() != "")
                {
                    InsurerId = int.Parse(currentDataset.Tables["CustomEventAuthorizationDocuments"].Rows[0]["InsurerId"].ToString());
                    //DataSet dsProviders = objAuthorizationEvent.GetProviders(BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId);
                    DataSet dsProviders = objAuthorizationEvent.GetProvidersByInsurer(InsurerId, BaseCommonFunctions.ApplicationInfo.LoggedInUser.LoggedinUserId);
                    DataView dvProviders = dsProviders.Tables[0].DefaultView;
                    dvProviders.Sort = "ProviderName asc";
                    DropDownList_CustomEventAuthorizationDocuments_ProviderId.DataTextField = "ProviderName";
                    DropDownList_CustomEventAuthorizationDocuments_ProviderId.DataValueField = "ProviderId";
                    DropDownList_CustomEventAuthorizationDocuments_ProviderId.DataSource = dvProviders;
                    DropDownList_CustomEventAuthorizationDocuments_ProviderId.DataBind();
                }
            }
            DropDownList_CustomEventAuthorizationDocuments_ProviderId.Items.Insert(0, new ListItem("", ""));
            #endregion
            //end
            ////This Code is used to bind the Insurer Name    
            // Modified by Jitender Kumar Kamboj on 10 Sep 2010
            //DropDownList_ProviderAuthorizations_InsurerId.DataSource = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Insurers;
            //commented by Priya
            //DataView DataViewInsurerName = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Insurers.DefaultView;
            //DataViewInsurerName.Sort = "InsurerName";

            //DropDownList_ProviderAuthorizations_InsurerId.DataSource = DataViewInsurerName;
            //DropDownList_ProviderAuthorizations_InsurerId.DataTextField = "InsurerName";
            //DropDownList_ProviderAuthorizations_InsurerId.DataValueField = "InsurerId";
            //DropDownList_ProviderAuthorizations_InsurerId.DataBind();
            //DropDownList_ProviderAuthorizations_InsurerId.Items.Insert(0, new ListItem("", ""));  

            CustomGrid.Bind(ParentDetailPageObject.ScreenId);
            //FillBillingCode();

        }

        //To fill The CodeDropDown
        //private void FillBillingCode()
        //{
        //    SHS.UserBusinessServices.AuthorizationEvent objAuthorization = new SHS.UserBusinessServices.AuthorizationEvent();
        //    DataSet DataSetBillingCodes = null;
        //    DataView DataViewBillingCodes = null;
        //    DataSetBillingCodes = objAuthorization.GetContractBillingCodes();
        //    DataViewBillingCodes = DataSetBillingCodes.Tables["BillingCodes"].DefaultView;
        //    DataViewBillingCodes.RowFilter = "ProviderId=0";
        //    DropDownList_ProviderAuthorizations_BillingCodeId.DataSource = DataViewBillingCodes;
        //    DropDownList_ProviderAuthorizations_BillingCodeId.DataTextField = "BillingCode";
        //    DropDownList_ProviderAuthorizations_BillingCodeId.DataValueField = "BillingCodeId";
        //    DropDownList_ProviderAuthorizations_BillingCodeId.DataBind();
        //}

        private void FillSiteDropDown(int ProviderId)
        {


            DataView dataViewSites = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Sites);

            dataViewSites.RowFilter = "ProviderId=" + ProviderId;
            // Below sort code added by Rakesh with ref to task 2318 in care management support
            dataViewSites.Sort = "SiteName asc";
            //Changes end here
            DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId.DataSource = dataViewSites;
            DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId.DataTextField = "SiteName";
            DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId.DataValueField = "SiteId";
            DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId.DataBind();
            DropDownList_CustomEventAuthorizationDocumentAuthorizations_SiteId.Items.Insert(0, new ListItem("", ""));

        }
    }

}
