﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;

public partial class ActivityPages_Client_PADocuments_Kalamazoo_Review : SHS.BaseLayer.ActivityPages.DataActivityTab
{
    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        hiddenRelative.Value = Page.ResolveUrl("~/");
    }
    public override void BindControls()
    {
        //DropDownList_CustomConcurrentReviews_CurrentTreatingPsychiatristId.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        //DropDownList_CustomConcurrentReviews_CurrentTreatingPsychiatristId.FillDropDownDropGlobalCodes();            
        DropDownList_CustomConcurrentReviews_CurrentTreatingPsychiatristId.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_CustomConcurrentReviews_CurrentTreatingPsychiatristId.FillDropDownDropGlobalCodes();
    }
}
