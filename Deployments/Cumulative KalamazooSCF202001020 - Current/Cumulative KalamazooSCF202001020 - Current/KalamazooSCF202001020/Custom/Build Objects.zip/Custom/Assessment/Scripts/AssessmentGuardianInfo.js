﻿//$("document").ready(function() {
//    try {

//        SetScreenData();
//        return false;

//    }
//    catch (err) {
//        LogClientSideException(err, 'Summary'); ///Code added by Devinder
//    }
//});

var GaurdianPhone;
function SetControlValuesonRadioSelect(key, rowIndex, obj, customGridTableName, gridPageName, insertButtonId, EnabledisableModifyButton) {
    try{
        GetColumnData(key);
        var delay = function () { SetControlValuesonRadioSelectCall(key, rowIndex, obj, customGridTableName, gridPageName, insertButtonId, EnabledisableModifyButton); }
        setTimeout(delay, 100);
    }
    catch (err) {
        LogClientSideException(err, 'SetControlValuesonRadioSelect function failed in AssessmentGuardianInfo.js');
    }
}
function GetColumnData(primarykey) {
    $.ajax({
        type: "POST",
        url: "../Custom/Assessment/WebPages/AjaxHRMSupport.aspx?FunctionName=GetGaurdianPhone&Key=" + primarykey,
        data: '',
        async: false,
        success: function (result) {
            if (result != "") {
                GaurdianPhone = result;
            }
        },
        error: function (result, err, Message) {
            LogClientSideException(err, 'GetColumnData function failed in AssessmentGuardianInfo.js');
        }
    });
}
function SetControlValuesonRadioSelectCall(key, rowIndex, obj, customGridTableName, gridPageName, insertButtonId, EnabledisableModifyButton) {
    try {
        //var Phonenumber = GetColumnValueInXMLNodeByKeyValue('CustomGuardianInformations', 'GuardianInformationId', key, 'GuardianPhone', AutoSaveXMLDom);
        ClearTable(customGridTableName, insertButtonId, true);
        var _tableName;
        var _parrentTdId;
        var tableName = "#" + customGridTableName + ">tbody>tr";


        /******* Fetch the Grid header Row *******/
        var _HeaderRow = $(obj).parents("table:first").find("tr:first");

        /******* Fetch the selected radio containing Row *******/
        var _parrentRow = $(obj).parents("tr:first");


        var _HeaderItems = $("span", _HeaderRow);
        var _ParentItems = $("td", _parrentRow);

        for (i = 0; i < _HeaderItems.length; i++) {

            _parrentTdId = $(_HeaderItems[i]).attr("id").split("_");

            if (_parrentTdId.length > 3) {
                _tableName = _parrentTdId[1];
                cloumnName = _parrentTdId[2];

                var childeren = $(_ParentItems[i]).children();
                if (childeren.length > 0) {
                    var controlType = childeren[0].nodeName.toLowerCase();
                    if (controlType == 'a' || controlType == 'span' || controlType == 'div') {
                        if (cloumnName == "GuardianPhone") {
                            columnValue = GaurdianPhone;
                        }
                        else {
                            columnValue = $(childeren[0]).html();
                        }
                    }
                    else {
                        columnValue = GetControlValue(childeren[0]);
                    }
                }
                else {
                    columnValue = $(_ParentItems[i]).text();
                }
                var ColumnValueTobeOverridden = false;
                //Following added by Sonia on 14 July 2011
                //As in some cases we need to override value of columns everytime 
                //Despite of column's value null/not null
                if (typeof CheckColumnValueTobeOverridden == 'function')
                    ColumnValueTobeOverridden = CheckColumnValueTobeOverridden(customGridTableName, cloumnName, rowIndex);
                if (columnValue != " ") {
                    SetParentControlValue(trim(columnValue), cloumnName, tableName);
                    // SetControlValues(trim(columnValue), cloumnName, tableName);
                }
                else if (columnValue == " " && ColumnValueTobeOverridden == true) {
                    SetParentControlValue(trim(columnValue), cloumnName, tableName);
                }
            }
        }




        if (gridPageName) {
            if ((gridPageName != undefined) && gridPageName != '' && (gridPageName == 'diagnosis' || gridPageName == 'Diagnostic Assessment')) {
                if (typeof SetCustomValueOnRadioClick == 'function')
                    SetCustomValueOnRadioClick(customGridTableName);
            }
        }
        var _insertButtonElement = $(tableName).find("#" + insertButtonId);
        if (_insertButtonElement.length == 0) {
            _insertButtonElement = $(tableName).find("[id=ButtonInsert]");
        }
        //Added By Karan Garg ref : task #1 Threshold (14 sept 2011)
        // Purpose : To check Permission for Parentchild ButtonInsert before removing disabled attr
        CheckPermissionBeforeClearingTableForParentChild(_insertButtonElement);
        //_insertButtonElement.removeAttr("disabled");
        // Above line commented by Karan


        _insertButtonElement.val("Modify");

        // Modified by - Shifali on (6July2012)
        //Purpose - Enable/Disable Modify button when parent child grid recod is locke/unlocked by logged in user.
        var tableName = customGridTableName.toString().substring(customGridTableName.toString().lastIndexOf("_") + 1, customGridTableName.toString().length);
        var hiddenFieldLocked = $("#HiddenField_" + tableName + "_Locked");
        var hiddenFieldLockedBy = $("#HiddenField_" + tableName + "_LockedBy");

        var LockedValue = hiddenFieldLocked.val();
        var LockedByValue = hiddenFieldLockedBy.val();
        var CustomScreenLockedValue = false; //Added by jagdeep to add new perameter CustomScreenLockedValue as per task #1512 	Thresholds - Bugs/Features (Offshore)

        if (LockedValue != "" && LockedValue != undefined && LockedValue != null) {
            if (LockedValue.toLowerCase() == "y") {
                if (LockedByValue != "" && LockedByValue != undefined && LockedByValue != null) {
                    if (LockedByValue != objectPageResponse.LoggedInUserCode) {
                        _insertButtonElement.attr("disabled", "disabled");
                        CustomScreenLockedValue = true; //Added by jagdeep to add new perameter CustomScreenLockedValue as per task #1512 	Thresholds - Bugs/Features (Offshore)
                    }
                }
            }
        }
        else {
            _insertButtonElement.removeAttr("disabled");
        }

        if (typeof AddParentChildRadioClickEventHandler == 'function') {
            //Modified by Swapan Mohan. Added more parameters to the function.
            AddParentChildRadioClickEventHandler(key, CustomScreenLockedValue, rowIndex, obj, customGridTableName, gridPageName, insertButtonId); //Modified by jagdeep to add new perameter CustomScreenLockedValue as per task #1512 	Thresholds - Bugs/Features (Offshore)
        }
        if (typeof AddParentChildRadioClickEventHandlerForCIR == 'function') {
            AddParentChildRadioClickEventHandlerForCIR(key, rowIndex, obj, customGridTableName, gridPageName, insertButtonId, CustomScreenLockedValue); //Modified by jagdeep to add new perameter CustomScreenLockedValue as per task #1512 	Thresholds - Bugs/Features (Offshore)
        }

        //To implement autoSave onParentChild grid

        if (arguments.callee.caller.caller == undefined) {
            var arrCustomGridTableName = customGridTableName.split('_');
            CreateParentChildAutoSaveXml(arrCustomGridTableName[1], "PrimaryKey", key, AutoSaveParentChildXmlDom, 'Y');

        }
        else {
            var CalledFunaction = arguments.callee.caller.caller.toString() + "";

            if (CalledFunaction.indexOf('LoadDocumentCallBack') != -1) {
                var arrCustomGridTableName = customGridTableName.split('_');
                CreateParentChildAutoSaveXml(arrCustomGridTableName[1], "PrimaryKey", key, AutoSaveParentChildXmlDom, 'Y');
            }
        }
        //
        //
        //added by Deej to bind image in image control
        if (typeof SetMiscControl == 'function') {
            SetMiscControl();
        }
    }
    catch (err) {
        LogClientSideException(err, 'SetControlValuesonRadioSelectCall function failed in AssessmentGuardianInfo.js');
    }

}


function SetGuardianInfo(result) {
    try {
        
        var retValue;
        var tableHeader = "<table width='100%'><thead><tr>";
        var tableBody = "<tbody>";
        var endTable = "</table>";
        tableHeader += "<th align='left' width='25%'>Name</th>";
        tableHeader += "<th align='left' width='20%'>Address</th>";
        tableHeader += "<th align='left' width='25%'>Phone</th>";
        tableHeader += "<th align='left' width='8%'>Type</b></th>";     
        tableHeader += "</thead></tr>";
        //if (val == 'ok') {
        $.xmlDOM(result).find("CustomGuardianInformations").each(function () {
            tableBody += "<tr>";
            tableBody += "<td align='left'>" + $(this).find('GuardianName').text() + "</td>";
            tableBody += "<td align='left'>" + $(this).find('GuardianAddress').text() + "</td>";
            tableBody += "<td align='left'>" + $(this).find('GuardianPhone').text() + "</td>";
            tableBody += "<td align='left'>" + $(this).find('GuardianTypeText').text() + "</td>";
            tableBody += "</tr>";
            
        });
        tableBody += "</tbody>";       
        retValue = tableHeader + tableBody + endTable;
        parent.$('#divGuardianAddressToDisplayOnly').html(retValue);
       
        
    }
    catch (err) {
        LogClientSideException(err, 'GuardianInfo'); //Code added by Damanpreet 
    }
}
function InsertGuardianGridData(TableChildControl_CustomGuardianInformations, InsertGrid, dataGridID, insertButtonObject) {
   
    
    InsertGridData(TableChildControl_CustomGuardianInformations, InsertGrid, dataGridID, insertButtonObject);
    parent.CreateUnsavedChangesInstance();

}
//function updateData() {
//    OpenPage(5763, 10018, 'CustomAction=UpdateGaurdianInfo', null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);

//}
//function SetScreenData() {

//    //Modified by sourabh with ref to task#452
//    var newDom = $.xmlDOM(parent.window.AutoSaveXMLDom[0].xml);
//    AutoSaveXMLDom = newDom;
//    //end here
//    var xmlHrmAssessmentRow = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomHRMAssessments");
//    if (xmlHrmAssessmentRow[0].selectNodes("GuardianName").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianName")[0].text.trim() != '') {
//        $("input[id$=TextBox_CustomHRMAssessments_GuardianName]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianName")[0].text);

//    }

//    if (xmlHrmAssessmentRow[0].selectNodes("GuardianAddress").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianAddress")[0].text.trim() != '') {
//        $("textarea[id$=TextArea_CustomHRMAssessments_GuardianAddress]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianAddress")[0].text);
//    }

//    if (xmlHrmAssessmentRow[0].selectNodes("GuardianPhone").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianPhone")[0].text.trim() != '') {
//        $("input[id$=TextBox_CustomHRMAssessments_GuardianPhone]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianPhone")[0].text);
//    }


//    if (xmlHrmAssessmentRow[0].selectNodes("GuardianType").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianType")[0].text.trim() != '') {
//        $("select:[id$=DropDownList_CustomHRMAssessments_GuardianType]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianType")[0].text);
//    }


//}


// Checks Max length of address textarea
//UpdateScreen(buttonClicked, isExternalURL, isPopUp)
function CheckAddressMaxLength(buttonClicked, isExternalURL, isPopUp) {
    if ($("[id$=TextArea_CustomGuardianInformations_GuardianAddress]").val().length <= 100) {
        ShowHideErrorMessage('Address can not be more than 100 characters', 'false');
        return;
    }
    else {
        ShowHideErrorMessage('Address can not be more than 100 characters', 'true');
        return;
    }
}

//function AddEventHandlers() {
//    try {
//       // debugger;
//        $("[id$=DropDownList_CustomHRMAssessments_GuardianType]").change(function() {
//            var GuardianTypeText = $("[id$=DropDownList_CustomHRMAssessments_GuardianType] option:selected").text();
//            if (GuardianTypeText !== "") {
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianTypeText', GuardianTypeText);
//            }
//            else
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianTypeText', '');

//            var GuardianType = $("[id$=DropDownList_CustomHRMAssessments_GuardianType] option:selected").val();
//            if (GuardianType !== "") {
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianType', GuardianType);
//            }
//            else
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianType', '');
//        });
//        $("[id$=TextBox_CustomHRMAssessments_GuardianName]").change(function() {
//            var GuardianName = $("[id$=TextBox_CustomHRMAssessments_GuardianName]").val();
//            if (GuardianName !== "") {
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianName', GuardianName);
//            }
//            else
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianName', '');
//        });

//        $("[id$=TextArea_CustomHRMAssessments_GuardianAddress]").change(function() {
//            var GuardianAddress = $("[id$=TextArea_CustomHRMAssessments_GuardianAddress]").val();
//            if (GuardianAddress !== "") {
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianAddress', GuardianAddress);
//            }
//            else
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianAddress', '');
//        });

//        $("[id$=TextBox_CustomHRMAssessments_GuardianPhone]").change(function() {
//           // PhoneFormatCheck(this);
//            var GuardianPhone = $("[id$=TextBox_CustomHRMAssessments_GuardianPhone]").val();
//            if (GuardianPhone !== "") {
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianPhone', GuardianPhone);
//            }
//            else
//                CreateAutoSaveXml('CustomHRMAssessments', 'GuardianPhone', '');
//        });
//    }
//    catch (err) {
//        LogClientSideException(err, 'CustomHRMAssessments');
//    }
//}
function updateData() {
    
    // OpenPage(5763, 10018, 'CustomAction=UpdateGaurdianInfo', null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    $.ajax({
       
        type: "POST",
        url: "../Custom/Assessment/WebPages/AjaxHRMSupport.aspx?FunctionName=GetGaurdianInfo",
        data: '',
        async: false,
        success: function (result) {
            
            
            if (result != "") {
                SetGuardianInfo(result);
            }
        },
        error: function (result, err, Message) {
            LogClientSideException(err, 'updateData function failed in AssessmentGuardianInfo.js');
        }
    });
}

function CustomAjaxRequestCallback(result, CustomAjaxRequest) {
    try{
        if (result.indexOf("###StartCurrentDiagnosisUC###") >= 0) {
            var start = result.indexOf("###StartCurrentDiagnosisUC###") + 29;
            var end = result.indexOf("###EndCurrentDiagnosisUC###");
            var htmlResponse = result.substr(start, end - start);
            SetGuardianInfo(htmlResponse);
        }
    }
    catch (ex) {
        LogClientSideException(ex, 'CustomAjaxRequestCallback function failed in AssessmentGuardianInfo.js');
    }
}
function CloseGuardianPopUp() {
    try{
        updateData();
        //parent.SetParentReturnValue();
       
        parent.CloaseModalPopupWindow();
        
       
    }
    catch (ex) {
        LogClientSideException(ex, 'CloseGuardianPopUp function failed in AssessmentGuardianInfo.js');
    }
}
function encodeTextSymbol(TextToEncode) {
    try {
        var encodedHtml = TextToEncode.replace(/\+/g, "%PL");
        return encodedHtml;
    }
    catch (ex) {
        LogClientSideException(ex, 'encodeTextSymbol function failed in AssessmentGuardianInfo.js');
    }
}