﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using SHS.BaseLayer;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using CarePlan;
using System.Linq;

///<summary>
///<Description>Need List In Care Plan</Description>
///</summary>
namespace SHS.SmartCare
{
    public partial class CarePlanNeeds : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        public string Screenname { get; private set; }
        public int screenDocumentCodeId = 0;
        public int assessmentDocumentCodeId = 0;
        string ListOfAssessmentDocumentCodeIds = "";
        private JavaScriptSerializer objectJavaScriptSerializer = null;
        DataSet dsMasterData = new DataSet();

       
        public override void BindControls()
        {
            //EI#677 - Analysis and Resolution to Fix - Exception: "There is no row at position 0" in SmartCare Application
            string _DocumentCodeId = string.Empty;            
            if (BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.IsDataTableFound("Documents"))            
                _DocumentCodeId = Convert.ToString(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["Documents"].Rows[0]["DocumentCodeId"].ToString());
            screenDocumentCodeId = Convert.ToInt32(string.IsNullOrEmpty(_DocumentCodeId) ? "0" : _DocumentCodeId);

            //int.TryParse(BaseCommonFunctions.GetSystemConfigurationValue("ASSESSMENTDOCUMENTCODEID"), out assessmentDocumentCodeId);

            ListOfAssessmentDocumentCodeIds = BaseCommonFunctions.GetSystemConfigurationValue("ASSESSMENTDOCUMENTCODEID");
            if (!string.IsNullOrEmpty(ListOfAssessmentDocumentCodeIds))
            {
                int _ReturnDocumetcodeId = 0;
                int[] ArrayofAssessmentDocumentCodeId = ListOfAssessmentDocumentCodeIds.Split(',').Select(s => int.TryParse(s, out _ReturnDocumetcodeId) ? _ReturnDocumetcodeId : 0).ToArray();
                //if (ArrayofAssessmentDocumentCodeId.Contains(screenDocumentCodeId))
                //{
                //    assessmentDocumentCodeId = screenDocumentCodeId;
                //    ArrayofAssessmentDocumentCodeId
                //}
                assessmentDocumentCodeId = ArrayofAssessmentDocumentCodeId[0];
            }
            Screenname = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.FindByScreenId(SHS.BaseLayer.BaseCommonFunctions.ScreenId).ScreenName.ToString();
             
            dsMasterData = CarePlan.CarePlan.GetMasterData();
            BindNeedsList();
        }

        ///<summary>
        ///<Description>Needs Tab Bind Template</Description>
        ///</summary>
        private void BindNeedsList()
        {
            string goalNumberString = string.Empty;
            string goalNumberComma = string.Empty;
            //EI#677 - Analysis and Resolution to Fix - Exception: "There is no row at position 0" in SmartCare Application
            string documentCodeId = string.Empty;
            if (BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.IsDataTableFound("Documents"))
                documentCodeId = Convert.ToString(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["Documents"].Rows[0]["DocumentCodeId"].ToString());
                //documentCodeId = assessmentDocumentCodeId.ToString();
            DataRow[] datarowGoalsArray = null;

            List<NeedsListData> objectListGridData = null;
            DataSet dataSetScreenData = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            objectListGridData = new List<NeedsListData>();
            NeedsListData objectNeedListData = new NeedsListData();
            objectNeedListData.objectListDomain = new List<Domain>();


            foreach (DataRow dataRowDomain in dsMasterData.Tables["CarePlanDomains"].Rows)
            {
                Domain objectDomain = new Domain();
                objectDomain.objectListNeeds = new List<Needs>();
                objectDomain.CarePlanDomainId = Convert.ToString(dataRowDomain["CarePlanDomainId"]);
                objectDomain.DomainName = Convert.ToString(dataRowDomain["DomainName"]);
               // objectDomain.DocumentCodeId = documentCodeId;
                objectDomain.DocumentCodeId = assessmentDocumentCodeId.ToString();
                foreach (DataRow datarowNeeds in dataSetScreenData.Tables["CarePlanNeeds"].Select("CarePlanDomainId=" + objectDomain.CarePlanDomainId + "AND ISNULL(RecordDeleted,'N')='N'"))
                {
                    goalNumberComma = string.Empty;
                    Needs objectNeed = new Needs();
                    objectNeed.objectListNeedGoals = new List<NeedGoals>();
                    objectNeed.CarePlanNeedId = Convert.ToString(datarowNeeds["CarePlanNeedId"]);
                    objectNeed.CarePlanDomainNeedId = Convert.ToString(datarowNeeds["CarePlanDomainNeedId"]);
                    objectNeed.AddressOnCarePlan = Convert.ToString(datarowNeeds["AddressOnCarePlan"]);

                    objectNeed.CarePlanDomainId = Convert.ToString(datarowNeeds["CarePlanDomainId"]);
                    objectNeed.NeedDescription = Convert.ToString(datarowNeeds["NeedDescription"]);
                    objectNeed.DeferralReason = Convert.ToString(datarowNeeds["DeferralReason"]);
                    objectNeed.NeedName = Convert.ToString(datarowNeeds["NeedName"]);
                    objectNeed.Source = Convert.ToString(datarowNeeds["Source"]);
                    objectNeed.SourceName = Convert.ToString(datarowNeeds["SourceName"]);
                    objectNeed.DocumentCodeId = documentCodeId;
                    //objectNeed.DocumentCodeId = assessmentDocumentCodeId.ToString(); ;



                    string actionTakenIsGoalExistFlag = "0";
                    int goalCounter = 1;

                    if (documentCodeId != "1469")
                    {
                        if (BaseCommonFunctions.CheckRowExists(dataSetScreenData, "CarePlanGoalNeeds"))
                        {
                            DataTable datatableTempGoalNeeds = CreateTableWithGoalNumberInGoalNeeds(dataSetScreenData);

                            DataRow[] datarowArrayGoalNeeds = datatableTempGoalNeeds.Select("CarePlanNeedId=" + objectNeed.CarePlanNeedId + "AND ISNULL(RecordDeleted,'N')='N'", "GoalNumber Asc");

                            foreach (DataRow datarowGoalNeeds in datarowArrayGoalNeeds)
                            {
                                string GoalNumberCheck = string.Empty;
                                NeedGoals objectNeedGoals = new NeedGoals();
                                datarowGoalsArray = dataSetScreenData.Tables["CarePlanGoals"].Select("CarePlanGoalId=" + datarowGoalNeeds["CarePlanGoalId"] + " AND ISNULL(RecordDeleted,'N')='N' AND ISNULL(GoalActive,'N')='Y'");

                                foreach (DataRow datarowDocumentCarePlanGoals in datarowGoalsArray)
                                {
                                    objectNeedGoals.GoalId = Convert.ToString(datarowDocumentCarePlanGoals["CarePlanGoalId"]);
                                    objectNeedGoals.GoalNeedId = objectNeed.CarePlanNeedId;

                                    objectNeedGoals.MemberGoalVision = Convert.ToString(datarowDocumentCarePlanGoals["ClientGoal"]);

                                    objectNeedGoals.GoalNumber = Convert.ToString(datarowDocumentCarePlanGoals["GoalNumber"]);
                                    objectNeedGoals.GoalCounterFlag = goalCounter;
                                    goalCounter = 2;

                                    int objectDomainGoalId = (string.IsNullOrEmpty(Convert.ToString(datarowDocumentCarePlanGoals["CarePlanDomainGoalId"]))) ? 0 : Convert.ToInt32(datarowDocumentCarePlanGoals["CarePlanDomainGoalId"]);
                                    if (objectDomainGoalId > 0)
                                    {
                                        foreach (DataRow datarowCarePlanDomainGoals in dsMasterData.Tables["CarePlanDomainGoals"].Select("CarePlanDomainGoalId=" + objectDomainGoalId + "AND ISNULL(RecordDeleted,'N')='N'"))
                                        {
                                            objectNeedGoals.GoalDescription = Convert.ToString(datarowCarePlanDomainGoals["GoalDescription"]);
                                        }
                                    }
                                    if ((objectNeed.AddressOnCarePlan == "Y") && datarowDocumentCarePlanGoals.Table.Rows.Count > 0)
                                    {
                                        actionTakenIsGoalExistFlag = "1";
                                    }
                                    else
                                    {
                                        actionTakenIsGoalExistFlag = "0";
                                    }
                                }

                                objectNeed.objectListNeedGoals.Add(objectNeedGoals);
                            }
                        }
                    }
                    objectNeed.ActionTakenIsGoalExist = actionTakenIsGoalExistFlag;
                    objectDomain.objectListNeeds.Add(objectNeed);
                }
                if (objectDomain.objectListNeeds.Count == 0)
                    objectDomain.NoIdenifiedNeedMsg = "No identified needs";

                objectNeedListData.objectListDomain.Add(objectDomain);
            }
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string strJSON = objectJavaScriptSerializer.Serialize(objectNeedListData);
            HiddenFieldNeeds.Value = strJSON;
        }

        public override void Activate()
        {
            base.Activate();
            CarePlanMergeUnsavedXML();
        }

        public void CarePlanMergeUnsavedXML()
        {
            DataSet dataSetPageDataSet = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            try
            {
                if (Request.Form["myxmlstring"] != null)
                {
                    string unsavedXML = Convert.ToString(Request.Form["myxmlstring"]);
                    string strxml = unsavedXML.Replace("xmlns=\"\"", "");
                    BaseCommonFunctions.MergeXMLInDataSet(ref dataSetPageDataSet, strxml);
                }
            }
            finally
            {
            }
        }

        private DataTable CreateTableWithGoalNumberInGoalNeeds(DataSet dataSetScreenData)
        {
            if (BaseCommonFunctions.CheckRowExists(dataSetScreenData, "CarePlanGoalNeeds"))
            {
                DataTable datatableGoalNeeds = dataSetScreenData.Tables["CarePlanGoalNeeds"];
                DataView dataviewGoalNeeds = datatableGoalNeeds.DefaultView;
                dataviewGoalNeeds.RowFilter = "ISNULL(RecordDeleted,'N')<>'Y'";

                DataTable datatableTempGoalNeeds = dataviewGoalNeeds.ToDataTable();
                datatableTempGoalNeeds.TableName = "DatatableTemporaryGoalNeeds";

                datatableTempGoalNeeds.Columns.Add("GoalNumber", System.Type.GetType("System.Int32"));

                DataTable datatableCarePlanGoals = null;
                if (BaseCommonFunctions.CheckRowExists(dataSetScreenData, "CarePlanGoals"))
                {
                    datatableCarePlanGoals = dataSetScreenData.Tables["CarePlanGoals"];
                }

                foreach (DataRow datarowCurrent in datatableTempGoalNeeds.Rows)
                {
                    string goalId = Convert.ToString(datarowCurrent["CarePlanGoalId"]);
                    DataRow[] datarowGoal = datatableCarePlanGoals.Select("CarePlanGoalId=" + goalId);
                    if (datarowGoal.Length > 0)
                    {
                        string goalNumber = Convert.ToString(datarowGoal[0]["GoalNumber"]);
                        datarowCurrent["GoalNumber"] = goalNumber;
                    }
                }
                return datatableTempGoalNeeds;
            }
            return null;
        }

        /// <summary>
        /// <purpose>Get Need Description text</purpose>
        /// </summary>
        /// <param name="domainNeedId"></param>
        /// <param name="dataSetScreenData"></param>
        /// <returns></returns>
        private string GetNeedDescriptionTextByDomainGroup(string domainNeedId, DataSet dataSetScreenData)
        {
            string needDescText = string.Empty;

            if (BaseCommonFunctions.CheckRowExists(dataSetScreenData, "CustomDocumentNeeds"))
            {
                DataRow[] datarowDomainNeeds = dataSetScreenData.Tables["CustomDocumentNeeds"].Select("DomainNeedId=" + domainNeedId);
                foreach (DataRow datarowCurrent in datarowDomainNeeds)
                {
                    needDescText += "\n" + datarowCurrent["NeedDescription"];
                }
            }

            return needDescText;
        }
    }
}