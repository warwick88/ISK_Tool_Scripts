﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SHS.BaseLayer;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using DevExpress.Web.ASPxGridView;
using System.Web.Services;
using System.Collections.Generic;
using System.IO;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using SHS.DataServices;


namespace SHS.SmartCare
{
    public partial class Custom_CarePlan_WebPages_CarePlanAjaxScript : System.Web.UI.Page
    {
        DataTable _DataTableClientNeeds = null;
        DataTable _DataTableTPObjectives = null;
        public string RelativePath = string.Empty;
        private JavaScriptSerializer JavaScriptSerializer = null;
        string CarePlanPrescribedServiceIdVal = string.Empty;
        List<InteractionAuthorizationCodes> _interactionAuthorizationCodes = new List<InteractionAuthorizationCodes>();
        SHS.UserBusinessServices.Document _objectDocuments = null;
        string agencyName = string.Empty;
        SqlParameter[] _objectSqlParmeters = null;
        public void Dispose()
        {
            this.DisposeObject();
        }
        public void DisposeObject()
        {
            _objectSqlParmeters = null;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _objectDocuments = new SHS.UserBusinessServices.Document();
                agencyName = _objectDocuments.GetAgencyName();
                _objectDocuments = null;

                RelativePath = Page.ResolveUrl("~/");
                switch (Request.Form["action"].ToLower())
                {
                    case "edit": //Handle On Blur
                        EditValue();
                        break;
                    case "fillauthorizationdropdown":
                        {
                            int siteID = -1;
                            int.TryParse(Convert.ToString(Request.Form["siteID"]), out siteID);
                            //goalNo = Request.Form["GoalNo"];
                            CreateServiceDropDownList(siteID, Convert.ToInt32(Request.Form["tPInterventionProcedureId"]), Convert.ToString(Request.Form["tpProcedureId"]), Convert.ToString(Request.Form["authorizationCodeId"]), Convert.ToBoolean(Request.Form["disableProcedureProvider"]));
                            break;
                        }
                    case "addintervention": //Handle Add Goal
                        BaseCommonFunctions.IsPopup = false;
                        AddIntervention();
                        break;
                    case "deleteintervention": //Handle delete Intervention
                        DeleteIntervention();
                        break;
                    case "unitcalculation":
                        UnitCalculation();
                        break;
                    case "fillrequestlcmccmlabels":
                        FillRequestLcmCcmLabels();
                        break;
                        
                }
            }
            catch (System.Threading.ThreadAbortException ex)
            {
                //System.Threading.ThreadAbortException need not to be logged
            }

            catch (Exception ex)
            {
                string ErrorMessage = string.Empty;
                ErrorMessage = "Error occured during Custom Ajax request at CarePlan Ajax Script Error Info:-" + " Action is " + Request.Form["action"] + ", ErrorMessage:-+ " + ex.Message;
                Exception exceptionObject1 = new Exception(ErrorMessage);
                LogManager.LogException(exceptionObject1, LogManager.LoggingCategory.Error, LogManager.LoggingLevel.Error);
            }
        }


        private void EditValue()
        {
            DataRow[] dataRowCarePlan = null;
            try
            {
                using (DataSet dataSetCarePlan = BaseCommonFunctions.GetScreenInfoDataSet())
                {
                    if (dataSetCarePlan != null && dataSetCarePlan.Tables.Count > 0)
                    {
                        if (dataSetCarePlan.Tables.Contains(Request.Form["tableName"]))
                        {
                            if (dataSetCarePlan.Tables[Request.Form["tableName"]].Rows.Count > 0)  //Perform Row Count Check
                            {
                                dataRowCarePlan = dataSetCarePlan.Tables[Request.Form["tableName"]].Select(Request.Form["keyFieldName"] + "=" + Request.QueryString["keyValue"]);
                                if (dataRowCarePlan.Length > 0)
                                {
                                    dataRowCarePlan[0].BeginEdit();
                                    if (!Request.Form["controlValue"].IsNullOrEmpty())
                                    {
                                        //Below code for Server.UrlDecode commented by Rakesh to w.r.f to task  398 Treatment Plan: Intervention text 
                                        //dataRowTreatmentPlanHRM[0][Request.Form["fieldName"]] = Server.UrlDecode(Request.Form["controlValue"]);
                                        dataRowCarePlan[0][Request.Form["fieldName"]] = (Request.Form["controlValue"]);
                                    }
                                    else
                                    {
                                        dataRowCarePlan[0][Request.Form["fieldName"]] = DBNull.Value;
                                    }

                                    if (!dataRowCarePlan[0]["IsInitializedFrom"].ToString().IsNullOrEmpty())
                                        dataRowCarePlan[0]["IsInitializedFrom"] = DBNull.Value;
                                    dataRowCarePlan[0].EndEdit();

                                    BaseCommonFunctions.GetScreenInfoDataSet().Merge(dataSetCarePlan);
                                }
                            }
                        }
                    }
                }

            }
            finally
            {
                dataRowCarePlan = null;
            }
        }


        /// <summary>
        /// <Description>This method is used to Read Data from TPNeeds and Create Goal Section </Description>
        /// <Author>Vikas Vyas</Author>       
        /// <CreatedOn></CreatedOn>
        /// <Modified By >Anuj Tomat</Author>
        /// <Modified On>12 oct,2009</CreatedOn>
        /// </summary>
        private void AddIntervention()
        {
            DataSet dataSetIntervention = null;
            DataView dataViewIntervention = null;
            DataRowView dataRowViewIntervention = null;
            StringBuilder stringBuilderHTML = null;

            DataRow[] DataRowCarePlans = null;
            DataRow dataRowInterventionNew = null;
            string interventionCount = Request.Form["InterventionCount"];

            try
            {
                PanelInterventionPlanMainAjax.Controls.Clear();

                using (dataSetIntervention = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
                {
                    if (dataSetIntervention != null && dataSetIntervention.Tables.Count > 0)
                    {
                        if (dataSetIntervention.Tables.Contains("CustomCarePlanPrescribedServices"))
                        {
                            dataViewIntervention = new DataView(dataSetIntervention.Tables["CustomCarePlanPrescribedServices"]);
                            dataViewIntervention.Sort = "CarePlanPrescribedServiceId";
                            dataViewIntervention.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'";
                            //Set Need Count in the hidden field
                            //HiddenFiedInterventionCount.Value = Convert.ToString(dataViewIntervention.Count);
                            //Loop how many rows exists in the TPNeeds table for creating Goal
                            stringBuilderHTML = new StringBuilder();
                            PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl("###STARTPAGERESPONSESINGLEGOAL###"));
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<table Id='TableInterventionMain1'  style='width:100%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");

                            DataRowCarePlans = dataSetIntervention.Tables["DocumentCarePlans"].Select("Isnull(RecordDeleted,'N')<>'Y'");
                            if (DataRowCarePlans.Length > 0)
                            {

                                dataRowInterventionNew = dataSetIntervention.Tables["CustomCarePlanPrescribedServices"].NewRow();
                                dataRowInterventionNew.BeginEdit();
                                dataRowInterventionNew["DocumentVersionId"] = DataRowCarePlans[0]["DocumentVersionId"];
                                BaseCommonFunctions.InitRowCredentials(dataRowInterventionNew);
                                dataRowInterventionNew.EndEdit();
                                dataSetIntervention.Tables["CustomCarePlanPrescribedServices"].Rows.Add(dataRowInterventionNew);
                                //dataRowInterventionNew["CarePlanPrescribedServiceId"] = Convert.ToInt32(dataSetIntervention.Tables["CustomCarePlanPrescribedServices"].Compute("Max(CarePlanPrescribedServiceId)", "")) + 1;
                                CarePlanPrescribedServiceIdVal = dataRowInterventionNew["CarePlanPrescribedServiceId"].ToString();

                                stringBuilderHTML.Append("<tr id='tr_MainIntervention" + CarePlanPrescribedServiceIdVal + "'>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table style='width:100%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                #region Main Table
                                stringBuilderHTML.Append("<table id='tbl_Sub_Intervention_" + CarePlanPrescribedServiceIdVal + "'  style='width:100%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");


                                //Start -- New Code Added By Damanpreet For Create a Section
                                #region First TR of Main Table (start Section)
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table cellspacing='0'  cellpadding='0' border='0' width='100%'>");

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td align='left' nowrap='nowrap' class='content_tab_left'>");
                                stringBuilderHTML.Append("<span name='Span_InterventionNo_" + CarePlanPrescribedServiceIdVal + "'  id='Span_InterventionNo_" + CarePlanPrescribedServiceIdVal + "' style='color:Black;font-size:11px;' BindAutoSaveEvents ='False'  BindSetFormData='False' >Interventions # " + (interventionCount) + "</span>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td width='17'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='17' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_sep.gif />");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td width='100%' class='content_tab_top'>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td width='7'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='7' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_right.gif />");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append(" </tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion First TR Main Table (start Section)

                                #region 3 TR for Main Table
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td class='right_contanier_bg'>");

                                #region TabContent Table

                                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%' id='tbl_" + CarePlanPrescribedServiceIdVal + "'>");
                                stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");

                                PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style='width:8%;'>&nbsp;</td>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table border='0' cellpadding='0' style='width:100%'  cellspacing='0' >"); //Create

                                CreateIntervention(CarePlanPrescribedServiceIdVal, ref dataSetIntervention);

                                stringBuilderHTML = new StringBuilder();

                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");


                                stringBuilderHTML.Append("</table>");
                                #endregion TabContent Table
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion 3 TR for Main Table

                                #region 4 TR for Main Table
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                                stringBuilderHTML.Append("<tr>");

                                stringBuilderHTML.Append("<td width='2' class='right_bottom_cont_bottom_bg'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_left.gif /> ");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td width='100%' class='right_bottom_cont_bottom_bg'>");

                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td align='right' width='2' class='right_bottom_cont_bottom_bg'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_right.gif />");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                #endregion 4 TR for Main Table


                                stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");


                                //----NewLY Commented 2 JULY
                                //stringBuilderHTML.Append("</table>");
                                //----END NewLY Commented 2 JULY
                                #endregion MainTable
                                PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                            }

                            stringBuilderHTML = new StringBuilder();
                            stringBuilderHTML.Append("</tr>");

                            stringBuilderHTML.Append("<tr id='MainInterventionEnd_" + CarePlanPrescribedServiceIdVal + "'>");
                            stringBuilderHTML.Append("<td style='width:3%;height:3px;' colspan='3'>&nbsp;</td>");
                            stringBuilderHTML.Append("</tr>");

                            stringBuilderHTML.Append("<tr>"); //8th Row Open Tag                           
                            stringBuilderHTML.Append("<td colspan='3' align='left'>");
                            stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create
                            stringBuilderHTML.Append("<tr>");

                            stringBuilderHTML.Append("<td width='9%' >");
                            stringBuilderHTML.Append("&nbsp;"); //Create
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("<td align='left'  >");
                            stringBuilderHTML.Append("<span name='Span_AddIntervention_" + CarePlanPrescribedServiceIdVal + "'  id='Span_AddIntervention_" + CarePlanPrescribedServiceIdVal + "'  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"AddNewCarePlanIntervention('" + CarePlanPrescribedServiceIdVal + "','Add Intervention');\" >Add Intervention</span>"); //Create
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                            dataSetIntervention.Tables["CustomCarePlanPrescribedServices"].DefaultView.RowFilter = "";
                            PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                            PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl("###ENDPAGERESPONSESINGLEGOAL###"));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Exception exx = new Exception();
                string dxml = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.GetXml().ToString();
                exx = new Exception(ex.Message + ex.StackTrace + dxml);
                throw new Exception(ex.Message + ex.StackTrace + dxml, ex.InnerException);
            }
            finally
            {

            }
        }

        /// <summary>
        /// <Description>Method is used to Read Data from TPInterventionProcedure and Create Intervention Section</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>16th-Sept-2009</CreatedOn>
        /// </summary>
        /// <param name="carePlanPrescribedServiceId"></param>
        /// <param name="dataSetInterventionPlan"></param>
        private void CreateIntervention(string carePlanPrescribedServiceId, ref DataSet dataSetInterventionPlan)
        {
            StringBuilder stringBuilderHTML = null;
            DataRow[] dataRowInterventionPlan = null;
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionFrequency = null;
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionProvider = null;
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionPersonResponsible = null;

            //All references of 'dropdownListinterVentionService' in current function commented by shifali
            // in ref to task# 4 of UM - Part two on 29th sept,2010
            //DropDownList dropdownListinterVentionService = null;
            DataRow[] dataRowTPInterventionPObjective = null;
            DataRow dataRowTPProcedures = null;
            DataTable dataTableTPObjective = null;
            bool disableProcedureProvider = false;
            int siteID = -1;
            string documentCodeId = string.Empty;
            string documentStatus = string.Empty;
            string fromDate = string.Empty;

            try
            {
                if (dataSetInterventionPlan.Tables.Contains("CustomCarePlanPrescribedServices"))
                {
                    if (BaseCommonFunctions.CheckRowExists(dataSetInterventionPlan, "Documents", 0))
                    {
                        documentCodeId = Convert.ToString(dataSetInterventionPlan.Tables["Documents"].Rows[0]["DocumentCodeId"]);
                        documentStatus = Convert.ToString(dataSetInterventionPlan.Tables["Documents"].Rows[0]["Status"]);
                        fromDate = Convert.ToString(dataSetInterventionPlan.Tables["Documents"].Rows[0]["EffectiveDate"]);
                    }

                    if (dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServices"].Rows.Count > 0)
                    {
                        stringBuilderHTML = new StringBuilder();
                        dataRowInterventionPlan = dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServices"].Select("Isnull(RecordDeleted,'N')<>'Y' and CarePlanPrescribedServiceId='" + carePlanPrescribedServiceId + "'");
                        if (dataRowInterventionPlan.Length > 0)
                        {
                            DataView dataViewTPInterventionProcedures = new DataView(dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServices"]);
                            dataViewTPInterventionProcedures.Sort = "CarePlanPrescribedServiceId";

                            dataViewTPInterventionProcedures.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'and CarePlanPrescribedServiceId=" + carePlanPrescribedServiceId;

                            stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");

                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td align='left'>");
                            stringBuilderHTML.Append("<table style='width:100%;' border='0' cellpadding='0' cellspacing='3' id='tbl_InterventionSection_" + carePlanPrescribedServiceId + "'>");
                            if (dataViewTPInterventionProcedures.Count > 0)
                            {
                                for (int interventionCount = 0; interventionCount < dataViewTPInterventionProcedures.Count; interventionCount++)
                                {
                                    stringBuilderHTML.Append("<tr class='tr_InterventionProcedures_" + carePlanPrescribedServiceId + "'>");
                                    stringBuilderHTML.Append("<td style='width:10px;color:Black;font-size:11px;' valign='top'>");
                                   
                                    stringBuilderHTML.Append("<img style='cursor:hand;' id='ImgDelete_" + carePlanPrescribedServiceId + "' src=" + RelativePath + "App_Themes/Includes/Images/deleteIcon.gif  onClick= \"DeleteIntervention('" + carePlanPrescribedServiceId + "','true');\" />");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td align='left' class='form_label'>Provider</td>");
                                    stringBuilderHTML.Append("<td valign='top'>");

                                    PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                    string tpProcedureId = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"]);
                                    string authorizationCodeId = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]);

                                    stringBuilderHTML = new StringBuilder();
                                    dropdownListinterVentionProvider = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionProvider.Width = 120;
                                    dropdownListinterVentionProvider.CssClass = "form_dropdown";

                                    dropdownListinterVentionProvider.ID = "DropDownList_CustomCarePlanPrescribedServices_ProviderId_" + carePlanPrescribedServiceId;
                                    
                                    if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers != null)
                                    {
                                        DataView dataViewProviders = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers);
                                        dataViewProviders.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y' and isnull(RenderingProvider,'N')<>'Y' ";
                                        dropdownListinterVentionProvider.DataTextField = "ProviderName";
                                        dropdownListinterVentionProvider.DataValueField = "SiteId";
                                        dropdownListinterVentionProvider.DataSource = dataViewProviders;
                                        dropdownListinterVentionProvider.DataBind();
                                        //dropdownListinterVentionProvider.Items.Insert(0, new ListItem(agencyName, "-1"));
                                        dropdownListinterVentionProvider.Items.Insert(0, new ListItem("", ""));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["ProviderId"] != DBNull.Value)
                                    {
                                        siteID = Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["ProviderId"]);
                                        dropdownListinterVentionProvider.SelectedValue = Convert.ToString(siteID);
                                    }
                                    else
                                    {
                                        siteID = -1;
                                    }
                                    dropdownListinterVentionProvider.Attributes.Add("onChange", "ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','ProviderId','" + dropdownListinterVentionProvider.ClientID + "','Edit','CarePlanPrescribedServiceId');");
                                    dropdownListinterVentionProvider.Attributes.Add("GoalNo", dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"].ToString());
                                    dropdownListinterVentionProvider.Attributes.Add("SiteId", siteID.ToString());
                                    dropdownListinterVentionProvider.Attributes.Add("BindAutoSaveEvents", "False");
                                    dropdownListinterVentionProvider.Attributes.Add("BindSetFormData", "False");

                                    PanelInterventionPlanMainAjax.Controls.Add(dropdownListinterVentionProvider);
                                    stringBuilderHTML = new StringBuilder();
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td align='center' class='form_label'>From Date</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>To Date</td>");
                                    stringBuilderHTML.Append("<td align='left' class='form_label'># Units</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>Frequency</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>Requested</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>Person Responsible</td>");


                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");
                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;' valign='top'></td>");
                                    stringBuilderHTML.Append("<td align='left' class='form_label'>Intervention</td>");
                                    stringBuilderHTML.Append("<td>");
                                    
                                    stringBuilderHTML.Append("<span id='Span_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + authorizationCodeId + "' name='Span_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + authorizationCodeId + "'>" + CreateServiceDropDownList(carePlanPrescribedServiceId, disableProcedureProvider, tpProcedureId, authorizationCodeId, siteID, "") + "</span>");
                                    stringBuilderHTML.Append("</td>");


                                    stringBuilderHTML.Append("<td valign='top' align='center'>");
                                    stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0'>");
                                    stringBuilderHTML.Append("<tr class='date_Container'>");
                                    stringBuilderHTML.Append("<td style='padding-left:3px;'>");

                                    if (dataViewTPInterventionProcedures[interventionCount]["FromDate"] == DBNull.Value)
                                    {
                                        dataViewTPInterventionProcedures[interventionCount]["FromDate"] = fromDate;
                                    }
                                    stringBuilderHTML.Append("<input type='text'  BindAutoSaveEvents ='False'  BindSetFormData='False' datatype='Date' value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["FromDate"]).ToString("MM/dd/yyyy") + "' name='Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "' id='Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "' class='form_textbox' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','FromDate','" + "Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "','Edit','CarePlanPrescribedServiceId');\" />");

                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td align='center'>");
                                    stringBuilderHTML.Append("&nbsp;<img id='Img_FromDate_" + carePlanPrescribedServiceId + "' name=Img_FromDate_" + carePlanPrescribedServiceId + "  src=" + RelativePath + "App_Themes/Includes/Images/calender_grey.gif  style='cursor:hand;' onclick=\"return showCalendar('Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "','%m/%d/%Y');\"/>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("</table>");
                                    stringBuilderHTML.Append("</td>");


                                    stringBuilderHTML.Append("<td valign='top' align='center'>");
                                    stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0'>");
                                    stringBuilderHTML.Append("<tr class='date_Container'>");
                                    stringBuilderHTML.Append("<td style='padding-left:3px;'>");
                                    if (dataViewTPInterventionProcedures[interventionCount]["ToDate"] != DBNull.Value)
                                    {
                                        stringBuilderHTML.Append("<input type='text' BindAutoSaveEvents ='False'  BindSetFormData='False' datatype='Date' value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["ToDate"]).ToString("MM/dd/yyyy") + "'   name='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "'  id='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "' class='form_textbox' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','ToDate','" + "Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input type='text' BindAutoSaveEvents ='False'  BindSetFormData='False' datatype='Date'  name='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "'  id='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "' class='form_textbox' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','ToDate','" + "Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td align='center'>");
                                    stringBuilderHTML.Append("&nbsp;<img id='Img_ToDate_" + carePlanPrescribedServiceId + "' name='Img_ToDate_" + carePlanPrescribedServiceId + "'  src=" + RelativePath + "App_Themes/Includes/Images/calender_grey.gif  style='cursor:hand;' onclick=\"return showCalendar('Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "','%m/%d/%Y');\"/>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("</table>");
                                    stringBuilderHTML.Append("</td>");


                                    stringBuilderHTML.Append("<td align='left' class='form_label' valign='top'>");
                                    if (dataViewTPInterventionProcedures[interventionCount]["Units"] == DBNull.Value)
                                    {
                                        stringBuilderHTML.Append("<input BindAutoSaveEvents ='False' class='dateTextBoxWidth form_textbox' style='width:30px;' datatype='Numeric' BindSetFormData='False' type='text' id='Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Units','" + "Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input BindAutoSaveEvents ='False' class='dateTextBoxWidth form_textbox' style='width:30px;' datatype='Numeric' BindSetFormData='False' type='text' id='Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "' value='" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Units"]) + "' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Units','" + "Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }

                                    stringBuilderHTML.Append("<span style='margin-left: 10px;'>per</span>");

                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td align='center' class='form_label' valign='top'>");
                                    PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));


                                    //Error Start
                                    dropdownListinterVentionFrequency = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionFrequency.Enabled = true;
                                    dropdownListinterVentionFrequency.Width = 100;
                                    dropdownListinterVentionFrequency.CssClass = "form_dropdown";
                                    dropdownListinterVentionFrequency.ID = "DropDownList_CustomCarePlanPrescribedServices_Frequency_" + carePlanPrescribedServiceId;
                                    using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPFREQUENCYTYPE", true, "", "SortOrder", false))
                                    {
                                        dropdownListinterVentionFrequency.DataTextField = "CodeName";
                                        dropdownListinterVentionFrequency.DataValueField = "GlobalCodeId";
                                        dropdownListinterVentionFrequency.DataSource = DataViewGlobalCodes;
                                        dropdownListinterVentionFrequency.DataBind();
                                        dropdownListinterVentionFrequency.Items.Insert(0, new ListItem("", ""));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["Frequency"] != DBNull.Value)
                                    {
                                        if (Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Frequency"]) != string.Empty)
                                        {
                                            dropdownListinterVentionFrequency.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Frequency"]);
                                        }
                                    }
                                    dropdownListinterVentionFrequency.Attributes.Add("onChange", "ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Frequency','" + dropdownListinterVentionFrequency.ClientID + "','Edit','CarePlanPrescribedServiceId');");
                                    dropdownListinterVentionFrequency.Attributes.Add("GoalNo", dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"].ToString());
                                    dropdownListinterVentionFrequency.Attributes.Add("SiteId", siteID.ToString());
                                    dropdownListinterVentionFrequency.Attributes.Add("BindAutoSaveEvents", "False");
                                    dropdownListinterVentionFrequency.Attributes.Add("BindSetFormData", "False");

                                    PanelInterventionPlanMainAjax.Controls.Add(dropdownListinterVentionFrequency);
                                    stringBuilderHTML = new StringBuilder();
                                    stringBuilderHTML.Append("</td>");


                                    stringBuilderHTML.Append("<td align='center' class='form_label' valign='top'>");
                                    stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False' class='dateTextBoxWidth form_textbox' style='width:30px;' datatype='Numeric' BindSetFormData='False' type='text' id='Text_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','TotalUnits','" + "Text_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td align='center' class='form_label' valign='top'>");


                                    PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));


                                    dropdownListinterVentionPersonResponsible = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionPersonResponsible.Enabled = true;
                                    dropdownListinterVentionPersonResponsible.Width = 100;
                                    dropdownListinterVentionPersonResponsible.CssClass = "form_dropdown";
                                    dropdownListinterVentionPersonResponsible.ID = "DropDownList_CustomCarePlanPrescribedServices_PersonResponsible_" + carePlanPrescribedServiceId;
                                    using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("PRESCRIBEDRESP", true, "", "SortOrder", false))
                                    {
                                        dropdownListinterVentionPersonResponsible.DataTextField = "CodeName";
                                        dropdownListinterVentionPersonResponsible.DataValueField = "GlobalCodeId";
                                        dropdownListinterVentionPersonResponsible.DataSource = DataViewGlobalCodes;
                                        dropdownListinterVentionPersonResponsible.DataBind();
                                        dropdownListinterVentionPersonResponsible.Items.Insert(0, new ListItem("", ""));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["PersonResponsible"] != DBNull.Value)
                                    {
                                        if (Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["PersonResponsible"]) != string.Empty)
                                        {
                                            dropdownListinterVentionPersonResponsible.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["PersonResponsible"]);
                                        }
                                    }
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("onChange", "ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','PersonResponsible','" + dropdownListinterVentionPersonResponsible.ClientID + "','Edit','CarePlanPrescribedServiceId');");
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("GoalNo", dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"].ToString());
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("SiteId", siteID.ToString());
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("BindAutoSaveEvents", "False");
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("BindSetFormData", "False");

                                    PanelInterventionPlanMainAjax.Controls.Add(dropdownListinterVentionPersonResponsible);
                                    stringBuilderHTML = new StringBuilder();
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td><span>1 Unit = </span>");
                                    stringBuilderHTML.Append("<span id='Label_UnitValue_" + carePlanPrescribedServiceId + "'>&nbsp;1</span>");
                                    stringBuilderHTML.Append("<span id='Label_UnitType_" + carePlanPrescribedServiceId + "'>&nbsp;Encounter</span></td>");
                                    stringBuilderHTML.Append("<td colspan='5'>&nbsp;</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr class='tr_CarePlanPrescribedService_" + carePlanPrescribedServiceId + "'>");

                                    stringBuilderHTML.Append("<td colspan='9'>");
                                    stringBuilderHTML.Append("<table style='width:99%;' border='0' cellpadding='0' cellspacing='3'>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td align='center' style='font-weight: bold'>");
                                    stringBuilderHTML.Append("<span class='form_label'>Requested</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td align='center' style='font-weight: bold'>");
                                    stringBuilderHTML.Append("<span class='form_label'>Previously Requested</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td align='center' style='font-weight: bold'>");
                                    stringBuilderHTML.Append("<span class='form_label'>Total</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td align='center' style='font-weight: bold'>");
                                    stringBuilderHTML.Append("<span class='form_label'>LCM Cap</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td align='center' style='font-weight: bold'>");
                                    stringBuilderHTML.Append("<span class='form_label'>CCM Cap</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td><span id='Span_UMCode_" + carePlanPrescribedServiceId + "'></span></td>");
                                    stringBuilderHTML.Append("<td><span id='Span_ServiceCategory_" + carePlanPrescribedServiceId + "'></span></td>");
                                    stringBuilderHTML.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                                    stringBuilderHTML.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>+</span></td>");
                                    stringBuilderHTML.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_PreviouslyRequested_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                                    stringBuilderHTML.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>=</span></td>");
                                    stringBuilderHTML.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalRequestedYTD_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                                    stringBuilderHTML.Append("<td align='center'><label id='Label_LCM_" + carePlanPrescribedServiceId + "' class='form_label'></label></td>");
                                    stringBuilderHTML.Append("<td align='center'><label id='Label_CCM_" + carePlanPrescribedServiceId + "' class='form_label'></label></td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("</table>");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td colspan='7'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td align='center'>");
                                    stringBuilderHTML.Append("<label style='visibility:hidden;color:red;' id='Label_LCM_Over_" + carePlanPrescribedServiceId + "'></label>");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td align='center'>");
                                    stringBuilderHTML.Append("<label style='visibility:hidden;color:red;' id='Label_CCM_Over_" + carePlanPrescribedServiceId + "'></label>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td colspan='9'>");
                                    stringBuilderHTML.Append("<span id='spnLCMAndCCMOver_" + carePlanPrescribedServiceId + "' style='color:red; display:none;'>Your current request equals or exceeds the amount allowed for auto approval.  Additional review will be needed to approve the authorization request.</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td colspan='2'>");
                                    stringBuilderHTML.Append("<span id='Span_" + carePlanPrescribedServiceId + "' class='span_textunderline_cursor' style='text-decoration: underline; color: blue;' onclick=\"OpenModelDialogueforEditViewObjectives(" + carePlanPrescribedServiceId + ",'')\" ");
                                    stringBuilderHTML.Append("tabindex='0' onfocus=\"this.style.fontWeight='bold'\" onblur=\"this.style.fontWeight='normal'\" onkeypress=\"if(event.keyCode==13){ OpenModelDialogueforEditViewObjectives(" + carePlanPrescribedServiceId + ",'')  }\">  ");
                                    stringBuilderHTML.Append("Link/Unlink Objectives</<span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td colspan='6'>");
                                    stringBuilderHTML.Append("<div id='Div_EditViewObjectives_" + carePlanPrescribedServiceId + "' class='form_textareaWithoutWidth' style='margin-left: 4px;width:580px;border:1px solid #ccc;background:#f2f2f2;padding:4px;'>");

                                    if (dataSetInterventionPlan.Tables.Contains("CustomCarePlanPrescribedServiceObjectives"))
                                    {
                                        if (SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServiceObjectives"], 0))
                                        {
                                            DataView dataRowPrescribedServiceObjectivesArray = new DataView(dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServiceObjectives"]);
                                            dataRowPrescribedServiceObjectivesArray.RowFilter = "CarePlanPrescribedServiceId=" + carePlanPrescribedServiceId + "AND ISNULL(RecordDeleted,'N')<>'Y'";
                                            dataRowPrescribedServiceObjectivesArray.Sort = "CarePlanPrescribedServiceId DESC";

                                            string htmlObjectiveSection = string.Empty;
                                            string objectiveDesc = string.Empty;
                                            string ObjectiveNum = string.Empty;

                                            for (int rowCounter = 0; rowCounter < dataRowPrescribedServiceObjectivesArray.Count; rowCounter++)
                                            {
                                                //EditViewObjectives objectEditViewObjectives = new EditViewObjectives();

                                                //objectiveDesc = Convert.ToString(dataRowPrescribedServiceObjectivesArray[rowCounter]["ObjectiveDescription"]);
                                                string objectiveId = Convert.ToString(dataRowPrescribedServiceObjectivesArray[rowCounter]["CarePlanObjectiveId"]);
                                                DataView dataViewCarePlanObjectives = new DataView(dataSetInterventionPlan.Tables["CarePlanObjectives"]);
                                                dataViewCarePlanObjectives.RowFilter = "CarePlanObjectiveId=" + objectiveId + "AND ISNULL(RecordDeleted,'N')<>'Y'";
                                                if (dataViewCarePlanObjectives.Count > 0)
                                                {
                                                    ObjectiveNum = Convert.ToString(dataViewCarePlanObjectives[0]["ObjectiveNumber"]);

                                                    if (rowCounter == dataRowPrescribedServiceObjectivesArray.Count - 1)
                                                    {
                                                        htmlObjectiveSection = ObjectiveNum;
                                                    }
                                                    else
                                                    {
                                                        htmlObjectiveSection = ObjectiveNum + ",";
                                                    }

                                                    htmlObjectiveSection = HttpUtility.HtmlDecode(htmlObjectiveSection);
                                                }
                                            }
                                            stringBuilderHTML.Append(htmlObjectiveSection);
                                        }
                                    }

                                    stringBuilderHTML.Append("</div>");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td colspan='8'>");
                                    stringBuilderHTML.Append("<textarea spellcheck='True' bindautosaveevents='False' data-preventexpand='1' id='TextArea_CarePlanPrescribedServices_Detail_" + carePlanPrescribedServiceId + "' name='TextArea_CarePlanPrescribedServices_Detail_" + carePlanPrescribedServiceId + "' ");
                                    stringBuilderHTML.Append("onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Detail','" + "TextArea_CarePlanPrescribedServices_Detail_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\"  ");
                                    //stringBuilderHTML.Append("value='" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Detail"]) + "'");
                                    stringBuilderHTML.Append("rows='4' cols='114' style='width: 99%' class='form_textareaWithoutWidth'></textarea> ");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");

                                }
                            }
                            stringBuilderHTML.Append("</table>");

                            stringBuilderHTML.Append("</td>");//1st Row 3rd Col Close Tag
                            stringBuilderHTML.Append("</tr>");


                            PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            finally
            {
                dataRowInterventionPlan = null;
                dataRowTPInterventionPObjective = null;
            }
        }

        /// <summary>
        /// <Description>Method is used to calculate unit on the selection</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>09 Oct,2009</CreatedOn>
        /// </summary>
        private string DisplayUnitType(DropDownList dropdownlistFrequency)
        {
            string selectedValue = string.Empty;
            string strCodeName = string.Empty;
            string[] parameterCollection = null;
            DataSet dataSetAuthorization = null;
            DataSet dataSetTemp = null;
            DataView dataViewAuthorization = null;
            DataRow[] dataRowAuthorizationCodeName = null;
            DataRow[] dataRowGlobalCodes = null;
            Int32 unitTypeValue = 0;
            Int32 units = 0;
            string unitCounterText = string.Empty;
            try
            {
                // selectedValue = Request.Form["selectedValue"];
                char[] cSpilt = new char[1];
                cSpilt[0] = ',';
                if (Request.Form["UnitCount"] != null)
                {
                    parameterCollection = Request.Form["UnitCount"].Split(cSpilt);
                }
                dataRowAuthorizationCodeName = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("Active='Y'", "AuthorizationCodeName");
                dataSetAuthorization = new DataSet();
                dataSetAuthorization.EnforceConstraints = false;//Need to Check Anuj forcefully  enforced constraints false.
                dataSetAuthorization.Merge(dataRowAuthorizationCodeName);

                dataViewAuthorization = new DataView(dataSetAuthorization.Tables[0]);

                dataViewAuthorization.RowFilter = "AuthorizationCodeId=" + Convert.ToInt32(dropdownlistFrequency.SelectedValue);
                if (dataViewAuthorization.Count > 0 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != -1 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != 0)
                {
                    if (dataViewAuthorization[0]["UnitType"] != null && dataViewAuthorization[0]["UnitType"] != System.DBNull.Value)
                        unitTypeValue = Convert.ToInt32(dataViewAuthorization[0]["UnitType"]);
                    if (dataViewAuthorization[0]["Units"] != null && dataViewAuthorization[0]["Units"] != System.DBNull.Value)
                        units = Convert.ToInt32(dataViewAuthorization[0]["Units"]);

                }

                dataRowGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitTypeValue);

                dataSetTemp = new DataSet();

                if (dataRowGlobalCodes.Length > 0)
                {
                    dataSetTemp.Merge(dataRowGlobalCodes);

                    if (unitTypeValue == 120 || unitTypeValue == 110)
                    {
                        // modified by Piyush on 6th March 2007 as per comment on "3/2/2007 8:08:07 AM " on task 390
                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 6);
                        if (units != 1)
                            unitCounterText = "(1 Unit = " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit = " + units + " " + strCodeName + ")";
                    }
                    else if (unitTypeValue == 124)
                    {

                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 9);
                        if (units != 1)
                            unitCounterText = "(1 Unit =  " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit =  " + units + " " + strCodeName + ")";
                    }
                    else
                    {
                        unitCounterText = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    }
                }

                return unitCounterText;
            }

            finally
            {

                selectedValue = string.Empty;
                strCodeName = string.Empty;
                parameterCollection = null;
                dataSetAuthorization = null;
                dataSetTemp = null;
                dataViewAuthorization = null;
                dataRowAuthorizationCodeName = null;
                dataRowGlobalCodes = null;

            }
        }

        /// <Description>Method is used to Create Service Dropdownlist for 'CreateIntervention' section of TxPlan</Description>
        /// <Author>Shifali</Author>
        /// <Purpose>Added by shifali on 29 sept,2010 in ref to task# 4 of UM - Part two</Purpose>
        /// <ModifiedBy> Rakesh Garg </ModifiedBy>
        /// <ModifiedDate> 23 Nove 2010 </ModifiedDate>
        /// </summary>
        /// <returns></returns>
        private StringBuilder CreateServiceDropDownList(string carePlanPrescribedServiceIdValue, bool disableProcedureProvider, string tpProcedureId, string authorizationCodeId, int siteID, string InitializedFromPreviousPlan)
        {
            StringBuilder strHtml = new StringBuilder();
            DataSet _dsAuthorizationCodes = null;

            if (_dsAuthorizationCodes == null)
            {
                SHS.UserBusinessServices.TreatmentPlan objectTreatmentPlan = new SHS.UserBusinessServices.TreatmentPlan();
                try
                {
                    _dsAuthorizationCodes = GetAuthorizationCodeTxPlanMain(siteID);
                    _interactionAuthorizationCodes.Add(new InteractionAuthorizationCodes() { dsAuthorizationCodes = _dsAuthorizationCodes, siteid = siteID });
                }
                catch (Exception ex)
                {

                }
            }
            if (_dsAuthorizationCodes.Tables.Count > 0 && _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Rows.Count > 0)
            {
                //if (disableProcedureProvider == false)
                //{
                //    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' goalNo='" + CarePlanPrescribedServiceIdVal + "' TPProcedureId='" + tpProcedureId + "' SiteId='" + siteID + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                //else
                //{
                    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;'  goalNo='" + CarePlanPrescribedServiceIdVal + "' TPProcedureId='" + tpProcedureId + "' SiteId='" + siteID + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}

                //For Filling Core Services
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                DataRow[] drCoreServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Core Services'", "DisplayAs asc");
                for (int loopCounter = 0; loopCounter < drCoreServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {   //By Vikas Vyas in ref. to task #679
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option selected='selected' title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }


                //For Filling Speciality Services
                strHtml.Append("</optgroup>");

                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");

                DataRow[] drSpecialityServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Speciality Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drSpecialityServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }

                //For Filling Other Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");

                DataRow[] drOtherServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Other Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drOtherServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }
                strHtml.Append("</optgroup>");

                strHtml.Append("</select>");
                return strHtml;
            }
            else
            {
                //if (disableProcedureProvider == false)
                //{
                //    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                //else
                //{
                    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                //For Filling Speciality Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("</select>");
            }

            return strHtml;


        }

        public DataSet GetAuthorizationCodeTxPlanMain(int SiteID)
        {
            DataSet dataSetAuthorizationCodeTxPlanMain = null;
            try
            {
                DataSet dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                if (dsCurrentScreen == null)
                    dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

                int ClientId = 0;
                int DocumentVersionId = 0;
                if (dsCurrentScreen.IsDataTableFound("Documents"))
                {
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                }
                if (ClientId <= 0)
                    ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                dataSetAuthorizationCodeTxPlanMain = new DataSet();
                System.Data.SqlClient.SqlParameter[] _objectSqlParmeters = new System.Data.SqlClient.SqlParameter[3];
                _objectSqlParmeters[0] = new System.Data.SqlClient.SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new System.Data.SqlClient.SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[2] = new System.Data.SqlClient.SqlParameter("@SiteID", SiteID);
                Microsoft.ApplicationBlocks.Data.SqlHelper.FillDataset(SHS.DataServices.Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCGetTPServiceUMAuthorization", dataSetAuthorizationCodeTxPlanMain, new string[] { "TPServiceAuthorizationCodes" }, _objectSqlParmeters);

            }
            catch
            {

            }
            return dataSetAuthorizationCodeTxPlanMain;
        }

        /// <summary>
        /// <Description>Delete Row from TPInterventionProcedures</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>18th-Sept-2009</CreatedOn>
        /// </summary>
        private void DeleteIntervention()
        {
            DataRow[] dataRowIntervention = null;
            //DataRow[] drTPInterventionProcedure = null;
            int carePlanPrescribedServiceId = 0;
            //double interventionNumber = 0.0;
            //int needId = 0;
            //double maxObjectiveNumber = 0.0;
            DataSet dataSetCarePlan = null;
            try
            {
                carePlanPrescribedServiceId = Convert.ToInt32(Request.QueryString["carePlanPrescribedServiceId"]);
                using (dataSetCarePlan = BaseCommonFunctions.GetScreenInfoDataSet())
                {
                    if (dataSetCarePlan != null && dataSetCarePlan.Tables.Count > 0)
                    {
                        if (dataSetCarePlan.Tables.Contains("CustomCarePlanPrescribedServices") && dataSetCarePlan.Tables["CustomCarePlanPrescribedServices"].Rows.Count > 0)
                        {
                            dataRowIntervention = dataSetCarePlan.Tables["CustomCarePlanPrescribedServices"].Select("Isnull(RecordDeleted,'N')<>'Y' and CarePlanPrescribedServiceId=" + carePlanPrescribedServiceId);
                            if (dataRowIntervention.Length > 0)
                            {
                                dataRowIntervention[0].BeginEdit();
                                dataRowIntervention[0]["RecordDeleted"] = 'Y';
                                dataRowIntervention[0]["DeletedDate"] = System.DateTime.Now;
                                dataRowIntervention[0]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                                dataRowIntervention[0].EndEdit();
                                //needId = Convert.ToInt32(dataRowTPInterventionProcedures[0]["NeedId"]);
                                ////Get Current Row Intervention number
                                //interventionNumber = Convert.ToDouble(dataRowTPInterventionProcedures[0]["InterventionNumber"]);
                                //maxObjectiveNumber = Convert.ToInt32(interventionNumber.ToString().Substring(0, interventionNumber.ToString().IndexOf(".")));
                                //maxObjectiveNumber += .01;
                                //drTPInterventionProcedure = dataSetCarePlan.Tables["TPInterventionProcedures"].Select("ISNULL(RecordDeleted,'N')<>'Y' and InterventionNumber >" + interventionNumber.ToString() + " and NeedID=" + Convert.ToInt32(dataRowTPInterventionProcedures[0]["NeedId"]));
                                //if (drTPInterventionProcedure.Length > 0)
                                //{
                                //    for (int interventionCount = 0; interventionCount < drTPInterventionProcedure.Length; interventionCount++)
                                //    {
                                //        drTPInterventionProcedure[interventionCount]["InterventionNumber"] = Convert.ToDouble(drTPInterventionProcedure[interventionCount]["InterventionNumber"]) - Convert.ToDouble(".01");
                                //    }
                                //}


                                //CreateGoal();
                                //PlaceHolderControlAssociatedNeeds.Controls.Add(PanelTxPlanMain);
                            }
                        }
                    }
                }
                //dataSetCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();
                //PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl("###STARTPAGERESPONSESINGLEINTERVENTION###"));
                ////ReDrawIntervention(needId, 0, dataSetTreatmentPlanHRM);
                //PanelInterventionPlanMainAjax.Controls.Add(new LiteralControl("###ENDPAGERESPONSESINGLEINTERVENTION###"));
            }
            finally
            {
                dataRowIntervention = null;
                //drTPInterventionProcedure = null;
            }
        }

        /// <summary>
        /// This is used for bind Add Intervention Authorization Dropdown based on the criteria selected from above TP Procedure Dropdown
        /// </summary>
        /// <param name="SiteID"></param>
        private void CreateServiceDropDownList(int SiteID, int carePlanPrescribedServiceId, string tpProcedureID, string authorizationID, bool disableProcedureProvider)
        {
            string InitializedFromPreviousPlan = "";
            if (tpProcedureID == "")
            {
                DataSet datasetCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();

                if (datasetCarePlan != null && datasetCarePlan.Tables.Count > 0 && datasetCarePlan.Tables["CustomCarePlanPrescribedServices"].Rows.Count > 0)
                {
                    DataRow[] drTPInterventionProcedure = datasetCarePlan.Tables["CustomCarePlanPrescribedServices"].Select("CarePlanPrescribedServiceId=" + carePlanPrescribedServiceId);
                    if (drTPInterventionProcedure.Length > 0)
                    {
                        drTPInterventionProcedure[0].BeginEdit();
                        drTPInterventionProcedure[0]["AuthorizationCodeId"] = DBNull.Value;
                        drTPInterventionProcedure[0].EndEdit();
                        //InitializedFromPreviousPlan = drTPInterventionProcedure[0]["InitializedFromPreviousPlan"].ToString();
                    }
                }

                disableProcedureProvider = true;
            }
            else
            {
                disableProcedureProvider = false;
            }

            StringBuilder str = CreateServiceDropDownList(carePlanPrescribedServiceId, disableProcedureProvider, tpProcedureID, authorizationID, SiteID, InitializedFromPreviousPlan);

            Response.Clear();
            Response.Write(str.ToString());
            Response.End();

        }

        /// <summary>
        /// <Description>Method is used to Create Service Dropdownlist for 'CreateIntervention' section of TxPlan</Description>
        /// <Author>Shifali</Author>
        /// <Purpose>Added by shifali on 29 sept,2010 in ref to task# 4 of UM - Part two</Purpose>
        /// <ModifiedBy> Rakesh Garg </ModifiedBy>
        /// <ModifiedDate> 23 Nove 2010 </ModifiedDate>
        /// </summary>
        /// <returns></returns>
        private StringBuilder CreateServiceDropDownList(int carePlanPrescribedServiceIdValue, bool disableProcedureProvider, string tpProcedureId, string authorizationCodeId, int siteID, string InitializedFromPreviousPlan)
        {
            //Will do on monday
            StringBuilder strHtml = new StringBuilder();
            DataSet _dsAuthorizationCodes = null;

            if (_dsAuthorizationCodes == null)
            {
                SHS.UserBusinessServices.TreatmentPlan objectTreatmentPlan = new SHS.UserBusinessServices.TreatmentPlan();
                try
                {
                    _dsAuthorizationCodes = GetAuthorizationCodeTxPlanMain(siteID);
                    _interactionAuthorizationCodes.Add(new InteractionAuthorizationCodes() { dsAuthorizationCodes = _dsAuthorizationCodes, siteid = siteID });
                }
                catch (Exception ex)
                {

                }
            }
            if (_dsAuthorizationCodes != null && _dsAuthorizationCodes.Tables.Count > 0 && _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Rows.Count > 0)
            {
                //if (disableProcedureProvider == false)
                //{
                //    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' goalNo='" + CarePlanPrescribedServiceIdVal + "' TPProcedureId='" + tpProcedureId + "' SiteId='" + siteID.ToString() + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                //else
                //{
                strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;'  goalNo='" + CarePlanPrescribedServiceIdVal + "' TPProcedureId='" + tpProcedureId + "'  SiteId='" + siteID.ToString() + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}

                //For Filling Core Services
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                DataRow[] drCoreServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Core Services'", "DisplayAs asc");
                for (int loopCounter = 0; loopCounter < drCoreServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {   //By Vikas Vyas in ref. to task #679
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                // if (disableProcedureProvider)
                                //  {
                                //       strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //  }
                                //   else
                                //  {
                                strHtml.Append("<option selected='selected' title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //  }
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                //if (disableProcedureProvider)
                                //{
                                //    strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                                //else
                                //{
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }


                //For Filling Speciality Services
                strHtml.Append("</optgroup>");

                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");

                DataRow[] drSpecialityServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Speciality Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drSpecialityServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                //if (disableProcedureProvider)
                                //{
                                //    strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                                //else
                                //{
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                //if (disableProcedureProvider)
                                //{
                                //    strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                                //else
                                //{
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }

                //For Filling Other Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");

                DataRow[] drOtherServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Other Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drOtherServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                //if (disableProcedureProvider)
                                //{
                                //    strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                                //else
                                //{
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}

                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                //if (disableProcedureProvider)
                                //{
                                //    strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                                //else
                                //{
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                                //}
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }
                strHtml.Append("</optgroup>");
                strHtml.Append("</select>");
                return strHtml;
            }
            else
            {
                //if (disableProcedureProvider == false)
                //{
                //    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                //else
                //{
                strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                //For Filling Speciality Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("</select>");
            }
            return strHtml;

        }

        /// <summary>
        /// New Unit Calulation method by shifali in ref to task# 16 of UM Part One
        /// </summary>
        private void UnitCalculation()
        {
            DateTime startDate;
            DateTime endDate;
            TimeSpan days;
            int unitDays = 0;
            double unitMonths = 0;
            double unitWeeks = 0;
            double unitQuarter = 0;
            double unitYear = 0;
            string carePlanPrescribedServiceIdVal = string.Empty;

            int frequencyType = 0;
            string procedureUnits = string.Empty;
            string totalUnitRequested = string.Empty;
            try
            {
                frequencyType = Convert.ToInt32(Request.Form["frequencyType"]);
                procedureUnits = Request.Form["procedureUnits"];
                startDate = Convert.ToDateTime(Request.Form["startDate"]);
                endDate = Convert.ToDateTime(Request.Form["endDate"]);
                days = (endDate - startDate);
                unitDays = Convert.ToInt32(days.TotalDays + 1);
                unitWeeks = Convert.ToInt32(Math.Round(Convert.ToDouble(unitDays) / 7, MidpointRounding.AwayFromZero));
                carePlanPrescribedServiceIdVal = Request.Form["careplanprescribedserviceid"];

                //unitDays = Convert.ToInt32(days.TotalDays) + 1;
                //unitWeeks = System.Math.Ceiling(Convert.ToDouble(unitDays) / 7);
                //unitYear = (endDate.Year - startDate.Year) + 1;

                //Modified w.r.f task#85
                //unitYear = endDate.Year - startDate.Year;
                unitYear = Convert.ToInt32(Math.Round(Convert.ToDouble(unitDays) / 365, MidpointRounding.AwayFromZero));
                unitMonths = Convert.ToInt32(Math.Round(Convert.ToDouble(unitDays) / 30, MidpointRounding.AwayFromZero));
                unitQuarter = Convert.ToInt32(Math.Round(Convert.ToDouble(unitMonths) / 3, MidpointRounding.AwayFromZero));
                /*
                if (unitYear > 1)
                {
                    unitMonths = System.Math.Ceiling(((12 - startDate.Month) + endDate.Month + 1) * (unitYear - 1));
                }
                else
                {
                    unitMonths = (endDate.Month - startDate.Month) + 1;
                }
                 */
                //unitQuarter = System.Math.Ceiling(Convert.ToDouble(unitMonths) / 3);
                if (unitDays != 0)
                {
                    if (frequencyType == 160 && procedureUnits != string.Empty) //for daily
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitDays).ToString();
                    }
                    else if (frequencyType == 161 && procedureUnits != string.Empty) //for 2 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 2)).ToString();
                        // totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 162 && procedureUnits != string.Empty) //for 3 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 3)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 3.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 163 && procedureUnits != string.Empty) //for 4 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 4)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 4.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 164 && procedureUnits != string.Empty) //for 5 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 5)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 5.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 165 && procedureUnits != string.Empty) //for 5 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 6)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 6.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 166 && procedureUnits != string.Empty) //for weekly
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)))).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 167 && procedureUnits != string.Empty) //for every two weeks
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) / 2)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 14.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 168 && procedureUnits != string.Empty) //for monthly
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitMonths * Convert.ToDouble(procedureUnits)))).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 30.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 169 && procedureUnits != string.Empty) //for twice a month
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitMonths * Convert.ToDouble(procedureUnits)) * 2)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 170 && procedureUnits != string.Empty) //for every four weeks
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitWeeks / 4).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 28.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 171 && procedureUnits != string.Empty) //for quarterly
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitQuarter).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 90.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 172 && procedureUnits != string.Empty) //for  twice a quarterly
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitQuarter * 2).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 90.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 173 && procedureUnits != string.Empty) //for  every two month
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitMonths * Convert.ToDouble(procedureUnits)) / 2)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 60.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 174 && procedureUnits != string.Empty) //for  twice a year
                    {
                        //totalUnitRequested = System.Math.Ceiling(((unitYear * Convert.ToDouble(procedureUnits)) * 2)).ToString();
                        //----Modified By:Ashwani K. Angrish on 8 Dec ref#781 on StreamLine Testing
                        //totalUnitRequested = (System.Math.Ceiling(2 * Convert.ToDouble(procedureUnits)) * ((Convert.ToInt32(days.TotalDays) / 365) + 1)).ToString();
                        // Below  2 *  to calulate  units properly twice a year added by Rakesh w.rf. to task 405 in SC web phaseII bugs/Features Tx Plan: Twice Yearly Calculation not working
                        totalUnitRequested = (System.Math.Ceiling(2 * Convert.ToDouble(procedureUnits)) * unitYear).ToString();
                    }
                    else if (frequencyType == 175 && procedureUnits != string.Empty) //for  once a year
                    {
                        //totalUnitRequested = System.Math.Ceiling(((unitYear * Convert.ToDouble(procedureUnits)))).ToString();
                        //----Modified By:Ashwani K. Angrish on 8 Dec ref#781 on StreamLine Testing
                        //totalUnitRequested = (System.Math.Ceiling(1 * Convert.ToDouble(procedureUnits)) * ((Convert.ToInt32(days.TotalDays) / 365) + 1)).ToString();
                        totalUnitRequested = (System.Math.Ceiling(1 * Convert.ToDouble(procedureUnits)) * unitYear).ToString();
                    }
                    else if (frequencyType == 176 && procedureUnits != string.Empty) //for only  once
                    {
                        totalUnitRequested = procedureUnits;
                    }
                    else if (frequencyType == 177 && procedureUnits != string.Empty)// for Every 3 weeks
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitWeeks / 3).ToString();
                    }

                    try
                    {
                        DataRow[] dataRowCarePlan = null;
                        using (DataSet dataSetCarePlan = BaseCommonFunctions.GetScreenInfoDataSet())
                        {
                            if (dataSetCarePlan != null && dataSetCarePlan.Tables.Count > 0)
                            {
                                if (dataSetCarePlan.Tables.Contains("CustomCarePlanPrescribedServices"))
                                {
                                    if (dataSetCarePlan.Tables["CustomCarePlanPrescribedServices"].Rows.Count > 0)  //Perform Row Count Check
                                    {
                                        if (!string.IsNullOrEmpty(carePlanPrescribedServiceIdVal))  //Perform Row Count Check
                                        {
                                            dataRowCarePlan = dataSetCarePlan.Tables["CustomCarePlanPrescribedServices"].Select("CarePlanPrescribedServiceId='" + carePlanPrescribedServiceIdVal + "'");
                                            if (dataRowCarePlan.Length > 0)
                                            {
                                                dataRowCarePlan[0].BeginEdit();
                                                if (!totalUnitRequested.IsNullOrEmpty())
                                                {
                                                    dataRowCarePlan[0]["TotalUnits"] = totalUnitRequested;
                                                }
                                                else
                                                {
                                                    dataRowCarePlan[0]["TotalUnits"] = DBNull.Value;
                                                }

                                                dataRowCarePlan[0].EndEdit();

                                                BaseCommonFunctions.GetScreenInfoDataSet().Merge(dataSetCarePlan);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                    }

                    Response.Clear();
                    Response.Write(totalUnitRequested);
                    try { Response.End(); }
                    catch (System.Threading.ThreadAbortException) { }
                }
            }
            finally
            {

            }
        }

        private void FillRequestLcmCcmLabels()
        {
            string carePlanPrescribedServiceId = Request.Form["carePlanPrescribedServiceId"];
            string authorizationCodeId = Request.Form["authorizationcodeid"];
            string providerId = Request.Form["providerid"];
            string totalUnits = Request.Form["totalunits"];
            int totalUnitsVal = 0;

            if (!string.IsNullOrEmpty(totalUnits))
                totalUnitsVal = Convert.ToInt32(Math.Floor(Convert.ToDecimal(totalUnits)));

            RequestLcmCcmLabels objRequestLcmCcmLabels = new RequestLcmCcmLabels();
            objRequestLcmCcmLabels.TotalUnits = Convert.ToString(totalUnitsVal);
            objRequestLcmCcmLabels.TotalRequestedYTD = Convert.ToString(totalUnitsVal);
            if (!string.IsNullOrEmpty(authorizationCodeId))
            {
                SHS.UserBusinessServices.TreatmentPlan objectTreatmentPlan = null;
                objectTreatmentPlan = new SHS.UserBusinessServices.TreatmentPlan();
                try
                {
                    DataRow[] drAuthCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("ISNULL(RecordDeleted,'N')<>'Y' and AuthorizationCodeId=" + authorizationCodeId);
                    int UMCodeId = 0;
                    DataSet dataSetLCMAndCCM = GetLCMAndCCM(Convert.ToInt32(authorizationCodeId));
                    if (dataSetLCMAndCCM != null)
                    {
                        if (dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows.Count > 0)
                        {
                            int.TryParse(Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["UMCodeId"]), out UMCodeId);
                            objRequestLcmCcmLabels.UMCode = BaseCommonFunctions.TrancateElementText(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CodeName"].ToString(), 20);
                            objRequestLcmCcmLabels.ServiceCategory = BaseCommonFunctions.TrancateElementText(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["ServiceCategoryName"].ToString(), 20);
                            objRequestLcmCcmLabels.LCMLabel = Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["LCM12MonthMax"]);
                            objRequestLcmCcmLabels.CCMLabel = Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CCM12MonthMax"]);
                        }
                    }
                    CalculatePreviousRequestedAjax(Convert.ToInt32((providerId == "" ? "0" : providerId)), Convert.ToInt32(authorizationCodeId), UMCodeId, carePlanPrescribedServiceId, totalUnitsVal, ref objRequestLcmCcmLabels);
                    GetUnitTypeAndValueAjax(authorizationCodeId, ref objRequestLcmCcmLabels);
                }
                finally
                {
                    objectTreatmentPlan = null;
                }
            }
            JavaScriptSerializer = new JavaScriptSerializer();
            Response.Clear();
            Response.Write(JavaScriptSerializer.Serialize(objRequestLcmCcmLabels));
            try { Response.End(); }
            catch (System.Threading.ThreadAbortException) { }

        }

        private void CalculatePreviousRequestedAjax(int siteId, int authorizationCodeId, int UMCodeId, string carePlanPrescribedServiceId, int totalUnitsValue, ref RequestLcmCcmLabels objRequestLcmCcmLabels)
        {
            StringBuilder stringBuilderHTMLPrevReq = null;
            stringBuilderHTMLPrevReq = new StringBuilder();
            try
            {
                using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
                {
                    int sumPrev = 0;

                    DataRow[] drTPInterventions = null;
                    if (siteId != -1)
                    {
                        drTPInterventions = dataSetTreatmentPlanHRM.Tables["CustomCarePlanPrescribedServices"].Select("AuthorizationCodeId=" + authorizationCodeId + " and  ProviderId=" + siteId + " and CarePlanPrescribedServiceId <> " + carePlanPrescribedServiceId);
                    }
                    else
                    {
                        drTPInterventions = dataSetTreatmentPlanHRM.Tables["CustomCarePlanPrescribedServices"].Select("AuthorizationCodeId=" + authorizationCodeId + " and  ((ProviderId is null or ProviderId = -1) or (ProviderId=" + siteId + ")) and CarePlanPrescribedServiceId <> " + carePlanPrescribedServiceId);
                    }
                    if (drTPInterventions.Length > 0)
                    {
                        foreach (DataRow drTPInt in drTPInterventions)
                        {
                            int totalSumInterven = 0;
                            int.TryParse(Convert.ToInt32(drTPInt["TotalUnits"] == DBNull.Value ? 0 : drTPInt["TotalUnits"]).ToString(), out totalSumInterven);
                            sumPrev += totalSumInterven;
                        }
                    }
                    if (BaseCommonFunctions.CheckRowExists(dataSetTreatmentPlanHRM, "PreviouslyRequested"))
                    {
                        DataRow[] dr = dataSetTreatmentPlanHRM.Tables["PreviouslyRequested"].Select("UMCodeId=" + UMCodeId);
                        if (dr.Length > 0)
                        {
                            sumPrev += Convert.ToInt32(dr[0]["TotalRequested"]);
                        }
                    }
                    if (sumPrev > 0)
                    {
                        objRequestLcmCcmLabels.PreviouslyRequested = Convert.ToString(sumPrev);
                        objRequestLcmCcmLabels.TotalRequestedYTD = Convert.ToString(totalUnitsValue + sumPrev);
                    }
                }
            }
            catch (Exception Ex)
            {
            }
        }

        public DataSet GetLCMAndCCM(int AuthorizationCodeId)
        {
            DataSet DataSetLCMAndCCM = null;
            SqlParameter[] _objectSqlParmeters = new SqlParameter[2];
            try
            {
                DataSet dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                if (dsCurrentScreen == null)
                    dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

                int ClientId = 0;
                int DocumentVersionId = 0;
                if (dsCurrentScreen.IsDataTableFound("Documents"))
                {
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                }
                if (ClientId <= 0)
                    ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                DataSetLCMAndCCM = new DataSet();
                _objectSqlParmeters = new SqlParameter[3];
                _objectSqlParmeters[0] = new SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[2] = new SqlParameter("@AuthorizationCodeId", AuthorizationCodeId);
                SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCWebGetLCMAndCCM", DataSetLCMAndCCM, new string[] { "LCMAndCCM" }, _objectSqlParmeters);
                return DataSetLCMAndCCM;
            }
            finally
            {
                if (DataSetLCMAndCCM != null)
                    DataSetLCMAndCCM.Dispose();
                _objectSqlParmeters = null;
            }

        }

        private void GetUnitTypeAndValueAjax(string AuthorizationCodeId, ref RequestLcmCcmLabels objRequestLcmCcmLabelsAjax)
        {
            StringBuilder stringBuilderHTMLUnit = null;
            stringBuilderHTMLUnit = new StringBuilder();
            decimal units = 0;
            int unitType = 0;
            try
            {
                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes != null && SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Rows.Count > 0)
                {
                    DataRow[] drAuthorizationCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("AuthorizationCodeId=" + AuthorizationCodeId);
                    if (drAuthorizationCode.Length > 0)
                    {
                        int.TryParse(Convert.ToString(drAuthorizationCode[0]["UnitType"]), out unitType);
                        decimal.TryParse(Convert.ToString(drAuthorizationCode[0]["Units"]), out units);
                        objRequestLcmCcmLabelsAjax.UnitValue = Convert.ToString(Math.Floor(Convert.ToDecimal(units)));
                        DataRow[] drGlobalCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitType);
                        if (drGlobalCode.Length > 0)
                            objRequestLcmCcmLabelsAjax.UnitType = Convert.ToString(drGlobalCode[0]["CodeName"]);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }


    }


    public class InteractionAuthorizationCodes
    {
        public int siteid { get; set; }
        public DataSet dsAuthorizationCodes { get; set; }
    }

    public class RequestLcmCcmLabels
    {
        public string UMCode { get; set; }
        public string ServiceCategory { get; set; }
        public string TotalUnits { get; set; }
        public string PreviouslyRequested { get; set; }
        public string TotalRequestedYTD { get; set; }
        public string LCMLabel { get; set; }
        public string CCMLabel { get; set; }
        public string UnitValue { get; set; }
        public string UnitType { get; set; }
    }

}