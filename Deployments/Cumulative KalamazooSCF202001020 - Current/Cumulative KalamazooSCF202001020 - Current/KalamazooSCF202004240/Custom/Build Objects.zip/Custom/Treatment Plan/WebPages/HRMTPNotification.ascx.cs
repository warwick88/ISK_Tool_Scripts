﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using SHS.BaseLayer;

namespace SHS.SmartCare
{
    public partial class ActivityPages_Client_Detail_TreatmentPlanHRM_HRMTPNotification : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        #region--User Defined Functions--
        /// <summary>
        /// <Description>This is overridable function inherited from base layer's
        /// DocumentDataActivityPage and is used to bind dropdown controll</Description>
        /// <Author>Anuj</Author>
        /// <CreatedOn>Aug 28,2009</CreatedOn>
        /// </summary>
        public override void BindControls()
        {
            //For binding of Staff dropdown which contains all those active staff where clinician='Y'
            if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff != null)
            {
                //DataView dataViewStaff = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff);
                DataView dataViewStaff = SHS.BaseLayer.SharedTables.GetSharedTableStaff();
                dataViewStaff.RowFilter = "Clinician='Y' and Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                DropDownList_TPGeneral_StaffId1.DataTextField = "StaffName";
                DropDownList_TPGeneral_StaffId1.DataValueField = "StaffId";
                DropDownList_TPGeneral_StaffId1.DataSource = dataViewStaff;
                DropDownList_TPGeneral_StaffId1.DataBind();
                DropDownList_TPGeneral_StaffId1.Items.Insert(0, new ListItem("", string.Empty));

                DropDownList_TPGeneral_StaffId2.DataTextField = "StaffName";
                DropDownList_TPGeneral_StaffId2.DataValueField = "StaffId";
                DropDownList_TPGeneral_StaffId2.DataSource = dataViewStaff;
                DropDownList_TPGeneral_StaffId2.DataBind();
                DropDownList_TPGeneral_StaffId2.Items.Insert(0, new ListItem("", string.Empty));

                DropDownList_TPGeneral_StaffId3.DataTextField = "StaffName";
                DropDownList_TPGeneral_StaffId3.DataValueField = "StaffId";
                DropDownList_TPGeneral_StaffId3.DataSource = dataViewStaff;
                DropDownList_TPGeneral_StaffId3.DataBind();
                DropDownList_TPGeneral_StaffId3.Items.Insert(0, new ListItem("", string.Empty));

                DropDownList_TPGeneral_StaffId4.DataTextField = "StaffName";
                DropDownList_TPGeneral_StaffId4.DataValueField = "StaffId";
                DropDownList_TPGeneral_StaffId4.DataSource = dataViewStaff;
                DropDownList_TPGeneral_StaffId4.DataBind();
                DropDownList_TPGeneral_StaffId4.Items.Insert(0, new ListItem("", string.Empty));
            }
        }
        #endregion
        public override string[] TablesUsedInTab
        {
            get
            {
                return new string[] { "TPGeneral" };
            }

        }
    }
}