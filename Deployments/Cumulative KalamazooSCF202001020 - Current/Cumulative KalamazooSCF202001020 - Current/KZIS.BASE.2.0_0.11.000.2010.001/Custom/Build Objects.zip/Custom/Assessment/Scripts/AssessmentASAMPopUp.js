﻿function SetScreenSpecificValues(dom, action) {
    try{
        //Below code is added for Disabled Save button if Document is signed
        if (parent.AutoSaveXMLDom != undefined && parent.AutoSaveXMLDom[0].xml != "") {
            var getDocumentStatus = GetFielValueFromXMLDom(parent.AutoSaveXMLDom[0], "Documents", "Status");
            var getDocumentCurrentStatus = GetFielValueFromXMLDom(parent.AutoSaveXMLDom[0], "Documents", "CurrentVersionStatus");
            if (getDocumentStatus == "22" && getDocumentCurrentStatus == "22") {
                $('#Button_ASAM_Save').attr('disabled', true);
            }
        }
    }
    catch (err) {
        LogClientSideException(err, 'SetScreenSpecificValues function failed in AssessmentASAMPopUp.js');
    }
}

function CloseASAMPopUp() {
    parent.CloaseModalPopupWindow();
}

function SaveASAMPopUpData() {
    try{
        if (AutoSaveXMLDom[0] != undefined && AutoSaveXMLDom != undefined && AutoSaveXMLDom[0].xml != undefined) {

      var _CustomASAMRow = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomASAMPlacements");
      //Initialize table values in parent DOM XML
      var data = {}
      if ($(AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomASAMPlacements")).length > 0) {
          $(AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomASAMPlacements")).each(function () {
              $(this).children().each(function () {
                  data[this.tagName] = $(this).text();


                  var parentTableObject = $("CustomASAMPlacements", parent.AutoSaveXMLDom);
                  var parentColumnObject = $(this.tagName, parentTableObject);

                  if ($(this.tagName, parentTableObject).length == 0) {
                      parentTableObject[0].appendChild(parent.AutoSaveXMLDom[0].createElement(this.tagName));
                      parentColumnObject = $(this.tagName, parentTableObject);
                      //Handle Null value
                      if ($(this).text() == "") {
                          parentColumnObject.attr("xsi:nil", 'true');
                      }
                      parentColumnObject.text($(this).text());
                  }
                  else {
                      //Handle Null value
                      if ($(this).text() == "") {
                          parentColumnObject.attr("xsi:nil", 'true');
                      }
                      if (parentColumnObject.text() != $(this).text()) {
                          parentColumnObject.text($(this).text());
                      }
                      else {
                          return;
                      }
                  }


              })
          });
      }
        
        if (_CustomASAMRow.length > 0) {
            OpenPage(5761, 10690, 'ASAMPopUpData=' + encodeTextSymbol(_CustomASAMRow[0].xml) + '^Flag=SaveASAMPopup', null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
        }
  }
    }
    catch (err) {
        LogClientSideException(err, 'SaveASAMPopUpData function failed in AssessmentASAMPopUp.js');
    }
}

function encodeTextSymbol(TextToEncode) {
    try {
        var encodedHtml = TextToEncode.replace(/\+/g, "%PL");
        return encodedHtml;
    }
    catch (ex) {
        LogClientSideException(ex, 'encodeTextSymbol function failed in AssessmentASAMPopUp.js');
    }
}

function GetXMLDomOnTabClick() {
    try {
        if (AutoSaveXMLDom[0] != undefined && AutoSaveXMLDom != undefined && AutoSaveXMLDom[0].xml != undefined) {
            objectPageResponse.ScreenDataSetXml = AutoSaveXMLDom[0].xml;
        }
    return AutoSaveXMLDom;
    }
    catch (ex) {
        LogClientSideException(ex, 'GetXMLDomOnTabClick function failed in AssessmentASAMPopUp.js');
    }
}