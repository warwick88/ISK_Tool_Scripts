﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SHS.BaseLayer;
using SHS.UserBusinessServices;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using SHS.DataServices;
namespace SHS.SmartCare
{
    public partial class ActivityPages_Client_Detail_TreatmentPlanHRM_TreatmentPlanHRM : SHS.BaseLayer.ActivityPages.DocumentDataActivityMultiTabPage
    {

        #region Variable/Object Declaration

        #endregion


        /// <summary>
        /// <Description>Overriden property used to set default tab</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>8th Nov 2009</CreatedOn>
        /// </summary>
        public override string DefaultTab
        {
            get { return "/Custom/Treatment Plan/WebPages/HRMTPGeneral.ascx"; }
        }

        /// <summary>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>8th Nov 2009</CreatedOn>
        /// </summary>
        public override string MultiTabControlName
        {
            get { return "TreatmentPlanHRM"; }
        }

        /// <summary>
        /// <Description></Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>8th Nov 2009</CreatedOn>
        /// </summary>
        /// <param name="TabIndex"></param>
        public override void setTabIndex(int TabIndex, out ControlCollection ctlcollection, out string UcPath)
        {
            TreatmentPlanHRM.ActiveTabIndex = (short)TabIndex;
            ctlcollection = TreatmentPlanHRM.TabPages[TabIndex].Controls;
            UcPath = TreatmentPlanHRM.TabPages[TabIndex].Name;
        }


        public override string[] TablesToBeInitialized
        {
            get
            {
                return new string[] { "TPGeneral", "TPNeeds" };
            }
        }


        /// <summary>
        /// <Description>This is overridable Property inherited from base layer's
        /// DataActivityPage and is used to pass the Dataset name.</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>Aug 31,2009</CreatedOn>
        /// </summary>        
        public override string PageDataSetName
        {
            // get { return "DataSetTreatmentPlanHRM"; }
            get { return "DataSetTreatmentPlan"; }

        }

        /// <summary>
        /// <Description></Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>8th Nov 2009</CreatedOn>
        /// </summary>
        public override void BindControls()
        {
            HiddenFieldRelativePath.Value = Page.ResolveUrl("~/");
        }


        /// <summary>
        /// <Description> Purpose - Overridden Add Mandatory Values Function</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>8th Nov, 2009</CreatedOn>
        /// </summary>
        /// <param name="dataRow"></param>
        /// <param name="tableName"></param>
        public override void AddMandatoryValues(DataRow dataRow, string tableName)
        {
            string strFirstNameLastName = string.Empty;
            switch (tableName)
            {
                case "TPGeneral":

                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        dataRow["PlanOrAddendum"] = "T";
                    }
                    else { dataRow["PlanOrAddendum"] = "A"; }

                    break;

                case "TPNeeds":
                    dataRow["NeedCreatedDate"] = DateTime.Now.ToString();
                    dataRow["NeedModifiedDate"] = DateTime.Now.ToString();
                    dataRow["GoalActive"] = "Y";
                    if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName != string.Empty)
                    {
                        strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName;
                    }
                    if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName != string.Empty)
                    {
                        if (strFirstNameLastName != string.Empty)
                        {
                            strFirstNameLastName = strFirstNameLastName + ", " + BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                        }
                        else
                        {
                            strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                        }
                    }

                    dataRow["GoalMonitoredBy"] = strFirstNameLastName;
                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        dataRow["GoalTargetDate"] = DBNull.Value;
                    }
                    dataRow["NeedNumber"] = 1;
                    break;



                default:
                    break;

            }


        }





        /// <summary>
        /// <Description></Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>8th Nov 2009</CreatedOn>
        /// </summary>
        /// <param name="dataSetObject"></param>
        public override void ChangeInitializedDataSet(ref DataSet dataSetObject)
        {
            DataRow[] dataRowTPNeeds = null;
            Double objectiveNumber = 0;
            Double newObjectiveNumber = 0;
            DataRow dataRowTPNeed = null;
            string tempObjectiveNumber = string.Empty;
            string strFirstNameLastName = string.Empty;
            string whereClause = string.Empty;
            string tempInterventionNumber = string.Empty;
            double interventionNumber = 0;
            double newInterventionNumber = 0;
            SHS.UserBusinessServices.Document objectDocument = null;

            if (BaseCommonFunctions.CheckRowExists(dataSetObject, "TPGeneral", 0))
            {

                if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                {
                    dataSetObject.Tables["TPGeneral"].Rows[0]["PlanOrAddendum"] = "T";
                }
                else
                {
                    dataSetObject.Tables["TPGeneral"].Rows[0]["PlanOrAddendum"] = "A";
                }

            }

            if (BaseCommonFunctions.CheckRowExists(dataSetObject, "TPNeeds", 0))
            {

                dataRowTPNeeds = dataSetObject.Tables["TPNeeds"].Select("", "NeedNumber ASC");
                for (int rows = 0; rows < dataRowTPNeeds.Length; rows++)
                {
                    dataRowTPNeeds[rows].BeginEdit();
                    dataRowTPNeeds[rows]["NeedNumber"] = rows + 1;
                    if (dataRowTPNeeds[rows]["NeedId"] != DBNull.Value && Convert.ToInt32(dataRowTPNeeds[rows]["NeedId"]) != -1)
                        dataRowTPNeeds[rows]["SourceNeedId"] = dataRowTPNeeds[rows]["NeedId"];

                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        dataRowTPNeeds[rows]["GoalTargetDate"] = System.DBNull.Value;
                        dataRowTPNeeds[rows]["NeedCreatedDate"] = DateTime.Now;
                        dataRowTPNeeds[rows]["NeedModifiedDate"] = DateTime.Now;
                    }

                    /*
                    if (dataRowTPNeeds[rows]["GoalMonitoredBy"] == DBNull.Value)
                    {

                        if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName != string.Empty)
                        {
                            strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName;
                        }
                        if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName != string.Empty)
                        {
                            if (strFirstNameLastName != string.Empty)
                            {
                                strFirstNameLastName = strFirstNameLastName + ", " + BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                            }
                            else
                            {
                                strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                            }
                        }


                        dataRowTPNeeds[rows]["GoalMonitoredBy"] = strFirstNameLastName;
                    }
                     */
                    if (dataRowTPNeeds[rows]["GoalMonitoredStaff"] == DBNull.Value)
                    {

                        if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName != string.Empty)
                        {
                            strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName;
                        }
                        if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName != string.Empty)
                        {
                            if (strFirstNameLastName != string.Empty)
                            {
                                strFirstNameLastName = strFirstNameLastName + ", " + BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                            }
                            else
                            {
                                strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                            }
                        }


                        dataRowTPNeeds[rows]["GoalMonitoredStaffOther"] = strFirstNameLastName;
                        dataRowTPNeeds[rows]["GoalMonitoredStaffOtherCheckbox"] = "Y";

                    }
                    dataRowTPNeeds[rows].AcceptChanges();
                    dataRowTPNeeds[rows].SetAdded();
                    dataRowTPNeeds[rows].EndEdit();

                }


            }
            else
            {
                dataRowTPNeed = dataSetObject.Tables["TPNeeds"].NewRow();
                dataRowTPNeed.BeginEdit();
                dataRowTPNeed["DocumentVersionId"] = Convert.ToInt32(dataSetObject.Tables["DocumentVersions"].Rows[0]["DocumentVersionId"]);

                dataRowTPNeed["NeedCreatedDate"] = DateTime.Now;
                dataRowTPNeed["NeedModifiedDate"] = DateTime.Now;
                dataRowTPNeed["GoalActive"] = "Y";

                if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName != string.Empty)
                {
                    strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName;
                }
                if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName != string.Empty)
                {
                    if (strFirstNameLastName != string.Empty)
                    {
                        strFirstNameLastName = strFirstNameLastName + ", " + BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                    }
                    else
                    {
                        strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                    }
                }


                // dataRowTPNeed["GoalMonitoredBy"] = strFirstNameLastName;
                dataRowTPNeed["GoalMonitoredStaffOther"] = strFirstNameLastName;
                dataRowTPNeed["GoalMonitoredStaffOtherCheckbox"] = "Y";
                if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                {
                    dataRowTPNeed["GoalTargetDate"] = System.DBNull.Value;
                }
                dataRowTPNeed["NeedNumber"] = 1;
                BaseCommonFunctions.InitRowCredentials(dataRowTPNeed);
                dataRowTPNeed.EndEdit();
                dataSetObject.Tables["TPNeeds"].Rows.Add(dataRowTPNeed);

            }




            //TPObjectives 
            if (BaseCommonFunctions.CheckRowExists(dataSetObject, "TPObjectives", 0))
            {
                for (int rows = 0; rows < dataSetObject.Tables["TPObjectives"].Rows.Count; rows++)
                {
                    dataSetObject.Tables["TPObjectives"].Rows[rows].BeginEdit();

                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        dataSetObject.Tables["TPObjectives"].Rows[rows]["TargetDate"] = System.DBNull.Value;
                    }

                    if (tempObjectiveNumber != dataSetObject.Tables["TPNeeds"].Select("NeedID=" + dataSetObject.Tables["TPObjectives"].Rows[rows]["NeedID"].ToString())[0]["NeedNumber"].ToString())
                    {
                        objectiveNumber = .01;
                    }
                    else
                    {
                        objectiveNumber += .01;
                    }

                    tempObjectiveNumber = dataSetObject.Tables["TPNeeds"].Select("NeedID=" + dataSetObject.Tables["TPObjectives"].Rows[rows]["NeedID"].ToString())[0]["NeedNumber"].ToString();


                    newObjectiveNumber = Convert.ToDouble(tempObjectiveNumber) + objectiveNumber;


                    dataSetObject.Tables["TPObjectives"].Rows[rows]["ObjectiveNumber"] = newObjectiveNumber.ToString();

                    dataSetObject.Tables["TPObjectives"].Rows[rows].AcceptChanges();
                    dataSetObject.Tables["TPObjectives"].Rows[rows].SetAdded();
                    dataSetObject.Tables["TPObjectives"].Rows[rows].EndEdit();
                }

            }

            //TPInterventionProcedures
            if (BaseCommonFunctions.CheckRowExists(dataSetObject, "TPInterventionProcedures", 0))
            {
                for (int rows = 0; rows < dataSetObject.Tables["TPInterventionProcedures"].Rows.Count; rows++)
                {

                    dataSetObject.Tables["TPInterventionProcedures"].Rows[rows].BeginEdit();
                    if (dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["TPProcedureId"] != System.DBNull.Value)
                    {
                        dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["RequestAuthorization"] = 'Y';
                    }
                    else { dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["RequestAuthorization"] = 'N'; }


                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["StartDate"] = System.DBNull.Value;
                        dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["EndDate"] = System.DBNull.Value;
                        dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["Units"] = System.DBNull.Value;
                        dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["frequencyType"] = System.DBNull.Value;
                        dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["TPProcedureId"] = System.DBNull.Value;
                    }


                    if (tempInterventionNumber != dataSetObject.Tables["TPNeeds"].Select("NeedID=" + dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["NeedID"].ToString())[0]["NeedNumber"].ToString())
                    {
                        interventionNumber = .01;
                    }
                    else
                    {
                        interventionNumber += .01;
                    }

                    tempInterventionNumber = dataSetObject.Tables["TPNeeds"].Select("NeedID=" + dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["NeedID"].ToString())[0]["NeedNumber"].ToString();


                    newInterventionNumber = Convert.ToDouble(tempInterventionNumber) + interventionNumber;


                    dataSetObject.Tables["TPInterventionProcedures"].Rows[rows]["InterventionNumber"] = newInterventionNumber.ToString();



                    dataSetObject.Tables["TPInterventionProcedures"].Rows[rows].AcceptChanges();
                    dataSetObject.Tables["TPInterventionProcedures"].Rows[rows].SetAdded();
                    dataSetObject.Tables["TPInterventionProcedures"].Rows[rows].EndEdit();
                }

            }


            //TPProcedures
            //Following is temprorary code which has been applied to fix a major show stopper
            //These will be changed once we will discuss details with SHS team
            //As in this case DocumentVersionId doesn't exist in parent table
            dataSetObject.EnforceConstraints = false;
            //Changes end here
            if (BaseCommonFunctions.CheckRowExists(dataSetObject, "TPProcedures", 0))
            {
                if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 503)
                {
                    for (int rows = 0; rows < dataSetObject.Tables["TPProcedures"].Rows.Count; rows++)
                    {
                        dataSetObject.Tables["TPProcedures"].Rows[rows].BeginEdit();
                        dataSetObject.Tables["TPProcedures"].Rows[rows]["SourceDocumentId"] = dataSetObject.Tables["TPProcedures"].Rows[rows]["DocumentVersionId"];
                        //dataSetObject.Tables["TPProcedures"].Rows[rows]["DocumentVersionId"] = dataSetObject.Tables["TPProcedures"].Rows[rows]["TPProcedureDocumentVersionId"];
                        //dataSetObject.Tables["TPProcedures"].Rows[rows].AcceptChanges();
                        dataSetObject.Tables["TPProcedures"].Rows[rows].EndEdit();
                    }
                }
            }



            if (ParentDocumentPageObject.PageAction == BaseCommonFunctions.PageActions.New || ParentDocumentPageObject.DocumentId == 0)
            {
                objectDocument = new SHS.UserBusinessServices.Document();
                DataSet dataTPQuick = null;
                if (dataSetObject.Tables.Contains("TPQuickGoals"))
                {
                    dataTPQuick = new DataSet();
                    dataSetObject.Tables["TPQuickGoals"].Rows.Clear();
                    whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                    DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataTPQuick, whereClause, "TPQuickGoals")).Tables["TPQuickGoals"];
                    dataSetObject.Tables["TPQuickGoals"].Merge(dtTemp);

                }
                if (dataSetObject.Tables.Contains("TPQuickObjectives"))
                {
                    dataTPQuick = null;
                    dataTPQuick = new DataSet();
                    dataSetObject.Tables["TPQuickObjectives"].Rows.Clear();
                    whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                    DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataTPQuick, whereClause, "TPQuickObjectives")).Tables["TPQuickObjectives"];
                    dataSetObject.Tables["TPQuickObjectives"].Merge(dtTemp);

                }

                if (dataSetObject.Tables.Contains("TPQuickInterventions"))
                {
                    dataTPQuick = null;
                    dataTPQuick = new DataSet();
                    dataSetObject.Tables["TPQuickInterventions"].Rows.Clear();
                    whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                    DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataTPQuick, whereClause, "TPQuickInterventions")).Tables["TPQuickInterventions"];
                    dataSetObject.Tables["TPQuickInterventions"].Merge(dtTemp);

                }

            }

            //#region Code Added By Vikas Vyas in ref. to Implement UMPart 2
            //if (BaseCommonFunctions.CheckRowExists(dataSetObject, "Documents"))
            //{
            //   dataSetObject.Tables["Documents"].Rows[0]["EffectiveDate"]= DateTime.Now.ToString("MM/dd/yyyy");
            //}

            //#endregion


        }





        #region Commented
        ///// <summary>
        ///// <Description>Hadle the action when new button is click</Description>
        ///// <Author>Vikas Vyas</Author>
        ///// <CreatedOn>02/08/2009</CreatedOn>
        ///// </summary>
        ///// <param name="dataSetNew"></param>
        ///// <param name="toBeInitialized"></param>
        //public override void DocumentNewDocument(ref DataSet dataSetDocument, string toBeInitialized)
        //{

        //    int documentCodeId = 0;
        //    base.DocumentNewDocument(ref dataSetDocument, toBeInitialized);

        //    if (toBeInitialized.ToLower() == "y")
        //    {
        //        if (dataSetDocument.Tables.Count > 0 && dataSetDocument.Tables["Documents"].Rows.Count > 0)
        //        {
        //            if (dataSetDocument.Tables["Documents"].Rows[0]["DocumentCodeId"] != DBNull.Value)
        //            {
        //                //Get DocumentCodeId
        //                Int32.TryParse(dataSetDocument.Tables["Documents"].Rows[0]["DocumentCodeId"].ToString(), out documentCodeId);
        //                //documentCodeId = Convert.ToInt32(dataSetDocument.Tables["Documents"].Rows[0]["DocumentCodeId"]);
        //                GeneralAddRowtoBasicTables(ref dataSetDocument, documentCodeId);
        //                BuildingGeneralPlanBuilder(ref dataSetDocument, documentCodeId);
        //            }
        //        }
        //    }
        //    //Remarks
        //    //else
        //    //{
        //    //GeneralAddRowtoBasicTables(ref dataSetDocument, documentCodeId,true);
        //    //BuildingGeneralPlanBuilder(ref dataSetDocument, documentCodeId);
        //    //
        //    //}


        //    //Do proper commenting over here
        //    //i.e for which purpose this code has beenn written
        //    if (dataSetDocument.Tables.Contains("TPInterventionProcedures"))
        //    {
        //        if (dataSetDocument.Tables["TPInterventionProcedures"].Rows.Count > 0)
        //        {
        //            for (int i = 0; i <= dataSetDocument.Tables["TPInterventionProcedures"].Rows.Count - 1; i++)
        //            {
        //                if ((dataSetDocument.Tables["TPInterventionProcedures"].Rows[i]["SiteId"] != DBNull.Value))
        //                {
        //                    if (Convert.ToInt32(dataSetDocument.Tables["TPInterventionProcedures"].Rows[i]["SiteId"]).ToString() != string.Empty)
        //                    {
        //                        if (Convert.ToInt32(dataSetDocument.Tables["TPInterventionProcedures"].Rows[i]["SiteId"]) == -1)
        //                            dataSetDocument.Tables["TPInterventionProcedures"].Rows[i]["SiteId"] = -2;
        //                    }

        //                }
        //            }

        //        }

        //    }
        //}

        #endregion
        /// <summary>
        /// <Description></Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn></CreatedOn>
        /// </summary>
        private void BuildingGeneralPlanBuilder(ref System.Data.DataSet dataSetNew, int documentCodeId)
        {
            DataRow[] dataRowTPNeeds = null; //Collection
            DataRow dataRowTPNeed = null;//Single

            string tempObjectiveNumber = string.Empty;
            Double objectiveNumber = 0;
            Double newObjectiveNumber = 0;
            if (dataSetNew.Tables.Contains("TPNeeds")) //Perform check wheather Table TPNeeds Exists or not
            {
                if (dataSetNew.Tables["TPNeeds"].Rows.Count > 0) //Perform RowCount Check 
                {
                    dataRowTPNeeds = dataSetNew.Tables["TPNeeds"].Select("", "NeedNumber ASC");
                    for (int rows = 0; rows < dataRowTPNeeds.Length; rows++)
                    {
                        dataRowTPNeeds[rows].BeginEdit();
                        dataRowTPNeeds[rows]["DocumentVersionId"] = -1;
                        dataRowTPNeeds[rows]["RowIdentifier"] = System.Guid.NewGuid();
                        dataRowTPNeeds[rows]["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataRowTPNeeds[rows]["CreatedDate"] = DateTime.Now;
                        dataRowTPNeeds[rows]["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataRowTPNeeds[rows]["ModifiedDate"] = DateTime.Now;
                        dataRowTPNeeds[rows]["NeedNumber"] = rows + 1;
                        dataRowTPNeeds[rows]["SourceNeedId"] = dataRowTPNeeds[rows]["NeedId"];
                        if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                            dataRowTPNeeds[rows]["GoalTargetDate"] = System.DBNull.Value;

                        //Code  Added by Vikas Vyas in ref to task 2580 On Dated Aug 05,2008
                        //If GoalMonitoredBy is null then we have to set the default value
                        if (dataRowTPNeeds[rows]["GoalMonitoredBy"] == DBNull.Value)
                        {
                            dataRowTPNeeds[rows]["GoalMonitoredBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        }
                        dataRowTPNeeds[rows].AcceptChanges();
                        dataRowTPNeeds[rows].SetAdded();
                        dataRowTPNeeds[rows].EndEdit();
                    }
                }
                else
                {
                    //If no rows exists in TPNeed add new row in TPNeed
                    dataRowTPNeed = dataSetNew.Tables["TPNeeds"].NewRow();
                    dataRowTPNeed.BeginEdit();
                    dataRowTPNeed["DocumentVersionId"] = -1;
                    dataRowTPNeed["RowIdentifier"] = System.Guid.NewGuid();
                    dataRowTPNeed["NeedCreatedDate"] = DateTime.Now.ToString();
                    dataRowTPNeed["NeedModifiedDate"] = DateTime.Now.ToString();
                    dataRowTPNeed["GoalActive"] = "Y";
                    dataRowTPNeed["GoalMonitoredBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        dataRowTPNeed["GoalTargetDate"] = System.DBNull.Value;
                    }
                    dataRowTPNeed["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                    dataRowTPNeed["CreatedDate"] = DateTime.Now;
                    dataRowTPNeed["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                    dataRowTPNeed["ModifiedDate"] = DateTime.Now;
                    dataRowTPNeed["NeedNumber"] = 1;
                    //dataRowTPNeed["RowAddedInCurrentPlan"] = true;
                    dataRowTPNeed.EndEdit();
                    dataSetNew.Tables["TPNeeds"].Rows.Add(dataRowTPNeed);
                    dataRowTPNeed.EndEdit();
                }
            }
            if (dataSetNew.Tables.Contains("TPObjectives")) //Perform Check for TPObjectives
            {
                if (dataSetNew.Tables["TPObjectives"].Rows.Count > 0)
                {
                    for (int rows = 0; rows < dataSetNew.Tables["TPObjectives"].Rows.Count; rows++)
                    {
                        dataSetNew.Tables["TPObjectives"].Rows[rows].BeginEdit();

                        dataSetNew.Tables["TPObjectives"].Rows[rows]["DocumentVersionId"] = -1;
                        if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                        {
                            dataSetNew.Tables["TPObjectives"].Rows[rows]["TargetDate"] = System.DBNull.Value;
                        }
                        dataSetNew.Tables["TPObjectives"].Rows[rows]["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataSetNew.Tables["TPObjectives"].Rows[rows]["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        if (tempObjectiveNumber != dataSetNew.Tables["TPNeeds"].Select("NeedID=" + dataSetNew.Tables["TPObjectives"].Rows[rows]["NeedID"].ToString())[0]["NeedNumber"].ToString())
                        {
                            objectiveNumber = .01;
                        }
                        else
                        {
                            objectiveNumber += .01;
                        }

                        tempObjectiveNumber = dataSetNew.Tables["TPNeeds"].Select("NeedID=" + dataSetNew.Tables["TPObjectives"].Rows[rows]["NeedID"].ToString())[0]["NeedNumber"].ToString();


                        newObjectiveNumber = Convert.ToDouble(tempObjectiveNumber) + objectiveNumber;


                        dataSetNew.Tables["TPObjectives"].Rows[rows]["ObjectiveNumber"] = newObjectiveNumber.ToString();

                        dataSetNew.Tables["TPObjectives"].Rows[rows].AcceptChanges();
                        dataSetNew.Tables["TPObjectives"].Rows[rows].SetAdded();
                        dataSetNew.Tables["TPObjectives"].Rows[rows].EndEdit();
                    }
                }
            }
            if (dataSetNew.Tables.Contains("TPInterventionProcedures"))
            {
                if (dataSetNew.Tables["TPInterventionProcedures"].Rows.Count > 0)
                {

                    for (int rows = 0; rows < dataSetNew.Tables["TPInterventionProcedures"].Rows.Count; rows++)
                    {

                        dataSetNew.Tables["TPInterventionProcedures"].Rows[rows].BeginEdit();
                        if (dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["TPProcedureId"] != System.DBNull.Value)
                        {
                            dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["RequestAuthorization"] = 'Y';
                        }
                        else { dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["RequestAuthorization"] = 'N'; }


                        if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                        {
                            dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["StartDate"] = System.DBNull.Value;
                            dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["EndDate"] = System.DBNull.Value;
                            dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["Units"] = System.DBNull.Value;
                            dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["frequencyType"] = System.DBNull.Value;
                            dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["TPProcedureId"] = System.DBNull.Value;
                        }

                        dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataSetNew.Tables["TPInterventionProcedures"].Rows[rows]["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataSetNew.Tables["TPInterventionProcedures"].Rows[rows].AcceptChanges();
                        dataSetNew.Tables["TPInterventionProcedures"].Rows[rows].SetAdded();
                        dataSetNew.Tables["TPInterventionProcedures"].Rows[rows].EndEdit();
                    }
                }
            }
            if (dataSetNew.Tables.Contains("TPInterventionProcedureObjectives"))
            {

                if (dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows.Count > 0)
                {

                    for (int rows = 0; rows < dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows.Count; rows++)
                    {
                        dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows[rows].BeginEdit();
                        dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows[rows]["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows[rows]["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows[rows].AcceptChanges();
                        dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows[rows].SetAdded();
                        dataSetNew.Tables["TPInterventionProcedureObjectives"].Rows[rows].EndEdit();
                    }
                }
            }
            if (dataSetNew.Tables.Contains("TPProcedures"))
            {
                if (dataSetNew.Tables["TPProcedures"].Rows.Count > 0)
                {
                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        for (int rows = 0; rows < dataSetNew.Tables["TPProcedures"].Rows.Count; rows++)
                        {
                            dataSetNew.Tables["TPProcedures"].Rows[rows].BeginEdit();

                            dataSetNew.Tables["TPProcedures"].Rows[rows]["DocumentVersionId"] = -1;
                            dataSetNew.Tables["TPProcedures"].Rows[rows].AcceptChanges();
                            dataSetNew.Tables["TPProcedures"].Rows[rows].SetAdded();
                            dataSetNew.Tables["TPProcedures"].Rows[rows].EndEdit();
                        }
                    }
                    else
                    {
                        for (int rows = 0; rows < dataSetNew.Tables["TPProcedures"].Rows.Count; rows++)
                        {
                            dataSetNew.Tables["TPProcedures"].Rows[rows].BeginEdit();
                            //dataSetNew.Tables["TPProcedures"].Rows[rows]["SourceDocumentId"] = dataSetNew.Tables["TPProcedures"].Rows[rows]["DocumentId"];
                            dataSetNew.Tables["TPProcedures"].Rows[rows]["SourceDocumentId"] = dataSetNew.Tables["TPProcedures"].Rows[rows]["DocumentVersionId"];

                            dataSetNew.Tables["TPProcedures"].Rows[rows]["DocumentVersionId"] = -1;
                            dataSetNew.Tables["TPProcedures"].Rows[rows].AcceptChanges();
                            dataSetNew.Tables["TPProcedures"].Rows[rows].EndEdit();
                        }
                    }
                }
            }
            if (dataSetNew.Tables.Contains("CustomTPNeedsClientNeeds"))
            {
                if (dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows.Count > 0)
                {
                    for (int rows = 0; rows < dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows.Count; rows++)
                    {
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows].BeginEdit();
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows]["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows]["CreatedDate"] = DateTime.Now;
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows]["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows]["ModifiedDate"] = DateTime.Now;
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows].AcceptChanges();
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows].SetAdded();
                        dataSetNew.Tables["CustomTPNeedsClientNeeds"].Rows[rows].EndEdit();
                    }
                }

            }

        }

        /// <summary>
        /// <Description></Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn></CreatedOn>
        /// </summary>
        /// <param name="dataSetTreatmentPlanHRM"></param>
        /// <param name="documentCodeId"></param>
        private void GeneralAddRowtoBasicTables(ref System.Data.DataSet dataSetDocument, int documentCodeId)
        {
            DataRow dataRowTPGeneral = null;
            //Remarks
            //Take an extra variable of bool type named as CreateNewRow as true/false
            //If same is true
            //dataRowTPGeneral = dataSetDocument.Tables["TPGeneral"].NewRow();
            //Else
            //dataRowTPGeneral = dataSetDocument.Tables["TPGeneral"].Rows[0];

            //dataRowTPGeneral["DocumentVersionId"] = -1;
            ////Remark - Remove DocumentId and Version fields from custom tables
            //dataRowTPGeneral["DocumentID"] = 0;
            //dataRowTPGeneral["Version"] = 1;
            //if (documentCodeId == 350)
            //    dataRowTPGeneral["PlanOrAddendum"] = "T";
            //else
            //    dataRowTPGeneral["PlanOrAddendum"] = "A";
            //dataRowTPGeneral["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
            //dataRowTPGeneral["CreatedDate"] = DateTime.Now;
            //dataRowTPGeneral["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
            //dataRowTPGeneral["ModifiedDate"] = DateTime.Now;
            //dataRowTPGeneral["RowIdentifier"] = System.Guid.NewGuid();
            //dataSetDocument.Tables["TPGeneral"].Rows.Add(dataRowTPGeneral);

            //If CreateNewRow==true
            //dataSetDocument.Tables["TPGeneral"].Rows.Add(dataRowTPGeneral);
            //else
            //{
            // dataSetDocument.Tables["TPGeneral"].AcceptChanges();
            // dataRowTPGeneral.SetAdded();
            //}
            if (dataSetDocument.Tables["TPGeneral"].Rows.Count == 0)
            {
                dataRowTPGeneral = dataSetDocument.Tables["TPGeneral"].NewRow();

                //Remark - DocumentVersionId field should not be hardcoded as -1 
                //It should be accessible from ParentDocumentPageObject.DocumentVersionId

                dataRowTPGeneral["DocumentVersionId"] = -1;
                if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    dataRowTPGeneral["PlanOrAddendum"] = "T";
                else
                    dataRowTPGeneral["PlanOrAddendum"] = "A";
                dataRowTPGeneral["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                dataRowTPGeneral["CreatedDate"] = DateTime.Now;
                dataRowTPGeneral["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                dataRowTPGeneral["ModifiedDate"] = DateTime.Now;
                dataRowTPGeneral["RowIdentifier"] = System.Guid.NewGuid();

                dataRowTPGeneral["DeferredTreatmentIssues"] = DBNull.Value;
                dataRowTPGeneral["CrisisPlan"] = DBNull.Value;

                dataSetDocument.Tables["TPGeneral"].Rows.Add(dataRowTPGeneral);
            }
            else
            {
                dataRowTPGeneral = dataSetDocument.Tables["TPGeneral"].Rows[0];
                dataSetDocument.Tables["TPGeneral"].Rows[0]["DocumentVersionID"] = -1;
                if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                {
                    dataSetDocument.Tables["TPGeneral"].Rows[0]["PlanOrAddendum"] = "T";
                }
                else
                {
                    dataSetDocument.Tables["TPGeneral"].Rows[0]["PlanOrAddendum"] = "A";
                }
                dataSetDocument.Tables["TPGeneral"].Rows[0]["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                dataSetDocument.Tables["TPGeneral"].Rows[0]["CreatedDate"] = DateTime.Now;
                dataSetDocument.Tables["TPGeneral"].Rows[0]["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName;
                dataSetDocument.Tables["TPGeneral"].Rows[0]["ModifiedDate"] = DateTime.Now;
                dataSetDocument.Tables["TPGeneral"].AcceptChanges();
                dataRowTPGeneral.SetAdded();
            }

        }



        /// <summary>
        /// <Description>Remove Table those are not used for update process</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>20th/11/2009</CreatedOn>
        /// </summary>
        /// <param name="dataSetObject"></param>
        public override void ChangeDataSetBeforeUpdate(ref DataSet dataSetObject)
        {

            if (dataSetObject != null && dataSetObject.Tables.Count > 0)
            {
                if (dataSetObject.Tables.Contains("DataTableGroup"))
                {
                    dataSetObject.Tables["DataTableGroup"].Constraints.Clear();
                    dataSetObject.Tables["DataTableGroup"].ChildRelations.Remove(dataSetObject.Tables["DataTableGroup"].ChildRelations[0]);
                    dataSetObject.Tables.Remove("DataTableGroup");

                }

                if (dataSetObject.Tables.Contains("CustomFieldsData"))
                {
                    if (dataSetObject.Tables["CustomFieldsData"].ParentRelations.Count < 1)
                    {

                        if (dataSetObject.Relations.Contains("DocumentVersion_CustomControl_DocumentId"))
                            dataSetObject.Relations.Remove("DocumentVersion_CustomControl_DocumentId");
                        if (dataSetObject.Relations.Contains("DocumentVersion_CustomControl_Version"))
                            dataSetObject.Relations.Remove("DocumentVersion_CustomControl_Version");
                        dataSetObject.Relations.Add("DocumentVersion_CustomControl_DocumentId", dataSetObject.Tables["DocumentVersions"].Columns["DocumentId"], dataSetObject.Tables["CustomFieldsData"].Columns["PrimaryKey1"]).ChildKeyConstraint.UpdateRule = Rule.Cascade;
                        dataSetObject.Relations.Add("DocumentVersion_CustomControl_Version", dataSetObject.Tables["DocumentVersions"].Columns["Version"], dataSetObject.Tables["CustomFieldsData"].Columns["PrimaryKey2"]).ChildKeyConstraint.UpdateRule = Rule.Cascade;
                    }
                }

                if (dataSetObject.Tables["TPGeneral"].Rows.Count > 0)
                {

                    if (String.IsNullOrEmpty(Convert.ToString(dataSetObject.Tables["TPGeneral"].Rows[0]["DeferredTreatmentIssues"])))
                    {
                        dataSetObject.Tables["TPGeneral"].Rows[0]["DeferredTreatmentIssues"] = DBNull.Value;
                    }
                    if (String.IsNullOrEmpty(Convert.ToString(dataSetObject.Tables["TPGeneral"].Rows[0]["CrisisPlan"])))
                    {
                        dataSetObject.Tables["TPGeneral"].Rows[0]["CrisisPlan"] = DBNull.Value;
                    }
                }

                if (dataSetObject.Tables.Contains("TPQuickInterventions"))
                {
                    dataSetObject.Tables["TPQuickInterventions"].Clear();
                }

                if (dataSetObject.Tables.Contains("TPQuickGoals"))
                {

                    dataSetObject.Tables["TPQuickGoals"].Clear();
                }


                if (dataSetObject.Tables.Contains("TPQuickObjectives"))
                {
                    dataSetObject.Tables["TPQuickObjectives"].Clear();
                }
                if (dataSetObject.Tables.Contains("TPQuickNeeds"))
                {
                    dataSetObject.Tables["TPQuickNeeds"].Clear();
                }
                if (dataSetObject.Tables.Contains("PreviouslyRequested"))
                {
                    dataSetObject.Tables["PreviouslyRequested"].Clear();
                }
                if (dataSetObject.Tables.Contains("AddendumNotifications"))
                {
                    dataSetObject.Tables["AddendumNotifications"].Clear();
                }


                if (!dataSetObject.Tables["TPNeeds"].ExtendedProperties.Contains("UpdateChildTable"))
                    dataSetObject.Tables["TPNeeds"].ExtendedProperties.Add("UpdateChildTable", true);
                else
                    dataSetObject.Tables["TPNeeds"].ExtendedProperties["UpdateChildTable"] = true;



                if (!dataSetObject.Tables["TPProcedures"].ExtendedProperties.Contains("UpdateChildTable"))
                    dataSetObject.Tables["TPProcedures"].ExtendedProperties.Add("UpdateChildTable", true);
                else
                    dataSetObject.Tables["TPProcedures"].ExtendedProperties["UpdateChildTable"] = true;


                if (!dataSetObject.Tables["TPObjectives"].ExtendedProperties.Contains("UpdateChildTable"))
                    dataSetObject.Tables["TPObjectives"].ExtendedProperties.Add("UpdateChildTable", true);
                else
                    dataSetObject.Tables["TPObjectives"].ExtendedProperties["UpdateChildTable"] = true;

                if (!dataSetObject.Tables["TPInterventionProcedureObjectives"].ExtendedProperties.Contains("UpdateChildTable"))
                    dataSetObject.Tables["TPInterventionProcedureObjectives"].ExtendedProperties.Add("UpdateChildTable", true);
                else
                    dataSetObject.Tables["TPInterventionProcedureObjectives"].ExtendedProperties["UpdateChildTable"] = true;


                //if (BaseCommonFunctions.CheckRowExists(dataSetObject.Tables["TPGeneral"], 1))
                //{
                //    for (int i = dataSetObject.Tables["TPGeneral"].Rows.Count; i > 1; i--)
                //    {
                //        dataSetObject.Tables["TPGeneral"].Rows[i-1].Delete();
                //    }
                //}


                if (dataSetObject.Tables.Contains("AuthorizationDocuments") && dataSetObject.Tables["AuthorizationDocuments"].Rows.Count > 0)
                {
                    dataSetObject.Tables["AuthorizationDocuments"].Clear();
                }

                if (dataSetObject.Tables.Contains("PlanDeliveryStaff"))
                {
                    dataSetObject.Tables["PlanDeliveryStaff"].Clear();
                }
                //Added by Maninder on 1/6/2011 wrf #130 in SCWeb Phase II Bugs/Features 
                if (BaseCommonFunctions.CheckRowExists(dataSetObject, "TPProcedures", 0))
                {
                    foreach (DataRow drTProc in dataSetObject.Tables["TPProcedures"].Rows)
                    {
                        if (drTProc["SiteId"] != DBNull.Value && Convert.ToInt32(drTProc["SiteId"]) == -1)
                        {
                            drTProc.BeginEdit();
                            drTProc["SiteId"] = DBNull.Value;
                            drTProc.EndEdit();
                        }

                    }
                }
                if (BaseCommonFunctions.CheckRowExists(dataSetObject, "TPInterventionProcedures", 0))
                {
                    foreach (DataRow drTPIntProc in dataSetObject.Tables["TPInterventionProcedures"].Rows)
                    {
                        if (drTPIntProc["SiteId"] != DBNull.Value && Convert.ToInt32(drTPIntProc["SiteId"]) == -1)
                        {
                            drTPIntProc.BeginEdit();
                            drTPIntProc["SiteId"] = DBNull.Value;
                            drTPIntProc.EndEdit();
                        }

                    }
                }
                if (!BaseCommonFunctions.CheckRowExists(dataSetObject, "TPNeeds", 0))
                {
                    DataRow dataRowTPNeed = null;
                    string strFirstNameLastName = string.Empty;
                    dataRowTPNeed = dataSetObject.Tables["TPNeeds"].NewRow();
                    dataRowTPNeed.BeginEdit();
                    dataRowTPNeed["DocumentVersionId"] = Convert.ToInt32(dataSetObject.Tables["DocumentVersions"].Rows[0]["DocumentVersionId"]);

                    dataRowTPNeed["NeedCreatedDate"] = DateTime.Now;
                    dataRowTPNeed["NeedModifiedDate"] = DateTime.Now;
                    dataRowTPNeed["GoalActive"] = "Y";

                    if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName != string.Empty)
                    {
                        strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.LastName;
                    }
                    if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName != string.Empty)
                    {
                        if (strFirstNameLastName != string.Empty)
                        {
                            strFirstNameLastName = strFirstNameLastName + ", " + BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                        }
                        else
                        {
                            strFirstNameLastName = BaseCommonFunctions.ApplicationInfo.LoggedInUser.FirstName;
                        }
                    }


                    // dataRowTPNeed["GoalMonitoredBy"] = strFirstNameLastName;
                    dataRowTPNeed["GoalMonitoredStaffOther"] = strFirstNameLastName;
                    dataRowTPNeed["GoalMonitoredStaffOtherCheckbox"] = "Y";
                    if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                    {
                        dataRowTPNeed["GoalTargetDate"] = System.DBNull.Value;
                    }
                    dataRowTPNeed["NeedNumber"] = 1;
                    BaseCommonFunctions.InitRowCredentials(dataRowTPNeed);
                    dataRowTPNeed.EndEdit();
                    dataSetObject.Tables["TPNeeds"].Rows.Add(dataRowTPNeed);
                }

                //End
            }

            if (dataSetObject.IsDataTableFound("CustomClientLOCs"))
                dataSetObject.Tables["CustomClientLOCs"].Clear();

            //BindLOCRecalculated(dataSetObject);
        }

        public void BindLOCRecalculated(DataSet dataSetObject)
        {
            int ClientId = 0;
            int DocumentVersionId = 0;
            int CurrentDocumentVersionId = 0;
            int Status = 0;
            string DocumentEffectiveDate = string.Empty;

            DataSet dataSetLOCRecords = new DataSet();
            SqlParameter[] _objectSqlParmeters = new SqlParameter[5];

            if (dataSetObject == null)
                dataSetObject = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

            if (dataSetObject.IsDataTableFound("Documents"))
            {
                if (dataSetObject.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dataSetObject.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                    int.TryParse(dataSetObject.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                if (dataSetObject.Tables["Documents"].Columns.Contains("EffectiveDate") && !string.IsNullOrEmpty(dataSetObject.Tables["Documents"].Rows[0]["EffectiveDate"].ToString()))
                    DocumentEffectiveDate = Convert.ToDateTime(dataSetObject.Tables["Documents"].Rows[0]["EffectiveDate"]).ToString("MM/dd/yyyy");
                if (dataSetObject.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dataSetObject.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                    int.TryParse(dataSetObject.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                if (dataSetObject.Tables["Documents"].Columns.Contains("CurrentDocumentVersionId") && !string.IsNullOrEmpty(dataSetObject.Tables["Documents"].Rows[0]["CurrentDocumentVersionId"].ToString()))
                    int.TryParse(dataSetObject.Tables["Documents"].Rows[0]["CurrentDocumentVersionId"].ToString(), out CurrentDocumentVersionId);
                if (dataSetObject.Tables["Documents"].Columns.Contains("Status") && !string.IsNullOrEmpty(dataSetObject.Tables["Documents"].Rows[0]["Status"].ToString()))
                    int.TryParse(dataSetObject.Tables["Documents"].Rows[0]["Status"].ToString(), out Status);
                if (Status == 22 && DocumentVersionId == CurrentDocumentVersionId)
                    DocumentVersionId = 0;
            }
            if (ClientId <= 0)
                ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

            if (DocumentVersionId > 0)
            {
                dataSetLOCRecords = new DataSet();
                _objectSqlParmeters = new SqlParameter[5];
                _objectSqlParmeters[0] = new SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new SqlParameter("@DocumentEffectiveDate", DocumentEffectiveDate);
                _objectSqlParmeters[2] = new SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[3] = new SqlParameter("@UserCode", SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode);
                _objectSqlParmeters[4] = new SqlParameter("@RecalculateLOC", "N");
                SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "csp_CalculateCurrentDocumentLevelsOfCare", dataSetLOCRecords, new string[] { "LOCOldRecords", "LOCRecords" }, _objectSqlParmeters);

            }
        }

        public override System.Collections.Generic.List<CustomParameters> customInitializationStoreProcedureParameters
        {
            get
            {

                System.Collections.Generic.List<CustomParameters> t = new List<CustomParameters>();
                if (BaseCommonFunctions.GetDocumentCodeId(this.ParentPageObject.ScreenId) == 350)
                {
                    string blankPlan = GetRequestParameterValue("ReIntialization");
                    if (blankPlan == "Y")
                    {
                        t.Add(new CustomParameters("BlankPlan", blankPlan));
                    }
                }

                return t;

            }
        }

        public override void ChangeDataSetAfterGetData()
        {
            DataSet dataSetTpHrm = null;
            SHS.UserBusinessServices.Document objectDocument = null;
            string whereClause = string.Empty;

            try
            {
                if (ParentDocumentPageObject.PageAction == BaseCommonFunctions.PageActions.New || ParentDocumentPageObject.PageAction == BaseCommonFunctions.PageActions.None)
                {
                    dataSetTpHrm = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                    objectDocument = new SHS.UserBusinessServices.Document();

                    if (!BaseCommonFunctions.CheckRowExists(dataSetTpHrm, "TPQuickGoals", 0))
                    {
                        whereClause = " where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                        DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataSetTpHrm, whereClause, "TPQuickGoals")).Tables["TPQuickGoals"];
                        dataSetTpHrm.Tables["TPQuickGoals"].Merge(dtTemp);

                    }
                    if (!BaseCommonFunctions.CheckRowExists(dataSetTpHrm, "TPQuickObjectives", 0))
                    {

                        whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                        DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataSetTpHrm, whereClause, "TPQuickObjectives")).Tables["TPQuickObjectives"];
                        dataSetTpHrm.Tables["TPQuickObjectives"].Merge(dtTemp);

                    }

                    if (!BaseCommonFunctions.CheckRowExists(dataSetTpHrm, "TPQuickInterventions", 0))
                    {

                        whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                        DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataSetTpHrm, whereClause, "TPQuickInterventions")).Tables["TPQuickInterventions"];
                        dataSetTpHrm.Tables["TPQuickInterventions"].Merge(dtTemp);

                    }

                    if (!BaseCommonFunctions.CheckRowExists(dataSetTpHrm, "TPQuickNeeds", 0))
                    {

                        whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                        DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataSetTpHrm, whereClause, "TPQuickNeeds")).Tables["TPQuickNeeds"];
                        dataSetTpHrm.Tables["TPQuickNeeds"].Merge(dtTemp);

                    }
                }

            }
            finally
            {
                if (dataSetTpHrm != null)
                    dataSetTpHrm = null;
                if (objectDocument != null)
                    objectDocument = null;


            }


        }

        public override void CustomAjaxRequest()
        {
            //if (GetRequestParameterValue("CustomAjaxRequestType") == "GetCurrentDiagnosis")
            //{
            //    //PanelMain.Visible = false;
            //    Literal literalStart = new Literal();
            //    Literal literalHtmlText = new Literal();
            //    Literal literalEnd = new Literal();
            //    literalStart.Text = "###StartCurrentDiagnosisUC###";
            //    DataSet CurrentDiagnosis = new DataSet();
            //    string CurrentDiagnosisString = string.Empty;
            //    SqlParameter[] _objectSqlParmeters = null;
            //    try
            //    {
            //        _objectSqlParmeters = new SqlParameter[1];
            //        _objectSqlParmeters[0] = new SqlParameter("@ClientId", SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId);
            //        SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "ssp_SCGetCurrentDiagnosis", CurrentDiagnosis, new string[] { "DocumentDiagnosisCodes", "DocumentDiagnosis" }, _objectSqlParmeters);
            //        if (CurrentDiagnosis != null)
            //        {
            //            //PreviousDiagnosisString = PreviosDiagnosis.GetXml().ToString();
            //            literalHtmlText.Text = CurrentDiagnosis.GetXml().ToString();
            //        }

            //    }
            //    finally
            //    {
            //        if (CurrentDiagnosis != null) CurrentDiagnosis.Dispose();
            //        _objectSqlParmeters = null;
            //    }
            //    literalEnd.Text = "###EndCurrentDiagnosisUC###";
            //    PanelLoadUC.Controls.Add(literalStart);
            //    PanelLoadUC.Controls.Add(literalHtmlText);
            //    PanelLoadUC.Controls.Add(literalEnd);
            //}
        }
    }
}