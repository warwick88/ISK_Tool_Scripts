﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SHS.BaseLayer;

namespace SHS.SmartCare
{
    public partial class Modules_Inquiry_Client_Details_WebPages_InquiryInsurance : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public override void BindControls()
        {
            LoadVerificationEligibiltyControl();
            //DropDownList_Inquiries_IncomeGeneralHouseholdComposition.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
            //DropDownList_Inquiries_IncomeGeneralHouseholdComposition.FillDropDownDropGlobalCodes();

            //DropDownList_Inquiries_IncomeGeneralPrimarySource.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
            //DropDownList_Inquiries_IncomeGeneralPrimarySource.FillDropDownDropGlobalCodes();
            //DropDownList_Inquiries_IncomeGeneralAlternativeSource.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
            //DropDownList_Inquiries_IncomeGeneralAlternativeSource.FillDropDownDropGlobalCodes(); 
        }
        private void LoadVerificationEligibiltyControl()
        {
            //UserControl userControl = LoadUC("~/CommonUserControls/VerifyEligibility.ascx");
            //PanelVerificationEligibility.Controls.Add(userControl);
            int inquiryid;
            if (Int32.TryParse(Convert.ToString(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CustomInquiries"].Rows[0]["InquiryId"]), out inquiryid))
            {
                eev1.InquiryId = inquiryid;
            }
        }

        public override string[] TablesUsedInTab
        {
            get
            {
                return new string[] { "CustomInquiryCoverageInformations", "CoveragePlans", "CustomInquiries" };
            }
        }
    }
}
