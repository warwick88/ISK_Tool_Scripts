﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;

public partial class ActivityPages_Client_Detail_Kalamazoo_MemberInquiryAdditionalInformation : SHS.BaseLayer.ActivityPages.DataActivityTab
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public override void BindControls()
    {
        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("REFERRALSOURCE", true, "", "CodeName", true))
        //{

        //    DropDownList_CustomInquiries_ReferralType.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_ReferralType.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_ReferralType.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_ReferralType.DataBind();
        //}
        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("REFERRALTYPE", true, "", "CodeName", true))
        //{

        //    DropDownList_CustomInquiries_ReferralSubtype.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_ReferralSubtype.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_ReferralSubtype.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_ReferralSubtype.DataBind();
        //}
        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("LIVINGARRANGEMENT", true, "", "CodeName", true))
        //{

        //    DropDownList_CustomInquiries_Living.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_Living.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_Living.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_Living.DataBind();
        //}

        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("CORRECTIONSTATUS", true, "", "CodeName", true))
        //{

        //    DropDownList_CustomInquiries_CorrectionStatus.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_CorrectionStatus.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_CorrectionStatus.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_CorrectionStatus.DataBind();
        //}

        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("EDUCATIONALSTATUS", true, "", "CodeName", true))
        //{

        //    DropDownList_CustomInquiries_EducationalStatus.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_EducationalStatus.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_EducationalStatus.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_EducationalStatus.DataBind();
        //}

        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("EMPLOYMENTSTATUS", true, "", "CodeName", true))
        //{

        //    DropDownList_CustomInquiries_EmploymentStatus.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_EmploymentStatus.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_EmploymentStatus.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_EmploymentStatus.DataBind();
        //}

        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("NUMBEROFBEDS", true, "", "Code", true))
        //{

        //    DropDownList_CustomInquiries_NoOfBeds.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_NoOfBeds.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_NoOfBeds.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_NoOfBeds.DataBind();
        //}

        //using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("EPISODESTATUS", true, "", "CodeName", true))
        //{

        //    DropDownList_CustomInquiries_EpisodeStatus.DataTextField = "CodeName";
        //    DropDownList_CustomInquiries_EpisodeStatus.DataValueField = "GlobalCodeId";
        //    DropDownList_CustomInquiries_EpisodeStatus.DataSource = DataViewGlobalCodes;
        //    DropDownList_CustomInquiries_EpisodeStatus.DataBind();
        //}

        if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Counties != null)
        {
            DataView DataViewStatesName = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Counties.DefaultView;
            DataViewStatesName.Sort = "CountyName";
            DataViewStatesName.RowFilter = "StateFIPS=" + SHS.BaseLayer.SharedTables.ApplicationSharedTables.SystemConfigurations[0]["StateFIPS"].ToString();
            DropDownList_CustomInquiries_CountyOfResidence.DataTextField = "CountyName";
            DropDownList_CustomInquiries_CountyOfResidence.DataValueField = "CountyFIPS";
            DropDownList_CustomInquiries_CountyOfResidence.DataSource = DataViewStatesName;
            DropDownList_CustomInquiries_CountyOfResidence.DataBind();
            DropDownList_CustomInquiries_CountyOfResidence.Items.Insert(0, new ListItem(String.Empty, String.Empty));

            DropDownList_CustomInquiries_COFR.DataTextField = "CountyName";
            DropDownList_CustomInquiries_COFR.DataValueField = "CountyFIPS";
            DropDownList_CustomInquiries_COFR.DataSource = DataViewStatesName;
            DropDownList_CustomInquiries_COFR.DataBind();
            DropDownList_CustomInquiries_COFR.Items.Insert(0, new ListItem(String.Empty, String.Empty));

        }
    }
}
