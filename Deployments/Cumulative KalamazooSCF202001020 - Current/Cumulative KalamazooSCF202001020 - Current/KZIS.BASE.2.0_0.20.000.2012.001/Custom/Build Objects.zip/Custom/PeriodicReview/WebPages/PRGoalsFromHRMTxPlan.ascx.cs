﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using SHS.BaseLayer;
namespace SHS.SmartCare
{

    public partial class ActivityPages_Client_Detail_PeriodicReview_PRGoalsFromHRMTxPlan : SHS.BaseLayer.ActivityPages.DataActivityTab
    {

        protected void Page_Load(object sender, EventArgs e)
        {


        }

        public override void BindControls()
        {
            DataSet dataSetPR = null;
            DataView dataViewTPNeeds = null;
            int activeTabIndex = 0;
            try
            {

                if (GetRequestParameterValue("needId") == "")
                {
                    using (dataSetPR = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
                    {
                        //---------------Loads Goal 1 Tab in Periodic Review
                        if (dataSetPR.Tables["TpNeeds"] != null && dataSetPR.Tables["TpNeeds"].Rows.Count > 0)
                        {
                            activeTabIndex = ParentPageObject.TabIndex;
                            //if (dataSetPR.Tables["TpNeeds"].Select("NeedNumber=1").Length > 0)
                            //{
                            dataViewTPNeeds = new DataView(dataSetPR.Tables["TpNeeds"]);
                            //Sort On the basis of Need Number because we have show Goal on Number basis
                            dataViewTPNeeds.Sort = "NeedNumber";
                            dataViewTPNeeds.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'";

                            //===========ref#640 and ref #664 of streamline testing
                            //=========Ashwani Kumar Angrish
                            if (dataSetPR.Tables["TpNeeds"].Select("NeedNumber=" + (activeTabIndex + 1)).Length > 0)
                            {
                                dataViewTPNeeds.RowFilter = "NeedNumber=" + (activeTabIndex + 1);
                            }
                            //=======================


                            CreateGoal(dataViewTPNeeds[0]["NeedId"].ToString());
                            dataViewTPNeeds[0].BeginEdit();
                            dataViewTPNeeds[0]["SourceNeedId"] = dataViewTPNeeds[0]["NeedId"].ToString();
                            dataViewTPNeeds[0].EndEdit();

                            //}
                        }
                        else
                        {
                            StringBuilder stringBuilderHTML = null;
                            //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
                            //try
                            //{

                            stringBuilderHTML = new StringBuilder();
                            stringBuilderHTML.Append("<table width='100%' cellpadding='0' cellspacing='0' ><tr><td align='center'>");
                            stringBuilderHTML.Append("<span    style='color:red;font-size:12px;'>There is no TxPlan for this Client</span>");
                            stringBuilderHTML.Append("</td></tr></table>");
                            PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                            //}
                            //catch (Exception ex)
                            //{
                            //    //throw;
                            //}

                        }
                    }

                }
                else
                {
                    CreateGoal(GetRequestParameterValue("needId"));
                }
            }
            //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
            //catch (Exception ex)
            //{

            //}
            finally
            {
                dataSetPR = null;
                dataViewTPNeeds = null;
            }
            //throw new NotImplementedException();
        }


        /// <summary>
        /// <Description>This method is used to Read Data from TPNeeds and Create Goal Section </Description>
        /// <Author>Ashwani Kumar Angrish</Author>       
        /// <CreatedOn></CreatedOn>
        /// <Modified By >Ashwani Kumar Angrish</Author>
        /// <Modified On>8 Feb,2010</CreatedOn>
        /// </summary>
        private void CreateGoal(string needId)
        {
            DataSet dataSetPeriodicReview = null;
            DataView dataViewTPNeeds = null;
            DataRow[] dataRowTPNeeds = null;
            StringBuilder stringBuilderHTML = null;
           // DropDownList dropDownListStageOfTreatment = null;
            SHS.CustomControl.DropDownListWithTooltip dropDownListStageOfTreatment = null;
            SHS.CustomControl.DropDownListWithTooltip dropdownListGoalMonitoredBy = null;
            SHS.CustomControl.DropDownListWithTooltip dropDownListTPGoalStatus = null;
            DataRow[] dataRowTpObjective = null;
            DataRowView[] dataRowViewTPObjective = null;
            DropDownList dropdownListObjectiveStatus = null;


            DataRow[] dataRowTPInterventionProcedures = null;
            DropDownList dropdownListinterVentionFrequency = null;
            DropDownList dropdownListinterVentionProvider = null;
            DropDownList dropdownListinterVentionService = null;
            DataRow[] dataRowTPInterventionPObjective = null;
            DataRow dataRowTPProcedures = null;
            DataTable dataTableTPObjective = null;
            bool disableProcedureProvider = false;
            string agencyName = string.Empty;
            SHS.UserBusinessServices.Document objectDocuments = null;
            //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
            //try
            //{
            PanelPeriodicReviewGoal.Controls.Clear();
            int goalNumber = 1;
            using (dataSetPeriodicReview = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                //if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                //{
                //    if (dataSetTreatmentPlanHRM.Tables.Contains("TPNeeds") && dataSetTreatmentPlanHRM.Tables["TPNeeds"].Rows.Count > 0)
                //    {


                dataViewTPNeeds = new DataView(dataSetPeriodicReview.Tables["TpNeeds"]);

                dataRowTPNeeds = dataSetPeriodicReview.Tables["TpNeeds"].Select("NeedId=" + needId);
                //Loop how many rows exists in the TPNeeds table for creating Goal
                //for (int needCount = 0; needCount < dataViewTPNeeds.Count; needCount++)
                //{
                //if ((Int32)dataViewTPNeeds[needCount]["NeedId"] < 0)
                //{

                if (dataRowTPNeeds.Length > 0)
                {
                    //-----ref #664 of streamline testing
                    //-----Modified by Ashwani Kumar Angrish
                    //goalNumber = Convert.ToInt32(dataRowTPNeeds[0]["NeedNumber"]);
                    goalNumber = ParentPageObject.TabIndex + 1;
                    //-----End
                }

                //---commnented by Ashwani Kumar Angrish with ref to task 740 point 1 of SCWeb Venture Documents
                //---Commented on 14 July 2010
                //int rowNumber = dataSetPeriodicReview.Tables["TpNeeds"].Rows.IndexOf(dataRowTPNeeds[0]);


                stringBuilderHTML = new StringBuilder(); //allocation of memory
                //Create  table for Goal
                stringBuilderHTML.Append("<table style='width:100%;' border='0' cellpadding='0' cellspacing='0'>");
                #region starts main Table
                //Start -- New Code Added By Damanpreet For Create a Section
                #region 1st Main TR
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td>");
                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");

                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td align='left' nowrap='nowrap' class='content_tab_left'>");

                stringBuilderHTML.Append("<span   name=Span_TPNeeds_NeedNumber_" + goalNumber + "  id=Span_TPNeeds_NeedNumber_" + goalNumber + "' style='color:Black;font-size:11px;'  > Goal # " + goalNumber + "</span>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("<td width='17'>");
                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='17' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_sep.gif ");
                stringBuilderHTML.Append("</td>");

                stringBuilderHTML.Append("<td width='100%' class='content_tab_top'>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("<td width='7'>");
                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='7' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_right.gif ");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append(" </tr>");
                stringBuilderHTML.Append("</table>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                #endregion
                //Stop -- New Code Added By Damanpreet For Create a Section

                #region 2nd Main TR
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3' class='right_contanier_bg' style='height:5px;'>");
                stringBuilderHTML.Append("&nbsp;");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                #endregion

                #region 3rd Main TR
                //---Added By Daman

                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td class='right_contanier_bg'>");
                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                #region //1st Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td width='55px'>");
                stringBuilderHTML.Append("<span  name=Span_TPNeeds_NeedNumber_" + goalNumber + "  id=Span_TPNeeds_NeedNumber_" + goalNumber + "' style='color:Black;font-size:11px;'  > Goal # " + goalNumber + "</span>");
                stringBuilderHTML.Append("</td>");
                //stringBuilderHTML.Append("</tr>");

                //stringBuilderHTML.Append("<tr>"); 
                stringBuilderHTML.Append("<td colspan='3' align='left' >"); //1st Row 3rd Column Open Tag                              
                stringBuilderHTML.Append("<textarea tabindex='0' bindautosaveevents='False' BindSetFormData='False'   style='width:97%;' name='TextArea_TPNeeds_GoalText_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='TextArea_TPNeeds_GoalText_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' rows='2' cols='6'  class='form_textarea' disabled='disabled'>");
                if (dataRowTPNeeds[0]["GoalText"] != DBNull.Value)
                {
                    stringBuilderHTML.Append(dataRowTPNeeds[0]["GoalText"].ToString().Trim() + "</textarea>");
                }
                else
                {
                    stringBuilderHTML.Append("</textarea>");
                }
                stringBuilderHTML.Append("</td>"); //1st Row 3rd Column Close Tag
                stringBuilderHTML.Append("</tr>");
                #endregion

                #region //Blank Row Open Tag
                //To show difference between the two rows
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("&nbsp;");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                //Ended Over here
                #endregion

                #region //2nd Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td></td><td ></td>"); //2nd Row 1st & 2nd Column Open Tag/Close Tag

                stringBuilderHTML.Append("<td align='left'>"); //2nd Row 3rd Column Open Tag
                #region Inside 2nd Row 3rd Column
                stringBuilderHTML.Append("<table cellpadding='5' cellspacing='5' border='0' width='98%'>");
                stringBuilderHTML.Append("<tr>"); //1st Row Open tag

                stringBuilderHTML.Append("<td style='width:14%;padding-right:5px;' align='right'>"); //1st Row 1st Column Open Tag                               
                stringBuilderHTML.Append("<span   name='Span_GoalCreated_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Span_GoalCreated'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'>Goal Start Date</span>");
                stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag



                stringBuilderHTML.Append("<td class='date_Container' style='width:10%;' valign='middle' align='left'>"); //1st Row 2nd Column Open Tag
                stringBuilderHTML.Append("<table cellpadding='2' cellspacing='2' border='0' width='100%'>");
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td valign='top' align='left'>");
                if (dataRowTPNeeds[0]["NeedCreatedDate"] != DBNull.Value) //Peform DBNull Check
                {
                    stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False'   datatype='Date' disabled='disabled' readonly='readonly'  tabindex='0' value='" + Convert.ToDateTime(dataRowTPNeeds[0]["NeedCreatedDate"]).ToString("MM/dd/yyyy") + "'  name='Text_TPNeeds_GoalStartDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Text_TPNeeds_GoalStartDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' class='dateTextBoxWidth form_textbox' />"); //Create  
                }
                else
                {
                    stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False'  disabled='disabled'  datatype='Date' tabindex='0' readonly='readonly'  name='Text_TPNeeds_GoalStartDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Text_TPNeeds_GoalStartDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' class='dateTextBoxWidth form_textbox'/>");
                }
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("</table>");
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag

                stringBuilderHTML.Append("<td style='width:15%;' align='left'>");  
                stringBuilderHTML.Append("</td>");

                stringBuilderHTML.Append("<td style='width: 20%' align='center' >"); //1st Row 3rd Column Open Tag
                stringBuilderHTML.Append("<table cellpadding='0' border='0' cellspacing='0' width='100%'>"); //Create
                stringBuilderHTML.Append("<tr>");//1st Row Open tag

                stringBuilderHTML.Append("<td align='right' style='padding-right:5px;'>"); //1st Row 1st Column Open Tag
                stringBuilderHTML.Append("<span   name='Span_GoalActive_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id='Span_GoalActive_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  style='color:Black;font-size:11px;' >Active ?</span>"); //Create
                stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag

                stringBuilderHTML.Append("<td valign='bottom' align='right'>"); //1st Row 1st Column Open Tag                               
                string goalActive = string.Empty;
                if (dataRowTPNeeds[0]["GoalActive"] != DBNull.Value) //Peform DBNull Check
                {
                    goalActive = dataRowTPNeeds[0]["GoalActive"].ToString();//Get the value of GoalActive
                }
                if (goalActive.ToUpper() == "Y")
                {
                    stringBuilderHTML.Append("<input type='radio' bindautosaveevents='False' BindSetFormData='False'   class='RadioText'  onclick = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_Y_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\" checked='checked' id='Radio_TPNeeds_GoalActive_Y_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  name='Radio_TPNeeds_GoalActive_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  tabindex='0' value='Y'/><span   class='RadioText'> Yes</span>");
                }
                else
                {
                    stringBuilderHTML.Append("<input type='radio' bindautosaveevents='False' BindSetFormData='False'  class='RadioText'  onclick = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_Y_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\"   id='Radio_TPNeeds_GoalActive_Y_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  name='Radio_TPNeeds_GoalActive_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'   tabindex='0' value='Y'/><span   class='RadioText'> Yes</span>");
                }
                stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag

                stringBuilderHTML.Append("<td valign='middle' align='left' style='padding-left:3px'>"); //1st Row 2nd Column Open Tag
                if (goalActive.ToUpper() == "N")
                {
                    stringBuilderHTML.Append("<input type='radio' bindautosaveevents='False' BindSetFormData='False'  class='RadioText'  onclick = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_N_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\"     checked='checked' id=Radio_TPNeeds_GoalActive_N_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  name=Radio_TPNeeds_GoalActive_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  tabindex='0' value='N' /><span   class='RadioText'> No</span>");
                }
                else
                {
                    stringBuilderHTML.Append("<input type='radio' bindautosaveevents='False' BindSetFormData='False'  class='RadioText' onclick = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_N_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\"    id=Radio_TPNeeds_GoalActive_N_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  name=Radio_TPNeeds_GoalActive_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  tabindex='0' value='N' /><span   class='RadioText'> No</span>");
                }
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag

                stringBuilderHTML.Append("</tr>");//1st Row Close tag
                stringBuilderHTML.Append("</table>"); //Close
                stringBuilderHTML.Append("</td>"); //1st Row 3rd Column Close Tag

                //stringBuilderHTML.Append("<td align='left' style='width:16%; padding-left:0px;'>");  //1st Row 4rth Column Open Tag
                stringBuilderHTML.Append("<td align='right' style='padding-right:2px;width:21%' >");  //1st Row 4rth Column Open Tag
                stringBuilderHTML.Append("<span   name='Span_GoalMonitoredBy_'" + "style='color:Black;font-size:11px;'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Span_GoalMonitoredBy_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'>Monitored By</span>"); //Create
                stringBuilderHTML.Append("</td>"); //1st Row 4rth Column Close Tag                                   

               // stringBuilderHTML.Append("<td align='left'>"); //1st Row 5th Column Open Tag  
                stringBuilderHTML.Append("<td align='left' style='padding-left:2px;'>"); //1st Row 5th Column Open Tag  

                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                stringBuilderHTML = new StringBuilder();
                dropdownListGoalMonitoredBy = new SHS.CustomControl.DropDownListWithTooltip();
                dropdownListGoalMonitoredBy.Width = 129;
                dropdownListGoalMonitoredBy.CssClass = "form_dropdown";
                //dropdownListGoalMonitoredBy.ID = "DropDownList_TPNeeds_" + dataRowTPNeeds[0]["NeedId"].ToString();
                dropdownListGoalMonitoredBy.ID = "DropDownList_TPNeeds_GoalMonitoredStaff_" + dataRowTPNeeds[0]["NeedId"].ToString();


                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff != null)
                {
                    DataView dataViewStaffs = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff);
                    dataViewStaffs.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                    dropdownListGoalMonitoredBy.DataTextField = "StaffName";
                    dropdownListGoalMonitoredBy.DataValueField = "StaffId";
                    dropdownListGoalMonitoredBy.DataSource = dataViewStaffs;
                    dropdownListGoalMonitoredBy.DataBind();
                    dropdownListGoalMonitoredBy.Items.Insert(0, "");
                    //dropdownListGoalMonitoredBy.Items.Insert(0, new ListItem("Other - Specify Below", ""));
                }
                //if (dataRowTPNeeds[0]["GoalMonitoredStaff"] != DBNull.Value)
                //{
                //    dropdownListGoalMonitoredBy.SelectedValue = Convert.ToString(dataRowTPNeeds[0]["GoalMonitoredStaff"]);
                //}
                if (dataRowTPNeeds[0]["GoalMonitoredStaff"] != DBNull.Value)
                {
                    dropdownListGoalMonitoredBy.SelectedValue = Convert.ToString(dataRowTPNeeds[0]["GoalMonitoredStaff"]);
                }
                else if (dataRowTPNeeds[0]["GoalMonitoredStaffOtherCheckbox"] != DBNull.Value && Convert.ToString(dataRowTPNeeds[0]["GoalMonitoredStaffOtherCheckbox"]) == "Y")
                    {
                        dropdownListGoalMonitoredBy.Attributes.Add("disabled", "disabled");
                    }
                PanelPeriodicReviewGoal.Controls.Add(dropdownListGoalMonitoredBy);
                //dropdownListGoalMonitoredBy.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredBy" + "','" + dropdownListGoalMonitoredBy.ClientID + "','" + "Edit" + "','" + "NeedId" + "');");
                //dropdownListGoalMonitoredBy.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredStaff" + "','" + dropdownListGoalMonitoredBy.ClientID + "','" + "Edit" + "','" + "NeedId" + "');");
                dropdownListGoalMonitoredBy.Attributes.Add("onChange", "ChangeOtherFields(this," + dataRowTPNeeds[0]["NeedId"].ToString() + ");PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredStaff" + "','" + dropdownListGoalMonitoredBy.ClientID + "','" + "Edit" + "','" + "NeedId" + "');");

                dropdownListGoalMonitoredBy.Attributes.Add("BindAutoSaveEvents", "False");
                dropdownListGoalMonitoredBy.Attributes.Add("BindSetFormData", "False");
                               
                #region Commented By Rakesh For UM Part 2
                //stringBuilderHTML.Append("<table width='100%' cellpadding='2' cellspacing='2' border='0'>");
                //stringBuilderHTML.Append("<tr>");
                //stringBuilderHTML.Append("<td align='left'>");
                //if (dataRowTPNeeds[0]["GoalMonitoredBy"] != DBNull.Value)
                //{
                //    stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False'   tabindex='0' class='form_textbox'   onchange = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalMonitoredBy','TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\"   maxlength='127'  name=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  value='" + dataRowTPNeeds[0]["GoalMonitoredBy"].ToString() + "' />");
                //}
                //else
                //{
                //    stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False'  tabindex='0' class='form_textbox'   onchange = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalMonitoredBy','TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\"   maxlength='127'  name=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  />");
                //}
                //stringBuilderHTML.Append("</td>");
                //stringBuilderHTML.Append("</tr>");
                //stringBuilderHTML.Append("</table>");
                #endregion

                stringBuilderHTML.Append("</td>"); //1st Row 5th Column Close Tag

                //Changes Start here with ref to task 187
                stringBuilderHTML.Append("<td style='width:12%'>");//1st Row 6th Column Open Tag
                stringBuilderHTML.Append("<table cellpading=0 cellspacing=0><tr class='checkbox_container'>");
                stringBuilderHTML.Append("<td align='left' style='padding-left:2px;'>");
                if (dataRowTPNeeds[0]["GoalMonitoredStaffOtherCheckbox"] != DBNull.Value && dataRowTPNeeds[0]["GoalMonitoredStaffOtherCheckbox"].ToString() != "N")
                {
                    stringBuilderHTML.Append("<input id='CheckBox_TPNeeds_GoalMonitoredStaffOtherCheckbox_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' name='CheckBox_TPNeeds_GoalMonitoredStaffOtherCheckbox_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' type='checkbox' checked='checked' onclick=EnableDisable_GoalMonitoredStaffOther(this,'" + dataRowTPNeeds[0]["NeedId"].ToString() + "') BindAutoSaveEvents ='False'  BindSetFormData='False' />");
                }
                else
                //    if (dataRowViewTPNeeds["GoalMonitoredStaff"] != DBNull.Value)
                {
                    stringBuilderHTML.Append("<input id='CheckBox_TPNeeds_GoalMonitoredStaffOtherCheckbox_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' name='CheckBox_TPNeeds_GoalMonitoredStaffOtherCheckbox_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' type='checkbox' onclick=EnableDisable_GoalMonitoredStaffOther(this,'" + dataRowTPNeeds[0]["NeedId"].ToString() + "') BindAutoSaveEvents ='False'  BindSetFormData='False' />");
                }
                //else
                //{
                //    stringBuilderHTML.Append("<input id='CheckBox_TPNeeds_GoalMonitoredStaffOtherCheckbox_" + dataRowViewTPNeeds["NeedId"].ToString() + "' name='CheckBox_TPNeeds_GoalMonitoredStaffOtherCheckbox_" + dataRowViewTPNeeds["NeedId"].ToString() + "' type='checkbox' checked='checked' onclick=EnableDisable_GoalMonitoredStaffOther(this,'" + dataRowViewTPNeeds["NeedId"].ToString() + "') BindAutoSaveEvents ='False'  BindSetFormData='False' />");
                //}
                stringBuilderHTML.Append("</td>");



                stringBuilderHTML.Append("<td align='left' style='padding-left:2px;'>"); //1st Row 7th Column Open Tag                              
                stringBuilderHTML.Append("<label for='CheckBox_TPNeeds_GoalMonitoredStaffOtherCheckbox_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' class='form_label'>Other</label>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr></table>");

                stringBuilderHTML.Append("</td>"); //1st Row 6th Column Close Tag


                //changes end here 




                stringBuilderHTML.Append("</tr>"); //1st Row Open tag
                stringBuilderHTML.Append("</table>");
                #endregion
                stringBuilderHTML.Append("</td>"); //2nd Row 3rd Column Close Tag
                stringBuilderHTML.Append("</tr>"); //2nd Row Close Tag
                #endregion

                #region //Blank Row Open Tag
                //To show difference between the two rows
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                //Ended Over here
                #endregion

                #region  //3rd Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td  colspan='2'></td>"); //3rd Row 1st & 2nd Column Open Tag/Close Tag
                stringBuilderHTML.Append("<td align='left'>"); //3rd Row 3rd Column Open Tag
                #region Inside 3rd Row 3rd Column
                stringBuilderHTML.Append("<table cellpadding='5' cellspacing='5' border='0' width='98%'>"); //Create
                stringBuilderHTML.Append("<tr>"); //1st Row Open tag

                stringBuilderHTML.Append("<td style='width:12%;padding-right:5px;' align='right' valign='middle'>"); //1st Row 1st Open Col tag
                stringBuilderHTML.Append("<span   name='Span_GoalTarget_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Span_GoalTarget_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'  >Goal Target Date</span>"); //Create
                stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close tag

                stringBuilderHTML.Append("<td style='width:24%'>"); //1st Row 2nd  Col Open tag
                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0'>"); //Create
                stringBuilderHTML.Append("<tr class='date_Container'>"); //1st Row Open tag

                stringBuilderHTML.Append("<td style='padding-left:2px;'>"); //1st Row 1st Col Open tag
                if (dataRowTPNeeds[0]["GoalTargetDate"] != DBNull.Value) //Perform Check for GoalTarget Date
                {
                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'   type='text' datatype='Date' tabindex='0'  class='dateTextBoxWidth form_textbox' value='" + Convert.ToDateTime(dataRowTPNeeds[0]["GoalTargetDate"]).ToString("MM/dd/yyyy") + "'   name=Text_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=Text_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + " class='form_textbox' onchange=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalTargetDate','Text_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\" />"); //Create  
                }
                else
                {
                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'   type='text' datatype='Date' tabindex='0'  class='dateTextBoxWidth form_textbox'  name=Text_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=Text_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + " class='form_textbox' onchange=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalTargetDate','Text_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\" />"); //Create  
                }
                stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close tag

                stringBuilderHTML.Append("<td align='center>");  //1st Row 2nd Col Open tag
                stringBuilderHTML.Append("&nbsp;<img style='cursor:hand;' id=Img_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + " name=Img_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  src=" + RelativePath + "App_Themes/Includes/Images/calender_grey.gif  style='cursor:hand;' onclick=\"return showCalendar('Text_TPNeeds_GoalTargetDate_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','%m/%d/%Y');\"/>"); //Create 
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close tag  

                stringBuilderHTML.Append("</tr>"); //1st Row Close tag
                stringBuilderHTML.Append("</table>"); //Close tag
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Col  Close tag

                //Changes Start here Modified By Rakesh With Ref to ticket 188 UM Part 2 (Need Stage of Treatment Icon)
                //stringBuilderHTML.Append("<td style='width:15%' align='left'>&nbsp;</td>");//1st Row 3rd Col Open/Close tag 
                //stringBuilderHTML.Append("<td style='width:16%' align='left'>");//1st Row 4rth Col Open tag

                stringBuilderHTML.Append("<td style='width:0%' align='left'>&nbsp;</td>");//1st Row 3rd Col Open/Close tag 
                stringBuilderHTML.Append("<td style='width:17%;' align='left'>");//1st Row 4rth Col Open tag

                stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0'>");
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td>");
                //Modified by Rakesh - 19-Sep-2011 Ref Task 194 in SC web phase II bugs/Features Treatment Plan: Tx Plan Main - "i" icons change image to help link
                stringBuilderHTML.Append("<span id='Img_TPNeeds_StageOfTreatment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' name='Img_TPNeeds_StageOfTreatment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' onclick = 'OpenStageofTreatmentPopUp();' class='span_textunderline_cursor' style='color: #0000FF'>Help</span>");
               // stringBuilderHTML.Append("<img id=Img_TPNeeds_StageOfTreatment_" + dataRowTPNeeds[0]["NeedId"].ToString() + " name=Img_TPNeeds_StageOfTreatment_" + dataRowTPNeeds[0]["NeedId"].ToString() + " onclick = 'OpenStageofTreatmentPopUp();'  src=" + RelativePath + "App_Themes/Includes/Images/info.png  style='cursor:hand;','%m/%d/%Y');\" />");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("<td>");

                stringBuilderHTML.Append("&nbsp;<span   name=Span_StageOfTreatment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=Span_StageOfTreatment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'  >Stage of Treatment</span>"); //Create
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("</table>");

                stringBuilderHTML.Append("</td>"); //1st Row 4rth Col Close tag  

                //stringBuilderHTML.Append("<td style='width:40%;padding-left:0px;'>");//1st Row 5th Col Open tag  
                stringBuilderHTML.Append("<td style='width:26%;padding-right:5px;' align='left'>");//1st Row 5th Col Open tag  
                //Changes End here

                stringBuilderHTML.Append("<table width='100%' cellpadding='2' cellspacing='2' border='0'>");
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td>");
                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                //Create Asp DropDown Control
                dropDownListStageOfTreatment = new SHS.CustomControl.DropDownListWithTooltip();
                dropDownListStageOfTreatment.ID = "DropDownList_GlobalCodes_" + dataRowTPNeeds[0]["NeedId"].ToString();
                dropDownListStageOfTreatment.Width = 128;
                dropDownListStageOfTreatment.CssClass = "form_dropdown";
                using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("StageOfTreatment", true, "", "SortOrder", false))
                {
                    dropDownListStageOfTreatment.DataTextField = "CodeName";
                    dropDownListStageOfTreatment.DataValueField = "GlobalCodeId";
                    dropDownListStageOfTreatment.DataSource = DataViewGlobalCodes;
                    dropDownListStageOfTreatment.DataBind();
                    dropDownListStageOfTreatment.Items.Insert(0, "");

                }
                if (dataRowTPNeeds[0]["StageOfTreatment"] != DBNull.Value)
                {
                    dropDownListStageOfTreatment.SelectedValue = dataRowTPNeeds[0]["StageOfTreatment"].ToString();
                }
                PanelPeriodicReviewGoal.Controls.Add(dropDownListStageOfTreatment);
                dropDownListStageOfTreatment.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','StageOfTreatment','" + dropDownListStageOfTreatment.ClientID + "','Edit','NeedId');");
                dropDownListStageOfTreatment.Attributes.Add("bindautosaveevents", "False");
                dropDownListStageOfTreatment.Attributes.Add("BindSetFormData", "False");
                stringBuilderHTML = new StringBuilder();
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("</table>");

                stringBuilderHTML.Append("</td>");//1st Row 5th Col Close tag 
                // changes start here added by Rakesh 06 April For Textbox for UM Part 2
                //stringBuilderHTML.Append("<td style='padding-right:5px;' align='left'>");//1st Row 6rth Col Open tag
                //if (dataRowTPNeeds[0]["GoalMonitoredBy"] != DBNull.Value)
                //{
                //    stringBuilderHTML.Append("<input type='text' class='form_textbox' BindAutoSaveEvents ='False'  BindSetFormData='False'  onChange = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredBy" + "','" + "TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"   maxlength='127'  name=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  value='" + dataRowTPNeeds[0]["GoalMonitoredBy"].ToString() + "' />");
                //}
                //else
                //{
                //    stringBuilderHTML.Append("<input type='text' class='form_textbox' BindAutoSaveEvents ='False'  BindSetFormData='False' onChange = \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredBy" + "','" + "TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"   maxlength='127'  name=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  />");
                //}

                //stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("<td style='padding-right:5px;' align='left'>");//1st Row 6rth Col Open tag
                if (dataRowTPNeeds[0]["GoalMonitoredStaffOther"] != DBNull.Value)
                {
                    stringBuilderHTML.Append("<input type='text' class='form_textbox' BindAutoSaveEvents ='False'  BindSetFormData='False'  onChange = \"ChangeOtherFields(this," + dataRowTPNeeds[0]["NeedId"].ToString() + ");PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredStaffOther" + "','" + "TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"   maxlength='127'  name='TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  value='" + dataRowTPNeeds[0]["GoalMonitoredStaffOther"].ToString() + "' />");
                }
                else
                {
                    if (dataRowTPNeeds[0]["GoalMonitoredStaffOtherCheckbox"] != DBNull.Value && Convert.ToString(dataRowTPNeeds[0]["GoalMonitoredStaffOtherCheckbox"]) == "Y")
                    {
                        stringBuilderHTML.Append("<input type='text' class='form_textbox' BindAutoSaveEvents ='False'  BindSetFormData='False' onChange = \"ChangeOtherFields(this," + dataRowTPNeeds[0]["NeedId"].ToString() + ");PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredStaffOther" + "','" + "TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"   maxlength='127'  name='TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' />");
                    }
                    else
                    {

                        stringBuilderHTML.Append("<input type='text' class='form_textbox' BindAutoSaveEvents ='False'  BindSetFormData='False' onChange = \"ChangeOtherFields(this," + dataRowTPNeeds[0]["NeedId"].ToString() + ");PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalMonitoredStaffOther" + "','" + "TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"   maxlength='127'  name='TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='TextBox_TPNeeds_GoalMonitoredStaffOther_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' disabled='disabled' />");
                    }
                }

                stringBuilderHTML.Append("</td>");
                // changes end here
                stringBuilderHTML.Append("</tr>"); //1st Row Close tag
                stringBuilderHTML.Append("</table>"); //Close

                #endregion

                stringBuilderHTML.Append("</td>"); //3rd Row 3rd Column Close Tag
                stringBuilderHTML.Append("</tr>"); //3rd Row Close Tag
                #endregion

                #region //Blank Row Open Tag
                //To show difference between the two rows
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("&nbsp;");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                //Ended Over here
                #endregion

                #region //4rth Row Open Tag
                stringBuilderHTML.Append("<tr>");

                stringBuilderHTML.Append("<td></td>"); //4rth Row 1st & 2nd Column Open Tag/Close Tag
                stringBuilderHTML.Append("<td align='left' colspan='2'>"); //4rth Row 3rd Column Open Tag
                #region 4rth Row 3rd Column

                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='98%'>"); //Create
                stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                stringBuilderHTML.Append("<td  style='width:1%' align='left' valign='Top'>"); //1st Row 1st Col Open tag
                stringBuilderHTML.Append("<span   name='Span_AssociatedNeeds_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Span_AssociatedNeeds_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'>Associated Needs</span>"); //Create 
                stringBuilderHTML.Append("</td>");

                stringBuilderHTML.Append("<td  rowspan='2' valign='top' width='40%'>"); //1st Row 2nd Col Open tag
                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='100%'>"); //Create
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td valign='top'>");
                #region for ListBox Control
                DataTable dataTableResult = new DataTable("Result");
                dataTableResult.Columns.Add("TPNeedsClientNeedId", typeof(int));
                dataTableResult.Columns.Add("NeedName", typeof(string));

                DataView dataViewCustomTPNeedsClientNeeds = new DataView(dataSetPeriodicReview.Tables["CustomTPNeedsClientNeeds"]);

                dataViewCustomTPNeedsClientNeeds.RowFilter = "NeedId=" + Convert.ToString(dataRowTPNeeds[0]["NeedId"]) + " and IsNull(RecordDeleted,'N')<>'Y'";

                //performs join between table.
                string needDescription = string.Empty;
                //   for (int i = 0; i < dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView.Count; i++)
                for (int i = 0; i < dataViewCustomTPNeedsClientNeeds.Count; i++)
                {
                    //DataRow parent = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i].Row.GetParentRow("ClientNeeds_TPNeedsClientNeeds_FK");

                    //DataRow parent = dataViewCustomTPNeedsClientNeeds[i].Row.GetParentRow("ClientNeeds_TPNeedsClientNeeds_FK");
                    DataRow parent = dataViewCustomTPNeedsClientNeeds[i].Row.GetParentRow("CustomClientNeeds_CustomTPNeedsClientNeeds_FK");
                    DataRow newRow = dataTableResult.NewRow();
                    if (parent != null && newRow != null)
                    {
                        //newRow["TPNeedsClientNeedId"] = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i].Row["TPNeedsClientNeedId"];

                        newRow["TPNeedsClientNeedId"] = dataViewCustomTPNeedsClientNeeds[i].Row["TPNeedsClientNeedId"];

                        //DataRowView drneedDescription = (DataRowView)dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i];
                        DataRowView drneedDescription = (DataRowView)dataViewCustomTPNeedsClientNeeds[i];
                        if (!string.IsNullOrEmpty(drneedDescription["NeedDescription"].ToString()))
                        {
                            needDescription = parent["NeedName"] + " - " + drneedDescription["NeedDescription"];
                        }
                        else
                        {
                            needDescription = parent["NeedName"].ToString();
                        }
                        if (needDescription.Length >= 120)
                        {
                            needDescription = BaseCommonFunctions.cutText(needDescription, 120);
                            needDescription = needDescription + "...";
                        }
                        newRow["NeedName"] = needDescription;
                        dataTableResult.Rows.Add(newRow);
                    }
                }
                #endregion
                #region AssoicatedNeed
                //Create Div
                stringBuilderHTML.Append("<div  id=div_CustomClientNeeds_NeedName_" + dataRowTPNeeds[0]["NeedId"].ToString() + " style='width: 100%;'>");
                stringBuilderHTML.Append("<select bindautosaveevents='False' BindSetFormData='False'   class='form_textarea' multiple='multiple' size='2' style='width:100%;' readonly='readonly'>");
                for (int tpneedClientNeedCount = 0; tpneedClientNeedCount < dataTableResult.Rows.Count; tpneedClientNeedCount++)
                {
                    stringBuilderHTML.Append("<option value= " + dataTableResult.Rows[tpneedClientNeedCount]["TPNeedsClientNeedId"].ToString() + ">");
                    stringBuilderHTML.Append(dataTableResult.Rows[tpneedClientNeedCount]["NeedName"].ToString() + "</option>");
                }

                stringBuilderHTML.Append("</select>");
                stringBuilderHTML.Append("</div>");
                #endregion
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");

                stringBuilderHTML.Append("</table>"); //Create
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close tag

                // dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView.RowFilter = string.Empty; //Clear the filter

                stringBuilderHTML.Append("</tr>"); //1st Row Close Tag

                stringBuilderHTML.Append("<tr>"); //2nd Row Open Tag
                stringBuilderHTML.Append("<td align='left'  valign='top' style='width:15%' >"); //2nd Row 1st Col Open Tag                               
                //-----Commneted on 8 Feb
                //stringBuilderHTML.Append("<span  name=Span_EditAssociatedNeed_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=Span_EditAssociatedNeed_" + dataRowTPNeeds[0]["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueforAssociatedNeeds('" + "div_CustomClientNeeds_NeedName_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + dataRowTPNeeds[0]["NeedNumber"].ToString() + "')\" ><B>Edit</B></span>"); //Create
                //-----Commneted on 8 Feb
                stringBuilderHTML.Append("</td>"); //2nd Row 1st Col Close Tag
                stringBuilderHTML.Append("</tr>"); //2nd Row Close Tag

                stringBuilderHTML.Append("</table>");
                #endregion
                stringBuilderHTML.Append("</td>"); //4rth Row 3rd Column Close Tag
                stringBuilderHTML.Append("</tr>"); //4rh Row Close Tag
                #endregion

                #region //Blank Row Open Tag
                //To show difference between the two rows
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("&nbsp;");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                //Ended Over here
                #endregion

                #region //5th Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td ></td>"); //5th Row 1st & 2nd Column Open Tag/Close Tag

                stringBuilderHTML.Append("<td align='left' colspan='2'>"); //5th Row 3rd Column Open Tag
                #region Inside 5th Row 3rd Column
                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='98%'>"); //Create
                stringBuilderHTML.Append("<tr>"); //1st Row  Open Tag

                stringBuilderHTML.Append("<td style='width:23%' valign='top' align='left'>"); //1st Row 1st Column Open tag
                stringBuilderHTML.Append("<span   name=Span_StrengthsPertinenttoGoal_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id=Span_StrengthsPertinenttoGoal_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "' style='color:Black;font-size:11px;' >Strengths pertinent to this goal</span>"); //Create
                stringBuilderHTML.Append("</td>");  //1st Row 1st Column Close tag

                stringBuilderHTML.Append("<td align='right'>");  //1st Row 2nd Column  tag
                stringBuilderHTML.Append("<textarea spellcheck='True' onchange=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalStrengths','TextArea_TPNeeds_GoalStrengths_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\"   name='TextArea_TPNeeds_GoalStrengths_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='TextArea_TPNeeds_GoalStrengths_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' rows='2' cols='120' class='form_textareaWithoutWidth' bindautosaveevents='False' BindSetFormData='False' >"); //Create   
                if (dataRowTPNeeds[0]["GoalStrengths"] != DBNull.Value)
                {
                    stringBuilderHTML.Append(dataRowTPNeeds[0]["GoalStrengths"].ToString() + " </textarea>");
                }
                else
                {
                    stringBuilderHTML.Append("</textarea>");
                }
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Column tag
                stringBuilderHTML.Append("<tr>"); //1st Row Close Tag
                stringBuilderHTML.Append("</table>");
                #endregion
                stringBuilderHTML.Append("</td>"); //5th Row 3rd Column Close Tag
                stringBuilderHTML.Append("</tr>"); //5th Row Close Tag
                #endregion

                #region //Blank Row Open Tag
                //To show difference between the two rows
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("&nbsp;");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                //Ended Over here
                #endregion

                #region //6th Row Open Tag
                //----RECENTLY ADDED
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td ></td>"); //6th Row 1st & 2nd Column Open Tag/Close Tag

                stringBuilderHTML.Append("<td align='left' colspan='2'>"); //6th Row 3rd Column Open Tag
                #region Inside 6th Row 3rd Column
                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' width='98%'>"); //Create
                stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                stringBuilderHTML.Append("<td style='width:23%' valign='top' align='left'>"); //1st Row 1st Col Open Tag
                stringBuilderHTML.Append("<span   name=Span_BarriersPertinenttoGoal_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id=Span_BarriersPertinenttoGoal_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "' style='color:Black;font-size:11px;'  > Barriers pertinent to this goal</span>"); //Create 
                stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close Tag

                stringBuilderHTML.Append("<td align='right'>"); //1st Row 2nd Col Open Tag

                stringBuilderHTML.Append("<textarea  onchange=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','TPNeeds','GoalBarriers','TextArea_TPNeeds_GoalBarriers_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\"  name='TextArea_TPNeeds_GoalBarriers_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='TextArea_TPNeeds_GoalBarriers_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' rows='2' cols='120' class='form_textareaWithoutWidth' bindautosaveevents='False' BindSetFormData='False'   spellcheck='True'>"); //Create           

                if (dataRowTPNeeds[0]["GoalBarriers"] != DBNull.Value)
                {
                    stringBuilderHTML.Append(dataRowTPNeeds[0]["GoalBarriers"].ToString() + " </textarea>");
                }
                else
                {
                    stringBuilderHTML.Append("</textarea>");
                }
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Open Tag

                stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                stringBuilderHTML.Append("</table>");

                #endregion
                stringBuilderHTML.Append("</td>"); //6th Row 3rd Column Close Tag
                stringBuilderHTML.Append("</tr>"); //6th Row Close Tag

                //To show difference between the two rows
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("&nbsp;");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                //Ended Over here
                #endregion


                #region //7th Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td ></td>"); //7th Row 1st & 2nd Column Open Tag/Close Tag
                stringBuilderHTML.Append("<td align='left' colspan='2'>"); //7th Row 3rd Column Open Tag

                #region 7th Row 3rd Column

                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='70%'>"); //Create
                stringBuilderHTML.Append("<tr class='checkbox_container'>"); //1st Row Open Tag

                stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>"); //1st Row 1st Column  Open Tag
                if (dataRowTPNeeds[0]["GoalNaturalSupports"] != DBNull.Value && dataRowTPNeeds[0]["GoalNaturalSupports"].ToString().ToUpper() == "Y")
                {
                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'   type='checkbox' disabled='disabled' checked='checked' onclick=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalNaturalSupports" + "','" + "CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"  name=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowTPNeeds[0]["NeedId"].ToString() + " /> <span disabled='disabled'> associated with natural support</span>"); //Create  
                }
                else
                {
                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'   type='checkbox' disabled='disabled' onclick=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalNaturalSupports" + "','" + "CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"  name=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowTPNeeds[0]["NeedId"].ToString() + " /><span disabled='disabled'>  associated with natural support</span>"); //Create  
                }
                stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag

                stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>"); //1st Row 2nd Column  Open Tag
                if (dataRowTPNeeds[0]["GoalNaturalSupports"] != DBNull.Value && dataRowTPNeeds[0]["GoalEmployment"].ToString().ToUpper() == "Y")
                {
                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'   type='checkbox' disabled='disabled' checked='checked' onclick= \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalEmployment" + "','" + "CheckBox_TPNeeds_GoalEmployment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"  name=CheckBox_TPNeeds_GoalEmployment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalEmployment_" + dataRowTPNeeds[0]["NeedId"].ToString() + " /> <span disabled='disabled'> associated with employment</span>"); //Create  
                }
                else
                {
                    stringBuilderHTML.Append("<input  bindautosaveevents='False' BindSetFormData='False'  type='checkbox' disabled='disabled' onclick=  \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalEmployment" + "','" + "CheckBox_TPNeeds_GoalEmployment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"  name=CheckBox_TPNeeds_GoalEmployment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalEmployment_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  />  <span disabled='disabled'>associated with employment</span>"); //Create  
                }
                stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag
                stringBuilderHTML.Append("</tr>"); //1st Row Close Tag

                stringBuilderHTML.Append("<tr class='checkbox_container'>"); //2nd Row Open Tag

                stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>"); //2nd Row 1st Col Open Tag
                if (dataRowTPNeeds[0]["GoalLivingArrangement"] != DBNull.Value && dataRowTPNeeds[0]["GoalLivingArrangement"].ToString().ToUpper() == "Y")
                {
                    stringBuilderHTML.Append("<input  bindautosaveevents='False' BindSetFormData='False'  type='checkbox' disabled='disabled' onclick=  \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalLivingArrangement" + "','" + "CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"    checked='checked'  name=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowTPNeeds[0]["NeedId"].ToString() + " /> <span disabled='disabled'> associated with  living arrangements</span>"); //Create                     
                }
                else
                {
                    stringBuilderHTML.Append("<input  bindautosaveevents='False' BindSetFormData='False'  type='checkbox' disabled='disabled' onclick=  \"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalLivingArrangement" + "','" + "CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"     name=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowTPNeeds[0]["NeedId"].ToString() + " /> <span disabled='disabled'> associated with  living arrangements</span>"); //Create
                }
                stringBuilderHTML.Append("</td>");//2nd Row 1st Col Close Tag

                stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>");//2nd Row 2nd Col Open Tag
                if (dataRowTPNeeds[0]["GoalHealthSafety"] != DBNull.Value && dataRowTPNeeds[0]["GoalHealthSafety"].ToString().ToUpper() == "Y")
                {
                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'   type='checkbox' disabled='disabled' onclick=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalHealthSafety" + "','" + "CheckBox_TPNeeds_GoalHealthSafety_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"   checked='checked' name=CheckBox_TPNeeds_GoalHealthSafety_'" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id=CheckBox_TPNeeds_GoalHealthSafety_" + dataRowTPNeeds[0]["NeedId"].ToString() + " /> <span disabled='disabled'> associated with CLS/Club House</span>"); //Create                     
                }
                else
                {
                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'   type='checkbox' disabled='disabled' onclick=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalHealthSafety" + "','" + "CheckBox_TPNeeds_GoalHealthSafety_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"     name=CheckBox_TPNeeds_GoalHealthSafety_" + dataRowTPNeeds[0]["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalHealthSafety_" + dataRowTPNeeds[0]["NeedId"].ToString() + " /> <span disabled='disabled'> associated with CLS/Club House</span>"); //Create
                }
                stringBuilderHTML.Append("</td>");//2nd Row 2nd Col Close Tag
                stringBuilderHTML.Append("</tr>"); //2nd Row Close Tag
                stringBuilderHTML.Append("</table>");
                #endregion
                stringBuilderHTML.Append("</td>"); //7th Row 3rd Column Close Tag
                stringBuilderHTML.Append("</tr>"); //7th Row Close Tag
                #endregion

                #region //Blank Row Open Tag
                //To show difference between the two rows
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("&nbsp;");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                //Ended Over here
                #endregion

                #region // 8th Row Open Tag Review Section
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='100%'>");
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td>");
                //stringBuilderHTML.Append("<span   name='Span_TPNeeds_NeedNumber_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Span_TPNeeds_NeedNumber_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' style='color:Black;font-size:11px;'  >Review For Goal # " + goalNumber + "</span>");
                //Changes Start
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td>");
                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' align='left'>");
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td>");
                stringBuilderHTML.Append("<span   name='Span_TPNeeds_NeedNumber_" + dataRowTPNeeds[0]["NeedId"].ToString() + "'  id='Span_TPNeeds_NeedNumber_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' style='color:Black;font-size:11px;padding-right:10px;'  >Review For Goal # " + goalNumber + "</span>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("<td>");
                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                dropDownListTPGoalStatus = new SHS.CustomControl.DropDownListWithTooltip();
                dropDownListTPGoalStatus.ID = "DropDownList_PeriodicReviewNeeds_ReviewProgress_" + dataRowTPNeeds[0]["NeedId"].ToString();
                dropDownListTPGoalStatus.Attributes.Add("onchange", "PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','PeriodicReviewNeeds','ReviewProgress','DropDownList_PeriodicReviewNeeds_ReviewProgress_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');");
                dropDownListTPGoalStatus.Attributes.Add("bindautosaveevents", "False");
                dropDownListTPGoalStatus.Attributes.Add("BindSetFormData", "False");
                dropDownListTPGoalStatus.Width = 128;
                dropDownListTPGoalStatus.CssClass = "form_dropdown";
                using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPGOALSTATUS", true, "", "SortOrder", false))
                {
                    dropDownListTPGoalStatus.DataTextField = "CodeName";
                    dropDownListTPGoalStatus.DataValueField = "GlobalCodeId";
                    dropDownListTPGoalStatus.DataSource = DataViewGlobalCodes;
                    dropDownListTPGoalStatus.DataBind();
                    dropDownListTPGoalStatus.Items.Insert(0, "");
                }
                PanelPeriodicReviewGoal.Controls.Add(dropDownListTPGoalStatus);
                stringBuilderHTML = new StringBuilder();
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("</table>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td style='height:3px;'>");
                //Changes End
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");

                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td>");
                stringBuilderHTML.Append("<textarea style='overflow-x:hidden;' bindautosaveevents='False' BindSetFormData='False'  id='TextArea_PeriodicReviewNeeds_Review_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' name='TextArea_PeriodicReviewNeeds_Review_" + dataRowTPNeeds[0]["NeedId"].ToString() + "' cols='160' rows='2' spellcheck='True' class='form_textareaWithoutWidth' onchange=\"PRModifyGoalValueInDataSet('" + dataRowTPNeeds[0]["NeedId"].ToString() + "','PeriodicReviewNeeds','Review','TextArea_PeriodicReviewNeeds_Review_" + dataRowTPNeeds[0]["NeedId"].ToString() + "','Edit','NeedId');\" >");
                if (BaseCommonFunctions.CheckRowExists(dataSetPeriodicReview.Tables["PeriodicReviewNeeds"], 0))
                {
                    DataRow[] dataRowReview = dataSetPeriodicReview.Tables["PeriodicReviewNeeds"].Select("NeedId=" + dataRowTPNeeds[0]["NeedId"].ToString() + " and IsNull(RecordDeleted,'N')='N'");
                    if (dataRowReview.Length > 0)
                    {
                        stringBuilderHTML.Append(dataRowReview[0]["Review"].ToString() + " </textarea>");
                        dropDownListTPGoalStatus.SelectedValue = dataRowReview[0]["ReviewProgress"].ToString();
                    }
                    else
                        stringBuilderHTML.Append("</textarea>");
                }
                else
                {
                    stringBuilderHTML.Append("</textarea>");
                }


                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("</table>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");

                #endregion Review Section

                #region //Blank Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3' style='height:10px;'>");
                #region //Added Blank Row By Daman
                stringBuilderHTML.Append("&nbsp;");
                #endregion
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                #endregion

                #region // 9th Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");

                #region Create Objective
                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='100%'>");

                //CreateObjective(Convert.ToInt32(dataRowTPNeeds[0]["NeedId"]), Convert.ToInt32(dataRowTPNeeds[0]["NeedNumber"]), ref dataSetTreatmentPlanHRM);
                if (dataSetPeriodicReview.Tables.Contains("TPobjectives")) //Perform Table contain Check
                {

                    if (dataSetPeriodicReview.Tables["TPobjectives"].Rows.Count > 0)
                    {

                        //Find out the Number of Objectives Corresponding to a Need
                        dataRowTpObjective = dataSetPeriodicReview.Tables["TPObjectives"].Select("Isnull(RecordDeleted,'N' )<>'Y' and NeedId=" + Convert.ToInt32(dataRowTPNeeds[0]["NeedId"]) + "", "ObjectiveNumber Asc");
                        if (dataRowTpObjective.Length > 0)
                        {
                            Double objectiveNumber = 0;
                            for (int objectiveCount = 0; objectiveCount < dataRowTpObjective.Length; objectiveCount++)
                            {

                                DataView dataViewTPObjectives = new DataView(dataSetPeriodicReview.Tables["TPobjectives"]);
                                dataViewTPObjectives.Sort = "ObjectiveId Asc";
                                dataRowViewTPObjective = dataViewTPObjectives.FindRows(dataRowTpObjective[objectiveCount]["ObjectiveId"]);
                                objectiveNumber = Convert.ToDouble(dataRowViewTPObjective[0]["ObjectiveNumber"].ToString());
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td width='13%' valign='top'>");
                                stringBuilderHTML.Append("<span bindautosaveevents='False' BindSetFormData='False'   style='color:Black;font-size:11px;' + name=Span_TPObjectives_ObjectiveId_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_TPNeeds_NeedNumber_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + ">Objective" + objectiveNumber.ToString("0.00") + "</span>");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<textarea  name='TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "'  id='TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "' bindautosaveevents='False' BindSetFormData='False'  rows='2' cols='8' style='width: 98%' disabled='disabled' class='form_textarea' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TPObjectives" + "','" + "ObjectiveText" + "','" + "TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "Edit" + "','" + "ObjectiveId" + "');\" >");
                                if (dataRowViewTPObjective[0]["ObjectiveText"] != DBNull.Value)
                                {
                                    stringBuilderHTML.Append(dataRowViewTPObjective[0]["ObjectiveText"].ToString() + "</textarea>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("</textarea>");
                                }
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td colspan='2' style='height:5px;' >");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table width='100%' cellpadding='0' cellspacing='0' border='0'>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td width='10%' valign='middle'>");
                                stringBuilderHTML.Append("<span bindautosaveevents='False' BindSetFormData='False'   name=Span_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='color:Black;font-size:11px;'>Target Date</span>");

                                stringBuilderHTML.Append("</td>");
                                // Added by Nisha 'width=10%'
                                stringBuilderHTML.Append("<td align='left' width='10%'>");//1st Row  2nd Col Open Tag
                                if (dataRowViewTPObjective[0]["TargetDate"] != DBNull.Value)
                                {
                                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'  class='dateTextBoxWidth form_textbox' type='text' datatype='Date' value='" + Convert.ToDateTime(dataRowViewTPObjective[0]["TargetDate"]).ToString("MM/dd/yyyy") + "'   name=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  class='form_textbox' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPObjectives','TargetDate','Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','Edit','ObjectiveId');\" />"); //Create  
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'  class='dateTextBoxWidth form_textbox' type='text' datatype='Date'  name=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  class='form_textbox' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPObjectives','TargetDate','Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','Edit','ObjectiveId');\" />"); //Create  
                                }
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td valign='middle' align='left'>");
                                stringBuilderHTML.Append("&nbsp;<img style='cursor:hand;' id=Img_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + " name=Img_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  src=" + RelativePath + "App_Themes/Includes/Images/calender_grey.gif   style='cursor:hand;' onclick=\"return showCalendar('Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','%m/%d/%Y');\"/>"); //Create 
                                stringBuilderHTML.Append("</td>");//1st Row  2nd Col Close Tag

                                stringBuilderHTML.Append("<td width='5%'>");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td width='14%' valign='middle'>");
                                stringBuilderHTML.Append("<span bindautosaveevents='False' BindSetFormData='False'   name=Span_ObjectiveStatus_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_ObjectiveStatus_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='color:Black;font-size:11px;'>Objective Status</span>");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td align='left'>");//1st Row  5th Col Open Tag
                                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                                dropdownListObjectiveStatus = new DropDownList();
                                dropdownListObjectiveStatus.ID = "DropDownList_GlobalCode_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString();
                                dropdownListObjectiveStatus.Width = 130;
                                dropdownListObjectiveStatus.CssClass = "form_dropdown";
                                using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPOBJECTIVESTATUS", true, "", "SortOrder", false))
                                {
                                    dropdownListObjectiveStatus.DataTextField = "CodeName";
                                    dropdownListObjectiveStatus.DataValueField = "GlobalCodeId";
                                    dropdownListObjectiveStatus.DataSource = DataViewGlobalCodes;
                                    dropdownListObjectiveStatus.DataBind();
                                }
                                if (dataRowViewTPObjective[0]["ObjectiveStatus"] != DBNull.Value)
                                {
                                    dropdownListObjectiveStatus.SelectedValue = dataRowViewTPObjective[0]["ObjectiveStatus"].ToString();
                                }
                                PanelPeriodicReviewGoal.Controls.Add(dropdownListObjectiveStatus);
                                dropdownListObjectiveStatus.Attributes.Add("bindautosaveevents", "False");
                                dropdownListObjectiveStatus.Attributes.Add("BindSetFormData", "False");
                                dropdownListObjectiveStatus.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPObjectives','ObjectiveStatus','" + dropdownListObjectiveStatus.ClientID + "','Edit','ObjectiveId');");

                                stringBuilderHTML.Append("</td>");//1st Row  5th Col Close Tag
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td colspan='2' style='height:5px;' >");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");


                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");



                            }
                        }
                    }
                }




                //stringBuilderHTML.Append("<tr>");
                //stringBuilderHTML.Append("<td>");

                //stringBuilderHTML.Append("</td>");
                //stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("</table>");
                #endregion Create Objective
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                #endregion


                #region // Blank Row Open Tag
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td style='height:30px;'>");
                #region //Added Blank Row By Daman
                stringBuilderHTML.Append("&nbsp;");
                #endregion
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                #endregion

                if (dataSetPeriodicReview.Tables.Contains("TPInterventionProcedures")) //Perform Table contain Check
                {
                    if (dataSetPeriodicReview.Tables["TPInterventionProcedures"].Rows.Count > 0)
                    {
                        //stringBuilderHTML = new StringBuilder();
                        dataRowTPInterventionProcedures = dataSetPeriodicReview.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId='" + dataRowTPNeeds[0]["NeedId"].ToString() + "'");
                        if (dataRowTPInterventionProcedures.Length > 0)
                        {

                            DataView dataViewTPInterventionProcedures = new DataView(dataSetPeriodicReview.Tables["TPInterventionProcedures"]);
                            dataViewTPInterventionProcedures.Sort = "InterventionNumber";
                            dataViewTPInterventionProcedures.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'and NeedId=" + dataRowTPNeeds[0]["NeedId"].ToString();

                            #region // 10th Row Open Tag
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag                    
                            stringBuilderHTML.Append("<td colspan='3' align='left'>");//1st Row 3rd Col Open Tag
                            #region Add Intervention
                            stringBuilderHTML.Append("<table style='width:100%;' border='0' cellpadding='0' cellspacing='3'>");

                            #region Intrevention table starts
                            //Ist Row
                            stringBuilderHTML.Append("<tr>");
                            #region first row
                            //Ist TD
                            stringBuilderHTML.Append("<td>");
                            //stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");

                            //II TD
                            stringBuilderHTML.Append("<td style='width:6%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span   name='SpanObjs' id='SpanObjs'>");
                            stringBuilderHTML.Append("Objs");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");

                            //III TD
                            stringBuilderHTML.Append("<td style='width:22%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span   name='SpanInterVentionText' id='SpanInterVentionText'>");
                            stringBuilderHTML.Append("Intervention Text");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");

                            //IV TD
                            stringBuilderHTML.Append("<td style='width:22%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span   name='SpanProviderService' id='SpanProviderService'>");
                            stringBuilderHTML.Append("Provider/Service");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");

                            //V TD

                            stringBuilderHTML.Append("<td style='width:30%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span   name='SpanUnitsFrequency' id='SpanUnitsFrequency'>");
                            stringBuilderHTML.Append("Units/Frequency");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");



                            //VI TD

                            stringBuilderHTML.Append("<td style='color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span   name='SpanFromTo' id='SpanFromTo'>");
                            stringBuilderHTML.Append("From/To");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");
                            #endregion first row

                            stringBuilderHTML.Append("</tr>");
                            for (int interventionCount = 0; interventionCount < dataViewTPInterventionProcedures.Count; interventionCount++)
                            {
                                stringBuilderHTML.Append("<tr>");
                                #region Second row
                                stringBuilderHTML.Append("<td colspan='6' style='height:10px;'>");
                                stringBuilderHTML.Append("</td>");
                                #endregion Second row
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("<tr>");
                                #region third row
                                stringBuilderHTML.Append("<td colspan='6' align='left' style='padding-left:5px;color:Black;font-size:11px;'>");
                                stringBuilderHTML.Append("<span   id=Span_TPInterventionProcedures_InterventionNumber_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ">");
                                stringBuilderHTML.Append("Intervention " + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InterventionNumber"]));
                                stringBuilderHTML.Append("</span>");
                                stringBuilderHTML.Append("</td>");
                                #endregion third row
                                stringBuilderHTML.Append("</tr>");


                                stringBuilderHTML.Append("<tr>");
                                #region Fourth row
                                //---1 TD
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("</td>");

                                //2 TD
                                stringBuilderHTML.Append("<td style='width:8%;' valign='top'>");
                                stringBuilderHTML.Append("<div id=div_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ">");
                                stringBuilderHTML.Append("<select class='form_textarea' bindautosaveevents='False' BindSetFormData='False'  multiple='multiple' size='3' style='width:99%;' disabled='disabled'>");
                                dataRowTPProcedures = dataSetPeriodicReview.Tables["TPProcedures"].Rows.Find(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]);
                                if (dataRowTPProcedures != null)
                                {
                                    if (dataRowTPProcedures["SourceDocumentId"] != System.DBNull.Value)
                                    {
                                        //Commented By Anuj as DocumentId Not Exist in New DataBase 3.1Dev
                                        //if (Convert.ToInt32(dataRowTPProcedures["SourceDocumentId"].ToString()) != Convert.ToInt32(dataRowTPProcedures["DocumentId"]))
                                        //Changes Ended Over Here
                                        if (Convert.ToInt32(dataRowTPProcedures["SourceDocumentId"].ToString()) != Convert.ToInt32(dataRowTPProcedures["DocumentVersionId"]))
                                        {
                                            disableProcedureProvider = true;
                                        }
                                    }
                                }
                                #region TPIntervention Procedure

                                dataRowTPInterventionPObjective = dataSetPeriodicReview.Tables["TPInterventionProcedureObjectives"].Select("Isnull(RecordDeleted,'N')<>'Y' and TPInterventionProcedureId=" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]));
                                if (dataRowTPInterventionPObjective.Length > 0)
                                {
                                    dataTableTPObjective = new DataTable("TPObjective");
                                    dataTableTPObjective.Columns.Add("ObjectiveId", typeof(int));
                                    dataTableTPObjective.Columns.Add("ObjectiveNumber", typeof(float));
                                    foreach (DataRow drTPInterventionObjective in dataRowTPInterventionPObjective)
                                    {
                                        DataRow[] dataRowTPObjective = dataSetPeriodicReview.Tables["TPObjectives"].Select("ObjectiveId=" + Convert.ToInt32(drTPInterventionObjective["ObjectiveId"]) + " and IsNull(RecordDeleted,'N')<>'Y'");
                                        if (dataRowTPObjective.Length > 0)
                                        {
                                            DataRow dRowTPObjective = dataTableTPObjective.NewRow();
                                            dRowTPObjective["ObjectiveId"] = Convert.ToInt32(dataRowTPObjective[0]["ObjectiveId"]);
                                            dRowTPObjective["ObjectiveNumber"] = Convert.ToSingle(dataRowTPObjective[0]["ObjectiveNumber"]);

                                            dataTableTPObjective.Rows.Add(dRowTPObjective);

                                        }
                                    }
                                    for (int objectiveNumber = 0; objectiveNumber < dataTableTPObjective.Rows.Count; objectiveNumber++)
                                    {
                                        stringBuilderHTML.Append("<option value= " + dataTableTPObjective.Rows[objectiveNumber]["ObjectiveId"].ToString() + ">");
                                        stringBuilderHTML.Append(dataTableTPObjective.Rows[objectiveNumber]["ObjectiveNumber"].ToString() + "</option>");
                                    }
                                }
                                #endregion

                                stringBuilderHTML.Append("</select>");
                                stringBuilderHTML.Append("</div>");

                                stringBuilderHTML.Append("</td>");

                                //---III TD
                                stringBuilderHTML.Append("<td style='width:25%;' valign='top' >");
                                //

                                stringBuilderHTML.Append("<textarea name='TextArea_TPInterventionProcdure_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' id='TextArea_TPInterventionProcdure_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' rows='3' cols='8' bindautosaveevents='False' BindSetFormData='False'  disabled='disabled' class='form_textarea' style='width: 96%' onchange= \"PRModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "InterventionText" + "','" + " TextArea_TPInterventionProcdure_InterventionText_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "');\" >"); //Create                        
                                if (dataViewTPInterventionProcedures[interventionCount]["InterventionText"] != DBNull.Value)
                                {
                                    stringBuilderHTML.Append(Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InterventionText"]));
                                }
                                stringBuilderHTML.Append("</textarea>");
                                stringBuilderHTML.Append("</td>");

                                //-----IV TD
                                stringBuilderHTML.Append("<td  valign='top' style='width:25%;'>");
                                stringBuilderHTML.Append("<table style='width:50%;' border='0' cellpadding='0' cellspacing='2'>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");

                                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                                dropdownListinterVentionProvider = new DropDownList();
                                dropdownListinterVentionProvider.Width = 180;
                                dropdownListinterVentionProvider.CssClass = "form_dropdown";
                                //dropdownListinterVentionProvider.ID = "DropDownList_TPInterventionProvider_" + Convert.ToString(dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView[interventionCount]["TPInterventionProcedureId"]);
                                dropdownListinterVentionProvider.ID = "DropDownList_TPInterventionProvider_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                dropdownListinterVentionProvider.Enabled = false;
                                //----Commented By Ashwani on 11 feb for Periodic Review
                                //if (disableProcedureProvider == true) { dropdownListinterVentionProvider.Enabled = false; }
                                //else
                                //{
                                //    dropdownListinterVentionProvider.Enabled = true;
                                //}

                                //------------End Commenetd---
                                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers != null)
                                {
                                    objectDocuments = new SHS.UserBusinessServices.Document();
                                    agencyName = objectDocuments.GetAgencyName();
                                    DataView dataViewProviders = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers);
                                    dataViewProviders.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                                    dropdownListinterVentionProvider.DataTextField = "ProviderName";
                                    dropdownListinterVentionProvider.DataValueField = "SiteId";
                                    dropdownListinterVentionProvider.DataSource = dataViewProviders;
                                    dropdownListinterVentionProvider.DataBind();
                                    dropdownListinterVentionProvider.Items.Insert(0, new ListItem(agencyName, "-1"));
                                    dropdownListinterVentionProvider.Items.Insert(1, new ListItem("Community/Natural Support", "-2"));
                                }
                                if (dataViewTPInterventionProcedures[interventionCount]["SiteId"] != DBNull.Value)
                                {
                                    dropdownListinterVentionProvider.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["SiteId"]);
                                }

                                dropdownListinterVentionProvider.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "SiteId" + "','" + dropdownListinterVentionProvider.ClientID + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "');");
                                dropdownListinterVentionProvider.Attributes.Add("bindautosaveevents", "False");
                                dropdownListinterVentionProvider.Attributes.Add("BindSetFormData", "False");
                                PanelPeriodicReviewGoal.Controls.Add(dropdownListinterVentionProvider);

                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                                dropdownListinterVentionService = new DropDownList();
                                dropdownListinterVentionService.Width = 180;
                                dropdownListinterVentionService.CssClass = "form_dropdown";
                                dropdownListinterVentionService.ID = "DropDownList_TPInterventionService_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                dropdownListinterVentionService.Enabled = false;
                                //--------Commenetd By Ashwani on 11 Feb for Periodic Review
                                //if (disableProcedureProvider == true) { dropdownListinterVentionService.Enabled = false; }
                                //else
                                //{
                                //    dropdownListinterVentionService.Enabled = true;
                                //}
                                //if (dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"] != DBNull.Value)
                                //{
                                //    dropdownListinterVentionService.Enabled = false;
                                //    dropdownListinterVentionProvider.Enabled = false;
                                //}
                                //else
                                //{
                                //    dropdownListinterVentionService.Enabled = true;
                                //    dropdownListinterVentionProvider.Enabled = true;
                                //}
                                //--------Commenetd By Ashwani on 11 Feb for Periodic Review

                                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes != null)
                                {
                                    DataView dataViewAuthorizationCodes = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes);
                                    dataViewAuthorizationCodes.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                                    dataViewAuthorizationCodes.Sort = "AuthorizationCodeName";
                                    dropdownListinterVentionService.DataTextField = "DisplayAs";
                                    dropdownListinterVentionService.DataValueField = "AuthorizationCodeId";
                                    dropdownListinterVentionService.DataSource = dataViewAuthorizationCodes;
                                    dropdownListinterVentionService.DataBind();
                                    dropdownListinterVentionService.Items.Insert(0, new ListItem("", ""));
                                }
                                if (dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"] != DBNull.Value)
                                {
                                    dropdownListinterVentionService.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]);
                                }
                                dropdownListinterVentionService.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "AuthorizationCodeId" + "','" + dropdownListinterVentionService.ClientID + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "');");
                                //dropdownListinterVentionService.Attributes.Add("parentchildcontrols", "True");
                                dropdownListinterVentionService.Attributes.Add("bindautosaveevents", "False");
                                dropdownListinterVentionService.Attributes.Add("BindSetFormData", "False");
                                PanelPeriodicReviewGoal.Controls.Add(dropdownListinterVentionService);
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");

                                //------------V TD
                                stringBuilderHTML.Append("<td align='left' valign='top' style='width:30%;'>");
                                stringBuilderHTML.Append("<table style='width:100%;' border='0' cellpadding='0' cellspacing='2'>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td align='left' style='width:50px;'>");

                                if (dataViewTPInterventionProcedures[interventionCount]["Units"] == DBNull.Value)
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled' class='form_textbox'  id='Text_Units_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:75%;'/>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled' class='form_textbox'  id='Text_Units_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:75%;' value='" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Units"]) + "'/>");
                                }

                                //Units
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td align='left'>");
                                stringBuilderHTML.Append("<div id=divEncounter_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:95%;'>");


                                string displayUnitText = DisplayUnitType(dropdownListinterVentionProvider);

                                if (displayUnitText == string.Empty)
                                {
                                    stringBuilderHTML.Append("<span  >(1 Unit =1 Encounter)</span>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<span  >");
                                    stringBuilderHTML.Append(displayUnitText);
                                    stringBuilderHTML.Append("</span>");
                                }


                                stringBuilderHTML.Append("</div>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td align='left' colspan='2'>");
                                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                stringBuilderHTML = new StringBuilder();
                                //Error Start
                                dropdownListinterVentionFrequency = new DropDownList();
                                dropdownListinterVentionFrequency.Enabled = false;
                                dropdownListinterVentionFrequency.Width = 180;
                                dropdownListinterVentionFrequency.CssClass = "form_dropdown";
                                dropdownListinterVentionFrequency.ID = "DropDownList_GlobalCodes_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPFREQUENCYTYPE", true, "", "SortOrder", false))
                                {
                                    dropdownListinterVentionFrequency.DataTextField = "CodeName";
                                    dropdownListinterVentionFrequency.DataValueField = "GlobalCodeId";
                                    dropdownListinterVentionFrequency.DataSource = DataViewGlobalCodes;
                                    dropdownListinterVentionFrequency.DataBind();
                                    dropdownListinterVentionFrequency.Items.Insert(0, new ListItem("", ""));
                                }
                                if (dataViewTPInterventionProcedures[interventionCount]["FrequencyType"] != DBNull.Value)
                                {
                                    if (Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["FrequencyType"]) != string.Empty)
                                    {
                                        dropdownListinterVentionFrequency.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["FrequencyType"]);
                                    }
                                }
                                //Error End
                                dropdownListinterVentionFrequency.Attributes.Add("bindautosaveevents", "False");
                                dropdownListinterVentionFrequency.Attributes.Add("BindSetFormData", "False");
                                PanelPeriodicReviewGoal.Controls.Add(dropdownListinterVentionFrequency);
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");

                                //------------VI TD
                                stringBuilderHTML.Append("<td valign='top' align='left'>");
                                stringBuilderHTML.Append("<table style='width:98%;' border='0' cellpadding='0' cellspacing='2'>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                //StartDate
                                if (dataViewTPInterventionProcedures[interventionCount]["StartDate"] != DBNull.Value)
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled' class='dateTextBoxWidth form_textbox'  id='Text_From_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'  value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["StartDate"]).ToString("MM/dd/yyyy") + "' />");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled' class='dateTextBoxWidth form_textbox'  id='Text_From_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' />");
                                }


                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                if (dataViewTPInterventionProcedures[interventionCount]["EndDate"] != DBNull.Value)
                                {

                                    stringBuilderHTML.Append("<input type='text' disabled='disabled' class='dateTextBoxWidth form_textbox'  id='Text_To_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'  value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["EndDate"]).ToString("MM/dd/yyyy") + "' />");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled' class='dateTextBoxWidth form_textbox'  id='Text_To_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' />");
                                }

                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");




                                #endregion Fourth row
                                stringBuilderHTML.Append("</tr>");
                            }
                            #endregion Intrevention table starts
                            stringBuilderHTML.Append("</table>");
                            stringBuilderHTML.Append("</td>"); //1st Row Open Tag                    
                            stringBuilderHTML.Append("</tr>");
                            #endregion Add Intervention
                            #endregion
                            //stringBuilderHTML.Append("</td>"); //1st Row Open Tag                    
                            //stringBuilderHTML.Append("</tr>");

                        }

                    }

                }

                ////Start-- Added By Daman

                stringBuilderHTML.Append("</table>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                #endregion

                #region // 4th Main TR
                stringBuilderHTML.Append("<tr>");
                stringBuilderHTML.Append("<td colspan='3'>");
                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                stringBuilderHTML.Append("<tr>");

                stringBuilderHTML.Append("<td width='2' class='right_bottom_cont_bottom_bg'>");
                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_left.gif ");
                stringBuilderHTML.Append("</td>");

                stringBuilderHTML.Append("<td width='100%' class='right_bottom_cont_bottom_bg'>");

                stringBuilderHTML.Append("</td>");

                stringBuilderHTML.Append("<td align='right' width='2' class='right_bottom_cont_bottom_bg'>");
                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_right.gif ");
                stringBuilderHTML.Append("</td>");

                stringBuilderHTML.Append("</tr>");
                stringBuilderHTML.Append("</table>");
                stringBuilderHTML.Append("</td>");
                stringBuilderHTML.Append("</tr>");
                #endregion
                //stringBuilderHTML.Append("</table>");
                ////End--

                stringBuilderHTML.Append("</table>");
                #endregion
                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));


            }
            //}
            //finally
            //{

            //}
        }

        /// <summary>
        /// <Description>This method is used to Read Data from TPObjective and Create Objective Section</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>11th-Sept-2009</CreatedOn>
        /// </summary>
        /// <param name="needId"></param>
        /// <param name="goalNumber"></param>
        private StringBuilder CreateObjective(int needId, int goalNumber, ref DataSet dataSetTreatmentPlanHRM)
        {
            StringBuilder stringBuilderObjectiveHTML = null;
            DataRow[] dataRowTpObjective = null;
            DataRowView[] dataRowViewTPObjective = null;
            double objectiveNumber = 0.0;
            DropDownList dropdownListObjectiveStatus = null;
            try
            {
                if (dataSetTreatmentPlanHRM.Tables.Contains("TPobjectives")) //Perform Table contain Check
                {
                    stringBuilderObjectiveHTML = new StringBuilder();
                    if (dataSetTreatmentPlanHRM.Tables["TPobjectives"].Rows.Count > 0)
                    {
                        //Find out the Number of Objectives Corresponding to a Need
                        dataRowTpObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("Isnull(RecordDeleted,'N' )<>'Y' and NeedId=" + needId + "", "ObjectiveNumber Asc");
                        if (dataRowTpObjective.Length > 0)
                        {
                            for (int objectiveCount = 0; objectiveCount < dataRowTpObjective.Length; objectiveCount++)
                            {
                                //dataSetTreatmentPlanHRM.Tables["TPobjectives"].DefaultView.Sort = "ObjectiveId Asc";

                                DataView dataViewTPObjectives = new DataView(dataSetTreatmentPlanHRM.Tables["TPobjectives"]);
                                dataViewTPObjectives.Sort = "ObjectiveId Asc";
                                //Create DataRowView 
                                //dataRowViewTPObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].DefaultView.FindRows(dataRowTpObjective[objectiveCount]["ObjectiveId"]);
                                dataRowViewTPObjective = dataViewTPObjectives.FindRows(dataRowTpObjective[objectiveCount]["ObjectiveId"]);
                                //########################3
                                stringBuilderObjectiveHTML.Append("<tr>");

                                stringBuilderObjectiveHTML.Append("<td colspan='3' style='height:2px;'>");
                                stringBuilderObjectiveHTML.Append("&nbsp;");
                                stringBuilderObjectiveHTML.Append("</td>");

                                stringBuilderObjectiveHTML.Append("</tr>");


                                stringBuilderObjectiveHTML.Append("<tr>"); //1st Row Open Tag

                                stringBuilderObjectiveHTML.Append("<td style='width:3%;'>"); //1st Row 1st Col Open tag                              
                                stringBuilderObjectiveHTML.Append("<img style='cursor:hand;color:Black;font-size:11px;' id=Img_TPObjectives_ObjectiveId_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  name=Img_TPObjectives_ObjectiveId_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + " src=" + RelativePath + "App_Themes/Includes/Images/close_icon.gif  tag='" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "'  onClick= \"DeleteObjective('" + needId + "','" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "');\" />");
                                stringBuilderObjectiveHTML.Append("</td>");//1st Row 1st Col Close tag


                                stringBuilderObjectiveHTML.Append("<td style=width:8%>");//1st Row 2nd Col Open tag
                                objectiveNumber = Convert.ToDouble(dataRowViewTPObjective[0]["ObjectiveNumber"].ToString());
                                stringBuilderObjectiveHTML.Append("<span    style='color:Black;font-size:11px;' + name=Span_TPObjectives_ObjectiveId_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_TPNeeds_NeedNumber_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + ">Objective" + objectiveNumber.ToString("0.00") + "</span>");
                                stringBuilderObjectiveHTML.Append("</td>");//1st Row 2nd Col Close tag

                                stringBuilderObjectiveHTML.Append("<td align='left'>"); //1st Row 3rd Column Open Tag
                                stringBuilderObjectiveHTML.Append("<table cellpadding='0' border='0' cellspacing='0' width='90%'>"); //Create
                                stringBuilderObjectiveHTML.Append("<tr>"); //1st Row Open Tag

                                stringBuilderObjectiveHTML.Append("<td align='left'>"); //1st Row 1st Col Open Tag
                                stringBuilderObjectiveHTML.Append("<textarea  spellcheck='True' name='TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "'  id='TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "' rows='4'  cols='8' bindautosaveevents='False' BindSetFormData='False'  style='width: 90%' class='form_textarea' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TPObjectives" + "','" + "ObjectiveText" + "','" + "TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "Edit" + "','" + "ObjectiveId" + "');\" >");
                                if (dataRowViewTPObjective[0]["ObjectiveText"] != DBNull.Value)
                                {
                                    stringBuilderObjectiveHTML.Append(dataRowViewTPObjective[0]["ObjectiveText"].ToString() + "</textarea>");
                                }
                                else
                                {
                                    stringBuilderObjectiveHTML.Append("</textarea>");
                                }
                                stringBuilderObjectiveHTML.Append("</td>"); //1st Row 1st Col Close Tag
                                stringBuilderObjectiveHTML.Append("</tr>"); //1st Row Close Tag
                                stringBuilderObjectiveHTML.Append("</table>");

                                stringBuilderObjectiveHTML.Append("</td>"); //1st Row 3rd Column Close Tag
                                stringBuilderObjectiveHTML.Append("</tr>"); //1st Row Close Tag

                                //To show difference between the two rows
                                stringBuilderObjectiveHTML.Append("<tr>");
                                stringBuilderObjectiveHTML.Append("<td colspan='3'>");
                                stringBuilderObjectiveHTML.Append("&nbsp;");
                                stringBuilderObjectiveHTML.Append("</td>");
                                stringBuilderObjectiveHTML.Append("</tr>");
                                //Ended Over here

                                stringBuilderObjectiveHTML.Append("<tr>"); //2nd Row Open Tag
                                stringBuilderObjectiveHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //2nd Row 1st & 2nd Column Open Tag/Close Tag


                                stringBuilderObjectiveHTML.Append("<td align='left'>");//2nd Row 3rd Col Open Tag

                                stringBuilderObjectiveHTML.Append("<table border='1' cellpadding='0' cellspacing='0' width='90%'>"); //Create

                                stringBuilderObjectiveHTML.Append("<tr>"); //1st Row Open Tag

                                stringBuilderObjectiveHTML.Append("<td>");//1st Row  1st Col Open Tag
                                stringBuilderObjectiveHTML.Append("<span    name=Span_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='color:Black;font-size:11px;'>Target Date</span>"); //Create                                                            
                                stringBuilderObjectiveHTML.Append("</td>");//1st Row  1st Col Close Tag

                                stringBuilderObjectiveHTML.Append("<td align='left'>");//1st Row  2nd Col Open Tag
                                if (dataRowViewTPObjective[0]["TargetDate"] != DBNull.Value)
                                {
                                    stringBuilderObjectiveHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False'  datatype='Date' value='" + Convert.ToDateTime(dataRowViewTPObjective[0]["TargetDate"]).ToString("MM/dd/yyyy") + "'   name=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  class='form_textbox' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TPObjectives" + "','" + "TargetDate" + "','" + "Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "Edit" + "','" + "ObjectiveId" + "');\" />"); //Create  
                                }
                                else
                                {
                                    stringBuilderObjectiveHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False'  datatype='Date'  name=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  class='form_textbox' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TPObjectives" + "','" + "TargetDate" + "','" + "Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "Edit" + "','" + "ObjectiveId" + "');\" />"); //Create  
                                }
                                stringBuilderObjectiveHTML.Append("&nbsp;<img style='cursor:hand;' id=Img_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + " name=Img_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  src=" + RelativePath + "App_Themes/Includes/Images/calender_grey.gif   style='cursor:hand;' onclick=\"return showCalendar('Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','%m/%d/%Y');\"/>"); //Create 
                                stringBuilderObjectiveHTML.Append("</td>");//1st Row  2nd Col Close Tag

                                stringBuilderObjectiveHTML.Append("<td align='left'>");//1st Row  3rd Col Open Tag
                                stringBuilderObjectiveHTML.Append("&nbsp;");
                                stringBuilderObjectiveHTML.Append("</td>");//1st Row  3rd Col Close Tag

                                stringBuilderObjectiveHTML.Append("<td align='center'>");//1st Row  4rth Col Open Tag
                                stringBuilderObjectiveHTML.Append("<span   name=Span_ObjectiveStatus_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_ObjectiveStatus_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='color:Black;font-size:11px;'>Objective Status</span>"); //Create                                                            
                                stringBuilderObjectiveHTML.Append("</td>");//1st Row  4rth Col Close Tag

                                stringBuilderObjectiveHTML.Append("<td align='left'>");//1st Row  5th Col Open Tag
                                PanelPeriodicReviewGoal.Controls.Add(new LiteralControl(stringBuilderObjectiveHTML.ToString()));
                                stringBuilderObjectiveHTML = new StringBuilder();
                                dropdownListObjectiveStatus = new DropDownList();
                                dropdownListObjectiveStatus.ID = "DropDownList_GlobalCode_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString();
                                dropdownListObjectiveStatus.Width = 130;
                                dropdownListObjectiveStatus.CssClass = "form_dropdown";
                                using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPOBJECTIVESTATUS", true, "", "SortOrder", false))
                                {
                                    dropdownListObjectiveStatus.DataTextField = "CodeName";
                                    dropdownListObjectiveStatus.DataValueField = "GlobalCodeId";
                                    dropdownListObjectiveStatus.DataSource = DataViewGlobalCodes;
                                    dropdownListObjectiveStatus.DataBind();
                                }
                                if (dataRowViewTPObjective[0]["ObjectiveStatus"] != DBNull.Value)
                                {
                                    dropdownListObjectiveStatus.SelectedValue = dataRowViewTPObjective[0]["ObjectiveStatus"].ToString();
                                }
                                PanelPeriodicReviewGoal.Controls.Add(dropdownListObjectiveStatus);
                                dropdownListObjectiveStatus.Attributes.Add("bindautosaveevents", "False");
                                dropdownListObjectiveStatus.Attributes.Add("BindSetFormData", "False");
                                dropdownListObjectiveStatus.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TPObjectives" + "','" + "ObjectiveStatus" + "','" + dropdownListObjectiveStatus.ClientID + "','" + "Edit" + "','" + "ObjectiveId" + "');");

                                stringBuilderObjectiveHTML.Append("</td>");//1st Row  5th Col Close Tag
                                stringBuilderObjectiveHTML.Append("</tr>");//1st Row Close Tag
                                stringBuilderObjectiveHTML.Append("</table>"); //Create

                                stringBuilderObjectiveHTML.Append("</td>");//2nd Row 3rd Col Close Tag
                                stringBuilderObjectiveHTML.Append("</tr>"); //2nd Row Close Tag

                                //To show difference between the two rows
                                stringBuilderObjectiveHTML.Append("<tr>");
                                stringBuilderObjectiveHTML.Append("<td colspan='3'>");
                                stringBuilderObjectiveHTML.Append("&nbsp;");
                                stringBuilderObjectiveHTML.Append("</td>");
                                stringBuilderObjectiveHTML.Append("</tr>");
                                //Ended Over here

                                stringBuilderObjectiveHTML.Append("<tr>"); //3rd Row Open Tag                             
                                stringBuilderObjectiveHTML.Append("<td align='left' colspan='3'>");//3rd Row 3rd Col Open Tag

                                stringBuilderObjectiveHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='100%'>"); //Create
                                stringBuilderObjectiveHTML.Append("<tr>");

                                stringBuilderObjectiveHTML.Append("<td align='left'>");
                                stringBuilderObjectiveHTML.Append("<span   name=Span_EditObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_EditObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueforEditObjective('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "DropDownList_GlobalCode_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "');\">Edit Objective</span>"); //Create 
                                stringBuilderObjectiveHTML.Append("</td>");

                                stringBuilderObjectiveHTML.Append("<td align='left'>");
                                stringBuilderObjectiveHTML.Append("<span   name=Span_UseQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_UseQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueQuickTxPlan('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TPQuickObjectives" + "','" + "TPObjectives" + "');\">Use Quick Objective</span>"); //Create
                                stringBuilderObjectiveHTML.Append("</td>");

                                stringBuilderObjectiveHTML.Append("<td align='left'>");
                                stringBuilderObjectiveHTML.Append("<span   name=Span_AddthistoQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_AddthistoQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueAddQuickTxPlan('" + "TPQuickObjectives" + "','" + "TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "');\">Add this to Quick Objective</span>"); //Create 
                                stringBuilderObjectiveHTML.Append("</td>");
                                stringBuilderObjectiveHTML.Append("</tr>");
                                stringBuilderObjectiveHTML.Append("<table>");

                                stringBuilderObjectiveHTML.Append("</td>");//3rd Row 3rd Col Close Tag
                                stringBuilderObjectiveHTML.Append("</tr>"); //3rd Row Close Tag

                            }
                        }
                        else
                        {
                            stringBuilderObjectiveHTML.Append("<tr>");

                            stringBuilderObjectiveHTML.Append("<td colspan='3' style='height:2px;'>");
                            stringBuilderObjectiveHTML.Append("&nbsp;");
                            stringBuilderObjectiveHTML.Append("</td>");

                            stringBuilderObjectiveHTML.Append("</tr>");
                        }

                    }
                    else
                    {
                        stringBuilderObjectiveHTML.Append("<tr>");

                        stringBuilderObjectiveHTML.Append("<td colspan='3' style='height:2px;'>");
                        stringBuilderObjectiveHTML.Append("&nbsp;");
                        stringBuilderObjectiveHTML.Append("</td>");

                        stringBuilderObjectiveHTML.Append("</tr>");
                    }


                }
                return stringBuilderObjectiveHTML;
            }
            catch (Exception ex)
            {
                ex.ToString();
                return stringBuilderObjectiveHTML;
            }
            finally
            {
                dataRowTpObjective = null;
                dataRowViewTPObjective = null;
            }
        }



        /// <summary>
        /// <Description>Method is used to calculate unit on the selection</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>09 Oct,2009</CreatedOn>
        /// </summary>
        private string DisplayUnitType(DropDownList dropdownlistFrequency)
        {
            string selectedValue = string.Empty;
            string strCodeName = string.Empty;
            string[] parameterCollection = null;
            DataSet dataSetAuthorization = null;
            DataSet dataSetTemp = null;
            DataView dataViewAuthorization = null;
            DataRow[] dataRowAuthorizationCodeName = null;
            DataRow[] dataRowGlobalCodes = null;
            Int32 unitTypeValue = 0;
            Int32 units = 0;
            string unitCounterText = string.Empty;
            try
            {
                // selectedValue = Request.Form["selectedValue"];
                char[] cSpilt = new char[1];
                cSpilt[0] = ',';
                if (Request.Form["UnitCount"] != null)
                {
                    parameterCollection = Request.Form["UnitCount"].Split(cSpilt);
                }
                dataRowAuthorizationCodeName = SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("Active='Y'", "AuthorizationCodeName");
                dataSetAuthorization = new DataSet();
                dataSetAuthorization.EnforceConstraints = false;//Need to Check Anuj forcefully  enforced constraints false.
                dataSetAuthorization.Merge(dataRowAuthorizationCodeName);

                dataViewAuthorization = new DataView(dataSetAuthorization.Tables[0]);

                dataViewAuthorization.RowFilter = "AuthorizationCodeId=" + Convert.ToInt32(dropdownlistFrequency.SelectedValue);
                if (dataViewAuthorization.Count > 0 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != -1 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != 0)
                {
                    if (dataViewAuthorization[0]["UnitType"] != null && dataViewAuthorization[0]["UnitType"] != System.DBNull.Value)
                        unitTypeValue = Convert.ToInt32(dataViewAuthorization[0]["UnitType"]);
                    if (dataViewAuthorization[0]["Units"] != null && dataViewAuthorization[0]["Units"] != System.DBNull.Value)
                        units = Convert.ToInt32(dataViewAuthorization[0]["Units"]);

                }

                dataRowGlobalCodes = SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitTypeValue);

                dataSetTemp = new DataSet();

                if (dataRowGlobalCodes.Length > 0)
                {
                    dataSetTemp.Merge(dataRowGlobalCodes);

                    if (unitTypeValue == 120 || unitTypeValue == 110)
                    {
                        // modified by Piyush on 6th March 2007 as per comment on "3/2/2007 8:08:07 AM " on task 390
                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 6);
                        if (units != 1)
                            unitCounterText = "(1 Unit = " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit = " + units + " " + strCodeName + ")";
                    }
                    else if (unitTypeValue == 124)
                    {

                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 9);
                        if (units != 1)
                            unitCounterText = "(1 Unit =  " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit =  " + units + " " + strCodeName + ")";
                    }
                    else
                    {
                        unitCounterText = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    }
                }
                return unitCounterText;
            }
            finally
            {
                selectedValue = string.Empty;
                strCodeName = string.Empty;
                parameterCollection = null;
                dataSetAuthorization = null;
                dataSetTemp = null;
                dataViewAuthorization = null;
                dataRowAuthorizationCodeName = null;
                dataRowGlobalCodes = null;
            }
        }
    }
}
