﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;
using System.Text;

public partial class ActivityPages_Client_Detail_PeriodicReview_PRNewGoalAjaxScript : System.Web.UI.Page
{
    public string RelativePath = string.Empty;
    DataTable _DataTableClientNeeds = null;
    DataTable _DataTableTPObjectives = null;
    bool _FromPROnload = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            RelativePath = Page.ResolveUrl("~/");
            //GetRequestParameterValue(
            switch (Request.Form["action"].ToLower())
            //  switch(GetRequestParameterValue("action").ToLower())
            {
                case "edit": //Handle On Blur
                    EditValue();
                    break;
                case "addgoal": //Handle Add Goal
                    BaseCommonFunctions.IsPopup = false;
                    AddGoal();
                    break;
                case "editgoal"://Handle Edit Goal
                    UpdateGoalValue();
                    break;
                case "addobjective": //Handle Add objective
                    AddObjective();
                    break;
                case "deleteobjective"://Hadle Delete objective 
                    DeleteObjective();
                    break;
                case "addintervention": //Handle Add Intervention
                    AddIntervention();
                    break;
                case "deleteintervention": //Handle delete Intervention
                    DeleteIntervention();
                    break;
                case "quickcopyintervention": //Handle quick copy intervention
                    QuickCopyIntervention();
                    break;
                case "editassociatedneed": //Handle associated Needs
                    UpdateAssociatedNeed();
                    break;
                case "editassociatedobjective"://Handle associated objective
                    UpdateAssociatedObjective();
                    break;
                case "updatequicktxplan": //Handle Add this to QuickTxPlan 
                    BaseCommonFunctions.IsPopup = false;
                    InsertNewRowInTxPlan();
                    break;
                case "updateusequicktxplan":
                    BaseCommonFunctions.IsPopup = false;
                    UpdateTxPlanText();
                    break;
                case "EditGoalValue":
                    //EditGoalValue();
                    break;
                case "addneedlist":
                    AddNeeddList();
                    break;
                case "deleteneedlist":
                    DeleteNeedList();
                    break;
                case "updateneedlist":
                    BaseCommonFunctions.IsPopup = false;
                    UpdateClientNeedList();
                    break;
                case "cancelneedlist":
                    //CancelClientNeedList();//Commented By Vikas Vyas On Dated Nov, 13th 2009
                    break;
                case "deletegoal":
                    DeleteGoal();
                    break;
                case "updateobjective":
                    UpdateObjective();
                    break;
                case "deletequicktxplan":
                    DeleteQuickTxPlan();
                    break;
                case "renumbertxplan":
                    BaseCommonFunctions.IsPopup = false;
                    RenumberTxPlan();
                    break;
                case "assignprocedures":
                    CalculateProceduresfromInterventions();
                    break;
                case "insertinterventionprocedure":
                    //BindProcedureGrid();
                    break;
                case "displayunits":
                    DisplayUnitType();
                    break;
                case "checkepisodenumber":
                    CheckEpisodeNumber();
                    break;
                case "checkclientneedassociation":
                    CheckClientneedAssociation();
                    break;
                case "editassociatedintervention":
                    EditAssociatedIntervention();
                    break;
                case "editclientneedvalue":
                    EditClientNeedValue();
                    break;
                case "unitcalculation":
                    UnitCalculation();
                    break;
                case "updatehrmtpassignprocedure":
                    //UpdateHRMTPAassignProcedure();
                    break;
                case "closehrmtpassignprocedure":
                    //CloseHRMTPAssignProcedure();
                    break;
                case "recreatetxplan":
                    RecreateTxPlan();
                    break;
                case "recreatetxplanaftersave":
                    RecreateTxPlanAfterSave();
                    break;
                case "bindgridviewtpprocedureaftersave":
                    //BindGridViewTPProcedureAfterSave();
                    break;

                case "createeditassociateinterventioncontrol":
                    CreateEditAssociateInterventionControl();
                    break;

                case "deletehrmtreatmentplantpprocedures":
                    //DeleteHRMTreatmentPlanTPProcedures(); 
                    break;

                case "editlof":
                    UpdateLOFDLA();
                    break;

            }
        }
        //Changes by Sonia reference 885 in SC Web Phase II - Bugs/New features
        //Catch block added as this page is not inherited from any base class
        //Without catch blck unhandled exceptions were being thrown
        //To catch the exact cause error has been logged with proper details
        catch (System.Threading.ThreadAbortException ex)
        {
            //System.Threading.ThreadAbortException need not to be logged
        }

        catch (Exception ex)
        {
            string ErrorMessage = string.Empty;
            ErrorMessage = "Error occured during Custom Ajax request at Periodic Review Ajax Script Error Info:-" + "ScreenID=6, Action is " + Request.Form["action"] + ", ErrorMessage:-+ " + ex.Message;
            Exception exceptionObject1 = new Exception(ErrorMessage);
            LogManager.LogException(exceptionObject1, LogManager.LoggingCategory.Error, LogManager.LoggingLevel.Error);

        }
    }





    private void UpdateLOFDLA()
    {
        DataRow[] dataRowPeriodicReview = null;
        try
        {
            //Get DataSet from Base Common Function
            using (DataSet dataSetPeriodicReview = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                //Perform check for null
                if (dataSetPeriodicReview != null && dataSetPeriodicReview.Tables.Count > 0)
                {
                    //Perform Table Contain Check 
                    if (dataSetPeriodicReview.Tables.Contains(Request.QueryString["tableName"]))
                    {
                        if (dataSetPeriodicReview.Tables[Request.QueryString["tableName"]].Rows.Count > 0)  //Perform Row Count Check
                        {
                            dataRowPeriodicReview = dataSetPeriodicReview.Tables[Request.QueryString["tableName"]].Select(Request.QueryString["primarykeyname"] + "=" + Request.QueryString["primarykeyvalue"]);
                            if (dataRowPeriodicReview.Length > 0)
                            {
                                dataRowPeriodicReview[0].BeginEdit();
                                string[] columnValue = Request.QueryString["columnvalue"].Split(':');
                                string[] columnName = Request.QueryString["columnname"].Split(':');
                                for (int i = 0; i < columnName.Length; i++)
                                {
                                    if (columnValue[i].Trim() != "")
                                    {
                                        dataRowPeriodicReview[0][columnName[i]] = columnValue[i];
                                        if (columnName[i] == "ActivityScore" || columnName[i] == "ActivityComment")
                                        {
                                            dataRowPeriodicReview[0]["ActivityComment"] = Convert.ToString(Request.QueryString["ActivityComment"]);
                                        }
                                    }
                                    else
                                    {
                                        dataRowPeriodicReview[0][columnName[i]] = DBNull.Value;
                                    }
                                }
                                dataRowPeriodicReview[0].EndEdit();

                                BaseCommonFunctions.GetScreenInfoDataSet().Merge(dataSetPeriodicReview);
                            }
                            else
                            {
                                if (Request.QueryString["columnvalue"].Trim() != "")
                                {
                                    UpdateCustomDailyLivingActivityScores(Request.QueryString["columnvalue"], Request.QueryString["columnname"], Request.QueryString["tableName"], Request.QueryString["primarykeyname"], Request.QueryString["primarykeyvalue"],Request.QueryString["foreignkeyname"],Request.QueryString["foreignkeyvalue"], dataSetPeriodicReview);
                                }

                            }
                        }
                        else
                        {
                            if (Request.QueryString["columnvalue"].Trim() != "")
                            {
                                UpdateCustomDailyLivingActivityScores(Request.QueryString["columnvalue"], Request.QueryString["columnname"], Request.QueryString["tableName"], Request.QueryString["primarykeyname"], Request.QueryString["primarykeyvalue"], Request.QueryString["foreignkeyname"], Request.QueryString["foreignkeyvalue"], dataSetPeriodicReview);

                            }

                        }

                    }
                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{

        //}
        finally
        {
            dataRowPeriodicReview = null;
        }
    }






    /// <summary>
    /// <Description>Change value in there respective Datatable</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>07/09/2009</CreatedOn>
    /// </summary>
    private void EditValue()
    {
        DataRow[] dataRowTreatmentPlanHRM = null;
        try
        {
            //Get DataSet from Base Common Function
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                //Perform check for null
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    //Perform Table Contain Check 
                    if (dataSetTreatmentPlanHRM.Tables.Contains(Request.Form["tableName"]))
                    {
                        if (dataSetTreatmentPlanHRM.Tables[Request.Form["tableName"]].Rows.Count > 0)  //Perform Row Count Check
                        {
                            dataRowTreatmentPlanHRM = dataSetTreatmentPlanHRM.Tables[Request.Form["tableName"]].Select(Request.Form["keyFieldName"] + "=" + Request.QueryString["keyValue"]);
                            if (dataRowTreatmentPlanHRM.Length > 0)
                            {
                                dataRowTreatmentPlanHRM[0].BeginEdit();
                                if (Request.Form["controlValue"] != "")
                                {
                                    dataRowTreatmentPlanHRM[0][Request.Form["fieldName"]] = Request.Form["controlValue"];
                                }
                                else
                                {
                                    dataRowTreatmentPlanHRM[0][Request.Form["fieldName"]] = DBNull.Value;
                                }
                                dataRowTreatmentPlanHRM[0].EndEdit();
                                //changes start with ref#187
                                if (Request.Form["fieldName"] == "GoalMonitoredStaffOtherCheckbox")
                                {
                                    dataRowTreatmentPlanHRM[0].BeginEdit();
                                    if (Request.Form["controlValue"].Trim().ToUpper() == "Y")
                                    {
                                        dataRowTreatmentPlanHRM[0]["GoalMonitoredStaff"] = DBNull.Value;
                                    }
                                    else
                                        if (Request.Form["controlValue"].Trim().ToUpper() == "N")
                                        {
                                            dataRowTreatmentPlanHRM[0]["GoalMonitoredStaffOther"] = DBNull.Value;
                                        }

                                    dataRowTreatmentPlanHRM[0].EndEdit();
                                }
                                else
                                    if (Request.Form["fieldName"] == "GoalMonitoredStaff")
                                    {
                                        dataRowTreatmentPlanHRM[0].BeginEdit();

                                        dataRowTreatmentPlanHRM[0]["GoalMonitoredStaffOther"] = DBNull.Value;
                                        dataRowTreatmentPlanHRM[0]["GoalMonitoredStaffOtherCheckbox"] = "N";

                                        dataRowTreatmentPlanHRM[0].EndEdit();
                                    }
                                    else
                                        if (Request.Form["fieldName"] == "GoalMonitoredStaffOther")
                                        {
                                            dataRowTreatmentPlanHRM[0].BeginEdit();

                                            dataRowTreatmentPlanHRM[0]["GoalMonitoredStaff"] = DBNull.Value;
                                            dataRowTreatmentPlanHRM[0]["GoalMonitoredStaffOtherCheckbox"] = "Y";

                                            dataRowTreatmentPlanHRM[0].EndEdit();
                                        }

                                //changes ends here
                                BaseCommonFunctions.GetScreenInfoDataSet().Merge(dataSetTreatmentPlanHRM);
                            }
                            else
                            {
                                if (Request.Form["controlValue"].Trim() != "" && (Request.Form["fieldName"] == "Review" || Request.Form["fieldName"] == "ReviewProgress"))
                                {
                                    UpdatePeriodicReviewNeeds(Request.Form["controlValue"], Request.Form["tableName"], Request.QueryString["keyValue"], dataSetTreatmentPlanHRM, Request.Form["fieldName"]);
                                }

                            }
                        }
                        else
                        {
                            if (Request.Form["controlValue"].Trim() != "" && (Request.Form["fieldName"] == "Review" || Request.Form["fieldName"] == "ReviewProgress"))
                            {
                                UpdatePeriodicReviewNeeds(Request.Form["controlValue"], Request.Form["tableName"], Request.QueryString["keyValue"], dataSetTreatmentPlanHRM, Request.Form["fieldName"]);

                            }

                        }

                    }
                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{

        //}
        finally
        {
            dataRowTreatmentPlanHRM = null;
        }
    }

    /// <summary>
    /// This Function adds a row to PeriodicReviewNeeds Tables with given NeedId
    /// <created by>Ashwani Kumar Angrish</created>
    /// <created On>13 Feb 2010</created>
    /// </summary>
    /// <param name="controlValue">String:value to be inserted for Review column of PeriodicReviewNeeds Tables i.e review of goal</param>
    /// <param name="tableName">string:Table Name i.e PeriodicReviewNeeds</param>
    /// <param name="keyValue">string:NeedId</param>
    /// <param name="dataSetPeriodicReview">DataSet:dataset to be updated</param>
    private void UpdatePeriodicReviewNeeds(string controlValue, string tableName, string keyValue, DataSet dataSetPeriodicReview, string fieldName)
    {
        DataRow dataRowPRGoalReview = dataSetPeriodicReview.Tables[tableName].NewRow();

        if (dataSetPeriodicReview.Tables["TPNeeds"] != null && dataSetPeriodicReview.Tables["TPNeeds"].Rows.Count > 0)
        {
            DataRow[] dataRowTPNeeds = dataSetPeriodicReview.Tables["TPNeeds"].Select("NeedId=" + keyValue);
            dataRowPRGoalReview["DocumentVersionId"] = dataRowTPNeeds[0]["DocumentVersionId"];
        }

        dataRowPRGoalReview["NeedId"] = keyValue;
        if (fieldName == "ReviewProgress")
        {
            dataRowPRGoalReview["ReviewProgress"] = controlValue;
        }
        else
        {
            dataRowPRGoalReview["Review"] = controlValue;
        }
        BaseCommonFunctions.InitRowCredentials(dataRowPRGoalReview);
        dataSetPeriodicReview.Tables[Request.Form["tableName"]].Rows.Add(dataRowPRGoalReview);
        BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Merge(dataSetPeriodicReview);
    }


    /// <summary>
    /// This Function adds a row to CustomDailyLivingActivityScores Tables 
    /// <created by>Ashwani Kumar Angrish</created>
    /// <created On>23 August 2010</created>
    /// </summary>
    /// <param name="controlValue">String:value to be inserted </param>
    /// <param name="tableName">string:Table Name </param>
    /// <param name="keyValue">string:primary key value </param>
    /// <param name="dataSetPeriodicReview">DataSet:dataset to be updated</param>
    private void UpdateCustomDailyLivingActivityScores(string controlValue, string columnNameToUpdated, string tableName, string primaryKeyName, string primaryKeyValue,string foreignKeyName,string foreignKeyValue, DataSet dataSetPeriodicReview)
    {
        DataRow dataRowPRGoalReview = dataSetPeriodicReview.Tables[tableName].NewRow();

        string[] columnName = columnNameToUpdated.Split(':');
        string[] columnValue = controlValue.Split(':');

        if (dataSetPeriodicReview.Tables[tableName] != null && dataSetPeriodicReview.Tables[tableName].Rows.Count > 0)
        {
            DataRow[] dataRowTPNeeds = dataSetPeriodicReview.Tables[tableName].Select(primaryKeyName + "=" + primaryKeyValue);
            if (dataRowTPNeeds.Length > 0)
                dataRowPRGoalReview["DocumentVersionId"] = dataRowTPNeeds[0]["DocumentVersionId"];
        }

        
        dataRowPRGoalReview[primaryKeyName] = primaryKeyValue;
        if (foreignKeyName.Trim() != "")
            dataRowPRGoalReview[foreignKeyName] = foreignKeyValue;

        for (int i = 0; i < columnName.Length; i++)
        {
            dataRowPRGoalReview[columnName[i]] = columnValue[i];
        
        }

        
        BaseCommonFunctions.InitRowCredentials(dataRowPRGoalReview);
        dataSetPeriodicReview.Tables[tableName].Rows.Add(dataRowPRGoalReview);
        BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Merge(dataSetPeriodicReview);
    }

    /// <summary>
    /// <Description>Update Associated Need in there respective dataset</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>09/Sept/2009</CreatedOn>
    /// </summary>
    private void UpdateAssociatedNeed()
    {
        string[] rowSeparator = null;
        string[] separatorCol = null;
        string[] arrayColCollection = null;
        DataTable dataTableResult = null;
        string needDescription = string.Empty;
        StringBuilder stringBuilderHTML = null;
        try
        {
            rowSeparator = new string[] { "||" };
            separatorCol = new string[] { "$$" };
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    if (dataSetTreatmentPlanHRM.Tables.Contains("CustomTPNeedsClientNeeds"))
                    {
                        _DataTableClientNeeds = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"];
                    }
                }
                string[] strSplitArr = Request.Form["strHTML"].Split(rowSeparator, StringSplitOptions.None);
                if (strSplitArr.Length > 0)
                {
                    for (int rowCount = 0; rowCount < strSplitArr.Length; rowCount++)
                    {
                        arrayColCollection = strSplitArr[rowCount].Split(separatorCol, StringSplitOptions.None);

                        if (arrayColCollection[1].Trim() == "true")
                        {
                            AddNewRecord(Convert.ToInt32(arrayColCollection[0]), "true");
                        }
                        else
                        {
                            AddNewRecord(Convert.ToInt32(arrayColCollection[0]), "false");
                        }
                    }

                    #region define relation between tables.

                    dataTableResult = new DataTable("ResultTable");
                    dataTableResult.Columns.Add("TPNeedsClientNeedId", typeof(int));
                    dataTableResult.Columns.Add("NeedName", typeof(string));

                    dataSetTreatmentPlanHRM.Merge(_DataTableClientNeeds);

                    if (dataSetTreatmentPlanHRM.Tables.Contains("CustomTPNeedsClientNeeds"))
                    {
                        //Set Filter On the Basis Of NeedId from TPNeedClientNeeds

                        // dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView.RowFilter = "NeedId=" + Convert.ToInt32(Request.QueryString["needId"]) + " and IsNull(RecordDeleted,'N')<>'Y'";


                        DataView dataViewCustomTPNeedsClientNeeds = new DataView(dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"]);

                        dataViewCustomTPNeedsClientNeeds.RowFilter = "NeedId=" + Convert.ToInt32(Request.QueryString["needId"]) + " and IsNull(RecordDeleted,'N')<>'Y'";

                        //performs join between table.
                        // for (int i = 0; i < dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView.Count; i++)
                        for (int i = 0; i < dataViewCustomTPNeedsClientNeeds.Count; i++)
                        {
                            //  DataRow parent = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i].Row.GetParentRow("ClientNeeds_TPNeedsClientNeeds_FK");
                            //DataRow parent = dataViewCustomTPNeedsClientNeeds[i].Row.GetParentRow("ClientNeeds_TPNeedsClientNeeds_FK");
                            DataRow parent = dataViewCustomTPNeedsClientNeeds[i].Row.GetParentRow("CustomClientNeeds_CustomTPNeedsClientNeeds_FK");


                            DataRow newRow = dataTableResult.NewRow();
                            //  newRow["TPNeedsClientNeedId"] = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i].Row["TPNeedsClientNeedId"];

                            newRow["TPNeedsClientNeedId"] = dataViewCustomTPNeedsClientNeeds[i].Row["TPNeedsClientNeedId"];

                            DataRowView needDescription1 = (DataRowView)dataViewCustomTPNeedsClientNeeds[i];

                            if (!string.IsNullOrEmpty(needDescription1["NeedDescription"].ToString()))
                                needDescription = parent["NeedName"] + " - " + needDescription1["NeedDescription"];
                            else
                                needDescription = parent["NeedName"].ToString();
                            if (needDescription.Length >= 120)
                            {
                                needDescription = BaseCommonFunctions.cutText(needDescription, 120);

                            }
                            newRow["NeedName"] = needDescription;

                            dataTableResult.Rows.Add(newRow);

                        }
                    }

                    stringBuilderHTML = new StringBuilder();
                    stringBuilderHTML.Append("<select class='form_textarea' multiple='multiple' size='2' style='width:99%'>");

                    for (int tpneedClientNeedCount = 0; tpneedClientNeedCount < dataTableResult.Rows.Count; tpneedClientNeedCount++)
                    {
                        stringBuilderHTML.Append("<option value= " + dataTableResult.Rows[tpneedClientNeedCount]["TPNeedsClientNeedId"].ToString() + ">");
                        stringBuilderHTML.Append(dataTableResult.Rows[tpneedClientNeedCount]["NeedName"].ToString() + "</option>");

                    }

                    stringBuilderHTML.Append("</select>");
                    PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                    #endregion
                }
            }
        }
        finally
        {
            //Memory Deallocation
            rowSeparator = null;
            separatorCol = null;
            arrayColCollection = null;
            dataTableResult = null;
            stringBuilderHTML = null;
        }
    }


    /// <summary>
    /// <Description>Update AssociatedObjective in there respective dataset</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>19/Sept/2009</CreatedOn>
    /// </summary>
    private void UpdateAssociatedObjective()
    {
        string[] rowSeparator = null;
        string[] separatorCol = null;
        string[] arrayColCollection = null;
        DataTable dataTableTPObjective = null;
        string needDescription = string.Empty;
        StringBuilder stringBuilderHTML = null;
        try
        {
            rowSeparator = new string[] { "||" };
            separatorCol = new string[] { "$$" };
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPObjectives"))
                    {
                        _DataTableTPObjectives = dataSetTreatmentPlanHRM.Tables["TPObjectives"];
                    }
                }
                string[] strSplitArr = Request.Form["strHTML"].Split(rowSeparator, StringSplitOptions.None);
                if (strSplitArr.Length > 0)
                {
                    for (int rowCount = 0; rowCount < strSplitArr.Length; rowCount++)
                    {
                        arrayColCollection = strSplitArr[rowCount].Split(separatorCol, StringSplitOptions.None);

                        if (arrayColCollection[1] == "true")
                        {
                            AddNewRecordAssociatedObjective(Convert.ToInt32(arrayColCollection[0]), "true");
                        }
                        else
                        {
                            AddNewRecordAssociatedObjective(Convert.ToInt32(arrayColCollection[0]), "false");
                        }
                    }
                    //Set the TPInterventionProcedureid from TPInterventionProcedure 
                    //Select the Row On the Basis Of TPInterventionProcedureId from TPInterventionProcedureObjectives
                    //And On the Basis Of ObjectiveId get the ObjectiveNumber from TPObjective

                    DataRow[] dataRowTPInterventionPObjective = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedureObjectives"].Select("TPInterventionProcedureId=" + Convert.ToInt32(Request.QueryString["tpInterventionProcedureId"]) + " and IsNull(RecordDeleted,'N')<>'Y'");
                    stringBuilderHTML = new StringBuilder();
                    stringBuilderHTML.Append("<select class='form_textarea' multiple='multiple' size='3' style='width:99%'>");
                    if (dataRowTPInterventionPObjective.Length > 0)
                    {
                        dataTableTPObjective = new DataTable("TPObjective");
                        dataTableTPObjective.Columns.Add("ObjectiveId", typeof(int));
                        dataTableTPObjective.Columns.Add("ObjectiveNumber", typeof(float));
                        foreach (DataRow drTPInterventionObjective in dataRowTPInterventionPObjective)
                        {
                            DataRow[] dataRowTPObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("ObjectiveId=" + Convert.ToInt32(drTPInterventionObjective["ObjectiveId"]) + " and IsNull(RecordDeleted,'N')<>'Y'");
                            if (dataRowTPObjective.Length > 0)
                            {
                                DataRow dRowTPObjective = dataTableTPObjective.NewRow();
                                dRowTPObjective["ObjectiveId"] = Convert.ToInt32(dataRowTPObjective[0]["ObjectiveId"]);
                                dRowTPObjective["ObjectiveNumber"] = Convert.ToSingle(dataRowTPObjective[0]["ObjectiveNumber"]);
                                dataTableTPObjective.Rows.Add(dRowTPObjective);
                            }
                        }
                        for (int objectiveNumber = 0; objectiveNumber < dataTableTPObjective.Rows.Count; objectiveNumber++)
                        {
                            stringBuilderHTML.Append("<option value= " + dataTableTPObjective.Rows[objectiveNumber]["ObjectiveId"].ToString() + ">");
                            stringBuilderHTML.Append(dataTableTPObjective.Rows[objectiveNumber]["ObjectiveNumber"].ToString() + "</option>");
                        }
                    }
                    stringBuilderHTML.Append("</select>");
                    PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            rowSeparator = null;
            separatorCol = null;
            arrayColCollection = null;
            dataTableTPObjective = null;
        }
    }


    /// <summary>
    /// <Description>Update Associated Intervention in TPInterventionProcedure</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>12th Nov,2009</CreatedOn>
    /// </summary>
    private void EditAssociatedIntervention()
    {
        string[] rowSeparator = null;
        string[] separatorCol = null;
        string[] arrayColCollection = null;
        DataTable dataTableTPObjective = null;
        string needDescription = string.Empty;
        StringBuilder stringBuilderHTML = null;
        string[] parameterValue = null;
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //try
        //{
        rowSeparator = new string[] { "||" };
        separatorCol = new string[] { "$$" };

        //  using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
        using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatPlanHRMTPProcedure"] as DataSet)
        {
            if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
            {
                string[] strSplitArr = Request.Form["strHTML"].Split(rowSeparator, StringSplitOptions.None);

                if (strSplitArr.Length > 0)
                {
                    for (int rowCount = 0; rowCount < strSplitArr.Length; rowCount++)
                    {
                        arrayColCollection = strSplitArr[rowCount].Split(separatorCol, StringSplitOptions.None);

                        if (arrayColCollection[1] == "true")
                        {
                            SetRecordStatus(Convert.ToInt32(arrayColCollection[0]), true);
                        }
                        else
                        {
                            SetRecordStatus(Convert.ToInt32(arrayColCollection[0]), false);
                        }


                    }

                }



                #region Create AssociatedInterventionControl

                //AuthorizationCodeId and SiteId
                char[] cSplit = new char[1];
                cSplit[0] = ',';
                parameterValue = Request.Form["selectedValue"].Split(cSplit);


                //  DataRow[] drTPInterventionProcedure = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["TPInterventionProcedures"].Select("AuthorizationCodeId=" + Convert.ToInt32(parameterValue[0]).ToString() + " and  SiteId=" + Convert.ToInt32(parameterValue[1]).ToString() + " and TPProcedureId is not null and  Isnull(RecordDeleted,'N')<>'Y' and ISNULL(TPProcedureAssociatedOrNot,'N')='Y'");
                DataRow[] drTPInterventionProcedure = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("AuthorizationCodeId=" + Convert.ToInt32(parameterValue[0]).ToString() + " and  SiteId=" + Convert.ToInt32(parameterValue[1]).ToString() + " and TPProcedureId is not null and  Isnull(RecordDeleted,'N')<>'Y' and ISNULL(TPProcedureAssociatedOrNot,'N')='Y'");

                DataTable myDataTable = null;
                DataColumn myDataColumn = null;

                if (drTPInterventionProcedure.Length > 0)
                {
                    myDataTable = new DataTable("TPInterventionProcedure");
                    myDataColumn = new DataColumn();
                    myDataColumn.DataType = System.Type.GetType("System.String");
                    myDataColumn.ColumnName = "InterventionText";
                    myDataTable.Columns.Add(myDataColumn);

                    foreach (DataRow drInterventionText in drTPInterventionProcedure)
                    {
                        if (Convert.ToInt32(drInterventionText["TPProcedureId"]) == Convert.ToInt32(Request.QueryString["tpProcedureId"]))
                            myDataTable.Rows.Add(drInterventionText["InterventionText"]);
                    }

                    stringBuilderHTML = new StringBuilder();
                    stringBuilderHTML.Append("<select class='form_textarea' multiple='multiple' style='width:98%;height:80px;'>");

                    for (int loopCount = 0; loopCount < myDataTable.Rows.Count; loopCount++)
                    {
                        //   stringBuilderHTML.Append("<option value= " + dataTableResult.Rows[tpneedClientNeedCount]["TPNeedsClientNeedId"].ToString() + ">");
                        //  stringBuilderHTML.Append(dataTableResult.Rows[tpneedClientNeedCount]["NeedName"].ToString() + "</option>");
                        stringBuilderHTML.Append("<option>");

                        if (myDataTable.Rows[loopCount]["InterventionText"].ToString().Length > 50)
                        {
                            stringBuilderHTML.Append(myDataTable.Rows[loopCount]["InterventionText"].ToString() + "</option>");
                        }
                        else
                        {
                            stringBuilderHTML.Append(BaseCommonFunctions.cutText(myDataTable.Rows[loopCount]["InterventionText"].ToString(), 50) + "</option>");
                        }
                    }

                    stringBuilderHTML.Append("</select>");
                    PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                    DataRow[] dataRowTPProcedure = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("TPProcedureId=max(TPProcedureId)");

                    if (dataRowTPProcedure.Length > 0) { Session["TPProcedureIdTemp"] = dataRowTPProcedure[0]["TPProcedureId"].ToString(); }


                }

                #endregion


            }
        }

        //}
        //finally
        //{

        //}

    }

    /// <summary>
    /// <Description>Use to  Set Status of record in tpInterventionProcedures</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>12th Nov 2009</CreatedOn>
    /// </summary>
    /// <param name="cellValue"></param>
    private void SetRecordStatus(int tpInterventionProcedureId, Boolean truefalse)
    {
        DataRow[] dataRowCheckExistance = null;
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //try
        //{
        DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatPlanHRMTPProcedure"] as DataSet;
        //dataRowCheckExistance = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["TPInterventionProcedures"].Select("Isnull('RecordDeleted','N')<> 'Y' and TPInterventionProcedureId= " + tpInterventionProcedureId);
        dataRowCheckExistance = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull('RecordDeleted','N')<> 'Y' and TPInterventionProcedureId= " + tpInterventionProcedureId);

        if (dataRowCheckExistance.Length > 0)
        {

            if (truefalse)
            {
                dataRowCheckExistance[0].BeginEdit();
                dataRowCheckExistance[0]["TPProcedureId"] = Request.QueryString["tpProcedureId"];
                dataRowCheckExistance[0]["TPProcedureAssociatedOrNot"] = "Y";
                dataRowCheckExistance[0].EndEdit();
            }
            else
            {
                dataRowCheckExistance[0].BeginEdit();
                dataRowCheckExistance[0]["TPProcedureAssociatedOrNot"] = "N";



                dataRowCheckExistance[0].EndEdit();
            }
        }
        //}
        //finally
        //{
        //}
    }





    /// <summary>
    /// <Description>Use to  AddNew Record in the TPInterventionProcedureObjectives</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>19/Sept/2009</CreatedOn>
    /// </summary>
    /// <param name="cellValue"></param>
    private void AddNewRecordAssociatedObjective(int objectiveId, string trueFalse)
    {
        DataRow[] drCheckExistance = null;
        try
        {
            drCheckExistance = _DataTableTPObjectives.DataSet.Tables["TPInterventionProcedureObjectives"].Select("Isnull('RecordDeleted','N')<> 'Y' and TPInterventionProcedureId= " + Convert.ToInt32(Request.QueryString["tpInterventionProcedureId"]) + " and  ObjectiveId= " + objectiveId);

            if (trueFalse == "true")
            {
                if (drCheckExistance.Length > 0)
                {
                    if (drCheckExistance[0].RowState != DataRowState.Added)
                    {
                        drCheckExistance[0]["RecordDeleted"] = "N";
                        //Modified By Mamta Gupta - Ref Task No. 863-SCWebPhaseII Bugs/Features - To fill DeletedBy and DeletedDate Information
                        drCheckExistance[0]["DeletedBy"] = DBNull.Value;
                        drCheckExistance[0]["DeletedDate"] = DBNull.Value;
                    }
                }
                else
                {
                    DataRow drNewRow = _DataTableTPObjectives.DataSet.Tables["TPInterventionProcedureObjectives"].NewRow();
                    drNewRow["TPInterventionProcedureId"] = Convert.ToInt32(Request.QueryString["tpInterventionProcedureId"]);
                    drNewRow["ObjectiveId"] = objectiveId;
                    BaseCommonFunctions.InitRowCredentials(drNewRow);
                    //-------------------------------------------------------
                    //drNewRow["RowIdentifier"] = System.Guid.NewGuid();
                    //drNewRow["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //drNewRow["CreatedDate"] = DateTime.Now.ToString();
                    //drNewRow["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //drNewRow["ModifiedDate"] = DateTime.Now.ToString();
                    //-------------------------------------------------------
                    _DataTableTPObjectives.DataSet.Tables["TPInterventionProcedureObjectives"].Rows.Add(drNewRow);
                }
            }
            else
            {
                if (drCheckExistance.Length > 0)
                {
                    if (drCheckExistance[0].RowState == DataRowState.Added)
                    {
                        drCheckExistance[0].Delete();
                    }
                    else
                    {
                        drCheckExistance[0]["RecordDeleted"] = "Y";
                        //Modified By Mamta Gupta - Ref Task No. 863-SCWebPhaseII Bugs/Features - To fill DeletedBy and DeletedDate Information
                        BaseCommonFunctions.UpdateRecordDeletedInformation(drCheckExistance[0]);
                    }
                }
            }
        }
        finally
        {
            drCheckExistance = null;
        }
    }

    /// <summary>
    /// <Description>Use to  AddNew Record in the TPNeedsClientNeeds</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>09/Sept/2009</CreatedOn>
    /// </summary>
    /// <param name="cellValue"></param>
    private void AddNewRecord(Int32 clientNeedId, string trueFalse)
    {
        DataRow[] drCheckExistance = null;
        string needDescription = string.Empty;
        try
        {
            drCheckExistance = _DataTableClientNeeds.Select("Isnull('RecordDeleted','N')<> 'Y' and NeedId= " + Convert.ToInt32(Request.QueryString["needId"]) + " and ClientNeedId= " + clientNeedId);//.DataSet.Tables["CustomTPNeedsClientNeeds"].Select("Isnull('RecordDeleted','N')<> 'Y' and NeedId= " + Convert.ToInt32(Request.QueryString["needId"]) + " and ClientNeedId= " + clientNeedId);
            if (trueFalse == "true")
            {
                if (drCheckExistance.Length > 0)
                {
                    if (drCheckExistance[0].RowState != DataRowState.Added)
                    {
                        drCheckExistance[0]["RecordDeleted"] = "N";
                        //Modified By Mamta Gupta - Ref Task No. 863-SCWebPhaseII Bugs/Features - To fill DeletedBy and DeletedDate Information
                        drCheckExistance[0]["DeletedBy"] = DBNull.Value;
                        drCheckExistance[0]["DeletedDate"] = DBNull.Value;
                    }
                }
                else
                {
                    DataRow drNewRow = _DataTableClientNeeds.NewRow();//.DataSet.Tables["CustomTPNeedsClientNeeds"].NewRow();
                    DataRow[] drClientNeed = _DataTableClientNeeds.DataSet.Tables["CustomClientNeeds"].Select("ClientNeedId=" + clientNeedId + " and isnull(RecordDeleted,'N')<>'Y'");
                    drNewRow["NeedId"] = Convert.ToInt32(Request.QueryString["needId"]);
                    drNewRow["ClientNeedId"] = clientNeedId;
                    if (drClientNeed.Length > 0)
                    {
                        if (drClientNeed[0]["NeedDescription"] != DBNull.Value)
                        {
                            drNewRow["NeedDescription"] = drClientNeed[0]["NeedDescription"];
                        }
                    }

                    BaseCommonFunctions.InitRowCredentials(drNewRow);
                    //-------------------------------------------------------
                    //drNewRow["RowIdentifier"] = System.Guid.NewGuid();
                    //drNewRow["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //drNewRow["CreatedDate"] = DateTime.Now.ToString();
                    //drNewRow["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //drNewRow["ModifiedDate"] = DateTime.Now.ToString();
                    //-------------------------------------------------------                 
                    _DataTableClientNeeds.Rows.Add(drNewRow);
                }
            }
            else
            {
                if (drCheckExistance.Length > 0)
                {
                    if (drCheckExistance[0].RowState == DataRowState.Added)
                    {
                        drCheckExistance[0].Delete();
                    }
                    else
                    {
                        drCheckExistance[0]["RecordDeleted"] = "Y";
                        drCheckExistance[0]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                        drCheckExistance[0]["DeletedDate"] = DateTime.Now.ToString();
                    }
                }
            }
        }
        finally
        {
            drCheckExistance = null;
        }
    }

    /// <summary>
    /// <Description></Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>10th-Sept-2009</CreatedOn>
    /// </summary>
    private void InsertNewRowInTxPlan()
    {
        SHS.UserBusinessServices.Document objectDocuments = null;
        DataRow dataRowQuick = null;
        DataSet dataSetForUpdate = null;
        DataRow[] dataRowTPElementOrder = null;
        string whereClause = string.Empty;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetTreatmentPlanHRM.Tables.Contains(Request.QueryString["tableName"]))
                {
                    dataRowQuick = dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].NewRow();
                    dataRowQuick.BeginEdit();
                    dataRowQuick["StaffId"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId;
                    dataRowQuick["TPElementTitle"] = Request.Form["elementTitle"];
                    dataRowTPElementOrder = dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].Select("IsNull(RecordDeleted,'N')<>'Y' and staffid = " + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId, "TPElementOrder Desc");
                    if (dataRowTPElementOrder.Length > 0)
                    {
                        dataRowQuick["TPElementOrder"] = Convert.ToInt32(dataRowTPElementOrder[0]["TPElementOrder"]) + 1;
                    }
                    else
                    {
                        dataRowQuick["TPElementOrder"] = 1;
                    }
                    dataRowQuick["TPElementText"] = Request.Form["goalText"];
                    dataRowQuick["RecordDeleted"] = "N";
                    //Modified By Mamta Gupta - Ref Task No. 863-SCWebPhaseII Bugs/Features - To fill DeletedBy and DeletedDate Information
                    dataRowQuick["DeletedBy"] = DBNull.Value;
                    dataRowQuick["DeletedDate"] = DBNull.Value;
                    BaseCommonFunctions.UpdateModifiedInformation(dataRowQuick);
                    //--------------------------------------------------------
                    //dataRowQuick["RowIdentifier"] = Guid.NewGuid();
                    //dataRowQuick["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //dataRowQuick["CreatedDate"] = DateTime.Now;
                    //dataRowQuick["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //dataRowQuick["ModifiedDate"] = DateTime.Now;
                    //-------------------------------------------------------------------

                    dataRowQuick.EndEdit();
                    dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].Rows.Add(dataRowQuick);
                    objectDocuments = new SHS.UserBusinessServices.Document();
                    if (!dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].ExtendedProperties.Contains("UpdateChildTable"))
                    {
                        dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].ExtendedProperties.Add("UpdateChildTable", false);
                    }
                    else
                    {
                        dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].ExtendedProperties["UpdateChildTable"] = false;
                    }
                    dataSetForUpdate = new DataSet();
                    dataSetForUpdate.Merge(dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]]);
                    //commented by shifali on 30 july,2010
                    //objectDocuments.UpdateDocuments(dataSetForUpdate, "", 0, "", BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode,"","");
                    objectDocuments.UpdateDocuments(dataSetForUpdate, "", 0, "", BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode, "", "", "",5763,"","","","");

                    dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].AcceptChanges();
                    dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].Clear();
                    whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                    DataTable dtTemp = (objectDocuments.GetUpdatedQuickTypeData(dataSetTreatmentPlanHRM, whereClause, Request.QueryString["tableName"])).Tables[Request.QueryString["tableName"]];
                    dataSetTreatmentPlanHRM.Tables[Request.QueryString["tableName"]].Merge(dtTemp);
                }
            }
        }
        finally
        {
            objectDocuments = null;
            dataRowQuick = null;
            dataSetForUpdate = null;
            dataRowTPElementOrder = null;
        }
    }


    /// <summary>
    /// <Description>This method is used to get value from TPQuickGoal/TPQuickObjective/TPQuickIntervention  and add in there respective table</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>11th-Sept-2009</CreatedOn>
    /// </summary>
    private void UpdateTxPlanText()
    {
        DataRow[] dataRowQuickTxPlan = null;
        DataRow[] dataRowTxPlan = null;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    dataRowQuickTxPlan = dataSetTreatmentPlanHRM.Tables[Request.Form["txtableField"]].Select("TPQuickId=" + Convert.ToInt32(Request.QueryString["keyTxValue"]));
                    if (dataRowQuickTxPlan.Length > 0)
                    {
                        dataRowTxPlan = dataSetTreatmentPlanHRM.Tables[Request.Form["tableField"]].Select(Request.Form["keyFieldName"] + "=" + Convert.ToInt32(Request.Form["keyValue"]));
                        if (dataRowTxPlan.Length > 0)
                        {
                            dataRowTxPlan[0].BeginEdit();
                            switch (Request.Form["tableField"])
                            {
                                case "TPNeeds":
                                    dataRowTxPlan[0]["GoalText"] = dataRowQuickTxPlan[0]["TPElementText"];
                                    break;
                                case "TPObjectives":
                                    dataRowTxPlan[0]["ObjectiveText"] = dataRowQuickTxPlan[0]["TPElementText"];
                                    break;
                                case "TPInterventionProcedures":
                                    dataRowTxPlan[0]["InterventionText"] = dataRowQuickTxPlan[0]["TPElementText"];
                                    break;
                            }
                            dataRowTxPlan[0].EndEdit();


                        }
                    }
                }
            }
        }
        finally
        {
            dataRowQuickTxPlan = null;
            dataRowTxPlan = null;
        }
    }


    /// <summary>
    /// <Description>Insert New Row in the TPObjective</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>16th-Sept-2009</CreatedOn>
    /// </summary>
    private void AddObjective()
    {
        int needId = 0;
        DataView dataViewTPObjectives = null;
        DataRowView dataRowViewObjective = null;
        DataRow[] dataRowTPNeeds = null;
        double objectiveNumber = 0.0;
        try
        {
            needId = Convert.ToInt32(Request.QueryString["needId"]);
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                //Perform table contain check
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Contains("TPObjectives") && dataSetTreatmentPlanHRM.Tables.Contains("TPNeeds"))
                {
                    if (dataSetTreatmentPlanHRM.Tables["TPObjectives"].Rows.Count >= 0)
                    {
                        dataRowTPNeeds = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Select("ISNULL(RecordDeleted,'N')<>'Y' and NeedId=" + needId);
                        if (dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("ISNULL(RecordDeleted,'N')<>'Y' and NeedId=" + needId).Length > 0)
                        {
                            objectiveNumber = Convert.ToDouble(dataSetTreatmentPlanHRM.Tables["TPObjectives"].Compute("Max(ObjectiveNumber)", "ISNULL(RecordDeleted,'N')<>'Y' and NeedId=" + needId));
                            objectiveNumber = Math.Round((objectiveNumber + .01), 2);
                        }
                        else
                        {
                            objectiveNumber = Math.Round(Convert.ToDouble(dataRowTPNeeds[0]["NeedNumber"]) + .01, 2);
                        }
                        //Create DataView of TPObjectives
                        dataViewTPObjectives = new DataView(dataSetTreatmentPlanHRM.Tables["TPObjectives"]);
                        dataRowViewObjective = dataViewTPObjectives.AddNew(); //Create New Row
                        dataRowViewObjective.BeginEdit();
                        dataRowViewObjective["NeedId"] = needId;
                        dataRowViewObjective["ObjectiveStatus"] = 191;
                        dataRowViewObjective["DocumentVersionId"] = dataRowTPNeeds[0]["DocumentVersionId"];
                        //Commented By Anuj as DocumentId and Version is not exit in new dataBase 3.1Dev
                        //dataRowViewObjective["DocumentId"] = dataRowTPNeeds[0]["DocumentId"];                                                
                        //dataRowViewObjective["Version"] = dataRowTPNeeds[0]["Version"];
                        //Chenges ended over here
                        dataRowViewObjective["ObjectiveNumber"] = Convert.ToDouble(objectiveNumber.ToString("0.00"));
                        //BaseCommonFunctions.InitRowCredentials(dataRowViewObjective);
                        //----------------------------------------------------------------
                        dataRowViewObjective["RowIdentifier"] = System.Guid.NewGuid();
                        dataRowViewObjective["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                        dataRowViewObjective["CreatedDate"] = DateTime.Now.ToString();
                        dataRowViewObjective["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                        dataRowViewObjective["ModifiedDate"] = DateTime.Now.ToString();
                        ////------------------------------------------------------------------
                        dataRowViewObjective.EndEdit();
                        //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
                        //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                        //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                        CreateGoal();
                        PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
                    }
                }
            }
        }
        finally
        {
            dataViewTPObjectives = null;
            dataRowViewObjective = null;
            dataRowTPNeeds = null;
        }

    }

    /// <summary>
    /// <Description>Delete Row from TPObjective</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>16th-Sept-2009</CreatedOn>
    /// </summary>
    private void DeleteObjective()
    {
        DataRow[] dataRowDeleteObjective = null;
        DataRow[] dataRowObjectives = null;
        Double maxObjectiveNumber = 0.0;
        string objectiveNumber = string.Empty;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Contains("TPObjectives") && dataSetTreatmentPlanHRM.Tables.Contains("TPNeeds"))
                {
                    dataRowDeleteObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("Isnull(RecordDeleted,'N')<>'Y' and ObjectiveID=" + Request.Form["objectiveId"]);
                    dataRowDeleteObjective[0].BeginEdit();
                    dataRowDeleteObjective[0]["RecordDeleted"] = "Y";
                    dataRowDeleteObjective[0]["DeletedDate"] = System.DateTime.Now;
                    dataRowDeleteObjective[0]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    dataRowDeleteObjective[0].EndEdit();
                    objectiveNumber = dataRowDeleteObjective[0]["ObjectiveNumber"].ToString();
                    maxObjectiveNumber = Convert.ToInt32(objectiveNumber.ToString().Substring(0, objectiveNumber.ToString().IndexOf(".")));
                    maxObjectiveNumber += .01;
                    //Commented By Anuj as DocumentId and Version is not exist in new DataBase
                    //dataRowObjectives = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("ISNULL(RecordDeleted,'N')<>'Y' and ObjectiveNumber >" + objectiveNumber.ToString() + " and DocumentID=" + Convert.ToInt32(dataRowDeleteObjective[0]["DocumentId"]) + " and Version=" + Convert.ToInt32(dataRowDeleteObjective[0]["Version"]) + " and NeedID=" + Request.QueryString["needId"]);
                    //Chnages Ended over here
                    dataRowObjectives = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("ISNULL(RecordDeleted,'N')<>'Y' and ObjectiveNumber >" + objectiveNumber.ToString() + " and DocumentVersionId=" + Convert.ToInt32(dataRowDeleteObjective[0]["DocumentVersionId"]) + " and NeedID=" + Request.QueryString["needId"]);
                    for (int objectiveCount = 0; objectiveCount < dataRowObjectives.Length; objectiveCount++)
                    {
                        dataRowObjectives[objectiveCount]["ObjectiveNumber"] = Convert.ToDouble(dataRowObjectives[objectiveCount]["ObjectiveNumber"]) - Convert.ToDouble(".01");
                    }
                    //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
                    //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                    //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                    CreateGoal();
                    PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
                }
            }
        }
        finally
        {
            dataRowDeleteObjective = null;
            dataRowObjectives = null;
        }
    }

    /// <summary>
    /// <Description>Insert New Row in TPInterventionProcedures</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>17th-Sept-2009</CreatedOn>
    /// </summary>
    private void AddIntervention()
    {
        DataRow[] dataRowTPNeeds = null;
        DataRow datarowTPInterventionProcedures = null;
        int needId = 0;
        double interventionNumber = 0.0;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                needId = Convert.ToInt32(Request.QueryString["needId"]);
                dataRowTPNeeds = dataSetTreatmentPlanHRM.Tables["TpNeeds"].Select("NeedId=" + needId);
                if (dataRowTPNeeds.Length > 0)
                {
                    if (dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + needId).Length > 0)
                    {
                        interventionNumber = Convert.ToDouble(dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Compute("Max(InterventionNumber)", "Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + needId));
                        interventionNumber = Math.Round((interventionNumber + .01), 2);
                    }
                    else
                    {
                        interventionNumber = Math.Round(Convert.ToDouble(dataRowTPNeeds[0]["NeedNumber"]) + .01, 2);
                    }
                    datarowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].NewRow();
                    datarowTPInterventionProcedures.BeginEdit();
                    datarowTPInterventionProcedures["NeedId"] = needId;
                    datarowTPInterventionProcedures["InterventionNumber"] = Convert.ToDouble(interventionNumber.ToString("0.00"));
                    BaseCommonFunctions.InitRowCredentials(datarowTPInterventionProcedures);
                    //-----------------------------------------------------------------------
                    //datarowTPInterventionProcedures["RowIdentifier"] = System.Guid.NewGuid();
                    //datarowTPInterventionProcedures["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //datarowTPInterventionProcedures["CreatedDate"] = DateTime.Now.ToString();
                    //datarowTPInterventionProcedures["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    //datarowTPInterventionProcedures["ModifiedDate"] = DateTime.Now.ToString();
                    //----------------------------------------------------------------------------
                    datarowTPInterventionProcedures.EndEdit();
                    dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Add(datarowTPInterventionProcedures);
                    //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
                    //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                    //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                    CreateGoal();

                    PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);

                }
            }
        }
        finally
        {
            dataRowTPNeeds = null;
            datarowTPInterventionProcedures = null;
        }
    }


    /// <summary>
    /// <Description>Delete Row from TPInterventionProcedures</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>18th-Sept-2009</CreatedOn>
    /// </summary>
    private void DeleteIntervention()
    {
        DataRow[] dataRowTPInterventionProcedures = null;
        DataRow[] drTPInterventionProcedure = null;
        int tpInterventionProcedureId = 0;
        double interventionNumber = 0.0;
        double maxObjectiveNumber = 0.0;
        try
        {
            tpInterventionProcedureId = Convert.ToInt32(Request.Form["TPInterventionProcedureId"]);
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPInterventionProcedures") && dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Count > 0)
                    {
                        dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and TPInterventionProcedureId=" + tpInterventionProcedureId);
                        if (dataRowTPInterventionProcedures.Length > 0)
                        {
                            dataRowTPInterventionProcedures[0].BeginEdit();
                            dataRowTPInterventionProcedures[0]["RecordDeleted"] = 'Y';
                            dataRowTPInterventionProcedures[0]["DeletedDate"] = System.DateTime.Now;
                            dataRowTPInterventionProcedures[0]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                            dataRowTPInterventionProcedures[0].EndEdit();

                            //Get Current Row Intervention number
                            interventionNumber = Convert.ToDouble(dataRowTPInterventionProcedures[0]["InterventionNumber"]);
                            maxObjectiveNumber = Convert.ToInt32(interventionNumber.ToString().Substring(0, interventionNumber.ToString().IndexOf(".")));
                            maxObjectiveNumber += .01;
                            drTPInterventionProcedure = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("ISNULL(RecordDeleted,'N')<>'Y' and InterventionNumber >" + interventionNumber.ToString() + " and NeedID=" + Convert.ToInt32(dataRowTPInterventionProcedures[0]["NeedId"]));
                            if (drTPInterventionProcedure.Length > 0)
                            {
                                for (int interventionCount = 0; interventionCount < drTPInterventionProcedure.Length; interventionCount++)
                                {
                                    drTPInterventionProcedure[interventionCount]["InterventionNumber"] = Convert.ToDouble(drTPInterventionProcedure[interventionCount]["InterventionNumber"]) - Convert.ToDouble(".01");
                                }
                            }
                            //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
                            //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                            //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                            CreateGoal();
                            PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
                        }
                    }
                }
            }
        }
        finally
        {
            dataRowTPInterventionProcedures = null;
            drTPInterventionProcedure = null;
        }
    }

    /// <summary>
    /// <Description>Method is used to Copy Intervention ( Add new row in TPIntervention Procedure as well as associated tables)</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>18th-Sept-2009</CreatedOn>
    /// </summary>
    private void QuickCopyIntervention()
    {
        DataRow datarowTPInterventionProcedures = null;
        DataRow[] datarowInterVention = null;
        DataRow datarowTPIntervention = null;
        DataRow[] dataRowTPIPObjectives = null;
        DataRow drNewRow = null;
        DataRow[] dataRowRenumber = null;
        int tpInterventionProcedureId = 0;
        int tpInterventionProcedureIdNew = 0;
        double tpInterventionNumber = 0.0;
        try
        {
            tpInterventionProcedureId = Convert.ToInt32(Request.QueryString["tpInterventionProcedureId"]);
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPInterventionProcedures") && dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Count > 0)
                    {
                        datarowInterVention = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and TPInterventionProcedureId=" + tpInterventionProcedureId);
                        if (datarowInterVention.Length > 0)
                        {
                            tpInterventionNumber = Convert.ToDouble(datarowInterVention[0]["InterventionNumber"]);
                            tpInterventionNumber = Math.Round((tpInterventionNumber + .01), 2);
                            datarowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].NewRow();
                            datarowTPInterventionProcedures.BeginEdit();
                            datarowTPInterventionProcedures["NeedId"] = datarowInterVention[0]["NeedId"];
                            datarowTPInterventionProcedures["InterventionText"] = datarowInterVention[0]["InterventionText"];
                            datarowTPInterventionProcedures["InterventionNumber"] = Convert.ToDouble(tpInterventionNumber.ToString("0.00"));
                            datarowTPInterventionProcedures["AuthorizationCodeId"] = datarowInterVention[0]["AuthorizationCodeId"];
                            datarowTPInterventionProcedures["SiteId"] = datarowInterVention[0]["SiteId"];
                            BaseCommonFunctions.InitRowCredentials(datarowTPInterventionProcedures);
                            //--------------------------------------------------------------------------------
                            //datarowTPInterventionProcedures["RowIdentifier"] = System.Guid.NewGuid();
                            //datarowTPInterventionProcedures["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                            //datarowTPInterventionProcedures["CreatedDate"] = DateTime.Now.ToString();
                            //datarowTPInterventionProcedures["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                            //datarowTPInterventionProcedures["ModifiedDate"] = DateTime.Now.ToString();
                            //--------------------------------------------------------------------------------
                            datarowTPInterventionProcedures.EndEdit();
                            tpInterventionProcedureIdNew = Convert.ToInt32(datarowTPInterventionProcedures["TPInterventionProcedureId"]);

                            dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Add(datarowTPInterventionProcedures);


                            #region copy objectives

                            dataRowTPIPObjectives = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedureObjectives"].Select("TPInterventionProcedureId=" + tpInterventionProcedureId + "  and Isnull(RecordDeleted,'N')<>'Y'");
                            for (int i = 0; i < dataRowTPIPObjectives.Length; i++)
                            {
                                drNewRow = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedureObjectives"].NewRow();
                                drNewRow["TPInterventionProcedureId"] = tpInterventionProcedureIdNew;
                                drNewRow["ObjectiveId"] = dataRowTPIPObjectives[i]["ObjectiveId"];
                                BaseCommonFunctions.InitRowCredentials(drNewRow);
                                //--------------------------------------------------
                                //drNewRow["RowIdentifier"] = System.Guid.NewGuid();
                                //drNewRow["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                                //drNewRow["CreatedDate"] = DateTime.Now.ToString();
                                //drNewRow["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                                //drNewRow["ModifiedDate"] = DateTime.Now.ToString();
                                //------------------------------------------------------------
                                dataSetTreatmentPlanHRM.Tables["TPInterventionProcedureObjectives"].Rows.Add(drNewRow);
                            }
                            #endregion

                            #region Logic for Regenerate numbers
                            DataRow[] _dataRowRenumber = null;
                            _dataRowRenumber = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + Convert.ToInt32(datarowTPInterventionProcedures["NeedId"]) + " and  TPInterventionProcedureId <> " + Convert.ToInt32(datarowTPInterventionProcedures["TPInterventionProcedureId"]));
                            foreach (DataRow dRowInterventionProcedure in _dataRowRenumber)
                            {
                                if (Convert.ToDouble(dRowInterventionProcedure["InterventionNumber"]) > Convert.ToDouble(datarowInterVention[0]["InterventionNumber"]))
                                {
                                    tpInterventionNumber = Math.Round((tpInterventionNumber + .01), 2);
                                    dRowInterventionProcedure.BeginEdit();
                                    dRowInterventionProcedure["InterventionNumber"] = tpInterventionNumber;
                                    dRowInterventionProcedure.EndEdit();
                                }
                            }
                            #endregion

                            CreateGoal();
                            PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
                           // Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/PeriodicReview/PRTxPlan.ascx");
                          //  (controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                           // PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                        }
                    }
                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            datarowTPInterventionProcedures = null;
            datarowInterVention = null;
            datarowTPIntervention = null;
            dataRowTPIPObjectives = null;
            drNewRow = null;
            dataRowRenumber = null;
        }
    }

    /// <summary>
    /// <Description>Method is used to create a new Goal i.e add new row in TPNeed table</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>19th-Sept-2009</CreatedOn>
    /// </summary>
    private void AddGoal()
    {
        DataRow[] DataRowTPNeeds = null;
        DataRow dataRowTPNeedNew = null;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPNeeds"))
                    {
                        DataRowTPNeeds = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + Convert.ToInt32(Request.QueryString["needId"]));
                        if (DataRowTPNeeds.Length > 0)
                        {

                            dataRowTPNeedNew = dataSetTreatmentPlanHRM.Tables["TPNeeds"].NewRow();

                            dataRowTPNeedNew.BeginEdit();
                            dataRowTPNeedNew["DocumentVersionId"] = DataRowTPNeeds[0]["DocumentVersionId"];

                            //string goalNumber = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Compute("Max(NeedNumber)", "Isnull(RecordDeleted,'N')<>'Y'").ToString().Trim();

                            //----Changed By Ashwani Kumar Angrish with ref to task:600 of SCWeb venture Documents
                            int goalNumber = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Select("Isnull(RecordDeleted,'N')<>'Y'").Length;
                            if (goalNumber != 0)
                                dataRowTPNeedNew["NeedNumber"] = Convert.ToInt32(goalNumber) + 1;
                            else
                                dataRowTPNeedNew["NeedNumber"] = 1;

                            dataRowTPNeedNew["GoalText"] = Request.Form["goalText"];
                            dataRowTPNeedNew["GoalStrengths"] = Request.Form["goalStrengths"];
                            dataRowTPNeedNew["GoalBarriers"] = Request.Form["goalBarriers"];
                            dataRowTPNeedNew["GoalActive"] = Request.Form["goalActive"];
                            dataRowTPNeedNew["GoalMonitoredBy"] = Request.Form["goalMonitoredBy"];

                            if (!string.IsNullOrEmpty(Request.Form["goalTargetDate"]))
                            {
                                dataRowTPNeedNew["GoalTargetDate"] = Convert.ToDateTime(Request.Form["goalTargetDate"]); //Convert.ToDateTime(Request.Form["goalTargetDate"]);
                            }
                            if (!string.IsNullOrEmpty(Request.Form["goalCreatedDate"]))
                            {
                                dataRowTPNeedNew["NeedCreatedDate"] = Request.Form["goalCreatedDate"];
                            }
                            if (!string.IsNullOrEmpty(Request.Form["stageOfTreatment"]))
                            {
                                dataRowTPNeedNew["StageOfTreatment"] = Request.Form["stageOfTreatment"];
                            }

                            dataRowTPNeedNew["NeedModifiedDate"] = DateTime.Now.ToString();
                            //----Commented By Ashwani on 3 Fed 2010 at 9:47 pm
                            //----Reason:No such column i.e RowAddedInCurrentPlan exists in the dataRowTPNeedNew
                            //dataRowTPNeedNew["RowAddedInCurrentPlan"] = true;
                            //----Commented By Ashwani on 3 Fed 2010 at 9:47 pm
                            dataRowTPNeedNew["GoalNaturalSupports"] = Request.Form["naturalSupport"];
                            dataRowTPNeedNew["GoalEmployment"] = Request.Form["goalEmployment"];
                            dataRowTPNeedNew["GoalLivingArrangement"] = Request.Form["goalliviningarragement"];
                            dataRowTPNeedNew["GoalHealthSafety"] = Request.Form["goalhealthSafety"];
                            BaseCommonFunctions.InitRowCredentials(dataRowTPNeedNew);
                            //----------------------------------------------------------------
                            //dataRowTPNeedNew["RowIdentifier"] = System.Guid.NewGuid();
                            //dataRowTPNeedNew["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                            //dataRowTPNeedNew["CreatedDate"] = DateTime.Now.ToString();
                            //dataRowTPNeedNew["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                            //dataRowTPNeedNew["ModifiedDate"] = DateTime.Now.ToString();
                            //-----------------------------------------------------------------
                            dataRowTPNeedNew.EndEdit();
                            dataSetTreatmentPlanHRM.Tables["TpNeeds"].Rows.Add(dataRowTPNeedNew);

                            CreateGoal();
                            //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
                            //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                            //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                            PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
                        }
                    }
                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            DataRowTPNeeds = null;
        }
    }




    /// <summary>
    /// <Description>This method is used to Read Data from TPNeeds and Create Goal Section </Description>
    /// <Author>Vikas Vyas</Author>       
    /// <CreatedOn></CreatedOn>
    /// <Modified By >Anuj Tomat</Author>
    /// <Modified On>12 oct,2009</CreatedOn>
    /// </summary>
    private void CreateGoal()
    {
        DataSet dataSetTreatmentPlanHRM = null;
        DataView dataViewTPNeeds = null;
        DataRowView dataRowViewTPNeeds = null;
        StringBuilder stringBuilderHTML = null;
        DropDownList dropDownListStageOfTreatment = null;
        bool isGoalCreated = false;
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //try
        //{
        PanelPeriodicReview.Controls.Clear();

        using (dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
        {
            if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
            {
                if (dataSetTreatmentPlanHRM.Tables.Contains("TPNeeds") && dataSetTreatmentPlanHRM.Tables["TPNeeds"].Rows.Count > 0)
                {
                    stringBuilderHTML = new StringBuilder();
                    //--------Added on 18 March
                    stringBuilderHTML.Append("<table>");
                    stringBuilderHTML.Append("<tr>");
                    stringBuilderHTML.Append("<td>");
                    stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0'   width='128px'>");
                    stringBuilderHTML.Append("<tr>");
                    stringBuilderHTML.Append("<td class='expandable_btn_left' align='left'>");
                    stringBuilderHTML.Append("<input class='form_btn_left1' type='button' value='View Client Needs' id='ButtonViewClientNeeds'  name='ButtonViewClientNeeds' tabindex='0' onclick= \"javascript:openClientNeed();\" />");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("<td class='expandable_btn_right'>");
                    stringBuilderHTML.Append("&nbsp;");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("</tr>");
                    stringBuilderHTML.Append("</table>");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("</tr>");
                    stringBuilderHTML.Append("</table>");
                    PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                    dataViewTPNeeds = new DataView(dataSetTreatmentPlanHRM.Tables["TpNeeds"]);
                    //Sort On the basis of Need Number because we have show Goal on Number basis
                    dataViewTPNeeds.Sort = "NeedNumber";
                    dataViewTPNeeds.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'";

                    //Loop how many rows exists in the TPNeeds table for creating Goal
                    for (int needCount = 0; needCount < dataViewTPNeeds.Count; needCount++)
                    {
                        #region to Check whether goal will be deleted or not
                        //----------Added by Ashwani kumar Angrish on 22 Feb
                        //----To handle Delete Goal from Periodic Review
                        if ((Int32)dataViewTPNeeds[needCount]["NeedId"] < 0)
                        {
                            //-------Changed By Ashwani Kumar Angrish on 29 June
                            isGoalCreated = true;
                        }
                        else if ((Int32)dataViewTPNeeds[needCount]["NeedId"] > 0 && dataViewTPNeeds[needCount]["SourceNeedId"].ToString().Trim() == "")
                        {
                            isGoalCreated = true;
                        }
                        #endregion to Check whether goal will be deleted or not


                        if (isGoalCreated == true)
                        {
                            dataRowViewTPNeeds = dataViewTPNeeds[needCount]; //Create DataRowView 
                            stringBuilderHTML = new StringBuilder(); //allocation of memory
                            //Create  table for Goal
                            if (needCount % 2 == 0)
                            {
                                stringBuilderHTML.Append("<table Id=" + needCount + "  style='width:99%;' border='0' cellpadding='0' cellspacing='0' >");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<table Id=" + needCount + "  style='width:99%;'  border='0' cellpadding='0' cellspacing='0' >");

                            }


                            //#region main table starts

                            //Start -- New Code Added By Damanpreet For Create a Section
                            #region 1st Main TR
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");

                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td align='left' nowrap='nowrap' class='content_tab_left'>");
                            //if (dataRowViewTPNeeds["SourceNeedId"] == DBNull.Value)
                            //{
                            //    if (_FromPROnload != true)
                            //        stringBuilderHTML.Append("<img id=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + " src=http://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/App_Themes/Includes/Images/deleteIcon.gif  tag=" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='cursor:hand;' onclick = \"DeletePRGoal('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + dataViewTPNeeds.Count + "','false');\"/>");
                            //    else
                            //        stringBuilderHTML.Append("<img id=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + " src=http://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/App_Themes/Includes/Images/deleteIcon.gif  tag=" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='cursor:hand;' onclick = \"DeletePRGoal('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + dataViewTPNeeds.Count + "','true');\"/>");
                            //}
                            //else
                            //{
                            //    stringBuilderHTML.Append("&nbsp;");
                            //}
                            stringBuilderHTML.Append("<span  name=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["NeedId"].ToString() + "' style='color:Black;font-size:11px;'> Goal # " + dataRowViewTPNeeds["NeedNumber"].ToString() + "</span>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("<td width='17'>");
                            stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='17' alt='' src="+RelativePath+"App_Themes/Includes/Images/content_tab_sep.gif /> ");
                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("<td width='100%' class='content_tab_top'>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("<td width='7'>");
                            stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='7' alt='' src="+RelativePath+"App_Themes/Includes/Images/content_tab_right.gif />");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append(" </tr>");
                            stringBuilderHTML.Append("</table>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            #endregion
                            //Stop -- New Code Added By Damanpreet For Create a Section

                            #region 2nd Main TR
                            //---Added By Daman

                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td class='right_contanier_bg' colspan='3'>");
                            stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                            stringBuilderHTML.Append("<tr>");
                            # region TR first
                            stringBuilderHTML.Append("<td colspan='3' style='height:3px;'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR first
                            stringBuilderHTML.Append("</tr>");


                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag
                            #region TR Second
                            stringBuilderHTML.Append("<td style='width:3%' valign='top'>");//1st Row 1st Column Open Tag
                            if (dataRowViewTPNeeds["SourceNeedId"] == DBNull.Value)
                            {
                                if (_FromPROnload != true)
                                    stringBuilderHTML.Append("<img id=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + " src="+RelativePath+"App_Themes/Includes/Images/deleteIcon.gif  tag=" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='cursor:hand;' onclick = \"DeletePRGoal('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + dataViewTPNeeds.Count + "','false');\"/>");
                                else
                                    stringBuilderHTML.Append("<img id=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + " src="+RelativePath+"App_Themes/Includes/Images/deleteIcon.gif  tag=" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='cursor:hand;' onclick = \"DeletePRGoal('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + dataViewTPNeeds.Count + "','true');\"/>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("&nbsp;");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Column  Close tag

                            stringBuilderHTML.Append("<td width='5%' valign='top' align='center'>");//1st Row 2nd Column Open Tag
                            //Assign Goal Text e.g (Goal#1)
                            stringBuilderHTML.Append("<span    name=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["NeedId"].ToString() + "' style='color:Black;font-size:11px;'> Goal # " + dataRowViewTPNeeds["NeedNumber"].ToString() + "</span>");
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag


                            stringBuilderHTML.Append("<td align='left'>"); //1st Row 3rd Column Open Tag                              
                            stringBuilderHTML.Append("<textarea spellcheck='True' tabindex='0' onchange = \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalText','TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"  name='TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id='TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "' rows='4'  bindautosaveevents='False' BindSetFormData='False' cols='5'  class='form_textarea'>");
                            if (dataRowViewTPNeeds["GoalText"] != DBNull.Value)
                            {
                                stringBuilderHTML.Append(dataRowViewTPNeeds["GoalText"].ToString().Trim() + "</textarea>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("</textarea>");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 3rd Column Close Tag
                            #endregion TR Second
                            stringBuilderHTML.Append("</tr>");

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region TR Third
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Third
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here

                            stringBuilderHTML.Append("<tr>"); //2nd Row Open Tag
                            #region TR Fourth
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //2nd Row 1st & 2nd Column Open Tag/Close Tag

                            stringBuilderHTML.Append("<td align='left'>"); //2nd Row 3rd Column Open Tag
                            #region Inside 2nd Row 3rd Column
                            stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='98%'>");
                            stringBuilderHTML.Append("<tr>"); //1st Row Open tag

                            stringBuilderHTML.Append("<td style='width:17%;padding-right:3px;' valign='middle' align='left' >"); //1st Row 1st Column Open Tag                               
                            stringBuilderHTML.Append("<span   name='Span_GoalCreated_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id='Span_GoalCreated'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'>Goal Start Date</span>");
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag

                            stringBuilderHTML.Append("<td  valign='top' align='left' style='width:17%;padding-left:3px;'>"); //1st Row 2nd Column Open Tag

                            if (dataRowViewTPNeeds["NeedCreatedDate"] != DBNull.Value) //Peform DBNull Check
                            {
                                stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False' datatype='Date' readonly='readonly'   tabindex='0'  value='" + Convert.ToDateTime(dataRowViewTPNeeds["NeedCreatedDate"]).ToString("MM/dd/yyyy") + "'  name=Text_TPNeeds_GoalStartDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Text_TPNeeds_GoalStartDate_" + dataRowViewTPNeeds["NeedId"].ToString() + " class='dateTextBoxWidth form_textbox' tabindex='1' />"); //Create  
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False'  datatype='Date'  tabindex='0'  readonly='readonly'  name=Text_TPNeeds_GoalStartDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Text_TPNeeds_GoalStartDate_" + dataRowViewTPNeeds["NeedId"].ToString() + " class='dateTextBoxWidth form_textbox'  tabindex='1' />");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag

                            stringBuilderHTML.Append("<td style='width: 25%'  valign='middle'>"); //1st Row 3rd Column Open Tag
                            stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' width='100%'>"); //Create
                            stringBuilderHTML.Append("<tr>");//1st Row Open tag

                            stringBuilderHTML.Append("<td align='right' style='padding-right:5px;'>"); //1st Row 1st Column Open Tag
                            stringBuilderHTML.Append("<span name='Span_GoalActive_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id='Span_GoalActive_" + dataRowViewTPNeeds["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'>Active ?</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag

                            stringBuilderHTML.Append("<td valign='top' align='right'>"); //1st Row 1st Column Open Tag                               
                            string goalActive = string.Empty;
                            if (dataRowViewTPNeeds["GoalActive"] != DBNull.Value) //Peform DBNull Check
                            {
                                goalActive = dataRowViewTPNeeds["GoalActive"].ToString();//Get the value of GoalActive
                            }
                            if (goalActive.ToUpper() == "Y")
                            {
                                stringBuilderHTML.Append("<input  class='RadioText'  type='radio' bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer'  onclick = \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_Y_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\" checked='checked' id=Radio_TPNeeds_GoalActive_Y_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Radio_TPNeeds_GoalActive_" + dataRowViewTPNeeds["NeedId"].ToString() + "   tabindex='0'  value='Y'/><span  class='RadioText'>Yes</span>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input  class='RadioText'  type='radio' bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer'  onclick = \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_Y_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"   id=Radio_TPNeeds_GoalActive_Y_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Radio_TPNeeds_GoalActive_" + dataRowViewTPNeeds["NeedId"].ToString() + "    tabindex='0'  value='Y'/><span  class='RadioText'>Yes</span>");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag

                            stringBuilderHTML.Append("<td valign='top' align='left' style='padding-left:3px'>"); //1st Row 2nd Column Open Tag
                            if (goalActive.ToUpper() == "N")
                            {
                                stringBuilderHTML.Append("<input type='radio'  class='RadioText'  style='cursor:pointer'  onclick = \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_N_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"     checked='checked' id=Radio_TPNeeds_GoalActive_N_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Radio_TPNeeds_GoalActive_" + dataRowViewTPNeeds["NeedId"].ToString() + "   tabindex='0'  value='N' /><span class='RadioText'>No</span>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='radio' class='RadioText'  style='cursor:pointer'  onclick = \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalActive','Radio_TPNeeds_GoalActive_N_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"    id=Radio_TPNeeds_GoalActive_N_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Radio_TPNeeds_GoalActive_" + dataRowViewTPNeeds["NeedId"].ToString() + "   tabindex='0'  value='N' /><span class='RadioText'>No</span>");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag

                            stringBuilderHTML.Append("</tr>");//1st Row Close tag
                            stringBuilderHTML.Append("</table>"); //Close
                            stringBuilderHTML.Append("</td>"); //1st Row 3rd Column Close Tag

                            //stringBuilderHTML.Append("<td  align='left' style='width:21%; padding-left:12px;'>");  //1st Row 4rth Column Open Tag
                            stringBuilderHTML.Append("<td align='right' style='padding-right:2px;' >");  //1st Row 4rth Column Open Tag
                            stringBuilderHTML.Append("<span   name='Span_GoalMonitoredBy_'" + "style='color:Black;font-size:11px;'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id='Span_GoalMonitoredBy_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'>Monitored By</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 4rth Column Close Tag                                   

                            //stringBuilderHTML.Append("<td align='left' style='padding-left:0px;'>"); //1st Row 5th Column Open Tag                              
                            stringBuilderHTML.Append("<td align='left' style='width:18%;padding-right:0px;'>"); //1st Row 5th Column Open Tag                              
                            if (dataRowViewTPNeeds["GoalMonitoredBy"] != DBNull.Value)
                            {
                                stringBuilderHTML.Append("<input type='text'  class='form_textbox'   tabindex='0' bindautosaveevents='False' BindSetFormData='False'    onchange = \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalMonitoredBy','TextBox_TPNeeds_GoalMonitoredBy_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"   maxlength='127'  name=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowViewTPNeeds["NeedId"].ToString() + "  value='" + dataRowViewTPNeeds["GoalMonitoredBy"].ToString() + "' />");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='text'  class='form_textbox'   tabindex='0' bindautosaveevents='False' BindSetFormData='False'    onchange = \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalMonitoredBy','TextBox_TPNeeds_GoalMonitoredBy_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"   maxlength='127'  name=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=TextBox_TPNeeds_GoalMonitoredBy_" + dataRowViewTPNeeds["NeedId"].ToString() + "  />");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 5th Column Close Tag
                            stringBuilderHTML.Append("</tr>"); //1st Row Open tag
                            stringBuilderHTML.Append("</table>");
                            #endregion
                            stringBuilderHTML.Append("</td>"); //2nd Row 3rd Column Close Tag
                            #endregion TR Fourth
                            stringBuilderHTML.Append("</tr>"); //2nd Row Close Tag

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region TR Fifth
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Fifth
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here


                            stringBuilderHTML.Append("<tr>"); //3rd Row Open Tag
                            #region TR Six
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //3rd Row 1st & 2nd Column Open Tag/Close Tag
                            stringBuilderHTML.Append("<td align='left'>"); //3rd Row 3rd Column Open Tag
                            #region Inside 3rd Row 3rd Column
                            stringBuilderHTML.Append("<table cellpadding='2' cellspacing='2' border='0' width='98%'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open tag

                            stringBuilderHTML.Append("<td style='width:16%' align='left' valign='middle'>"); //1st Row 1st Open Col tag
                            stringBuilderHTML.Append("<span   name='Span_GoalTarget_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id='Span_GoalTarget_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'>Goal Target Date</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close tag

                            stringBuilderHTML.Append("<td style='width:24%'>"); //1st Row 2nd  Col Open tag
                            stringBuilderHTML.Append("<table  cellpadding='2' cellspacing='2' width='100%' border='0'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open tag

                            //stringBuilderHTML.Append("<td style='width:20%;padding-left:2px;'>"); //1st Row 1st Col Open tag
                            stringBuilderHTML.Append("<td align='left' width='45%' style='padding-left:4px'>"); //1st Row 1st Col Open tag
                            if (dataRowViewTPNeeds["GoalTargetDate"] != DBNull.Value) //Perform Check for GoalTarget Date
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False' type='text' datatype='Date'  tabindex='0'  value='" + Convert.ToDateTime(dataRowViewTPNeeds["GoalTargetDate"]).ToString("MM/dd/yyyy") + "'   name=Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + " class='dateTextBoxWidth form_textbox' onchange=\"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalTargetDate','Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\" />"); //Create  
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False'  type='text' datatype='Date'  tabindex='0'   name=Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + " class='dateTextBoxWidth form_textbox' onchange=\"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalTargetDate','Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\" />"); //Create  
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close tag

                            stringBuilderHTML.Append("<td  align='left'>");  //1st Row 2nd Col Open tag
                            stringBuilderHTML.Append("&nbsp;<img style='cursor:hand;' id=Img_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + " name=Img_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "  src="+RelativePath+"App_Themes/Includes/Images/calender_grey.gif  style='cursor:hand;' onclick=\"return showCalendar('Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "','%m/%d/%Y');\"/>"); //Create 
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close tag  

                            stringBuilderHTML.Append("</tr>"); //1st Row Close tag
                            stringBuilderHTML.Append("</table>"); //Close tag
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Col  Close tag

                            //Changes Start here Modified By Rakesh With Ref to ticket 188 UM Part 2 (Need Stage of Treatment Icon)
                            //stringBuilderHTML.Append("<td style='width:15%;padding-right:3px;' align='left'>&nbsp;</td>");//1st Row 3rd Col Open/Close tag 
                            //stringBuilderHTML.Append("<td style='width:17%' align='left'>");//1st Row 4rth Col Open tag
                            stringBuilderHTML.Append("<td style='width:4%' align='left'>&nbsp;</td>");//1st Row 3rd Col Open/Close tag 
                            stringBuilderHTML.Append("<td style='width:40%;padding-right:5px;' align='right'>");//1st Row 4rth Col Open tag

                            stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0'>");
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td>");
                             
                            stringBuilderHTML.Append("<img id=Img_TPNeeds_StageOfTreatment_" + dataRowViewTPNeeds["NeedId"].ToString() + " name=Img_TPNeeds_StageOfTreatment_" + dataRowViewTPNeeds["NeedId"].ToString() + " onclick = 'OpenStageofTreatmentPopUp();'  src=" + RelativePath + "App_Themes/Includes/Images/info.png  style='cursor:hand;','%m/%d/%Y');\" />");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("<td>");
                            stringBuilderHTML.Append("&nbsp;<span   name=Span_StageOfTreatment_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_StageOfTreatment_" + dataRowViewTPNeeds["NeedId"].ToString() + "'  style='color:Black;font-size:11px;' >Stage of Treatment</span>"); //Create
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");

                            stringBuilderHTML.Append("</td>"); //1st Row 4rth Col Close tag  

                            stringBuilderHTML.Append("<td style='width:18%;padding-right:0px;' align='left'>");//1st Row 5th Col Open tag  
                            //stringBuilderHTML.Append("<td style='width:40%;padding-left:13px;'>");//1st Row 5th Col Open tag  
                            //Changes End here

                            PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                            //Create Asp DropDown Control
                            dropDownListStageOfTreatment = new DropDownList();
                            dropDownListStageOfTreatment.ID = "DropDownList_GlobalCodes_" + dataRowViewTPNeeds["NeedId"].ToString();
                            dropDownListStageOfTreatment.Width = 128;
                            dropDownListStageOfTreatment.CssClass = "form_dropdown";
                            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("StageOfTreatment", true, "", "SortOrder", false))
                            {
                                dropDownListStageOfTreatment.DataTextField = "CodeName";
                                dropDownListStageOfTreatment.DataValueField = "GlobalCodeId";
                                dropDownListStageOfTreatment.DataSource = DataViewGlobalCodes;
                                dropDownListStageOfTreatment.DataBind();
                                //dropDownListStageOfTreatment.TabIndex = 6;
                                dropDownListStageOfTreatment.Items.Insert(0, "");

                            }
                            if (dataRowViewTPNeeds["StageOfTreatment"] != DBNull.Value)
                            {
                                dropDownListStageOfTreatment.SelectedValue = dataRowViewTPNeeds["StageOfTreatment"].ToString();
                            }
                            PanelPeriodicReview.Controls.Add(dropDownListStageOfTreatment);
                            dropDownListStageOfTreatment.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','StageOfTreatment','" + dropDownListStageOfTreatment.ClientID + "','Edit','NeedId');");
                            dropDownListStageOfTreatment.Attributes.Add("BindSetFormData", "False");
                            dropDownListStageOfTreatment.Attributes.Add("bindautosaveevents", "False");
                            stringBuilderHTML = new StringBuilder();
                            stringBuilderHTML.Append("</td>");//1st Row 5th Col Close tag  
                            stringBuilderHTML.Append("</tr>"); //1st Row Close tag
                            stringBuilderHTML.Append("</table>"); //Close

                            #endregion

                            stringBuilderHTML.Append("</td>"); //3rd Row 3rd Column Close Tag
                            #endregion TR Six
                            stringBuilderHTML.Append("</tr>"); //3rd Row Close Tag

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region TR Seven
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Seven
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here

                            stringBuilderHTML.Append("<tr>"); //4rth Row Open Tag
                            #region TR Eight
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //4rth Row 1st & 2nd Column Open Tag/Close Tag
                            stringBuilderHTML.Append("<td align='left'>"); //4rth Row 3rd Column Open Tag
                            #region 4rth Row 3rd Column

                            stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='98%'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td  style='width:17%;padding-right:5px;' align='left'>"); //1st Row 1st Col Open tag
                            stringBuilderHTML.Append("<span   name='Span_AssociatedNeeds_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id='Span_AssociatedNeeds_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  style='color:Black;font-size:11px;'>Associated Needs</span>"); //Create 
                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("<td  rowspan='2' valign='top' width='40%'>"); //1st Row 2nd Col Open tag
                            stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='100%'>"); //Create
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td>");
                            #region for ListBox Control
                            DataTable dataTableResult = new DataTable("Result");
                            dataTableResult.Columns.Add("TPNeedsClientNeedId", typeof(int));
                            dataTableResult.Columns.Add("NeedName", typeof(string));


                            // dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView.RowFilter = "NeedId=" + Convert.ToString(dataRowViewTPNeeds["NeedId"] + " and IsNull(RecordDeleted,'N')<>'Y'");

                            DataView dataViewCustomTPNeedsClientNeeds = new DataView(dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"]);

                            dataViewCustomTPNeedsClientNeeds.RowFilter = "NeedId=" + Convert.ToString(dataRowViewTPNeeds["NeedId"]) + " and IsNull(RecordDeleted,'N')<>'Y'";

                            //performs join between table.
                            string needDescription = string.Empty;
                            //   for (int i = 0; i < dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView.Count; i++)
                            for (int i = 0; i < dataViewCustomTPNeedsClientNeeds.Count; i++)
                            {
                                //DataRow parent = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i].Row.GetParentRow("ClientNeeds_TPNeedsClientNeeds_FK");

                                //DataRow parent = dataViewCustomTPNeedsClientNeeds[i].Row.GetParentRow("ClientNeeds_TPNeedsClientNeeds_FK");
                                DataRow parent = dataViewCustomTPNeedsClientNeeds[i].Row.GetParentRow("CustomClientNeeds_CustomTPNeedsClientNeeds_FK");
                                DataRow newRow = dataTableResult.NewRow();
                                if (parent != null && newRow != null)
                                {
                                    //newRow["TPNeedsClientNeedId"] = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i].Row["TPNeedsClientNeedId"];

                                    newRow["TPNeedsClientNeedId"] = dataViewCustomTPNeedsClientNeeds[i].Row["TPNeedsClientNeedId"];

                                    //DataRowView drneedDescription = (DataRowView)dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView[i];
                                    DataRowView drneedDescription = (DataRowView)dataViewCustomTPNeedsClientNeeds[i];
                                    if (!string.IsNullOrEmpty(drneedDescription["NeedDescription"].ToString()))
                                    {
                                        needDescription = parent["NeedName"] + " - " + drneedDescription["NeedDescription"];
                                    }
                                    else
                                    {
                                        needDescription = parent["NeedName"].ToString();
                                    }
                                    if (needDescription.Length >= 120)
                                    {
                                        needDescription = BaseCommonFunctions.cutText(needDescription, 120);
                                        needDescription = needDescription + "...";
                                    }
                                    newRow["NeedName"] = needDescription;
                                    dataTableResult.Rows.Add(newRow);
                                }
                            }
                            #endregion
                            #region AssoicatedNeed
                            //Create Div
                            stringBuilderHTML.Append("<div id=div_CustomClientNeeds_NeedName_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='width: 99%;'>");
                            stringBuilderHTML.Append("<select class='form_textarea' multiple='multiple' size='2' style='width:100%;' tabindex='0' >");
                            for (int tpneedClientNeedCount = 0; tpneedClientNeedCount < dataTableResult.Rows.Count; tpneedClientNeedCount++)
                            {
                                stringBuilderHTML.Append("<option value= " + dataTableResult.Rows[tpneedClientNeedCount]["TPNeedsClientNeedId"].ToString() + ">");
                                stringBuilderHTML.Append(dataTableResult.Rows[tpneedClientNeedCount]["NeedName"].ToString() + "</option>");
                            }

                            stringBuilderHTML.Append("</select>");
                            stringBuilderHTML.Append("</div>");
                            #endregion
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");

                            stringBuilderHTML.Append("</table>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close tag

                            // dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].DefaultView.RowFilter = string.Empty; //Clear the filter

                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag

                            stringBuilderHTML.Append("<tr>"); //2nd Row Open Tag
                            stringBuilderHTML.Append("<td align='right'  valign='top' style='width:15%;padding-right:19px;' >"); //2nd Row 1st Col Open Tag                               
                            stringBuilderHTML.Append("<span    name=Span_EditAssociatedNeed_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_EditAssociatedNeed_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueforAssociatedNeeds('" + "div_CustomClientNeeds_NeedName_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + dataRowViewTPNeeds["NeedNumber"].ToString() + "')\" >Edit</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //2nd Row 1st Col Close Tag
                            stringBuilderHTML.Append("</tr>"); //2nd Row Close Tag

                            stringBuilderHTML.Append("</table>");
                            #endregion
                            stringBuilderHTML.Append("</td>"); //4rth Row 3rd Column Close Tag
                            stringBuilderHTML.Append("</tr>"); //4rh Row Close Tag
                            #endregion TR Eight

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region TR Nine
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Nine
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here



                            stringBuilderHTML.Append("<tr>"); //5th Row Open Tag
                            #region TR Tenth
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //5th Row 1st & 2nd Column Open Tag/Close Tag

                            stringBuilderHTML.Append("<td align='left'>"); //5th Row 3rd Column Open Tag
                            #region Inside 5th Row 3rd Column
                            stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='98%'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row  Open Tag

                            stringBuilderHTML.Append("<td style='width:26%' valign='top' align='left'>"); //1st Row 1st Column Open tag
                            stringBuilderHTML.Append("<span   name=Span_StrengthsPertinenttoGoal_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id=Span_StrengthsPertinenttoGoal_'" + dataRowViewTPNeeds["NeedId"].ToString() + "' style='color:Black;font-size:11px;'>Strengths pertinent to this goal</span>"); //Create
                            stringBuilderHTML.Append("</td>");  //1st Row 1st Column Close tag

                            stringBuilderHTML.Append("<td>");  //1st Row 2nd Column  tag
                            stringBuilderHTML.Append("<textarea onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalStrengths','TextArea_TPNeeds_GoalStrengths_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"  name='TextArea_TPNeeds_GoalStrengths_" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id='TextArea_TPNeeds_GoalStrengths_" + dataRowViewTPNeeds["NeedId"].ToString() + "' rows='4' cols='8'  bindautosaveevents='False' BindSetFormData='False' style='width: 98%' tabindex='0' class='form_textarea' spellcheck='True' >"); //Create   
                            if (dataRowViewTPNeeds["GoalStrengths"] != DBNull.Value)
                            {
                                stringBuilderHTML.Append(dataRowViewTPNeeds["GoalStrengths"].ToString() + " </textarea>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("</textarea>");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Column tag
                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                            stringBuilderHTML.Append("</table>");
                            #endregion
                            stringBuilderHTML.Append("</td>"); //5th Row 3rd Column Close Tag
                            #endregion TR Tenth
                            stringBuilderHTML.Append("</tr>"); //5th Row Close Tag

                            //---Commented on 11 MArch 2010
                            //stringBuilderHTML.Append("<tr>"); //6th Row Open Tag
                            //---END Commented on 11 MArch 2010

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region TR Eleven
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Eleven
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here

                            stringBuilderHTML.Append("<tr>");
                            #region TR Twelve
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //6th Row 1st & 2nd Column Open Tag/Close Tag

                            stringBuilderHTML.Append("<td align='left'>"); //6th Row 3rd Column Open Tag
                            #region Inside 6th Row 3rd Column
                            stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' width='98%'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td style='width:26%' valign='top' align='left'>"); //1st Row 1st Col Open Tag
                            stringBuilderHTML.Append("<span  name=Span_BarriersPertinenttoGoal_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id=Span_BarriersPertinenttoGoal_'" + dataRowViewTPNeeds["NeedId"].ToString() + "' style='color:Black;font-size:11px;'> Barriers pertinent to this goal</span>"); //Create 
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close Tag

                            stringBuilderHTML.Append("<td>"); //1st Row 2nd Col Open Tag

                            stringBuilderHTML.Append("<textarea  onchange=\"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalBarriers','TextArea_TPNeeds_GoalBarriers_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\" name='TextArea_TPNeeds_GoalBarriers_" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id='TextArea_TPNeeds_GoalBarriers_" + dataRowViewTPNeeds["NeedId"].ToString() + "' rows='4' cols='8'  bindautosaveevents='False' BindSetFormData='False' style='width: 98%'  tabindex='0' class='form_textarea' spellcheck='True' >"); //Create           

                            if (dataRowViewTPNeeds["GoalBarriers"] != DBNull.Value)
                            {
                                stringBuilderHTML.Append(dataRowViewTPNeeds["GoalBarriers"].ToString() + " </textarea>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("</textarea>");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Open Tag

                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                            stringBuilderHTML.Append("</table>");

                            #endregion
                            stringBuilderHTML.Append("</td>"); //6th Row 3rd Column Close Tag
                            #endregion TR Twelve
                            stringBuilderHTML.Append("</tr>"); //6th Row Close Tag

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region Thirteen
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion Thirteen
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here




                            stringBuilderHTML.Append("<tr>"); //7th Row Open Tag
                            #region Fourteen
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //7th Row 1st & 2nd Column Open Tag/Close Tag
                            stringBuilderHTML.Append("<td align='left'>"); //7th Row 3rd Column Open Tag

                            #region 7th Row 3rd Column

                            stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='70%'>"); //Create
                            stringBuilderHTML.Append("<tr class='checkbox_container'>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>"); //1st Row 1st Column  Open Tag
                            if (dataRowViewTPNeeds["GoalNaturalSupports"] != DBNull.Value && dataRowViewTPNeeds["GoalNaturalSupports"].ToString().ToUpper() == "Y")
                            {
                                stringBuilderHTML.Append("<input style='cursor:pointer;color:Black;font-size:11px;' bindautosaveevents='False' BindSetFormData='False'  tabindex='0' type='checkbox' checked='checked' onclick=\"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalNaturalSupports','CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"  name=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowViewTPNeeds["NeedId"].ToString() + " />  associated with natural support"); //Create  
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input style='cursor:pointer;color:Black;font-size:11px;' tabindex='0' bindautosaveevents='False' BindSetFormData='False'  type='checkbox' onclick=\"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalNaturalSupports','CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"  name=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowViewTPNeeds["NeedId"].ToString() + " />  associated with natural support"); //Create  
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Column Close Tag

                            stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>"); //1st Row 2nd Column  Open Tag
                            if (dataRowViewTPNeeds["GoalNaturalSupports"] != DBNull.Value && dataRowViewTPNeeds["GoalEmployment"].ToString().ToUpper() == "Y")
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;' tabindex='0'  type='checkbox' checked='checked' onclick= \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalEmployment','CheckBox_TPNeeds_GoalEmployment_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"  name=CheckBox_TPNeeds_GoalEmployment_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalEmployment_" + dataRowViewTPNeeds["NeedId"].ToString() + " />  associated with employment"); //Create  
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;' tabindex='0'  type='checkbox' onclick=  \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalEmployment','CheckBox_TPNeeds_GoalEmployment_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"  name=CheckBox_TPNeeds_GoalEmployment_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalEmployment_" + dataRowViewTPNeeds["NeedId"].ToString() + "  />  associated with employment"); //Create  
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag
                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag

                            stringBuilderHTML.Append("<tr class='checkbox_container'>"); //2nd Row Open Tag

                            stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>"); //2nd Row 1st Col Open Tag
                            if (dataRowViewTPNeeds["GoalLivingArrangement"] != DBNull.Value && dataRowViewTPNeeds["GoalLivingArrangement"].ToString().ToUpper() == "Y")
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;'  tabindex='0'  type='checkbox' onclick=  \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalLivingArrangement','CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"    checked='checked'  name=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowViewTPNeeds["NeedId"].ToString() + " />  associated with  living arrangement"); //Create                     
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;'  tabindex='0'   type='checkbox' onclick=  \"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalLivingArrangement','CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"     name=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowViewTPNeeds["NeedId"].ToString() + " />  associated with  living arrangement"); //Create
                            }
                            stringBuilderHTML.Append("</td>");//2nd Row 1st Col Close Tag

                            stringBuilderHTML.Append("<td style='color:Black;font-size:11px;'>");//2nd Row 2nd Col Open Tag
                            if (dataRowViewTPNeeds["GoalHealthSafety"] != DBNull.Value && dataRowViewTPNeeds["GoalHealthSafety"].ToString().ToUpper() == "Y")
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;'  tabindex='0'   type='checkbox' onclick=\"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalHealthSafety','CheckBox_TPNeeds_GoalHealthSafety_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"   checked='checked' name=CheckBox_TPNeeds_GoalHealthSafety_'" + dataRowViewTPNeeds["NeedId"].ToString() + "'  id=CheckBox_TPNeeds_GoalHealthSafety_" + dataRowViewTPNeeds["NeedId"].ToString() + " />  associated with CLS/Club House"); //Create                     
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input bindautosaveevents='False' BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;'  tabindex='0'   type='checkbox' onclick=\"PRModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','TPNeeds','GoalHealthSafety','CheckBox_TPNeeds_GoalHealthSafety_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit','NeedId');\"     name=CheckBox_TPNeeds_GoalHealthSafety_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=CheckBox_TPNeeds_GoalHealthSafety_" + dataRowViewTPNeeds["NeedId"].ToString() + " />  associated with CLS/Club House"); //Create
                            }
                            stringBuilderHTML.Append("</td>");//2nd Row 2nd Col Close Tag
                            stringBuilderHTML.Append("</tr>"); //2nd Row Close Tag
                            stringBuilderHTML.Append("</table>");
                            #endregion
                            stringBuilderHTML.Append("</td>"); //7th Row 3rd Column Close Tag
                            #endregion Fourteen
                            stringBuilderHTML.Append("</tr>"); //7th Row Close Tag

                            //-----start commented on 11 MArch 2010
                            //stringBuilderHTML.Append("<tr>"); //8th Row Open Tag
                            //-----end commented on 11 MArch 2010

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region Fifteen
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion Fifteen
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here

                            stringBuilderHTML.Append("<tr>");
                            #region TR Sixteen
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style='width:8%;'>&nbsp;</td>"); //8th Row 1st & 2nd Column Open Tag/Close Tag
                            stringBuilderHTML.Append("<td align='left'>"); //8th Row 3rd Column Open Tag
                            #region 8th Row 3rd Column

                            stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td style='width:15%;'>"); //1st Row 1st Col Open Tag                             
                            stringBuilderHTML.Append("<span   name=Span_EditGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_EditGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;'  onClick=\"OpenEditGoalPopUp('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TextArea_TPNeeds_GoalStrengths_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TextArea_TPNeeds_GoalBarriers_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Text_TPNeeds_GoalStartDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Radio_TPNeeds_GoalActive_Y_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Radio_TPNeeds_GoalActive_N_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TextBox_TPNeeds_GoalMonitoredBy_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Text_TPNeeds_GoalTargetDate_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "DropDownList_GlobalCodes_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "CheckBox_TPNeeds_GoalNaturalSupports_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "CheckBox_TPNeeds_GoalEmployment_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "CheckBox_TPNeeds_GoalLivingArrangement_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "CheckBox_TPNeeds_GoalHealthSafety_" + dataRowViewTPNeeds["NeedId"].ToString() + "','Edit Goal');\" >Edit Goal</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close Tag

                            stringBuilderHTML.Append("<td style='width:25%;'>"); //1st Row 2nd Col Open Tag                              
                            stringBuilderHTML.Append("<span   name=Span_UseQuickGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_UseQuickGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueQuickTxPlan('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TPQuickGoals" + "','" + "TPNeeds" + "');\">Use Quick Goal</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close Tag

                            stringBuilderHTML.Append("<td style='width:25%'>"); //1st Row 3rd Col Open Tag
                            stringBuilderHTML.Append("<span   name=Span_AddtoQuickGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_AddtoQuickGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueAddQuickTxPlan('TPQuickGoals','TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Add this to Quick Goal</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 3rd Col Close Tag

                            stringBuilderHTML.Append("<td align='center'"); //1st Row 4rth Col Open Tag
                            stringBuilderHTML.Append("<span   name=Span_RenumberGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_RenumberGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenRenumberTxPlan('" + "TPNeeds" + "','" + "NeedId" + "','" + dataRowViewTPNeeds["NeedNumber"].ToString() + "','" + dataRowViewTPNeeds["NeedId"].ToString() + "');\"> Renumber Goals</span>"); //Create 
                            stringBuilderHTML.Append("</td>"); //1st Row 4rth Col Close Tag

                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                            stringBuilderHTML.Append("</table>");

                            #endregion
                            stringBuilderHTML.Append("</td>"); //8th Row 3rd Column Close Tag
                            #endregion TR Sixteen
                            stringBuilderHTML.Append("</tr>"); //8th Row Close Tag
                            PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                            #region Objective Section

                            #region Create Objective Control
                            //Find Objective with respect to there NeedId from TPObjective table

                            stringBuilderHTML.Append("<tr>"); //8th Row Open Tag
                            #region TR SevenTeen
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style='width:8%;'>&nbsp;</td>");

                            stringBuilderHTML.Append("<td>");

                            if (needCount % 2 == 0)
                            {
                                stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0'  width='90%'>"); //Create

                            }
                            else
                            {
                                stringBuilderHTML.Append("<table  style='width:90%;'  cellpadding='0' cellspacing='0' >"); //Create
                            }


                            //   stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create



                            CreateObjective(Convert.ToInt32(dataRowViewTPNeeds["NeedId"]), Convert.ToInt32(dataRowViewTPNeeds["NeedNumber"]), ref dataSetTreatmentPlanHRM);


                            stringBuilderHTML = new StringBuilder();

                            //-----12 april
                            //stringBuilderHTML.Append("</table>");
                            //stringBuilderHTML.Append("</td>");
                            #endregion TR SevenTeen
                            //stringBuilderHTML.Append("</tr>"); //8th Row Open Tag
                            //-----12 april
                            #endregion

                            #region for objective link
                            stringBuilderHTML.Append("<tr>");
                            #region TR Eightteen
                            stringBuilderHTML.Append("<td colspan='3' style='height:2px;'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Eightteen
                            stringBuilderHTML.Append("</tr>");

                            stringBuilderHTML.Append("<tr>"); //9th Row Open Tag  
                            #region TR NineTeen
                            stringBuilderHTML.Append("<td align='left' colspan='3'>"); //9th Row 3rd Column Open Tag
                            #region 9th Row 3rd Column
                            if (needCount % 2 == 0)
                            {
                                stringBuilderHTML.Append("<table cellpadding='0' border='0' cellspacing='0' style='width:100%' >"); //Create
                            }
                            else
                            {
                                stringBuilderHTML.Append("<table cellpadding='0'  style='width:100%;' border='0' cellspacing='0' >"); //Create
                            }
                            //stringBuilderHTML.Append("<table cellpadding='0' border='0' cellspacing='0' width='100%;'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td width='20%' align='right'>"); //1st Row 1st Col Open Tag
                            stringBuilderHTML.Append("<span   name=Span_AddObjective_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_AddObjective_" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"AddObjective('" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Add Objective</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close Tag

                            stringBuilderHTML.Append("<td width='40%' align='center'>"); //1st Row 2nd Col Open Tag

                            DataRow[] dataRowTpObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("Isnull(RecordDeleted,'N' )<>'Y' and NeedId=" + dataRowViewTPNeeds["NeedId"].ToString());
                            if (dataRowTpObjective.Length > 0)
                            {
                                stringBuilderHTML.Append("<span   name=Span_RenumberObjective_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_RenumberObjective_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenRenumberTxPlan('" + "TPObjectives" + "','" + "ObjectiveId" + "','" + dataRowViewTPNeeds["NeedNumber"].ToString() + "','" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Renumber Objective</span>"); //Create
                            }
                            else
                            {
                                stringBuilderHTML.Append("<span   name=Span_RenumberObjective_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_RenumberObjective_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;color:Black;font-size:11px;' disabled='disabled'>Renumber Objective</span>"); //Create
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close Tag

                            stringBuilderHTML.Append("<td>"); //1st Row 1st Col Open Tag
                            stringBuilderHTML.Append("&nbsp;"); //Create
                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                            stringBuilderHTML.Append("</table>");
                            #endregion

                            stringBuilderHTML.Append("</td>"); //9th Row 3rd Column Close Tag
                            #endregion TR NineTeen
                            stringBuilderHTML.Append("</tr>"); //9th Row Close Tag

                            #endregion
                            PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                            #endregion

                            #region Intervention Section
                            //--------------- 12 April
                            //stringBuilderHTML = new StringBuilder();
                            //----------------------
                            stringBuilderHTML.Append("<tr>"); //8th Row Open Tag

                            #region TR Twenty
                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style='width:8%;'>&nbsp;</td>");
                            stringBuilderHTML.Append("<td>");

                            if (needCount % 2 == 0)
                            {

                                stringBuilderHTML.Append("<table border='1' cellpadding='0' cellspacing='0' width='90%'>"); //Create
                            }
                            else
                            {
                                stringBuilderHTML.Append("<table border='1' style='width:90%;'  cellpadding='0' cellspacing='0' >"); //Create
                            }


                            //stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create

                            CreateIntervention(Convert.ToInt32(dataRowViewTPNeeds["NeedId"]), Convert.ToInt32(dataRowViewTPNeeds["NeedNumber"]), ref dataSetTreatmentPlanHRM);


                            stringBuilderHTML = new StringBuilder();

                            //---------12 April
                            // stringBuilderHTML.Append("</table>");
                            // stringBuilderHTML.Append("</td>");
                            //---------12 April
                            #endregion TR Twenty
                            //---------12 April
                            //stringBuilderHTML.Append("</tr>"); //8th Row Open Tag
                            //---------12 April
                            #endregion

                            #region for Intervention link
                            stringBuilderHTML.Append("<tr>");
                            #region TR TwentyOne
                            stringBuilderHTML.Append("<td colspan='3' style='height:2px;'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR TwentyOne
                            stringBuilderHTML.Append("</tr>");

                            stringBuilderHTML.Append("<tr>"); //9th Row Open Tag  
                            #region TR TwentyTwo
                            stringBuilderHTML.Append("<td align='left' colspan='3'>"); //9th Row 3rd Column Open Tag
                            #region 9th Row 3rd Column

                            if (needCount % 2 == 0)
                            {
                                stringBuilderHTML.Append("<table cellpadding='0' border='0' cellspacing='0' width='100%;'>"); //Create

                            }
                            else
                            {
                                stringBuilderHTML.Append("<table cellpadding='0' style='width:100%;' border='0' cellspacing='0'>"); //Create
                            }
                            //stringBuilderHTML.Append("<table cellpadding='0' border='0' cellspacing='0' width='100%;'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td style='width:30%;' align='center'>"); //1st Row 1st Col Open Tag                              
                            stringBuilderHTML.Append("<span   name=Span_AddIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_AddIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"AddIntervention('" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Add Intervention</span>"); //Create
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close Tag

                            stringBuilderHTML.Append("<td align='left'>"); //1st Row 2nd Col Open Tag                             
                            DataRow[] dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId='" + dataRowViewTPNeeds["NeedId"].ToString() + "'");

                            if (dataRowTPInterventionProcedures.Length > 0)
                            {
                                stringBuilderHTML.Append("<span   name=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenRenumberTxPlan('" + "TPInterventionProcedures" + "','" + "TPInterventionProcedureId" + "','" + dataRowViewTPNeeds["NeedNumber"].ToString() + "','" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Renumber Intervention</span>"); //Create 
                            }
                            else
                            {
                                stringBuilderHTML.Append("<span   name=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;color:Black;font-size:11px;' disabled='disabled'>Renumber Intervention</span>"); //Create 
                            }

                            stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close Tag

                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                            stringBuilderHTML.Append("</table>");

                            #endregion
                            stringBuilderHTML.Append("</td>"); //9th Row 3rd Column Close Tag
                            #endregion TR TwentyTwo
                            stringBuilderHTML.Append("</tr>");

                            ////Start-- Added By Daman
                            stringBuilderHTML.Append("</table>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            #endregion
                            #endregion

                            #region // 3rd Main TR
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                            stringBuilderHTML.Append("<tr>");

                            stringBuilderHTML.Append("<td width='2' class='right_bottom_cont_bottom_bg'>");
                            stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src="+RelativePath+"App_Themes/Includes/Images/right_bottom_cont_bottom_left.gif ");
                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("<td width='100%' class='right_bottom_cont_bottom_bg'>");

                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("<td align='right' width='2' class='right_bottom_cont_bottom_bg'>");
                            stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src="+RelativePath+"App_Themes/Includes/Images/right_bottom_cont_bottom_right.gif ");
                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            //stringBuilderHTML.Append("</table>");
                            #endregion

                            //---Space b/w two Goal Sections
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");


                            PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                        }
                        isGoalCreated = false;
                    }


                    stringBuilderHTML = new StringBuilder();

                    #region // 4th Main TR -- Added By Damanpreet
                    stringBuilderHTML.Append("<tr>");
                    stringBuilderHTML.Append("<td colspan='3'>");
                    stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");

                    #region Add Goal
                    stringBuilderHTML = new StringBuilder();
                    stringBuilderHTML.Append("<tr>");
                    #region TR 23
                    stringBuilderHTML.Append("<td style='width:3%;height:3px;' colspan='3'>&nbsp;</td>");
                    stringBuilderHTML.Append("</td>");
                    #endregion TR 23
                    stringBuilderHTML.Append("</tr>");

                    stringBuilderHTML.Append("<tr>"); //8th Row Open Tag 


                    //stringBuilderHTML.Append("<tr>");
                    //stringBuilderHTML.Append("<td style='width:3%;height:3px;' colspan='3'>&nbsp;</td>");
                    //stringBuilderHTML.Append("</tr>");

                    //stringBuilderHTML.Append("<tr>"); //8th Row Open Tag                           
                    //stringBuilderHTML.Append("<td colspan='3' align='left'>");
                    //stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");


                    //stringBuilderHTML.Append("<tr>");
                    //#region TR TwentyThree
                    //stringBuilderHTML.Append("<td style='width:3%;height:3px;' colspan='3'>&nbsp;</td>");
                    //stringBuilderHTML.Append("</td>");
                    //#endregion TR TwentyThree
                    //stringBuilderHTML.Append("</tr>");

                    stringBuilderHTML.Append("<tr>"); //8th Row Open Tag  
                    #region TR TwentyFour
                    stringBuilderHTML.Append("<td align='left'>");
                    //stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create
                    //stringBuilderHTML.Append("<tr>");

                    //stringBuilderHTML.Append("<td width='9%'>");
                    //stringBuilderHTML.Append("&nbsp;");
                    //stringBuilderHTML.Append("</td>");


                    //stringBuilderHTML.Append("<td align='left'>");

                    //--Commented By Ashwani Kumar Angrish on 20 feb
                    //--refer Task 385 of SCWEB Venture document 
                    //if (_FromPROnload == true)
                    //{
                    if (dataRowViewTPNeeds != null && dataRowViewTPNeeds["NeedId"] != null && dataRowViewTPNeeds["NeedId"].ToString().Trim() != "")
                        stringBuilderHTML.Append("<span    name=Span_AddGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_AddGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueHRMTPGoal('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Add Goal" + "',true);\" >Add Goal</span>"); //Create
                    if (dataRowViewTPNeeds == null)
                    {
                        DataRowView dataRowGoal = null;

                        dataViewTPNeeds = new DataView(dataSetTreatmentPlanHRM.Tables["TpNeeds"]);
                        //Sort On the basis of Need Number because we have show Goal on Number basis
                        dataViewTPNeeds.Sort = "NeedNumber";
                        dataViewTPNeeds.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'";
                        dataRowGoal = dataViewTPNeeds[dataViewTPNeeds.Count - 1];
                        if (_FromPROnload == true)
                            stringBuilderHTML.Append("<span    name=Span_AddGoal_" + dataRowGoal["NeedId"].ToString() + "  id=Span_AddGoal_" + dataRowGoal["NeedId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueHRMTPGoal('" + dataRowGoal["NeedId"].ToString() + "','" + "Add Goal" + "',true);\" >Add Goal</span>"); //Create
                        else
                            stringBuilderHTML.Append("<span    name=Span_AddGoal_" + dataRowGoal["NeedId"].ToString() + "  id=Span_AddGoal_" + dataRowGoal["NeedId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueHRMTPGoal('" + dataRowGoal["NeedId"].ToString() + "','" + "Add Goal" + "',false);\" >Add Goal</span>"); //Create

                    }
                    // }
                    //----End Commented
                    stringBuilderHTML.Append("</td>");

                    stringBuilderHTML.Append("</tr>");
                    stringBuilderHTML.Append("</table>");
                    stringBuilderHTML.Append("</td>");
                    #endregion TR TwentyFour
                    stringBuilderHTML.Append("</tr>");

                    stringBuilderHTML.Append("</table>");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("</tr>");
                    #endregion

                    stringBuilderHTML.Append("</table>");
                    //stringBuilderHTML.Append("</td>");
                    //stringBuilderHTML.Append("</tr>");
                    #endregion

                    //#endregion main table starts
                    //stringBuilderHTML.Append("</table>");
                    dataSetTreatmentPlanHRM.Tables["TpNeeds"].DefaultView.RowFilter = "";
                    PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                }
            }
        }
        //}
        //finally
        //{

        //}
    }

    /// <summary>
    /// <Description>This method is used to Read Data from TPObjective and Create Objective Section</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>11th-Sept-2009</CreatedOn>
    /// </summary>
    /// <param name="needId"></param>
    /// <param name="goalNumber"></param>
    private void CreateObjective(int needId, int goalNumber, ref DataSet dataSetTreatmentPlanHRM)
    {
        StringBuilder stringBuilderHTML = null;
        DataRow[] dataRowTpObjective = null;
        DataRowView[] dataRowViewTPObjective = null;
        double objectiveNumber = 0.0;
        DropDownList dropdownListObjectiveStatus = null;
        try
        {
            if (dataSetTreatmentPlanHRM.Tables.Contains("TPobjectives")) //Perform Table contain Check
            {
                stringBuilderHTML = new StringBuilder();
                if (dataSetTreatmentPlanHRM.Tables["TPobjectives"].Rows.Count > 0)
                {
                    //Find out the Number of Objectives Corresponding to a Need
                    dataRowTpObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("Isnull(RecordDeleted,'N' )<>'Y' and NeedId=" + needId + "", "ObjectiveNumber Asc");
                    if (dataRowTpObjective.Length > 0)
                    {
                        for (int objectiveCount = 0; objectiveCount < dataRowTpObjective.Length; objectiveCount++)
                        {
                            //dataSetTreatmentPlanHRM.Tables["TPobjectives"].DefaultView.Sort = "ObjectiveId Asc";

                            DataView dataViewTPObjectives = new DataView(dataSetTreatmentPlanHRM.Tables["TPobjectives"]);
                            dataViewTPObjectives.Sort = "ObjectiveId Asc";
                            //Create DataRowView 
                            //dataRowViewTPObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].DefaultView.FindRows(dataRowTpObjective[objectiveCount]["ObjectiveId"]);
                            dataRowViewTPObjective = dataViewTPObjectives.FindRows(dataRowTpObjective[objectiveCount]["ObjectiveId"]);

                            stringBuilderHTML.Append("<tr>");
                            #region TR First
                            stringBuilderHTML.Append("<td colspan='3' style='height:2px;'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR First
                            stringBuilderHTML.Append("</tr>");


                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag
                            #region TR Second
                            stringBuilderHTML.Append("<td style='width:3%;'  valign='top'>"); //1st Row 1st Col Open tag                              
                            stringBuilderHTML.Append("<img style='cursor:hand;color:Black;font-size:11px;' id=Img_TPObjectives_ObjectiveId_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  name=Img_TPObjectives_ObjectiveId_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + " src="+RelativePath+"App_Themes/Includes/Images/deleteIcon.gif  tag='" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "'  onClick= \"DeleteObjective('" + needId + "','" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "');\" />");
                            stringBuilderHTML.Append("</td>");//1st Row 1st Col Close tag


                            stringBuilderHTML.Append("<td style='width:12%;' valign='top'>");//1st Row 2nd Col Open tag
                            objectiveNumber = Convert.ToDouble(dataRowViewTPObjective[0]["ObjectiveNumber"].ToString());
                            stringBuilderHTML.Append("<span    style='color:Black;font-size:11px;' + name=Span_TPObjectives_ObjectiveId_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_TPNeeds_NeedNumber_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + ">Objective" + objectiveNumber.ToString("0.00") + "</span>");
                            stringBuilderHTML.Append("</td>");//1st Row 2nd Col Close tag

                            stringBuilderHTML.Append("<td align='left'>"); //1st Row 3rd Column Open Tag
                            stringBuilderHTML.Append("<table cellpadding='0' border='0' cellspacing='0' width='90%'>"); //Create
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td align='left'>"); //1st Row 1st Col Open Tag
                            stringBuilderHTML.Append("<textarea  name='TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "'  spellcheck='True' id='TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "'  bindautosaveevents='False' BindSetFormData='False' rows='4' cols='8' style='width: 90%' class='form_textarea' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPObjectives','ObjectiveText','TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','Edit','ObjectiveId');\" >");
                            if (dataRowViewTPObjective[0]["ObjectiveText"] != DBNull.Value)
                            {
                                stringBuilderHTML.Append(dataRowViewTPObjective[0]["ObjectiveText"].ToString() + "</textarea>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("</textarea>");
                            }
                            stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close Tag
                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                            stringBuilderHTML.Append("</table>");

                            stringBuilderHTML.Append("</td>"); //1st Row 3rd Column Close Tag
                            #endregion TR Second
                            stringBuilderHTML.Append("</tr>"); //1st Row Close Tag

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region TR Third
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Third

                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here

                            stringBuilderHTML.Append("<tr>"); //2nd Row Open Tag
                            #region TR Four

                            stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style=width:8%>&nbsp;</td>"); //2nd Row 1st & 2nd Column Open Tag/Close Tag


                            stringBuilderHTML.Append("<td align='left'>");//2nd Row 3rd Col Open Tag

                            stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create

                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                            stringBuilderHTML.Append("<td width='15%' valign='middle' align='right' style='padding-right:5px;'>");//1st Row  1st Col Open Tag
                            stringBuilderHTML.Append("<span  name=Span_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='color:Black;font-size:11px;'>Target Date</span>"); //Create                                                            
                            stringBuilderHTML.Append("</td>");//1st Row  1st Col Close Tag

                            stringBuilderHTML.Append("<td align='left'   width='12%'>");//1st Row  2nd Col Open Tag
                            if (dataRowViewTPObjective[0]["TargetDate"] != DBNull.Value)
                            {
                                stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False' datatype='Date' value='" + Convert.ToDateTime(dataRowViewTPObjective[0]["TargetDate"]).ToString("MM/dd/yyyy") + "'   name=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  class='dateTextBoxWidth form_textbox' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPObjectives','TargetDate','Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','Edit','ObjectiveId');\" />"); //Create  
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='text' bindautosaveevents='False' BindSetFormData='False' datatype='Date'  name=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  class='dateTextBoxWidth form_textbox' onchange= \"PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPObjectives','TargetDate','Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','Edit','ObjectiveId');\" />"); //Create  
                            }
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("<td  valign='middle' align='left'>");
                            stringBuilderHTML.Append("&nbsp;<img style='cursor:hand;' id=Img_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + " name=Img_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  src="+RelativePath+"App_Themes/Includes/Images/calender_grey.gif   style='cursor:hand;' onclick=\"return showCalendar('Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','%m/%d/%Y');\"/>"); //Create 
                            stringBuilderHTML.Append("</td>");//1st Row  2nd Col Close Tag

                            stringBuilderHTML.Append("<td align='left'>");//1st Row  3rd Col Open Tag
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");//1st Row  3rd Col Close Tag

                            stringBuilderHTML.Append("<td align='right' style='padding-right:5px;'>");//1st Row  4rth Col Open Tag
                            stringBuilderHTML.Append("<span   name=Span_ObjectiveStatus_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_ObjectiveStatus_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='color:Black;font-size:11px;'>Objective Status</span>"); //Create                                                            
                            stringBuilderHTML.Append("</td>");//1st Row  4rth Col Close Tag

                            stringBuilderHTML.Append("<td align='left'>");//1st Row  5th Col Open Tag
                            PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                            stringBuilderHTML = new StringBuilder();
                            dropdownListObjectiveStatus = new DropDownList();
                            dropdownListObjectiveStatus.ID = "DropDownList_GlobalCode_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString();
                            dropdownListObjectiveStatus.Width = 130;
                            dropdownListObjectiveStatus.CssClass = "form_dropdown";
                            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPOBJECTIVESTATUS", true, "", "SortOrder", false))
                            {
                                dropdownListObjectiveStatus.DataTextField = "CodeName";
                                dropdownListObjectiveStatus.DataValueField = "GlobalCodeId";
                                dropdownListObjectiveStatus.DataSource = DataViewGlobalCodes;
                                dropdownListObjectiveStatus.DataBind();
                            }
                            if (dataRowViewTPObjective[0]["ObjectiveStatus"] != DBNull.Value)
                            {
                                dropdownListObjectiveStatus.SelectedValue = dataRowViewTPObjective[0]["ObjectiveStatus"].ToString();
                            }
                            PanelPeriodicReview.Controls.Add(dropdownListObjectiveStatus);
                            dropdownListObjectiveStatus.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPObjectives','ObjectiveStatus','" + dropdownListObjectiveStatus.ClientID + "','Edit','ObjectiveId');");
                            dropdownListObjectiveStatus.Attributes.Add("BindSetFormData", "False");
                            dropdownListObjectiveStatus.Attributes.Add("bindautosaveevents", "False");
                            stringBuilderHTML.Append("</td>");//1st Row  5th Col Close Tag
                            stringBuilderHTML.Append("</tr>");//1st Row Close Tag
                            stringBuilderHTML.Append("</table>"); //Create

                            stringBuilderHTML.Append("</td>");//2nd Row 3rd Col Close Tag
                            #endregion TR Four
                            stringBuilderHTML.Append("</tr>"); //2nd Row Close Tag

                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            #region TR Five
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            #endregion TR Four
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here

                            stringBuilderHTML.Append("<tr>"); //3rd Row Open Tag   
                            #region TR Six
                            stringBuilderHTML.Append("<td align='left' colspan='3'>");//3rd Row 3rd Col Open Tag

                            stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='100%'>"); //Create
                            stringBuilderHTML.Append("<tr>");

                            stringBuilderHTML.Append("<td align='right' style='width:26%;padding-right:19px;'>");
                            stringBuilderHTML.Append("<span    name=Span_EditObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_EditObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueforEditObjective('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "Text_TPObjectives_TargetDate_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','" + "DropDownList_GlobalCode_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "');\">Edit Objective</span>"); //Create 
                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("<td align='right'>");
                            stringBuilderHTML.Append("<span   name=Span_UseQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_UseQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueQuickTxPlan('" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "','TPQuickObjectives','TPObjectives');\" >Use Quick Objective</span>"); //Create
                            stringBuilderHTML.Append("</td>");

                            stringBuilderHTML.Append("<td align='center'>");
                            stringBuilderHTML.Append("<span  name=Span_AddthistoQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  id=Span_AddthistoQuickObjective_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueAddQuickTxPlan('" + "TPQuickObjectives" + "','" + "TextArea_TPObjectives_ObjectiveText_" + dataRowViewTPObjective[0]["ObjectiveId"].ToString() + "');\">Add this to Quick Objective</span>"); //Create 
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");

                            stringBuilderHTML.Append("</td>");//3rd Row 3rd Col Close Tag
                            #endregion TR Six
                            stringBuilderHTML.Append("</tr>"); //3rd Row Close Tag

                        }
                    }
                    else
                    {
                        stringBuilderHTML.Append("<tr>");
                        #region Alertnate TR
                        stringBuilderHTML.Append("<td colspan='3' style='height:2px;'>");
                        stringBuilderHTML.Append("&nbsp;");
                        stringBuilderHTML.Append("</td>");
                        #endregion Alertnate TR
                        stringBuilderHTML.Append("</tr>");
                    }

                }
                else
                {
                    stringBuilderHTML.Append("<tr>");
                    #region Alertnate TR
                    stringBuilderHTML.Append("<td colspan='3' style='height:2px;'>");
                    stringBuilderHTML.Append("&nbsp;");
                    stringBuilderHTML.Append("</td>");
                    #endregion Alertnate TR
                    stringBuilderHTML.Append("</tr>");
                }

                PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            dataRowTpObjective = null;
            dataRowViewTPObjective = null;
        }
    }

    /// <summary>
    /// <Description>Method is used to Read Data from TPInterventionProcedure and Create Intervention Section</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>16th-Sept-2009</CreatedOn>
    /// </summary>
    /// <param name="needId"></param>
    /// <param name="dataSetTreatmentPlanHRM"></param>
    private void CreateIntervention(int needId, int goalNumber, ref DataSet dataSetTreatmentPlanHRM)
    {
        StringBuilder stringBuilderHTML = null;
        DataRow[] dataRowTPInterventionProcedures = null;
        //DropDownList dropdownListinterVentionFrequency = null;
        SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionProvider = null;
        SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionService = null;
        DataRow[] dataRowTPInterventionPObjective = null;
        DataRow dataRowTPProcedures = null;
        DataTable dataTableTPObjective = null;
        bool disableProcedureProvider = false;
        string agencyName = string.Empty;
        SHS.UserBusinessServices.Document objectDocuments = null;
        try
        {
            if (dataSetTreatmentPlanHRM.Tables.Contains("TPInterventionProcedures")) //Perform Table contain Check
            {
                if (dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Count > 0)
                {
                    stringBuilderHTML = new StringBuilder();
                    // dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId='" + needId + "'", "InterventionNumber asc");                
                    dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId='" + needId + "'");
                    if (dataRowTPInterventionProcedures.Length > 0)
                    {
                        //dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView.Sort = "InterventionNumber";
                        //dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'and NeedId=" + needId;

                        DataView dataViewTPInterventionProcedures = new DataView(dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"]);
                        dataViewTPInterventionProcedures.Sort = "InterventionNumber";

                        dataViewTPInterventionProcedures.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'and NeedId=" + needId;


                        stringBuilderHTML = new StringBuilder();


                        //To show difference between the two rows
                        stringBuilderHTML.Append("<tr>");
                        #region TR First
                        stringBuilderHTML.Append("<td colspan='3'>");
                        stringBuilderHTML.Append("&nbsp;");
                        stringBuilderHTML.Append("</td>");
                        #endregion TR First
                        stringBuilderHTML.Append("</tr>");
                        //Ended Over here

                        stringBuilderHTML.Append("<tr>"); //1st Row Open Tag  
                        #region TR Second
                        stringBuilderHTML.Append("<td colspan='3' align='left'>");//1st Row 3rd Col Open Tag


                        stringBuilderHTML.Append("<table style='width:95%' border='0' cellpadding='0' cellspacing='3'>");
                        #region TR Second First Table
                        //Ist Row
                        stringBuilderHTML.Append("<tr>");
                        #region TR Second First Table First TR
                        //Ist TD
                        stringBuilderHTML.Append("<td style='width:5%;'>");
                        stringBuilderHTML.Append("&nbsp;");
                        stringBuilderHTML.Append("</td>");

                        //II TD
                        stringBuilderHTML.Append("<td style='width:6%;color:Black;font-size:11px;' align='center'>");
                        stringBuilderHTML.Append("<span    name='SpanObjs' id='SpanObjs'>");
                        stringBuilderHTML.Append("Objs");
                        stringBuilderHTML.Append("</span>");
                        stringBuilderHTML.Append("</td>");

                        //III TD
                        stringBuilderHTML.Append("<td style='width:22%;color:Black;font-size:11px;' align='center'>");
                        stringBuilderHTML.Append("<span    name='SpanInterVentionText' id='SpanInterVentionText'>");
                        stringBuilderHTML.Append("Intervention Text");
                        stringBuilderHTML.Append("</span>");
                        stringBuilderHTML.Append("</td>");

                        //IV TD
                        stringBuilderHTML.Append("<td style='width:22%;color:Black;font-size:11px;' align='center'>");
                        stringBuilderHTML.Append("<span    name='SpanProviderService' id='SpanProviderService'>");
                        stringBuilderHTML.Append("Provider/Service");
                        stringBuilderHTML.Append("</span>");
                        stringBuilderHTML.Append("</td>");

                        //V TD
                        //-----Commented By Ashwani on 4 Feb
                        stringBuilderHTML.Append("<td style='width:32%;color:Black;font-size:11px;' align='center'>");
                        stringBuilderHTML.Append("<span    name='SpanUnitsFrequency' id='SpanUnitsFrequency'  style='display:none'>");
                        stringBuilderHTML.Append("Units/Frequency");
                        stringBuilderHTML.Append("</span>");
                        stringBuilderHTML.Append("</td>");
                        //-----End Commented By Ashwani on 4 Feb


                        //VI TD
                        //-----Commented By Ashwani on 4 Feb
                        stringBuilderHTML.Append("<td style='color:Black;font-size:11px;' align='center'>");
                        stringBuilderHTML.Append("<span    name='SpanFromTo' id='SpanFromTo'  style='display:none'>");
                        stringBuilderHTML.Append("From/To");
                        stringBuilderHTML.Append("</span>");
                        stringBuilderHTML.Append("</td>");
                        //-----End Commented By Ashwani on 4 Feb
                        #endregion TR Second First Table First TR
                        stringBuilderHTML.Append("</tr>");

                        //    for (int interventionCount = 0; interventionCount < dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView.Count; interventionCount++)

                        if (dataViewTPInterventionProcedures != null && dataViewTPInterventionProcedures.Count > 0)
                        {

                            for (int interventionCount = 0; interventionCount < dataViewTPInterventionProcedures.Count; interventionCount++)
                            {
                                stringBuilderHTML.Append("<tr>");
                                #region TR Second First Table Second TR
                                stringBuilderHTML.Append("<td colspan='6' align='left' style='padding-left:5px;color:Black;font-size:11px;'>");
                                stringBuilderHTML.Append("<span   id=Span_TPInterventionProcedures_InterventionNumber_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ">");
                                stringBuilderHTML.Append("Intervention " + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InterventionNumber"]));
                                stringBuilderHTML.Append("</span>");
                                stringBuilderHTML.Append("</td>");
                                #endregion TR Second First Table Second TR
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("<tr>");
                                #region TR Second First Table Third TR
                                //Ist TD
                                stringBuilderHTML.Append("<td style='width:5%;color:Black;font-size:11px;' valign='top'>");

                                //Logic for Deletion of Intervention 
                                //If Procedure is associated and the below give written logic pass the criteria the deletion can possible
                                if (dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"] != DBNull.Value)
                                {
                                    DataRow[] dataRowTPProcedure = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("TPProcedureId=" + dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]);
                                    if (dataRowTPProcedure.Length > 0)
                                    {
                                        //Changed by anuj as documentid not exist in new database 3.1Dev databse
                                        //if (Convert.ToInt32(dataRowTPProcedure[0]["DocumentId"]) == BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentId && dataRowTPProcedure[0]["SourceDocumentId"] == System.DBNull.Value)
                                        //Changes ended over here
                                        if (Convert.ToInt32(dataRowTPProcedure[0]["DocumentVersionId"]) == Convert.ToInt32(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["DocumentVersions"].Rows[0]["DocumentVersionId"]) && dataRowTPProcedure[0]["SourceDocumentId"] == System.DBNull.Value)
                                        {
                                            stringBuilderHTML.Append("<img  style='cursor:hand;' id='ImgDeleteIntervention1' name='ImgDeleteIntervention1' src='"+RelativePath+"App_Themes/Includes/Images/deleteIcon.gif' tag='Delete Intervention'  onclick =\"DeleteIntervention('" + needId + "','" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','false');\" />");


                                        }
                                    }
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<img  style='cursor:hand;' id='ImgDeleteIntervention2' name='ImgDeleteIntervention2' src='"+RelativePath+"App_Themes/Includes/Images/deleteIcon.gif' tag='Delete Intervention'  onclick=\"DeleteIntervention('" + needId + "','" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','true');\" />");
                                }
                                stringBuilderHTML.Append("</td>");

                                //II TD
                                stringBuilderHTML.Append("<td style='width:8%;' valign='top'>");
                                stringBuilderHTML.Append("<div id=div_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ">");
                                stringBuilderHTML.Append("<select class='form_textarea' multiple='multiple' size='3' style='width:99%;'>");
                                dataRowTPProcedures = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Rows.Find(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]);
                                if (dataRowTPProcedures != null)
                                {
                                    if (dataRowTPProcedures["SourceDocumentId"] != System.DBNull.Value)
                                    {
                                        //Commented By Anuj as DocumentId Not Exist in New DataBase 3.1Dev
                                        //if (Convert.ToInt32(dataRowTPProcedures["SourceDocumentId"].ToString()) != Convert.ToInt32(dataRowTPProcedures["DocumentId"]))
                                        //Changes Ended Over Here
                                        if (Convert.ToInt32(dataRowTPProcedures["SourceDocumentId"].ToString()) != Convert.ToInt32(dataRowTPProcedures["DocumentVersionId"]))
                                        {
                                            disableProcedureProvider = true;
                                        }
                                    }
                                }
                                #region TPIntervention Procedure

                                dataRowTPInterventionPObjective = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedureObjectives"].Select("Isnull(RecordDeleted,'N')<>'Y' and TPInterventionProcedureId=" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]));
                                if (dataRowTPInterventionPObjective.Length > 0)
                                {
                                    dataTableTPObjective = new DataTable("TPObjective");
                                    dataTableTPObjective.Columns.Add("ObjectiveId", typeof(int));
                                    dataTableTPObjective.Columns.Add("ObjectiveNumber", typeof(float));
                                    foreach (DataRow drTPInterventionObjective in dataRowTPInterventionPObjective)
                                    {
                                        DataRow[] dataRowTPObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("ObjectiveId=" + Convert.ToInt32(drTPInterventionObjective["ObjectiveId"]) + " and IsNull(RecordDeleted,'N')<>'Y'");
                                        if (dataRowTPObjective.Length > 0)
                                        {
                                            DataRow dRowTPObjective = dataTableTPObjective.NewRow();
                                            dRowTPObjective["ObjectiveId"] = Convert.ToInt32(dataRowTPObjective[0]["ObjectiveId"]);
                                            dRowTPObjective["ObjectiveNumber"] = Convert.ToSingle(dataRowTPObjective[0]["ObjectiveNumber"]);

                                            dataTableTPObjective.Rows.Add(dRowTPObjective);

                                        }
                                    }
                                    for (int objectiveNumber = 0; objectiveNumber < dataTableTPObjective.Rows.Count; objectiveNumber++)
                                    {
                                        stringBuilderHTML.Append("<option value= " + dataTableTPObjective.Rows[objectiveNumber]["ObjectiveId"].ToString() + ">");
                                        stringBuilderHTML.Append(dataTableTPObjective.Rows[objectiveNumber]["ObjectiveNumber"].ToString() + "</option>");
                                    }
                                }
                                #endregion

                                stringBuilderHTML.Append("</select>");
                                stringBuilderHTML.Append("</div>");
                                stringBuilderHTML.Append("</td>");

                                //III TD
                                stringBuilderHTML.Append("<td style='width:22%;' valign='top' >");
                                //

                                stringBuilderHTML.Append("<textarea class='form_textarea' spellcheck='True' name='TextArea_TPInterventionProcdure_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' id='TextArea_TPInterventionProcdure_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'  bindautosaveevents='False' BindSetFormData='False' rows='3' cols='831' onchange= \"PRModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','TPInterventionProcedures','InterventionText','TextArea_TPInterventionProcdure_InterventionText_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','Edit','TPInterventionProcedureId');\" >"); //Create                        
                                if (dataViewTPInterventionProcedures[interventionCount]["InterventionText"] != DBNull.Value)
                                {
                                    stringBuilderHTML.Append(Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InterventionText"]));
                                }
                                stringBuilderHTML.Append("</textarea>");
                                stringBuilderHTML.Append("</td>");

                                //IV TD
                                stringBuilderHTML.Append("<td  valign='top' style='width:22%;'>");
                                stringBuilderHTML.Append("<table style='width:50%;' border='0' cellpadding='0' cellspacing='2'>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");

                                PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                                dropdownListinterVentionProvider = new SHS.CustomControl.DropDownListWithTooltip();
                                dropdownListinterVentionProvider.Width = 180;
                                dropdownListinterVentionProvider.CssClass = "form_dropdown";
                                //dropdownListinterVentionProvider.ID = "DropDownList_TPInterventionProvider_" + Convert.ToString(dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView[interventionCount]["TPInterventionProcedureId"]);
                                dropdownListinterVentionProvider.ID = "DropDownList_TPInterventionProvider_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                if (disableProcedureProvider == true) { dropdownListinterVentionProvider.Enabled = false; }
                                else
                                {
                                    dropdownListinterVentionProvider.Enabled = true;
                                }
                                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers != null)
                                {
                                    objectDocuments = new SHS.UserBusinessServices.Document();
                                    agencyName = objectDocuments.GetAgencyName();
                                    DataView dataViewProviders = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers);
                                    dataViewProviders.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                                    dropdownListinterVentionProvider.DataTextField = "ProviderName";
                                    dropdownListinterVentionProvider.DataValueField = "SiteId";
                                    dropdownListinterVentionProvider.DataSource = dataViewProviders;
                                    dropdownListinterVentionProvider.DataBind();
                                    dropdownListinterVentionProvider.Items.Insert(0, new ListItem(agencyName, "-1"));
                                    dropdownListinterVentionProvider.Items.Insert(1, new ListItem("Community/Natural Support", "-2"));
                                }
                                if (dataViewTPInterventionProcedures[interventionCount]["SiteId"] != DBNull.Value)
                                {
                                    dropdownListinterVentionProvider.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["SiteId"]);
                                }
                                dropdownListinterVentionProvider.Attributes.Add("bindautosaveevents", "False");
                                dropdownListinterVentionProvider.Attributes.Add("BindSetFormData", "False");

                                dropdownListinterVentionProvider.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','TPInterventionProcedures','SiteId','" + dropdownListinterVentionProvider.ClientID + "','Edit','TPInterventionProcedureId');");
                                PanelPeriodicReview.Controls.Add(dropdownListinterVentionProvider);

                                stringBuilderHTML.Append("</td>");
                                #endregion TR Second First Table Third TR
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("<tr>");
                                #region TR Second First Table Fourth TR
                                stringBuilderHTML.Append("<td>");
                                PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                                dropdownListinterVentionService = new SHS.CustomControl.DropDownListWithTooltip();
                                dropdownListinterVentionService.Width = 180;
                                dropdownListinterVentionService.CssClass = "form_dropdown";
                                dropdownListinterVentionService.ID = "DropDownList_TPInterventionService_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                if (disableProcedureProvider == true) { dropdownListinterVentionService.Enabled = false; }
                                else
                                {
                                    dropdownListinterVentionService.Enabled = true;
                                }
                                if (dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"] != DBNull.Value)
                                {
                                    dropdownListinterVentionService.Enabled = false;
                                    dropdownListinterVentionProvider.Enabled = false;
                                }
                                else
                                {
                                    dropdownListinterVentionService.Enabled = true;
                                    dropdownListinterVentionProvider.Enabled = true;
                                }
                                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes != null)
                                {
                                    DataView dataViewAuthorizationCodes = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes);
                                    dataViewAuthorizationCodes.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                                    dataViewAuthorizationCodes.Sort = "AuthorizationCodeName";
                                    dropdownListinterVentionService.DataTextField = "DisplayAs";
                                    dropdownListinterVentionService.DataValueField = "AuthorizationCodeId";
                                    dropdownListinterVentionService.DataSource = dataViewAuthorizationCodes;
                                    dropdownListinterVentionService.DataBind();
                                    dropdownListinterVentionService.Items.Insert(0, new ListItem("", ""));
                                }
                                if (dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"] != DBNull.Value)
                                {
                                    dropdownListinterVentionService.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]);
                                }
                                dropdownListinterVentionService.Attributes.Add("onChange", "PRModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','TPInterventionProcedures','AuthorizationCodeId','" + dropdownListinterVentionService.ClientID + "','Edit','TPInterventionProcedureId');");
                                dropdownListinterVentionService.Attributes.Add("bindautosaveevents", "False");
                                dropdownListinterVentionService.Attributes.Add("BindSetFormData", "False");
                                PanelPeriodicReview.Controls.Add(dropdownListinterVentionService);
                                stringBuilderHTML.Append("</td>");
                                #endregion TR Second First Table Fourth TR
                                stringBuilderHTML.Append("</tr>");
                        #endregion TR Second First Table
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");


                                //V TD

                                stringBuilderHTML.Append("<td align='left' valign='top' style='width:32%;'>");
                                #region  V TD
                                //-------Commented By Ashwani on 4 Feb
                                stringBuilderHTML.Append("<table style='width:95%;' border='0' cellpadding='0' cellspacing='2'>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td style='width:50%;' align='left'>");

                                if (dataViewTPInterventionProcedures[interventionCount]["Units"] == DBNull.Value)
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled'  id='Text_Units_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:35%;display:none'/>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled'  id='Text_Units_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:35%;display:none' value='" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Units"]) + "'/>");
                                }
                                //-------End Commented By Ashwani on 4 Feb
                                ////Units
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td style='width:50%;' align='left'>");
                                //-------Commented By Ashwani on 4 Feb
                                stringBuilderHTML.Append("<div id=divEncounter_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:95%;'>");


                                string displayUnitText = DisplayUnitType(dropdownListinterVentionProvider);

                                if (displayUnitText == string.Empty)
                                {
                                    stringBuilderHTML.Append("<span   style='display:none'>1 Unit =1 Encounter</span>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<span style='display:none'>");
                                    stringBuilderHTML.Append(displayUnitText);
                                    stringBuilderHTML.Append("</span>");
                                }


                                stringBuilderHTML.Append("</div>");
                                //-------End Commented By Ashwani on 4 Feb
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td align='left' colspan='2'>");


                                //PanelPeriodicReview.Controls.Add(dropdownListinterVentionFrequency);
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                #endregion  V TD
                                stringBuilderHTML.Append("</td>");


                                //VI TD
                                stringBuilderHTML.Append("<td valign='top' align='left'>");
                                #region  VI TD
                                //-------Commented By Ashwani on 4 Feb
                                stringBuilderHTML.Append("<table style='width:98%;' border='0' cellpadding='0' cellspacing='2'>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                //StartDate
                                if (dataViewTPInterventionProcedures[interventionCount]["StartDate"] != DBNull.Value)
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled'  id='Text_From_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'  value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["StartDate"]).ToString("MM/dd/yyyy") + "' style='width:92%;display:none'/>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled'  id='Text_From_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'  style='width:92%;display:none'/>");
                                }


                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                if (dataViewTPInterventionProcedures[interventionCount]["EndDate"] != DBNull.Value)
                                {

                                    stringBuilderHTML.Append("<input type='text' disabled='disabled'  id='Text_To_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'  value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["EndDate"]).ToString("MM/dd/yyyy") + "' style='width:92%;display:none'/>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<input type='text' disabled='disabled'  id='Text_To_'" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' style='width:92%;display:none'/>");
                                }

                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                //-------End Commented By Ashwani on 4 Feb
                                #endregion  VI TD
                                stringBuilderHTML.Append("</td>");
                        #endregion TR Second
                                stringBuilderHTML.Append("</tr>");

                                //IIIrd row
                                stringBuilderHTML.Append("<tr>");
                                #region TR Third
                                //Ist TD
                                stringBuilderHTML.Append("<td style='width:5%;'>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("</td>");

                                //II TD
                                stringBuilderHTML.Append("<td style='width:6%;'>");
                                stringBuilderHTML.Append("<span   name='Span_EditInterVention'  id='Span_EditInterVention'  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueforAssociatedObjective('" + "div_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','" + needId + "','" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "')\">Edit</span>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");

                                stringBuilderHTML.Append("</td>");
                                //III TD
                                stringBuilderHTML.Append("<td style='width:15%;'>");
                                stringBuilderHTML.Append("<span name='Span_QuickCopy'  id=Span_QuickCopy_TPInterventionProcedures_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"QuickCopyIntervention('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + "' );\">Quick Copy</span>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("</td>");

                                //IV TD
                                stringBuilderHTML.Append("<td style='width:22%;'>");
                                stringBuilderHTML.Append("<span name='Span_QuickInterVention'  id=Span_QuickInterVention_TPInterventionProcedures_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueQuickTxPlan('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + "','" + "TextArea_TPInterventionProcdure_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','" + "TPQuickInterventions" + "','" + "TPInterventionProcedures" + "');\">Use Quick Intervention</span>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("</td>");


                                //V TD
                                stringBuilderHTML.Append("<td colspan='2'>");
                                stringBuilderHTML.Append("<span  name='Span_AddQuickInterVention'  id=Span_AddQuickInterVention_TPInterventionProcedures_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueAddQuickTxPlan('" + "TPQuickInterventions" + "','" + "TextArea_TPInterventionProcdure_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "');\">Add this to Quick Interventions</span>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("</td>");
                                #endregion TR Third
                                stringBuilderHTML.Append("</tr>");

                            }
                            stringBuilderHTML.Append("</table>");
                        }
                        else
                            stringBuilderHTML.Append("</table>");



                        stringBuilderHTML.Append("</td>");//1st Row 3rd Col Close Tag
                        stringBuilderHTML.Append("</tr>");
                        PanelPeriodicReview.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                    }
                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            dataRowTPInterventionProcedures = null;
            dataRowTPInterventionPObjective = null;
        }
    }
    /// <summary>
    /// <Description>Method is used to calculate unit on the selection</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>09 Oct,2009</CreatedOn>
    /// </summary>
    private string DisplayUnitType(DropDownList dropdownlistFrequency)
    {
        string selectedValue = string.Empty;
        string strCodeName = string.Empty;
        string[] parameterCollection = null;
        DataSet dataSetAuthorization = null;
        DataSet dataSetTemp = null;
        DataView dataViewAuthorization = null;
        DataRow[] dataRowAuthorizationCodeName = null;
        DataRow[] dataRowGlobalCodes = null;
        Int32 unitTypeValue = 0;
        Int32 units = 0;
        string unitCounterText = string.Empty;
        try
        {
            // selectedValue = Request.Form["selectedValue"];
            char[] cSpilt = new char[1];
            cSpilt[0] = ',';
            if (Request.Form["UnitCount"] != null)
            {
                parameterCollection = Request.Form["UnitCount"].Split(cSpilt);
            }
            dataRowAuthorizationCodeName = SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("Active='Y'", "AuthorizationCodeName");
            dataSetAuthorization = new DataSet();
            dataSetAuthorization.EnforceConstraints = false;//Need to Check Anuj forcefully  enforced constraints false.
            dataSetAuthorization.Merge(dataRowAuthorizationCodeName);

            dataViewAuthorization = new DataView(dataSetAuthorization.Tables[0]);

            dataViewAuthorization.RowFilter = "AuthorizationCodeId=" + Convert.ToInt32(dropdownlistFrequency.SelectedValue);
            if (dataViewAuthorization.Count > 0 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != -1 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != 0)
            {
                if (dataViewAuthorization[0]["UnitType"] != null && dataViewAuthorization[0]["UnitType"] != System.DBNull.Value)
                    unitTypeValue = Convert.ToInt32(dataViewAuthorization[0]["UnitType"]);
                if (dataViewAuthorization[0]["Units"] != null && dataViewAuthorization[0]["Units"] != System.DBNull.Value)
                    units = Convert.ToInt32(dataViewAuthorization[0]["Units"]);

            }

            dataRowGlobalCodes = SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitTypeValue);

            dataSetTemp = new DataSet();

            if (dataRowGlobalCodes.Length > 0)
            {
                dataSetTemp.Merge(dataRowGlobalCodes);

                if (unitTypeValue == 120 || unitTypeValue == 110)
                {
                    // modified by Piyush on 6th March 2007 as per comment on "3/2/2007 8:08:07 AM " on task 390
                    strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    strCodeName = strCodeName.Substring(0, 6);
                    if (units != 1)
                        unitCounterText = "(1 Unit = " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                    else
                        unitCounterText = "(1 Unit = " + units + " " + strCodeName + ")";
                }
                else if (unitTypeValue == 124)
                {

                    strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    strCodeName = strCodeName.Substring(0, 9);
                    if (units != 1)
                        unitCounterText = "(1 Unit =  " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                    else
                        unitCounterText = "(1 Unit =  " + units + " " + strCodeName + ")";
                }
                else
                {
                    unitCounterText = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                }
            }

            return unitCounterText;
        }
        finally
        {

            selectedValue = string.Empty;
            strCodeName = string.Empty;
            parameterCollection = null;
            dataSetAuthorization = null;
            dataSetTemp = null;
            dataViewAuthorization = null;
            dataRowAuthorizationCodeName = null;
            dataRowGlobalCodes = null;
        }
    }


    /// <summary>
    /// <Description>Create Associated Intervention control on the basis of Radio click on HRMTreatmentPlan Procedure</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>05-Dec-2009</CreatedOn>
    /// </summary>
    private void CreateEditAssociateInterventionControl()
    {

        StringBuilder stringBuilderHTML = null;
        string authorizationCodeId = string.Empty;
        string siteId = string.Empty;
        try
        {

            authorizationCodeId = Request.Form["authorizationCodeId"];
            siteId = Request.Form["siteId"];
            using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatPlanHRMTPProcedure"] as DataSet)
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    DataRow[] drTPInterventionProcedure = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("AuthorizationCodeId=" + Convert.ToInt32(authorizationCodeId) + " and  SiteId=" + Convert.ToInt32(siteId) + " and TPProcedureId is not null and  Isnull(RecordDeleted,'N')<>'Y' and ISNULL(TPProcedureAssociatedOrNot,'N')='Y'");

                    DataTable myDataTable = null;
                    DataColumn myDataColumn = null;

                    if (drTPInterventionProcedure.Length > 0)
                    {
                        myDataTable = new DataTable("TPInterventionProcedure");
                        myDataColumn = new DataColumn();
                        myDataColumn.DataType = System.Type.GetType("System.String");
                        myDataColumn.ColumnName = "InterventionText";
                        myDataTable.Columns.Add(myDataColumn);

                        foreach (DataRow drInterventionText in drTPInterventionProcedure)
                        {
                            if (Convert.ToInt32(drInterventionText["TPProcedureId"]) == Convert.ToInt32(Request.QueryString["tpProcedureId"]))
                                myDataTable.Rows.Add(drInterventionText["InterventionText"]);
                        }

                        stringBuilderHTML = new StringBuilder();
                        stringBuilderHTML.Append("<select class='form_textarea' multiple='multiple' style='width:100%;height:80px'>");

                        for (int loopCount = 0; loopCount < myDataTable.Rows.Count; loopCount++)
                        {
                            stringBuilderHTML.Append("<option>");

                            if (myDataTable.Rows[loopCount]["InterventionText"].ToString().Length > 50)
                            {
                                stringBuilderHTML.Append(myDataTable.Rows[loopCount]["InterventionText"].ToString() + "</option>");
                            }
                            else
                            {
                                stringBuilderHTML.Append(BaseCommonFunctions.cutText(myDataTable.Rows[loopCount]["InterventionText"].ToString(), 50) + "</option>");
                            }
                        }
                        stringBuilderHTML.Append("</select>");
                        PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                    }
                }
            }
        }
        finally
        {
            stringBuilderHTML = null;
            authorizationCodeId = string.Empty;
            siteId = string.Empty;

        }
    }




    /// <summary>
    /// <Description>Change value in there TPNeeds Datatable</Description>
    /// <Author></Author>
    /// <CreatedOn></CreatedOn>
    /// </summary>
    private void UpdateGoalValue()
    {
        DataRow[] dataRowTreatmentPlanHRM = null;
        string goalText = string.Empty;
        string goalStrength = string.Empty;
        string goalBarriers = string.Empty;
        string goalActive = string.Empty;
        string goalMonitoredBy = string.Empty;
        string goalTargetDate = string.Empty;
        string stageOfTreatment = string.Empty;
        string goalStartDate = string.Empty;
        string goalNaturalSupports = string.Empty;
        string goalEmployment = string.Empty;
        string goalLivingArrangement = string.Empty;
        string goalHealthSafety = string.Empty;
        string strHTML = string.Empty;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPNeeds"))
                    {
                        if (dataSetTreatmentPlanHRM.Tables["TPNeeds"].Rows.Count > 0)
                        {
                            dataRowTreatmentPlanHRM = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + Convert.ToInt32(Request.QueryString["needId"]));
                            //dataRowTreatmentPlanHRM = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Select("NeedId" + "=" + Request.QueryString["NeedIdValue"]);
                            if (dataRowTreatmentPlanHRM.Length > 0)
                            {
                                dataRowTreatmentPlanHRM[0].BeginEdit();
                                if (Request.Form["goalText"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalText"] = Request.Form["goalText"].ToString();
                                    goalText = Request.Form["goalText"].ToString();
                                }
                                else
                                {
                                    goalText = "";
                                }
                                if (Request.Form["goalStrengths"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalStrengths"] = Request.Form["goalStrengths"].ToString();
                                    goalStrength = Request.Form["goalStrengths"].ToString();
                                }
                                else
                                {
                                    goalStrength = "";
                                }
                                if (Request.Form["goalBarriers"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalBarriers"] = Request.Form["goalBarriers"].ToString();
                                    goalBarriers = Request.Form["goalBarriers"].ToString();
                                }
                                else
                                {
                                    goalBarriers = "";
                                }
                                if (Request.Form["goalActive"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalActive"] = Request.Form["goalActive"].ToString();
                                    goalActive = Request.Form["goalActive"].ToString();
                                }
                                else
                                {
                                    goalActive = "";
                                }
                                if (Request.Form["goalMonitoredBy"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalMonitoredBy"] = Request.Form["goalMonitoredBy"].ToString();
                                    goalMonitoredBy = Request.Form["goalMonitoredBy"].ToString();
                                }
                                else
                                {
                                    goalMonitoredBy = "";
                                }
                                if (!string.IsNullOrEmpty(Request.Form["goalTargetDate"]))
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalTargetDate"] = Convert.ToDateTime(Request.Form["goalTargetDate"]);
                                    goalTargetDate = Convert.ToString(Request.Form["goalTargetDate"]);
                                }
                                else
                                {
                                    goalTargetDate = "";
                                }
                                if (!string.IsNullOrEmpty(Request.Form["goalCreatedDate"]))
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalStartDate"] = Convert.ToDateTime(Request.Form["goalCreatedDate"]);
                                    goalStartDate = Convert.ToString(Request.Form["goalCreatedDate"]);
                                }
                                else
                                {
                                    goalStartDate = "";
                                }
                                if (!string.IsNullOrEmpty(Request.Form["stageOfTreatment"]))
                                {
                                    dataRowTreatmentPlanHRM[0]["StageOfTreatment"] = Request.Form["stageOfTreatment"].ToString();
                                    stageOfTreatment = Request.Form["stageOfTreatment"].ToString();
                                }
                                else
                                {
                                    stageOfTreatment = "";
                                }
                                if (Request.Form["naturalSupport"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalNaturalSupports"] = Request.Form["naturalSupport"].ToString();
                                    goalNaturalSupports = Request.Form["naturalSupport"].ToString();
                                }
                                else
                                {
                                    goalNaturalSupports = "";
                                }
                                if (Request.Form["goalEmployment"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalEmployment"] = Request.Form["goalEmployment"].ToString();
                                    goalEmployment = Request.Form["goalEmployment"].ToString();
                                }
                                else
                                {
                                    goalEmployment = "";
                                }
                                if (Request.Form["goalliviningarragement"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalLivingArrangement"] = Request.Form["goalliviningarragement"].ToString();
                                    goalLivingArrangement = Request.Form["goalliviningarragement"].ToString();
                                }
                                else
                                {
                                    goalLivingArrangement = "";
                                }
                                if (Request.Form["goalhealthSafety"] != string.Empty)
                                {
                                    dataRowTreatmentPlanHRM[0]["GoalHealthSafety"] = Request.Form["goalhealthSafety"].ToString();
                                    goalHealthSafety = Request.Form["goalhealthSafety"].ToString();
                                }
                                else
                                {
                                    goalHealthSafety = "";
                                }
                                dataRowTreatmentPlanHRM[0].EndEdit();
                                strHTML = strHTML + "$$" + goalText + "$$" + goalStrength + "$$" + goalBarriers + "$$" + goalActive + "$$" + goalMonitoredBy + "$$" + goalTargetDate + "$$" + stageOfTreatment + "$$" + goalStartDate + "$$" + goalNaturalSupports + "$$" + goalEmployment + "$$" + goalLivingArrangement + "$$" + goalHealthSafety;
                                PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(strHTML));
                            }
                        }
                    }
                }
            }
        }
        finally
        {
            dataRowTreatmentPlanHRM = null;
        }
    }

    /// <summary>
    /// <Description>Method is used to add Need ClientList)</Description>
    /// <Author>Anuj Tomar</Author>
    /// <CreatedOn>22th-Sept-2009</CreatedOn>
    /// </summary>
    private void AddNeeddList()
    {
        DataView dataViewClientNeedList = null;
        DataRowView dataRowViewCustomClientNeeds = null;
        DataRow[] dataRowCustomClientNeeds = null;
        try
        {
            // using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatmentPlanHRM"] as DataSet)
            {
                //Perform table contain check
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Contains("CustomClientNeeds") && dataSetTreatmentPlanHRM.Tables.Contains("CustomClientNeeds"))
                {
                    if (dataSetTreatmentPlanHRM.Tables["CustomClientNeeds"].Rows.Count >= 0)
                    {

                        //dataRowCustomClientNeeds = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].Select("ISNULL(RecordDeleted,'N')<>'Y' and NeedId=" + needId);
                        dataViewClientNeedList = new DataView(dataSetTreatmentPlanHRM.Tables["CustomClientNeeds"]);
                        dataRowViewCustomClientNeeds = dataViewClientNeedList.AddNew(); //Create New Row
                        dataRowViewCustomClientNeeds.BeginEdit();
                        dataRowViewCustomClientNeeds["NeedStatus"] = 5234;

                        dataRowViewCustomClientNeeds["AssessmentUpdateType"] = "A";
                        dataRowViewCustomClientNeeds["NeedName"] = string.Empty;
                        dataRowViewCustomClientNeeds["NeedDescription"] = string.Empty;
                        //Set Episode number of the client
                        dataRowViewCustomClientNeeds["ClientEpisodeId"] = BaseCommonFunctions.GetEpisodeNumber(BaseCommonFunctions.ApplicationInfo.Client.ClientId);

                        dataRowViewCustomClientNeeds["SourceDocumentVersionId"] = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentVersionId;
                        //---Commented By Ashwani Kumar Angrish
                        //dataRowViewCustomClientNeeds["SourceDocumentVersion"] = 1;//Hard Coded for temp per BaseCommonFunctions.ScreenInfo.CurrentDocument.Version;
                        //dataRowViewCustomClientNeeds["SourceDocumentId"] = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentId;
                        //------------END

                        //BaseCommonFunctions.InitRowCredentials(dataRowViewCustomClientNeeds);
                        //--------------------------------------------------------------------------
                        dataRowViewCustomClientNeeds["RowIdentifier"] = System.Guid.NewGuid();
                        dataRowViewCustomClientNeeds["CreatedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                        dataRowViewCustomClientNeeds["CreatedDate"] = DateTime.Now.ToString();
                        dataRowViewCustomClientNeeds["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                        dataRowViewCustomClientNeeds["ModifiedDate"] = DateTime.Now.ToString();
                        //----------------------------------------------------------------------------
                        dataRowViewCustomClientNeeds.EndEdit();

                        //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMViewClientNeedList.ascx");
                        //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                        //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);

                        #region Code Added by Vikas Vyas
                        CreateViewClientNeedControl();

                        #endregion
                    }
                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            dataViewClientNeedList = null;
            dataRowViewCustomClientNeeds = null;
            dataRowCustomClientNeeds = null;
        }

    }


    /// <summary>
    /// <Description>Create ViewClientNeed Control</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>10th Nov,2009</CreatedOn>
    /// </summary>
    private void CreateViewClientNeedControl()
    {
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //try
        //{
        StringBuilder stringBuilderHTML = null;
        stringBuilderHTML = new StringBuilder();
        StringBuilder filterString = null;
        DataRow[] dRowTPNeedsClientNeeds = null;
        DataTable dataTableClientNeeds = null;

        //using (DataSet dataSetHRMTreatmentPlan = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
        using (DataSet dataSetHRMTreatmentPlan = Session["dataSetTreatmentPlanHRM"] as DataSet)
        {
            if (dataSetHRMTreatmentPlan != null && dataSetHRMTreatmentPlan.Tables.Count > 0)
            {
                filterString = new StringBuilder();
                if (dataSetHRMTreatmentPlan.Tables.Contains("CustomTPNeedsClientNeeds") && (dataSetHRMTreatmentPlan.Tables["CustomTPNeedsClientNeeds"].Rows.Count > 0))
                {
                    int ClientId = BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                    dRowTPNeedsClientNeeds = dataSetHRMTreatmentPlan.Tables["CustomTPNeedsClientNeeds"].Select("IsNull(RecordDeleted,'N')<>'Y'");

                    if (dRowTPNeedsClientNeeds.Length > 0)
                    {
                        for (int i = 0; i < dRowTPNeedsClientNeeds.Length; i++)
                        {
                            filterString.Append(Convert.ToString(dRowTPNeedsClientNeeds[i]["ClientNeedId"]));
                            filterString.Append(" ,");
                        }
                        filterString = filterString.Remove(filterString.Length - 1, 1);
                    }
                }
                dataTableClientNeeds = dataSetHRMTreatmentPlan.Tables["CustomClientNeeds"];

                if (filterString.Length > 0)
                {
                    dataTableClientNeeds.DefaultView.RowFilter = "ISNULL(RecordDeleted,'N')<>'Y' and NeedStatus<>5237 and ClientNeedId not in( " + filterString + " )";

                }
                else
                {
                    dataTableClientNeeds.DefaultView.RowFilter = "NeedStatus not in (5236,5237) and Isnull(RecordDeleted,'N')<>'Y'";
                }


                //stringBuilderHTML = new StringBuilder();
                if (dataTableClientNeeds.DefaultView.Count > 0)
                {
                    #region Create Controls
                    stringBuilderHTML.Append("<table width='98%' cellpadding='4' cellspacing='0' border='0' id='TableHRMClientNeedsList' name='TableHRMClientNeedsList'>");
                    stringBuilderHTML.Append("<tr>");
                    stringBuilderHTML.Append("<td >");
                    stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                    stringBuilderHTML.Append("<tr>");
                    stringBuilderHTML.Append("<td align='left' nowrap='nowrap' class='content_tab_left'>");
                    stringBuilderHTML.Append("<span >Need List</span>");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("<td width='17'>");
                    stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='17' alt='' src="+RelativePath+"App_Themes/Includes/Images/content_tab_sep.gif ");
                    stringBuilderHTML.Append("</td>");

                    stringBuilderHTML.Append("<td width='98%' class='content_tab_top'>");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("<td width='7'>");
                    stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='7' alt='' src="+RelativePath+"App_Themes/Includes/Images/content_tab_right.gif ");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append(" </tr>");
                    stringBuilderHTML.Append("</table>");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("</tr>");

                    stringBuilderHTML.Append("<tr>");
                    //stringBuilderHTML.Append("<td class='right_contanier_bg'>");
                    stringBuilderHTML.Append("<td>");
                    stringBuilderHTML.Append("<table width='98%' border='0' cellpadding='0' cellspacing='0'>");
                    stringBuilderHTML.Append("<tr>");
                    stringBuilderHTML.Append("<td style='width: 25%' align='center'>");
                    stringBuilderHTML.Append("<span id='SpanNeed' name='SpanNeed' class='formlegend'>Need</span>");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("<td style='width: 30%' align='center'>");
                    stringBuilderHTML.Append("<span  id='SpanDescription' name='SpanDescription' class='formlegend'>Description of Need</span>");
                    stringBuilderHTML.Append("</td>");

                    stringBuilderHTML.Append("<td style='width: 20%' align='center'>");
                    stringBuilderHTML.Append("<span   id='SpanStatus' name='SpanStatus' class='formlegend'>Status</span>");
                    stringBuilderHTML.Append("</td>");

                    stringBuilderHTML.Append("<td style='width: 25%' align='center'>");
                    stringBuilderHTML.Append("<span  id='SpanCreatedBy' name='SpanCreatedBy' class='formlegend'>Created ByOn</span>");
                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append("</tr>");

                    stringBuilderHTML.Append("</table>");


                    stringBuilderHTML.Append("</td>");
                    stringBuilderHTML.Append(" </tr>");



                    //  for (int i = 0; i < dataTableClientNeeds.DefaultView.Count; i++)
                    for (int i = dataTableClientNeeds.DefaultView.Count - 1; i >= 0; i--)
                    {
                        DataRow currentRow = dataTableClientNeeds.DefaultView[i].Row;




                        stringBuilderHTML.Append("<tr>");
                        //stringBuilderHTML.Append("<td class='right_contanier_bg' align='left'>");
                        stringBuilderHTML.Append("<td>");

                        stringBuilderHTML.Append("<Div id=divNeedList" + Convert.ToInt32(currentRow["ClientNeedId"]) + ">");
                        stringBuilderHTML.Append("<table  id=TableNeedList_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  width='100%' border='0' cellpadding='0' cellspacing='3'>");
                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td style='width:3%' valign='top'>");

                        if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                        {
                            stringBuilderHTML.Append("<img id=ImageDelete_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "   name=ImageDelete_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " src="+RelativePath+"App_Themes/Includes/Images/deleteIcon.gif  alt='' Needlistvalue=" + Convert.ToInt32(currentRow["ClientNeedId"]) + " onclick=\"DeleteNeedListHTML('" + currentRow["ClientNeedId"].ToString() + "');\" />");
                        }
                        else
                        {
                            stringBuilderHTML.Append("<img id=ImageDelete_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " style='display:none'  name=ImageDelete_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " src="+RelativePath+"App_Themes/Includes/Images/deleteIcon.gif  alt='' Needlistvalue=" + Convert.ToInt32(currentRow["ClientNeedId"]) + " onclick=\"DeleteNeedListHTML('" + currentRow["ClientNeedId"].ToString() + "');\" />");
                        }

                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("<td style='width:22%' valign='top' align='center'>");
                        if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                        {
                            stringBuilderHTML.Append("<textarea  id='TextArea_CustomClientNeeds_NeedName_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' name='TextArea_CustomClientNeeds_NeedName_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "'  bindautosaveevents='False' BindSetFormData='False' rows='7' cols='10' style='width:96%;' spellcheck='True' class='form_textarea'  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedName" + "','" + "TextArea_CustomClientNeeds_NeedName_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\">");

                        }
                        else
                        {
                            stringBuilderHTML.Append("<textarea  id='TextArea_CustomClientNeeds_NeedName_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' readonly=readonly  name='TextArea_CustomClientNeeds_NeedName_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' bindautosaveevents='False' BindSetFormData='False'  rows='7' cols='10' style='width:96%;' class='form_textarea'  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedName" + "','" + "TextArea_CustomClientNeeds_NeedName_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\">");

                        }
                        stringBuilderHTML.Append(currentRow["NeedName"].ToString());
                        stringBuilderHTML.Append("</textarea>");

                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("<td style='width:31%;' valign='top' align ='center'>");
                        if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                        {
                            stringBuilderHTML.Append("<textarea  bindautosaveevents='False' BindSetFormData='False' id='TextArea_CustomClientNeeds_NeedDescription_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' spellcheck='True' name='TextArea_CustomClientNeeds_NeedDescription_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' rows='7' cols='15' style='width:96%;' class='form_textarea' onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedDescription" + "','" + "TextArea_CustomClientNeeds_NeedDescription_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\">");
                        }
                        else
                        {
                            stringBuilderHTML.Append("<textarea bindautosaveevents='False' BindSetFormData='False'  id='TextArea_CustomClientNeeds_NeedDescription_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' readonly=readonly  name='TextArea_CustomClientNeeds_NeedDescription_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' rows='7' cols='15' style='width:96%;' class='form_textarea' onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedDescription" + "','" + "TextArea_CustomClientNeeds_NeedDescription_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\">");
                        }

                        stringBuilderHTML.Append(currentRow["NeedDescription"].ToString());
                        stringBuilderHTML.Append("</textarea>");
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("<td style='width:20%' valign='top' align='left'>");
                        stringBuilderHTML.Append("<table  id=TableStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  width='100%' border='0' cellpadding='0' cellspacing='0'>");
                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td  valign='top'>");
                        if (currentRow["NeedStatus"].ToString() == "5234")
                        {
                            stringBuilderHTML.Append("<input type='radio' value='5234' checked='checked' id=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_Add  name=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedStatus" + "','" + "Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_Add" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\" />");
                            stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_Add class='form_label'>Add To Tx Plan </label>");
                        }
                        else
                        {
                            stringBuilderHTML.Append("<input type='radio' value='5234'  id=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_Add  name=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedStatus" + "','" + "Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_Add" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\" />");
                            stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_Add class='form_label'>Add To Tx Plan </label>");
                        }

                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");

                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td  valign='top'>");
                        if (currentRow["NeedStatus"].ToString() == "5236")
                        {
                            stringBuilderHTML.Append("<input type='radio' value='5236' checked='checked' id=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_D  name=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedStatus" + "','" + "Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_D" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\" />");
                            stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_D class='form_label'>Defer</label>");
                        }
                        else
                        {
                            stringBuilderHTML.Append("<input type='radio' value='5236' id=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_D  name=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "NeedStatus" + "','" + "Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_D" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\"/>");
                            stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_NeedStatus_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_D class='form_label'>Defer</label>");

                        }

                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");

                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td  valign='top'>");
                        stringBuilderHTML.Append("&nbsp;");
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");

                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td  valign='top'>");
                        if (currentRow["AssessmentUpdateType"].ToString() == "A")
                        {

                            if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                            {
                                stringBuilderHTML.Append("<input type='radio' value='A' checked='checked'  id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_AC " + " name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "AssessmentUpdateType" + "','" + "Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_AC" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\"/>");
                                stringBuilderHTML.Append("<label  for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_AC  class='form_label'>Amend Current Assessment</label>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='radio' value='A' style='display:none'  checked='checked' id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_AC " + " name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "AssessmentUpdateType" + "','" + "Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_AC" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\"/>");
                                stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_AC  class='form_label' style='display:none'>Amend Current Assessment</label>");
                            }

                        }
                        else
                        {
                            if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                            {
                                stringBuilderHTML.Append("<input type='radio' value='A' id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " _AC " + " name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "/>");
                                stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " _AC class='form_label'>Amend Current Assessment</label>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='radio' value='A' style='display:none'   id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " _AC " + " name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "/>");
                                stringBuilderHTML.Append("<label   for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " _AC  class='form_label' style='display:none'>Amend Current Assessment</label>");
                            }

                        }

                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");

                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td  valign='top'>");
                        if (currentRow["AssessmentUpdateType"].ToString() == "U")
                        {
                            if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                            {
                                stringBuilderHTML.Append("<input type='radio' value='U' checked='checked'     id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA " + " name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "AssessmentUpdateType" + "','" + "Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\"/>");
                                stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA class='form_label' >Create Assessment Update</label>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='radio' value='U' checked='checked'  style='display:none'    id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA " + " name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "AssessmentUpdateType" + "','" + "Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\"/>");
                                stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA class='form_label'  style='display:none' >Create Assessment Update</label>");
                            }
                        }
                        else
                        {
                            if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                            {
                                stringBuilderHTML.Append("<input type='radio' value='U'    id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA  name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "AssessmentUpdateType" + "','" + "Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\"/>");
                                stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA class='form_label' >Create Assessment Update</label>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='radio' value='U' style='display:none'   id=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA  name=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "AssessmentUpdateType" + "','" + "Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA" + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\"/>");
                                stringBuilderHTML.Append("<label for=Radio_CustomClientNeeds_AssessmentUpdate_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "_CA class='form_label' style='display:none' >Create Assessment Update</label>");
                            }


                        }
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");

                        stringBuilderHTML.Append("</table>");
                        stringBuilderHTML.Append("</td>");

                        stringBuilderHTML.Append("<td style='width:24%' valign='top' align='center'>");
                        stringBuilderHTML.Append("<table id=TableCreated_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  width='100%' border='0' cellpadding='0' cellspacing='0'>");
                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td  valign='top'  align ='center'>");
                        stringBuilderHTML.Append("<textarea  id='TextArea_CustomClientNeeds_CreatedBy_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' readonly=readonly  name='TextArea_CustomClientNeeds_CreatedBy_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "' rows='7' cols='13' style='width:96%;' class='form_textarea' bindautosaveevents='False' BindSetFormData='False' spellcheck='True' >");

                        stringBuilderHTML.Append("CreatedBy:" + currentRow["CreatedBy"].ToString() + " ");
                        stringBuilderHTML.Append("CreatedDate:" + currentRow["CreatedDate"].ToString() + " ");

                        stringBuilderHTML.Append("</textarea>");
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");
                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td align='left'>");
                        if (currentRow["DiagnosisUpdateRequired"].ToString() == "Y")
                        {
                            if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                            {

                                stringBuilderHTML.Append("<input type='checkbox' value='Y'  checked='checked' id=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  name=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "DiagnosisUpdateRequired" + "','" + "CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\" />");
                                stringBuilderHTML.Append("<label for=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " class='form_label'  >Diagnosis Update Required</label>");
                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='checkbox' value='Y' style='display:none'  checked='checked' id=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  name=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "DiagnosisUpdateRequired" + "','" + "CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\" />");
                                stringBuilderHTML.Append("<label for=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " class='form_label' style='display:none' >Diagnosis Update Required</label>");

                            }

                        }
                        else
                        {
                            if (currentRow.RowState == DataRowState.Added || Convert.ToString(currentRow["DisplayRadioButtons"]) == "Y")
                            {
                                stringBuilderHTML.Append("<input type='checkbox' value='N'   id=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  name=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "DiagnosisUpdateRequired" + "','" + "CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\" />");
                                stringBuilderHTML.Append("<label  for=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " class='form_label'  >Diagnosis Update Required</label>");

                            }
                            else
                            {
                                stringBuilderHTML.Append("<input type='checkbox' value='N' style='display:none'   id=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "  name=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " onchange = \"PRModifyGoalValueInDataSet('" + currentRow["ClientNeedId"].ToString() + "','" + "CustomClientNeeds" + "','" + "DiagnosisUpdateRequired" + "','" + "CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + "','" + "EditClientNeedValue" + "','" + "ClientNeedId" + "');\" />");
                                stringBuilderHTML.Append("<label for=CheckBox_CustomClientNeeds_DiagnosisUpdateRequired_" + Convert.ToInt32(currentRow["ClientNeedId"]) + " class='form_label' style='display:none' >Diagnosis Update Required</label>");

                            }

                        }




                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");
                        stringBuilderHTML.Append("</table>");
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");


                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td colspan='5'>");
                        stringBuilderHTML.Append("<hr style=color: #000000; height: 1px; />");
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");
                        stringBuilderHTML.Append("</table>");
                        stringBuilderHTML.Append("</Div>");
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");

                    }

                    stringBuilderHTML.Append("</table>");
                    PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                    #endregion
                }
            }
        }
        //}
        //finally
        //{

        //}
    }


    /// <summary>
    /// <Description>Method is used to Delete  ClientNeedList)</Description>
    /// <Author>Anuj Tomar</Author>
    /// <CreatedOn>22th-Sept-2009</CreatedOn>
    /// </summary>
    private void DeleteNeedList()
    {
        DataRow[] dataRowDeleteNeedList = null;
        DataRow[] dataRowNeedList = null;
        try
        {
            //using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatmentPlanHRM"] as DataSet)
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Contains("CustomClientNeeds") && dataSetTreatmentPlanHRM.Tables.Contains("CustomClientNeeds"))
                {
                    dataRowDeleteNeedList = dataSetTreatmentPlanHRM.Tables["CustomClientNeeds"].Select("Isnull(RecordDeleted,'N')<>'Y' and ClientNeedId=" + Request.QueryString["ClientNeedId"].ToString());
                    dataRowDeleteNeedList[0].BeginEdit();
                    dataRowDeleteNeedList[0]["RecordDeleted"] = "Y";
                    dataRowDeleteNeedList[0]["DeletedDate"] = System.DateTime.Now;
                    dataRowDeleteNeedList[0]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                    dataRowDeleteNeedList[0].EndEdit();
                    //dataRowNeedList = dataSetTreatmentPlanHRM.Tables["CustomClientNeeds"].Select("ISNULL(RecordDeleted,'N')<>'Y'  and ClientNeedId=" + Request.QueryString["ClientNeedId"]);
                    //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMViewClientNeedList.ascx");
                    //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                    //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                    CreateViewClientNeedControl();

                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            dataRowDeleteNeedList = null;
            dataRowNeedList = null;
        }
    }

    /// <summary>
    /// <Description>Method is used to Merge Copy  of ClientNeedList data in Base Dataset)</Description>
    /// <Author>Anuj Tomar</Author>
    /// <CreatedOn>24th-Sept-2009</CreatedOn>
    /// <ModifiedBy>Vikas Vyas</ModifiedBy>
    /// <ModifiedOn>13th- Nov-2009</ModifiedOn>
    /// <Purpose>get Data from Session dataSet and Merge in the Base DataSet</Purpose>
    /// </summary>
    private void UpdateClientNeedList()
    {
        using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatmentPlanHRM"] as DataSet)
        {
            BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Merge(dataSetTreatmentPlanHRM);
        }
    }

    #region Commented By Vikas Vyas (Because as we are working on copy of dataSet)

    ///// <summary>
    ///// <Description>Method is used to Cancel ClientNeedList data in Dataset)</Description>
    ///// <Author>Anuj Tomar</Author>
    ///// <CreatedOn>24th-Sept-2009</CreatedOn>
    ///// </summary>
    //private void CancelClientNeedList()
    //{
    //    using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
    //    {
    //        if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Contains("CustomClientNeeds") && dataSetTreatmentPlanHRM.Tables.Contains("CustomClientNeeds"))
    //        {
    //            dataSetTreatmentPlanHRM.Tables["CustomClientNeeds"].RejectChanges();
    //        }
    //    }
    //}

    #endregion

    /// <summary>
    /// Created By Anuj Tomar
    /// Created On:24 Sep,2009
    /// <Description>Method is used to Delete the Goal</Description>
    /// </summary>
    private void DeleteGoal()
    {
        DataView dataViewGoal = null;
        DataRow[] dataRowObjective = null;
        DataRow[] dataRowIntervention = null;
        int needNumber = 0;
        int needId = 0;
        try
        {
            _FromPROnload = Convert.ToBoolean(Request.Form["fromPR"]);
            needId = Convert.ToInt32(Request.QueryString["needId"]);
            // using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            //{
            DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet();

            if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
            {
                if (dataSetTreatmentPlanHRM.Tables.Contains("TPNeeds"))
                {
                    //dataSetTreatmentPlanHRM.Tables["TPNeeds"].DefaultView.RowFilter = "Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + Convert.ToInt32(Request.QueryString["needId"]);

                    DataRow[] dataRowTPNeeds = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + Convert.ToInt32(Request.QueryString["needId"]));
                    //dataViewGoal = dataSetTreatmentPlanHRM.Tables["TPNeeds"].DefaultView;                   
                    if (dataRowTPNeeds.Length > 0)
                    {

                        needNumber = Convert.ToInt32(dataRowTPNeeds[0]["NeedNumber"]);
                        dataRowTPNeeds[0].BeginEdit();
                        dataRowTPNeeds[0]["RecordDeleted"] = "Y";
                        dataRowTPNeeds[0]["DeletedDate"] = System.DateTime.Now;
                        dataRowTPNeeds[0]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                        dataRowTPNeeds[0].EndEdit();
                        #region Section for Objective
                        if (dataSetTreatmentPlanHRM.Tables.Contains("TPObjectives") && dataSetTreatmentPlanHRM.Tables["TPObjectives"].Rows.Count > 0)
                        {
                            dataRowObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + needId);

                            for (int objectiveCount = 0; objectiveCount < dataRowObjective.Length; objectiveCount++)
                            {
                                dataRowObjective[objectiveCount].BeginEdit();

                                dataRowObjective[objectiveCount]["RecordDeleted"] = "Y";
                                dataRowObjective[objectiveCount]["DeletedDate"] = System.DateTime.Now;
                                dataRowObjective[objectiveCount]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                                dataRowObjective[objectiveCount].EndEdit();
                            }
                        }
                        #endregion
                        #region Section for Intervention
                        if (dataSetTreatmentPlanHRM.Tables.Contains("TPInterventionProcedures") && dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Count > 0)
                        {
                            dataRowIntervention = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId=" + needId);
                            for (int interventionCount = 0; interventionCount < dataRowIntervention.Length; interventionCount++)
                            {
                                dataRowIntervention[interventionCount].BeginEdit();
                                dataRowIntervention[interventionCount]["RecordDeleted"] = "Y";
                                dataRowIntervention[interventionCount]["DeletedDate"] = System.DateTime.Now;
                                dataRowIntervention[interventionCount]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                                dataRowIntervention[interventionCount].EndEdit();
                            }
                        }
                        #endregion
                        #region Renumber Goal
                        //dataSetTreatmentPlanHRM.Tables["TPNeeds"].DefaultView.RowFilter = "";
                        // dataSetTreatmentPlanHRM.Tables["TPNeeds"].DefaultView.RowFilter = "NeedId<>" + needId + " and ISNULL(RecordDeleted,'N')<>'Y' and NeedNumber>" + needNumber;
                        dataRowTPNeeds = dataSetTreatmentPlanHRM.Tables["TPNeeds"].Select("NeedId<>" + needId + " and ISNULL(RecordDeleted,'N')<>'Y' and NeedNumber >" + needNumber);
                        //dataViewGoal = dataSetTreatmentPlanHRM.Tables["TPNeeds"].DefaultView;
                        for (int needCount = 0; needCount < dataRowTPNeeds.Length; needCount++)
                        {
                            ChangeObjectiveNumbers(Convert.ToInt32(dataRowTPNeeds[needCount]["NeedId"]), Convert.ToInt32(dataRowTPNeeds[needCount]["NeedNumber"]) - 1, ref dataSetTreatmentPlanHRM);
                            dataRowTPNeeds[needCount].BeginEdit();
                            dataRowTPNeeds[needCount]["NeedNumber"] = Convert.ToInt32(dataRowTPNeeds[needCount]["NeedNumber"]) - 1;
                            dataRowTPNeeds[needCount].EndEdit();
                        }
                        #endregion
                        //dataSetTreatmentPlanHRM.Tables["TPNeeds"].DefaultView.RowFilter = "";
                        //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
                        //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                        //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                        CreateGoal();
                        PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
                    }
                }
            }
        }
        finally
        {
            dataRowObjective = null;
            dataRowIntervention = null;
        }
    }
    /// <summary>
    /// Created By Ashwani Kumar Angrish
    /// Created On:3 Feb 2010
    /// <Description>Method is used to Update the objective values</Description>
    /// </summary>
    private void UpdateObjective()
    {
        DataRow[] dataRowTPObjectives = null;
        int objectiveId = 0;
        string strHTML = string.Empty;
        try
        {
            objectiveId = Convert.ToInt32(Request.QueryString["objectiveId"]);

            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {

                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPObjectives") && dataSetTreatmentPlanHRM.Tables["TPObjectives"].Rows.Count > 0)
                    {
                        dataRowTPObjectives = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("Isnull(RecordDeleted,'N')<>'Y' and ObjectiveId=" + objectiveId);

                        if (dataRowTPObjectives.Length > 0)
                        {
                            string objectvetext = string.Empty;
                            string targetdate = string.Empty;
                            string objectiveStatus = string.Empty;
                            dataRowTPObjectives[0].BeginEdit();

                            if (Request.Form["ObjectiveText"] != string.Empty)
                            {
                                dataRowTPObjectives[0]["ObjectiveText"] = Request.Form["ObjectiveText"];
                                objectvetext = Convert.ToString(Request.Form["ObjectiveText"]);
                            }
                            else
                            {
                                objectvetext = "";
                            }
                            if (Request.Form["TargetDate"] != string.Empty)
                            {
                                dataRowTPObjectives[0]["TargetDate"] = Convert.ToDateTime(Request.Form["TargetDate"]);
                                targetdate = Convert.ToString(Request.Form["TargetDate"]);
                            }
                            else
                            {
                                targetdate = "";
                            }
                            if (Request.Form["ObjectiveStatus"] != string.Empty)
                            {
                                dataRowTPObjectives[0]["ObjectiveStatus"] = Request.Form["ObjectiveStatus"];
                                objectiveStatus = Convert.ToString(Request.Form["ObjectiveStatus"]);

                            }
                            else
                            {
                                objectiveStatus = "";
                            }

                            dataRowTPObjectives[0]["ModifiedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                            dataRowTPObjectives[0]["ModifiedDate"] = DateTime.Now.ToString();
                            dataRowTPObjectives[0].EndEdit();


                            strHTML = strHTML + "$$" + objectvetext + "$$" + targetdate.Trim() + "$$" + objectiveStatus.Trim();

                            PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(strHTML));
                        }
                    }
                }
            }
        }
        finally
        {
            dataRowTPObjectives = null;
        }
    }


    /// <summary>
    /// Created By Ashwani Kumar Angrish
    /// Created On:3 Feb,2010
    /// <Description>Method is used to Update the objective values</Description>
    /// </summary>
    private void DeleteQuickTxPlan()
    {
        DataRow[] dataRowDeleteQuickTxPlan = null;
        //DataRow[] dataRowQuickTxPlan = null;
        string tableName = string.Empty;
        DataSet datasetQuicktype = null;
        SHS.UserBusinessServices.Document objectDocument = null;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (Request.Form["tableName"] != null && Request.Form["tableName"] != "")
                {
                    tableName = Request.Form["tableName"].ToString();
                }

                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Contains(tableName) && dataSetTreatmentPlanHRM.Tables.Contains(tableName))
                {
                    dataRowDeleteQuickTxPlan = dataSetTreatmentPlanHRM.Tables[tableName].Select("Isnull(RecordDeleted,'N')<>'Y' and TPQuickId=" + Request.QueryString["quickId"].ToString());
                    if (dataRowDeleteQuickTxPlan.Length > 0)
                    {
                        dataRowDeleteQuickTxPlan[0].BeginEdit();
                        dataRowDeleteQuickTxPlan[0]["RecordDeleted"] = "Y";
                        dataRowDeleteQuickTxPlan[0]["DeletedDate"] = System.DateTime.Now;
                        dataRowDeleteQuickTxPlan[0]["DeletedBy"] = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode;
                        dataRowDeleteQuickTxPlan[0].EndEdit();


                        if (!dataSetTreatmentPlanHRM.Tables[tableName].ExtendedProperties.Contains("UpdateChildTable"))
                            dataSetTreatmentPlanHRM.Tables[tableName].ExtendedProperties.Add("UpdateChildTable", false);
                        else
                            dataSetTreatmentPlanHRM.Tables[tableName].ExtendedProperties["UpdateChildTable"] = false;

                        objectDocument = new SHS.UserBusinessServices.Document();
                        datasetQuicktype = new DataSet();


                        datasetQuicktype.Merge(dataSetTreatmentPlanHRM.Tables[tableName]);

                        //commented by shifali on 30 july,2010
                        //objectDocument.UpdateDocuments(datasetQuicktype, "", 0, "", BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode, "", "");

                        objectDocument.UpdateDocuments(datasetQuicktype, "", 0, "", BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserName, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode, "", "", "",5763,"","","","");

                        dataSetTreatmentPlanHRM.Tables[tableName].AcceptChanges();
                        dataSetTreatmentPlanHRM.Tables[tableName].Clear();


                        string whereClause = "  where IsNull(RecordDeleted,'N')<>'Y' AND StaffId= '" + BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId + "'";
                        //DataTable dtTemp = (objectDocument.GetUpdatedQuickTypeData(dataSetTreatmentPlanHRM, whereClause, Request.QueryString["tableName"])).Tables[Request.QueryString["tableName"]];
                        DataSet dataSetTemp = objectDocument.GetUpdatedQuickTypeData(dataSetTreatmentPlanHRM, whereClause, tableName);
                        if (dataSetTemp != null)
                        {
                            if (dataSetTemp.Tables.Count > 0)
                            {
                                dataSetTreatmentPlanHRM.Tables[tableName].Merge(dataSetTemp.Tables[tableName]);
                            }


                        }



                    }

                }
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            dataRowDeleteQuickTxPlan = null;
        }
    }

    /// <summary>
    /// Created By Ashwani Kumar Angrish
    /// Created On:4 Feb,2010
    /// <Description>Method is used to Renumber the objective</Description>
    /// </summary>
    private void ChangeObjectiveNumbers(int newNeedId, int newNumber, ref DataSet dataSetTreatmentPlan)
    {
        DataRow[] dataRowsObjectives = null;
        string objectiveNumber = string.Empty;
        try
        {
            dataRowsObjectives = dataSetTreatmentPlan.Tables["TPObjectives"].Select("NeedID=" + newNeedId);
            for (int objectiveCount = 0; objectiveCount < dataRowsObjectives.Length; objectiveCount++)
            {
                dataRowsObjectives[objectiveCount].BeginEdit();
                objectiveNumber = dataRowsObjectives[objectiveCount]["ObjectiveNumber"].ToString();
                dataRowsObjectives[objectiveCount]["ObjectiveNumber"] = newNumber.ToString() + objectiveNumber.Substring(objectiveNumber.IndexOf("."));
                dataRowsObjectives[objectiveCount].EndEdit();
            }
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {
            dataRowsObjectives = null;
        }
    }

    /// <summary>
    /// <Description>Handle Renumber Goal/Objective/Intervention</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>6th Oct,2009</CreatedOn>
    /// </summary>
    private void RenumberTxPlan()
    {
        string[] rowSeparator = null;
        string[] separatorCol = null;
        DataRow[] dataRowTPNeeds = null;
        string[] arrayColCollection = null;
        DataSet dataSetTreatmentPlanHRM = null;
        string tableName = string.Empty;
        string keyFieldName = string.Empty;
        string fieldText = string.Empty;
        try
        {
            rowSeparator = new string[] { "||" };
            separatorCol = new string[] { "$$" };
            dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet();
            if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
            {
                tableName = Request.QueryString["tableName"];
                keyFieldName = Request.Form["keyFieldName"];
                switch (tableName.ToLower())
                {
                    case "tpneeds":
                        fieldText = "NeedNumber";
                        break;
                    case "tpobjectives":
                        fieldText = "ObjectiveNumber";
                        break;
                    case "tpinterventionprocedures":
                        fieldText = "InterventionNumber";
                        break;
                }
                if (dataSetTreatmentPlanHRM.Tables.Contains(tableName) && dataSetTreatmentPlanHRM.Tables[tableName].Rows.Count > 0)
                {
                    string[] strSplitArr = Request.Form["strHTML"].Split(rowSeparator, StringSplitOptions.None);
                    if (strSplitArr.Length > 0)
                    {
                        for (int rowCount = 0; rowCount < strSplitArr.Length; rowCount++)
                        {
                            arrayColCollection = strSplitArr[rowCount].Split(separatorCol, StringSplitOptions.None);
                            dataRowTPNeeds = dataSetTreatmentPlanHRM.Tables[tableName].Select("Isnull(RecordDeleted,'N')<>'Y' and " + keyFieldName + "=" + Convert.ToInt32(arrayColCollection[0]));
                            if (dataRowTPNeeds.Length > 0)
                            {
                                dataRowTPNeeds[0].BeginEdit();
                                dataRowTPNeeds[0][fieldText] = arrayColCollection[1];
                                dataRowTPNeeds[0].EndEdit();
                                if (tableName.ToLower() == "tpneeds")
                                {
                                    ChangeObjectiveNumbers(Convert.ToInt32(dataRowTPNeeds[0]["NeedId"]), Convert.ToInt32(dataRowTPNeeds[0]["NeedNumber"]), ref dataSetTreatmentPlanHRM);
                                    ChangeInterventionNumber(Convert.ToInt32(dataRowTPNeeds[0]["NeedId"]), Convert.ToInt32(dataRowTPNeeds[0]["NeedNumber"]), ref dataSetTreatmentPlanHRM);
                                }
                            }
                        }
                        //Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
                        //(controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
                        //PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
                        CreateGoal();
                        PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
                    }
                }
            }
        }
        finally
        {
            rowSeparator = null;
            separatorCol = null;
            dataRowTPNeeds = null;
            arrayColCollection = null;
            dataSetTreatmentPlanHRM = null;
        }
    }

    /// <summary>
    /// <Description>Handle Renumber Interventions</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>6th Oct,2009</CreatedOn>
    /// </summary>
    private void ChangeInterventionNumber(int needId, int number, ref DataSet dataSetTreatmentPlan)
    {
        DataRow[] dataRowsTPIntervention = null;
        string interVentionNumber = string.Empty;
        try
        {
            dataRowsTPIntervention = dataSetTreatmentPlan.Tables["TPInterventionProcedures"].Select("NeedID=" + needId);
            for (int interVentionCount = 0; interVentionCount < dataRowsTPIntervention.Length; interVentionCount++)
            {
                dataRowsTPIntervention[interVentionCount].BeginEdit();
                interVentionNumber = dataRowsTPIntervention[interVentionCount]["InterventionNumber"].ToString();
                dataRowsTPIntervention[interVentionCount]["InterventionNumber"] = number.ToString() + interVentionNumber.Substring(interVentionNumber.IndexOf("."));// .Replace(CurrentNumber.ToString() + ".",NeedNumber);
                dataRowsTPIntervention[interVentionCount].EndEdit();
            }
        }
        finally
        {
            dataRowsTPIntervention = null;
        }
    }


    /// <summary>
    /// <Description>Perform logic for calculate Procedure Intervention</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>08 Oct,2009</CreatedOn>
    /// </summary>
    private void CalculateProceduresfromInterventions()
    {
        DataSet dataSetGrouping = null;
        DataRow[] dataRowTPProcedures = null;
        DataRow[] dataRowTPInterventionProcedure = null;
        DataRow[] dataRowProviders = null;
        DataRow[] dataRowAuthorizationCodeName = null;
        string strResult = null;
        string tpProcedureIds = "";
        string agencyName = string.Empty;
        SHS.UserBusinessServices.Document objectDocuments = null;
        bool calculateOrNot = false;
        try
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetTreatmentPlanHRM != null)
                {
                    //Perform Check for TPProcedures
                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPProcedures") && dataSetTreatmentPlanHRM.Tables["TPProcedures"].Rows.Count > 0)
                    {
                        dataRowTPProcedures = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("(Isnull(RecordDeleted,'N')<>'Y') and DocumentVersionId<>" + BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentId);
                        if (dataRowTPProcedures.Length > 0)
                        {
                            for (int procedureCount = 0; procedureCount < dataRowTPProcedures.Length; procedureCount++)
                            {
                                tpProcedureIds += dataRowTPProcedures[procedureCount]["TPProcedureId"].ToString() + ",";
                            }
                        }
                    }
                    dataSetGrouping = new DataSet("Grouping");
                    if (dataSetTreatmentPlanHRM.Tables.Contains("DataTableGroup"))
                    {
                        dataSetTreatmentPlanHRM.Tables["DataTableGroup"].Clear();
                    }
                    //Peform Check for TPInterventionProcedure
                    if (dataSetTreatmentPlanHRM.Tables.Contains("TPInterventionProcedures") && dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Count > 0)
                    {
                        dataRowTPInterventionProcedure = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("(ISNULL(RecordDeleted,'N')<>'Y')  and  AuthorizationCodeId Is not Null");
                        foreach (DataRow rowTPInterventionProcedure in dataRowTPInterventionProcedure)
                        {
                            //Case when Agency is selected in that Case SiteId is null
                            //So we have to set the default value for that
                            if (rowTPInterventionProcedure["SiteId"] == DBNull.Value) { rowTPInterventionProcedure["SiteId"] = -1; }

                            if (Convert.ToInt32(rowTPInterventionProcedure["SiteId"].ToString()) != -2)
                            {
                                AddGroup(dataSetTreatmentPlanHRM.Tables["DataTableGroup"], rowTPInterventionProcedure["AuthorizationCodeId"], rowTPInterventionProcedure["SiteId"]);

                                if (dataSetTreatmentPlanHRM.Tables["DataTableGroup"].Rows.Count > 0) //Special Case
                                {
                                    calculateOrNot = true;
                                }
                            }
                        }
                        if (calculateOrNot == true)
                        {
                            foreach (DataRow row in dataRowTPInterventionProcedure)
                            {
                                //Here No check for TPProcedureId 
                                if (Convert.ToInt32(row["SiteId"].ToString()) != -2)
                                {
                                    //Case when Agency is selected in that Case SiteId is null
                                    //So we have to set the default value for that
                                    if (row["SiteId"] == DBNull.Value) { row["SiteId"] = -1; }
                                    AddGroup(dataSetTreatmentPlanHRM.Tables["DataTableGroup"], row["AuthorizationCodeId"], row["SiteId"]);
                                    DataRow[] _drCollection = dataSetTreatmentPlanHRM.Tables["DataTableGroup"].Select("AuthorizationCodeId=" + row["AuthorizationCodeId"].ToString() + " and SiteId=" + row["SiteId"].ToString());
                                    if (_drCollection.Length > 0)
                                    {
                                        _drCollection[0].BeginEdit();
                                        _drCollection[0]["TpProcedureId"] = row["TpProcedureId"];
                                        _drCollection[0].EndEdit();
                                    }
                                }
                            }
                        }
                        foreach (DataRow rowDataTableGroup in dataSetTreatmentPlanHRM.Tables["DataTableGroup"].Rows)
                        {
                            rowDataTableGroup.BeginEdit();
                            dataRowProviders = SharedTables.ApplicationSharedTables.Providers.Select("SiteId=" + Convert.ToInt32(rowDataTableGroup["SiteId"]) + " and isnull(RecordDeleted,'N')<>'Y'");

                            if (dataRowProviders.Length > 0)
                            {
                                rowDataTableGroup["ProviderName"] = dataRowProviders[0]["ProviderName"];
                            }
                            else
                            {
                                //Get the Agency Name If Provider name is not avail
                                //Need to add agencyName
                                //_agencyName = ObjTPProcedure.GetAgencyName();
                                objectDocuments = new SHS.UserBusinessServices.Document();
                                agencyName = objectDocuments.GetAgencyName();
                                rowDataTableGroup["providername"] = agencyName;
                            }
                            dataRowAuthorizationCodeName = SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("AuthorizationCodeId=" + Convert.ToInt32(rowDataTableGroup["AuthorizationCodeId"]) + " and Isnull(RecordDeleted,'N')<>'Y'");
                            if (dataRowAuthorizationCodeName.Length > 0)
                            {
                                rowDataTableGroup["AuthorizationCodeName"] = dataRowAuthorizationCodeName[0]["AuthorizationCodeName"];
                            }
                            else
                            {
                                rowDataTableGroup["AuthorizationCodeName"] = string.Empty;
                            }
                            rowDataTableGroup["ProviderProcedure"] = rowDataTableGroup["AuthorizationCodeName"].ToString().TrimEnd() + ", " + rowDataTableGroup["ProviderName"].ToString().TrimEnd();
                            rowDataTableGroup["ProviderProceduresId"] = rowDataTableGroup["AuthorizationCodeId"] + "," + rowDataTableGroup["SiteId"];
                            rowDataTableGroup.EndEdit();
                        }
                    }
                    if (dataSetTreatmentPlanHRM.Tables["DataTableGroup"].Rows.Count > 0)
                    {
                        strResult = "success"; //Allow to Open the HRMTreatmentPlanProceudre Pop Up
                    }
                    else
                    {
                        strResult = "fail";  //Not Allowed to Open the  HRMTreatmentPlanProceudre Pop Up                  
                    }
                    PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(strResult.Trim()));

                }
            }
        }

        finally
        {
            //Memory Deallocation 
            dataSetGrouping = null;
            dataRowTPProcedures = null;
            dataRowTPInterventionProcedure = null;
            dataRowProviders = null;
            dataRowAuthorizationCodeName = null;
            strResult = null;
            objectDocuments = null;
        }

    }


    /// <summary>
    /// <Description></Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>09 Oct,2009</CreatedOn>
    /// </summary>
    /// <param name="group"></param>
    /// <param name="keys"></param>
    private void AddGroup(DataTable group, params object[] keys)
    {
        if (group.Rows.Find(keys) == null)
        {
            group.Rows.Add(keys);

        }

    }

    /// <summary>
    /// <Description>Method is used to calculate unit on the selection</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>09 Oct,2009</CreatedOn>
    /// </summary>
    private void DisplayUnitType()
    {
        string selectedValue = string.Empty;
        string strCodeName = string.Empty;
        string[] parameterCollection = null;
        DataSet dataSetAuthorization = null;
        DataSet dataSetTemp = null;
        DataView dataViewAuthorization = null;
        DataRow[] dataRowAuthorizationCodeName = null;
        DataRow[] dataRowGlobalCodes = null;
        Int32 unitTypeValue = 0;
        Int32 units = 0;
        string unitCounterText = string.Empty;
        try
        {
            // selectedValue = Request.Form["selectedValue"];
            char[] cSpilt = new char[1];
            cSpilt[0] = ',';
            if (Request.Form["UnitCount"] != null)
            {
                parameterCollection = Request.Form["UnitCount"].Split(cSpilt);
            }
            dataRowAuthorizationCodeName = SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("Active='Y'", "AuthorizationCodeName");
            dataSetAuthorization = new DataSet();
            dataSetAuthorization.EnforceConstraints = false;//Need to Check Anuj forcefully  enforced constraints false.
            dataSetAuthorization.Merge(dataRowAuthorizationCodeName);

            dataViewAuthorization = new DataView(dataSetAuthorization.Tables[0]);

            dataViewAuthorization.RowFilter = "AuthorizationCodeId=" + Convert.ToInt32(parameterCollection[0]);
            if (dataViewAuthorization.Count > 0 && Convert.ToInt32(parameterCollection[0]) != -1 && Convert.ToInt32(parameterCollection[0]) != 0)
            {
                if (dataViewAuthorization[0]["UnitType"] != null && dataViewAuthorization[0]["UnitType"] != System.DBNull.Value)
                    unitTypeValue = Convert.ToInt32(dataViewAuthorization[0]["UnitType"]);
                if (dataViewAuthorization[0]["Units"] != null && dataViewAuthorization[0]["Units"] != System.DBNull.Value)
                    units = Convert.ToInt32(dataViewAuthorization[0]["Units"]);

            }

            dataRowGlobalCodes = SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitTypeValue);

            dataSetTemp = new DataSet();

            if (dataRowGlobalCodes.Length > 0)
            {
                dataSetTemp.Merge(dataRowGlobalCodes);

                if (unitTypeValue == 120 || unitTypeValue == 110)
                {
                    // modified by Piyush on 6th March 2007 as per comment on "3/2/2007 8:08:07 AM " on task 390
                    strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    strCodeName = strCodeName.Substring(0, 6);
                    if (units != 1)
                        unitCounterText = "(1 Unit = " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                    else
                        unitCounterText = "(1 Unit = " + units + " " + strCodeName + ")";
                }
                else if (unitTypeValue == 124)
                {

                    strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    strCodeName = strCodeName.Substring(0, 9);
                    if (units != 1)
                        unitCounterText = "(1 Unit =  " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                    else
                        unitCounterText = "(1 Unit =  " + units + " " + strCodeName + ")";
                }
                else
                {
                    unitCounterText = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                }
            }

            PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(unitCounterText));
        }
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        finally
        {

            selectedValue = string.Empty;
            strCodeName = string.Empty;
            parameterCollection = null;
            dataSetAuthorization = null;
            dataSetTemp = null;
            dataViewAuthorization = null;
            dataRowAuthorizationCodeName = null;
            dataRowGlobalCodes = null;
        }
    }


    /// <summary>
    /// <Description>Perform check wheather Episode number exists or not</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>Oct 10th, 2009</CreatedOn>
    /// </summary>
    private void CheckEpisodeNumber()
    {
        Int32 maxEpisodeNumber = 0;
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //try
        //{
        maxEpisodeNumber = BaseCommonFunctions.GetEpisodeNumber(BaseCommonFunctions.ApplicationInfo.Client.ClientId);

        if (maxEpisodeNumber == 0)
        {
            PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl("fail"));
        }
        else
        {
            PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl("success"));
        }
        //}
        //finally
        //{
        // }
    }


    /// <summary>
    /// <Description>Perform check Is clientNeed is associated with CustomTPNeedClientNeeds or not</Description>
    /// <Atuhor>Vikas Vyas</Atuhor>
    /// <CreatedOn>Nov 10th,2009</CreatedOn>
    /// </summary>
    private void CheckClientneedAssociation()
    {
        DataRow[] dataRowCheckAssociation = null;
        DataRow[] dataRowCustomClientNeeds = null;
        string strHTML = string.Empty;
        try
        {

            //using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatmentPlanHRM"] as DataSet)
            {
                if (dataSetTreatmentPlanHRM != null)
                {
                    if (dataSetTreatmentPlanHRM.Tables.Count > 0)
                    {
                        if (dataSetTreatmentPlanHRM.Tables.Contains("CustomTPNeedsClientNeeds") && dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].Rows.Count > 0)
                        {
                            dataRowCheckAssociation = dataSetTreatmentPlanHRM.Tables["CustomTPNeedsClientNeeds"].Select("ClientNeedId=" + Convert.ToInt32(Request.QueryString["ClientNeedId"]) + " and IsNull(RecordDeleted,'N')<>'Y'");

                            if (dataRowCheckAssociation.Length > 0)
                            {
                                strHTML = Request.QueryString["ClientNeedId"] + "$$" + "fail";
                                PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(strHTML));
                            }
                            else
                            {
                                strHTML = Request.QueryString["ClientNeedId"] + "$$" + "success";
                                PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(strHTML));
                            }
                        }
                        else if (dataSetTreatmentPlanHRM.Tables.Contains("CustomClientNeeds") && dataSetTreatmentPlanHRM.Tables["CustomClientNeeds"].Rows.Count > 0)
                        {
                            dataRowCustomClientNeeds = dataSetTreatmentPlanHRM.Tables["CustomClientNeeds"].Select("ClientNeedId=" + Convert.ToInt32(Request.QueryString["ClientNeedId"]) + " and IsNull(RecordDeleted,'N')<>'Y'");
                            if (dataRowCustomClientNeeds.Length > 0)
                            {
                                strHTML = Request.QueryString["ClientNeedId"] + "$$" + "success";
                                PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(strHTML));
                            }
                            else
                            {
                                strHTML = Request.QueryString["ClientNeedId"] + "$$" + "fail";
                                PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(strHTML));
                            }

                        }
                    }
                }
            }
        }
        finally
        {
            dataRowCheckAssociation = null;
        }
    }





    /// <summary>
    /// <Description>Change value in there respective Datatable</Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>07/09/2009</CreatedOn>
    /// </summary>
    private void EditClientNeedValue()
    {
        DataRow[] dataRowTreatmentPlanHRM = null;
        try
        {
            //Get DataSet from Base Common Function
            using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatmentPlanHRM"] as DataSet)
            {
                //Perform check for null
                if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                {
                    //Perform Table Contain Check 
                    if (dataSetTreatmentPlanHRM.Tables.Contains(Request.Form["tableName"]))
                    {
                        if (dataSetTreatmentPlanHRM.Tables[Request.Form["tableName"]].Rows.Count > 0)  //Perform Row Count Check
                        {
                            dataRowTreatmentPlanHRM = dataSetTreatmentPlanHRM.Tables[Request.Form["tableName"]].Select(Request.Form["keyFieldName"] + "=" + Request.QueryString["keyValue"]);
                            if (dataRowTreatmentPlanHRM.Length > 0)
                            {
                                dataRowTreatmentPlanHRM[0].BeginEdit();
                                if (Request.Form["controlValue"] != "")
                                {
                                    if (Request.Form["fieldName"] == "NeedName")
                                    {
                                        if (Request.Form["controlValue"].Length > 45)
                                        {
                                            dataRowTreatmentPlanHRM[0][Request.Form["fieldName"]] = Request.Form["controlValue"].Substring(0, 48).TrimEnd(); // BaseCommonFunctions.cutText(Request.Form["controlValue"],48);
                                        }
                                        else
                                        {
                                            dataRowTreatmentPlanHRM[0][Request.Form["fieldName"]] = Request.Form["controlValue"];
                                        }
                                    }
                                    else
                                    {
                                        dataRowTreatmentPlanHRM[0][Request.Form["fieldName"]] = Request.Form["controlValue"];
                                    }

                                }
                                //else
                                //{
                                //    dataRowTreatmentPlanHRM[0][Request.Form["fieldName"]] = DBNull.Value;
                                //}
                                dataRowTreatmentPlanHRM[0].EndEdit();
                                dataSetTreatmentPlanHRM.Merge(dataRowTreatmentPlanHRM);
                                Session["dataSetTreatmentPlanHRM"] = dataSetTreatmentPlanHRM;
                                // BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Merge(dataRowTreatmentPlanHRM);
                            }
                        }
                    }
                }
            }
        }
        finally
        {
            dataRowTreatmentPlanHRM = null;
        }
    }

    /// <summary>
    /// <Description>Calculate units on the basis of </Description>
    /// <Author>Vikas Vyas</Author>
    /// <CreatedOn>17/11/2009</CreatedOn>
    /// </summary>
    private void UnitCalculation()
    {
        DateTime startDate;
        DateTime endDate;
        TimeSpan days;
        int unitDays = 0;
        int frequencyType = 0;
        string procedureUnits = string.Empty;
        string totalUnitRequested = string.Empty;
        //try catch finally block commented by shifali in ref to task# 950 on 5 june,2010
        //try
        //{
        startDate = Convert.ToDateTime(Request.Form["startDate"]);
        endDate = Convert.ToDateTime(Request.Form["endDate"]);
        days = (endDate - startDate);
        unitDays = Convert.ToInt32(days.TotalDays) + 1;

        frequencyType = Convert.ToInt32(Request.Form["frequencyType"]);
        procedureUnits = Request.Form["procedureUnits"];
        if (unitDays != 0)
        {
            if (frequencyType == 160 && procedureUnits != string.Empty) //for daily
            {
                totalUnitRequested = (Convert.ToInt32(Convert.ToDouble(procedureUnits)) * unitDays).ToString();
            }
            else if (frequencyType == 161 && procedureUnits != string.Empty) //for 2 days/week
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 7.0 * unitDays).ToString();
            }
            else if (frequencyType == 162 && procedureUnits != string.Empty) //for 3 days/week
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 3.0 / 7.0 * unitDays).ToString();
            }
            else if (frequencyType == 163 && procedureUnits != string.Empty) //for 4 days/week
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 4.0 / 7.0 * unitDays).ToString();
            }
            else if (frequencyType == 164 && procedureUnits != string.Empty) //for 5 days/week
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 5.0 / 7.0 * unitDays).ToString();
            }
            else if (frequencyType == 165 && procedureUnits != string.Empty) //for 5 days/week
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 6.0 / 7.0 * unitDays).ToString();
            }
            else if (frequencyType == 166 && procedureUnits != string.Empty) //for weekly
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 7.0 * unitDays).ToString();
            }
            else if (frequencyType == 167 && procedureUnits != string.Empty) //for every two weeks
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 14.0 * unitDays).ToString();
            }
            else if (frequencyType == 168 && procedureUnits != string.Empty) //for monthly
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 30.0 * unitDays).ToString();
            }
            else if (frequencyType == 169 && procedureUnits != string.Empty) //for twice a month
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 30.0 * unitDays).ToString();
            }
            else if (frequencyType == 170 && procedureUnits != string.Empty) //for twice a month
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 28.0 * unitDays).ToString();
            }
            else if (frequencyType == 171 && procedureUnits != string.Empty) //for quarterly
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 90.0 * unitDays).ToString();
            }
            else if (frequencyType == 172 && procedureUnits != string.Empty) //for  twice a quarterly
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 90.0 * unitDays).ToString();
            }
            else if (frequencyType == 173 && procedureUnits != string.Empty) //for  twice a quarterly
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 60.0 * unitDays).ToString();
            }
            else if (frequencyType == 174 && procedureUnits != string.Empty) //for  twice a year
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 365.0 * unitDays).ToString();
            }
            else if (frequencyType == 175 && procedureUnits != string.Empty) //for  once a year
            {
                totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 365.0 * unitDays).ToString();
            }
            else if (frequencyType == 176 && procedureUnits != string.Empty) //for only  once
            {
                totalUnitRequested = procedureUnits;
            }
            PlaceHolderControlAssociatedNeeds.Controls.Add(new LiteralControl(totalUnitRequested));
        }
        //}
        //finally
        //{

        //}

    }

    private void RecreateTxPlan()
    {
        Control controlHRMTxPlan = LoadControl("~/ActivityPages/Client/Detail/TreatmentPlanHRM/HRMTxPlan.ascx");
        (controlHRMTxPlan as SHS.BaseLayer.ActivityPages.DataActivityTab).BindControls();
        PlaceHolderControlAssociatedNeeds.Controls.Add(controlHRMTxPlan);
    }

    private void RecreateTxPlanAfterSave()
    {
        CreateGoal();
        PlaceHolderControlAssociatedNeeds.Controls.Add(PanelPeriodicReview);
    }

    protected void GridViewProcedures_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            HiddenField HiddenFieldTPProcedureId = e.Row.FindControl("HiddenFieldTPProcedure") as HiddenField;
            RadioButton radioButtonTPProcedure = e.Row.FindControl("RadioButtonTPProcedure") as RadioButton;
            Image imageDelete = e.Row.FindControl("imageDelete") as Image;
            #region Pass Parameter on the basis of TPProcedureId
            using (DataSet dataSetTreatmentPlanHRM = Session["dataSetTreatPlanHRMTPProcedure"] as DataSet)
            {
                DataRow[] dataRowTPProcedure = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and TPProcedureId=" + Convert.ToInt32(HiddenFieldTPProcedureId.Value));
                //Find Value related to all control
                Int32 siteId = 0;
                if (dataRowTPProcedure[0]["SiteId"] == DBNull.Value) { siteId = -1; }
                else { siteId = Convert.ToInt32(dataRowTPProcedure[0]["SiteId"]); }

                int authorizationCodeId = 0;
                if (dataRowTPProcedure[0]["AuthorizationCodeId"] != DBNull.Value) { authorizationCodeId = Convert.ToInt32(dataRowTPProcedure[0]["AuthorizationCodeId"]); }

                string selectedValueProviderSite = authorizationCodeId.ToString() + "," + siteId.ToString();

                string units = Convert.ToString(dataRowTPProcedure[0]["Units"]);

                string startDate = Convert.ToDateTime(dataRowTPProcedure[0]["StartDate"]).ToString("MM/dd/yyyy");

                string endDate = Convert.ToDateTime(dataRowTPProcedure[0]["EndDate"]).ToString("MM/dd/yyyy");

                string frequencyType = Convert.ToString(dataRowTPProcedure[0]["FrequencyType"]);

                string totalUnits = Convert.ToString(dataRowTPProcedure[0]["TotalUnits"]);

                //Program
                DataRow dataRowTPGeneral = dataSetTreatmentPlanHRM.Tables["TPGeneral"].Rows[0];

                string program = Convert.ToString(dataRowTPGeneral["Assigned"]);

                string authorizationRequesterComment = Convert.ToString(dataRowTPGeneral["AuthorizationRequestorComment"]);

                //End

                radioButtonTPProcedure.Attributes.Add("onclick", "return radioClickTPProcedure(this " + ", '" + HiddenFieldTPProcedureId.Value + "', '" + selectedValueProviderSite + "','" + units + "','" + startDate + "','" + endDate + "','" + frequencyType + "','" + totalUnits + "','" + program + "','" + authorizationRequesterComment + "','" + authorizationCodeId + "','" + siteId + "')");// "," + authorizationRequesterComment + ")");


            }


            #endregion

            #region Delete Event
            imageDelete.Attributes.Add("onclick", " return hadleTPProcedureDelete(" + HiddenFieldTPProcedureId.Value + ")");
            #endregion


        }

    }


    protected void GridViewProcedureAssignProcedure_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //LinkButton LinkButtonTPProcedure = e.Row.FindControl("LinkButtonProcedureLink") as LinkButton;
            //LinkButtonTPProcedure.Attributes.Add("onclick", "return AssignProcedureClickFromLink(" + LinkButtonTPProcedure.Text + ")");
            Button ButtonProcedureLink = e.Row.FindControl("ButtonProcedureLink") as Button;
            ButtonProcedureLink.Attributes.Add("onclick", "return AssignProcedureClickFromLink(" + ButtonProcedureLink.Text + ")");

        }
    }
}
