﻿// For Initial Assessment Tab

var CheckBoxDDPopulation = null;
var CheckBoxSAPopulation = null;
var CheckBoxMHPopulation = null;
var RadioButtonAdultorChild = null;
var SavetabControl = "";
var flag = 0;
var Uncopeflag = 0;
var Crafftflag = 0;
var _needlistHtml = "";
var _currentSelectedTab = null;
var _ChangeSelectedIndexAfterNeedInsertion = false;
var checkLevelBehavior = "";
var UncopeCheck = false;
var UncopeCountGlobal = 0;
var _DeleteAssessmentHrmNeeds = false;

var AssessmentTypeI = null;
var AssessmentTypeU = null;
var AssessmentTypeA = null;
var AssessmentTypeAutsim = null;
var NeedName = "";
var NeedDescription = "";

var _reinitializeTabs = false;
var tabobject = null;
var dialogResult = '';
var CafasUrl = '';
var executeChangeEventWithScript = null;

var isPopulationChecked = false;
var CAFASFlag = '';
var previousAssessmentType = '';
var AgencyName = '';
var ScreenCode = 0;

function ValidateCustomPageEventHandler() {

    //AssessmentType(AutoSaveXMLDom);

    var DDPopulation = $('[id$=CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation]')[0];
    var SAPopulation = $('[id$=CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation]')[0];
    var MHPopulation = $('[id$=CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation]')[0];

    var TypeofAssessment;
    AssessmentTypeI = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]');
    AssessmentTypeU = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]');
    AssessmentTypeA = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]');

    if (AssessmentTypeI.length > 0) {

        if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]')[0].checked) {
            AssessmentTypeI.checked = true; TypeofAssessment = 'I';
            SetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'AssessmentType', TypeofAssessment, AutoSaveXMLDom[0]);
        }
    }
    if (AssessmentTypeU.length > 0) {
        if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]')[0].checked) {
            AssessmentTypeU.checked = true; TypeofAssessment = 'U';
            SetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'AssessmentType', TypeofAssessment, AutoSaveXMLDom[0]);
        }
    }
    if (AssessmentTypeA.length > 0) {
        if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]')[0].checked) {
            AssessmentTypeA.checked = true; TypeofAssessment = 'A';
            SetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'AssessmentType', TypeofAssessment, AutoSaveXMLDom[0]);
        }
    }


    else {
        var AssessmentType;
        if (AutoSaveXMLDom != "" && AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0) {
            var CustomDocumentMHAssessments = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            if (CustomDocumentMHAssessments[0].selectNodes("AssessmentType").length > 0) {
                AssessmentType = CustomDocumentMHAssessments[0].selectNodes("AssessmentType")[0].text;
            }
        }
        if (AssessmentType != "") { }
        else {
            ShowHideErrorMessage('Please select any option from Initial,Update or Annual', 'true');
            return false;
        }
    }

    if (DDPopulation != undefined && SAPopulation != undefined && MHPopulation != undefined) {
        if (DDPopulation.checked || SAPopulation.checked || MHPopulation.checked) {

        }
        else {
            ShowHideErrorMessage('Please select at least one option from DD,SUD, MH', 'true');
            return false;
        }
    }
    var disablePHQ9Tabcalling = 'N';
    if ($('[id$=CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation]')[0].checked == true) { disablePHQ9Tabcalling = 'Y'; }
    else {
        var AssessmentXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
        if (AssessmentXml.length > 0) {
            var DDNode = AssessmentXml[0].selectNodes("ClientInDDPopulation");
            if (DDNode.length > 0) {
                var DDtext = DDNode[0].text;
                if (DDtext == 'Y') {
                    disablePHQ9Tabcalling = "Y";
                }
            }
        }
    }
    var PHQ9_tab = tabobject.findTabByText('PHQ9');
    var AdultOrChildXML = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
    if (AdultOrChildXML.length > 0) {
        var AdultOrChildDD = AdultOrChildXML[0].selectNodes("AdultOrChild");
    }
    if (AdultOrChildDD.length > 0) {
        var AdultOrChildText = AdultOrChildDD[0].text;
    }
    if (disablePHQ9Tabcalling == 'Y') { PHQ9_tab.set_visible(false); }
    else if (disablePHQ9Tabcalling == 'N' && AdultOrChildText == 'A') {
        PHQ9ValidateCustomPageEventHandler();
    }
    PHQAValidateCustomPageEventHandler();

}
function PHQAValidateCustomPageEventHandler() {
    if ($('#CheckBox_PHQ9ADocuments_ClientDeclinedToParticipate').attr('checked') == true) {
        $('#Textbox_PHQ9ADocuments_PerformedDate').removeAttr('required');
        $('#Textbox_PHQ9ADocuments_PerformedTime').removeAttr('required');
    }
    else {
        $('#Textbox_PHQ9ADocuments_PerformedDate').attr('required', 'required');
        $('#Textbox_PHQ9ADocuments_PerformedTime').attr('required', 'required');
    }
  }
function PHQ9ValidateCustomPageEventHandler() {

    DepressionSeverityPHQ9();
    var SeverityValue = $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').val();

    var score = $('[id$=Textbox_PHQ9Documents_TotalScore]').val();
    if (SeverityValue != undefined) {
        CreateAutoSaveXml("PHQ9Documents", "DepressionSeverity", SeverityValue);
    }
    if (score != undefined) {
        CreateAutoSaveXml("PHQ9Documents", "TotalScore", score);
    }
    if ($('#CheckBox_PHQ9Documents_ClientDeclinedToParticipate').attr('checked') == true) {
        $('#Textbox_PHQ9Documents_PerformedDate').removeAttr('required');
        $('#Textbox_PHQ9Documents_PerformedTime').removeAttr('required');
    }
    else {
        $('#Textbox_PHQ9Documents_PerformedDate').attr('required', 'required');
        $('#Textbox_PHQ9Documents_PerformedTime').attr('required', 'required');
    }
  }
function DeleteGridRowValidation(primaryKeyValue, primaryKey, divGridName, tableName, customGridTableName) {
   
    return true;
}

function DiableRadioAfterUpdate(dom) {
    try {

        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').attr("disabled", true);
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').attr("disabled", true);
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').attr("disabled", true);
       
        if (dom.length > 0) {
            var CheckBoxDom = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            documentRowFilterCheckBoxDom = 'AssessmentType';
            docummentRowDomFilterCheckBoxDom = $(documentRowFilterCheckBoxDom, CheckBoxDom[0]);
            if (docummentRowDomFilterCheckBoxDom.length > 0) {
                var CheckValue = CheckBoxDom[0].selectNodes("AssessmentType")[0].text;
                switch (CheckValue) {
                    case 'I':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').attr("checked", true);
                        break;
                    case 'U':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').attr("checked", true);
                        break;
                    case 'A':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').attr("checked", true);
                        break;
                                                                      
                    default:
                }
            }
        }
    }
    catch (ex) {
        throw ex;
    }
}

function SelectCheckBoxExist(dom) {
 
    try {
        if (dom.length > 0) {
            var CheckBoxDom = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            documentRowFilterCheckBoxDom = 'AssessmentType';
            docummentRowDomFilterCheckBoxDom = $(documentRowFilterCheckBoxDom, CheckBoxDom[0]);
            if (docummentRowDomFilterCheckBoxDom.length > 0) {
                var CheckValue = CheckBoxDom[0].selectNodes("AssessmentType")[0].text;

                switch (CheckValue) {
                    case 'I':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').attr("checked", true);
                        break;
                    case 'U':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').attr("checked", true);
                        break;
                    case 'A':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').attr("checked", true);
                        break;
                                                                              
                    default:
                }
            }
            var CheckBoxDD = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            documentRowFilterCheckBoxDD = 'ClientInDDPopulation';
            docummentRowDomFilterCheckBoxDD = $(documentRowFilterCheckBoxDD, CheckBoxDD[0]);
            if (docummentRowDomFilterCheckBoxDD.length > 0) {
                var CheckValueDD = CheckBoxDD[0].selectNodes("ClientInDDPopulation")[0].text;
                if (CheckValueDD == 'Y' && $("#CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation").length > 0) {
                    $("#CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation")[0].checked = true;
                }
                flag = 2;

            }

           
            var CheckBoxSA = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            documentRowFilterCheckBoxSA = 'ClientInSAPopulation';
            docummentRowDomFilterCheckBoxSA = $(documentRowFilterCheckBoxSA, CheckBoxSA[0]);
            if (docummentRowDomFilterCheckBoxSA.length > 0) {
                var CheckValueSA = CheckBoxSA[0].selectNodes("ClientInSAPopulation")[0].text;
                if (CheckValueSA == 'Y' && $("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation").length > 0) {
                    $("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation")[0].checked = true;
                }
                flag = 2;


            }

            var CheckBoxMM = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            documentRowFilterCheckBoxMM = 'ClientInMHPopulation';
            docummentRowDomFilterCheckBoxMM = $(documentRowFilterCheckBoxMM, CheckBoxMM[0]);
            if (docummentRowDomFilterCheckBoxMM.length > 0) {
                var CheckValueMH = CheckBoxMM[0].selectNodes("ClientInMHPopulation")[0].text;
                if (CheckValueMH == 'Y' && $("#CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation").length > 0) {
                    $("#CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation")[0].checked = true;
                }
                flag = 2;


            }
        }
    }
    catch (ex) {
        throw ex;
    }
}

//Description:Function is used to maintain telerik control tabs


function CheckInitilization(action) {
   
    if (action == pageActionEnum.New || action == "") {

        if (AutoSaveXMLDom.length > 0) {
            var CheckBoxDom = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            documentRowFilterCheckBoxDom = 'AssessmentType';
            docummentRowDomFilterCheckBoxDom = $(documentRowFilterCheckBoxDom, CheckBoxDom[0]);

            if (docummentRowDomFilterCheckBoxDom.length > 0) {
                var CheckValue = CheckBoxDom[i].selectNodes("AssessmentType")[0].text;
                switch (CheckValue) {
                    case 'I':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').attr("checked", true);
                        break;
                    case 'U':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').attr("checked", true);
                        break;
                    case 'A':
                        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').attr("checked", true);
                        break;
                                                                               
                    default:
                }
            }
        }
    }

}

function ModalPopupWindowClosed(ModelPopUpName) {
    if (ModelPopUpName.indexOf('###StartAssociateNeedPopUp###') >= 0) {
        SetFieldValueInCtrl(ModelPopUpName);
    }
    else if (ModelPopUpName.indexOf("###StartAddNeedsPopUp###") >= 0) {
        RefreshNeedsTemplate(ModelPopUpName);

    }
   
    if (window.frames["iframeWindowDialog"]._popupUpdateClicked == true) {
        
        dialogResult = window.frames["iframeWindowDialog"].GetScreenXML();
    }
    else {
        dialogResult = "";
        return;
    }
}

//To createAutoSave XML after modal poppup closed  
function PopUpCloseCallBackComplete() {
    var guardianFirstName = "",guardianLastName = "", guardianAddress = "", guardianPhone = "",guardianCity="",guardianState="",guardianZipcode="",relationWithGuardian="", guardianInformation = "", GuardianTypeText = "";
   
    if (dialogResult != "") {
        
        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianLastName').length > 0) {
            guardianLastName = $('CustomDocumentMHAssessments', dialogResult).find('GuardianLastName').text();
            guardianInformation = guardianLastName + ", ";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianLastName', guardianLastName);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianLastName', '');
        }
        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianFirstName').length > 0) {
            guardianFirstName = $('CustomDocumentMHAssessments', dialogResult).find('GuardianFirstName').text();
            guardianInformation = guardianInformation + guardianFirstName + "\n";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianFirstName', guardianFirstName);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianFirstName', '');
        }
      
        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianAddress').length > 0) {
            guardianAddress = $('CustomDocumentMHAssessments', dialogResult).find('GuardianAddress').text();
            guardianInformation = guardianInformation + guardianAddress + "\n";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianAddress', guardianAddress);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianAddress', '');
        }
       
        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianCity').length > 0) {
            guardianCity = $('CustomDocumentMHAssessments', dialogResult).find('GuardianCity').text();
            guardianInformation = guardianInformation + guardianCity + " ,";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianCity', guardianCity);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianCity', '');
        }

        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianState').length > 0) {
            guardianState = $('CustomDocumentMHAssessments', dialogResult).find('GuardianState').text();
           guardianInformation = guardianInformation + guardianState + " ";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianState', guardianState);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianState', '');
        }
        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianStateText').length > 0) {
            GuardianStateText = $('CustomDocumentMHAssessments', dialogResult).find('GuardianStateText').text();
          //  guardianInformation = guardianInformation + GuardianStateText + " ";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianStateText', GuardianStateText);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianStateText', '');
        }
        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianZipcode').length > 0) {
            guardianZipcode = $('CustomDocumentMHAssessments', dialogResult).find('GuardianZipcode').text();
            guardianInformation = guardianInformation + guardianZipcode + "\n";
            SetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'GuardianZipcode', guardianZipcode, AutoSaveXMLDom[0]);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianZipcode', '');
        }


        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianPhone').length > 0) {
            guardianPhone = $('CustomDocumentMHAssessments', dialogResult).find('GuardianPhone').text();
            guardianInformation = guardianInformation + guardianPhone + "\n";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianPhone', guardianPhone);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianPhone', '');
        }
       
        

        if ($('CustomDocumentMHAssessments', dialogResult).find('RelationWithGuardian').length > 0) {
            relationWithGuardian = $('CustomDocumentMHAssessments', dialogResult).find('RelationWithGuardian').text();
           // guardianInformation = guardianInformation + relationWithGuardian + "\n";
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'RelationWithGuardian', relationWithGuardian);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'relationWithGuardian', '');
        }
        if ($('CustomDocumentMHAssessments', dialogResult).find('GuardianTypeText').length > 0) {
            GuardianTypeText = $('CustomDocumentMHAssessments', dialogResult).find('GuardianTypeText').text();
            guardianInformation = guardianInformation + GuardianTypeText;
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianTypeText', GuardianTypeText);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianTypeText', '');
        }

        $('#TextArea_CustomDocumentMHAssessments_GuardianAddressToDisplayOnly').val(guardianInformation);
    }
}


//Description:Function is used to Fill current client Values


function callUncope() {
    
    var SUAssessment_tab = tabobject.findTabByText('Substance Abuse');
    
    if (Uncopeflag == 0) {
        $('#RadioButton_CustomDocumentMHAssessments_UncopeApplicable_Y').attr("checked", false);
        $('#RadioButton_CustomDocumentMHAssessments_UncopeApplicable_N').attr("checked", false);
        Uncopeflag == 1;
        var UncopeXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
        if (UncopeXml.length > 0) {
            var UncopeNode = UncopeXml[0].selectNodes("UncopeApplicable");
            if (UncopeNode.length > 0) {
                var Uncopetext = UncopeXml[0].selectNodes("UncopeApplicable")[0].text;
                if (Uncopetext == 'Y') {
                    $('#RadioButton_CustomDocumentMHAssessments_UncopeApplicable_Y').attr("checked", true);
                    SetEnableDisableUncope('Y', AutoSaveXMLDom);
                    CreateInitializationImages(AutoSaveXMLDom);
                }
                else {
                    $('#RadioButton_CustomDocumentMHAssessments_UncopeApplicable_N').attr("checked", true);
                    SetEnableDisableUncope('N', AutoSaveXMLDom);
                }
            }
        }

    }
}



function BindPsychosocialstepper() {
    try {
       
        $("span[class*='ui-stepper']").stepper({ start: 0, min: 0, max: 30, step: 10 });

    }
    catch (ex) {
        throw ex;
    }
}



function ClearReInitializeAssessment(ControlID) {
    CSSRSHideAndShow();
    if (ValidateClientDateOfBirth() == false) {
        $("#" + ControlID).attr("checked", false);
        CreateAutoSaveXml('CustomDocumentMHAssessments', "AssessmentType", "");
        return false;
    }
    var action = "Clear";
    value = ShowMsgBox('Previous data will be cleared.', ConfirmationMessageCaption, MessageBoxButton.YesNo, MessageBoxIcon.Information, 'ConfirmMessageForCompleteDocumentOnOK(\'' + action + '\')', 'ConfirmMessageForCompleteDocumentOnCancel(\'' + ControlID + '\')');
}


//Purpose :Implement the coustom message box
function ConfirmMessageForCompleteDocumentOnCancel(ControlID) {
    try {
        var ControlObject = '';
       
        if (previousAssessmentType != "" && previousAssessmentType != undefined) {
            ControlObject = $("#" + previousAssessmentType);
            $('#' + previousAssessmentType).attr("checked", true);
        }
        else {
            ControlObject = $("#" + ControlID);
        }
        SaveAutoSaveXMLDom(ControlObject[0]);
      
        parent.HidePopupProcessing();
        return false;
    }
    catch (err) {
        LogClientSideException(err, 'Documents');
    }


}


//Purpose :Implement the coustom message box
function ConfirmMessageForCompleteDocumentOnOK(action) {
    try {
       
        var _filterData = "UnsavedChangeId=" + UnsavedChangeId;
        var AssessmentScreenType;
        if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]')[0].checked == true) {
            AssessmentScreenType = 'AssessmentScreenType=I';
        }
        else if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]')[0].checked == true) {
            AssessmentScreenType = 'AssessmentScreenType=U';
        }
        else if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]')[0].checked == true) {
            AssessmentScreenType = 'AssessmentScreenType=A';
        }
       
        else {
        }
              
        SetPreviousAssessmentType();
       
        var documentRow = AutoSaveXMLDom[0].childNodes[0].selectNodes("Documents");
        documentRowFilter = 'AuthorId';
        var docummentRowDomFilter = $(documentRowFilter, documentRow[0]);

        var _currentAuthorId = -1;
        if (docummentRowDomFilter.length > 0) {
            _currentAuthorId = documentRow[0].selectNodes("AuthorId")[0].text;
        }


        if (docummentRowDomFilterCheckBoxDom.length > 0) {
             _currentAuthorId = documentRow[0].selectNodes("AuthorId")[0].text;

        }
        _filterData = _filterData + '^' + AssessmentScreenType + '^ReIntialization=Y' + '^CurrentAuthorId=' + _currentAuthorId;
        _reinitializeTabs = true;
        LoadDocument(GetCurrentScreenID(), 5763, _filterData, CurrentHistoryId, GetRelativePath(), pageActionEnum.New, null, false, globalCurrentScreenTabIndex);
        CreateInitializationImages(AutoSaveXMLDom);

    }
    catch (err) {
        LogClientSideException(err, 'Documents');
    }


}

//Search a value in a array string.
findValueInArray = function(array, val) {
    var flag = false;
    $.each(array, function() {
        if (this == val) {
            flag = true;
        }
    });

    return flag;
}

//Description:Function is used to Call Slider windows


function BindUIstepper1() {
    try {
        $("span[class='ui-stepper']").stepper({ start: 0, min: 0, max: 7, step: 1 });
    }
    catch (ex) {
        throw ex;
    }
}


//Description:hide and show controls.


function hideTable() {
    if ($("#CheckBox_CustomDocumentMHAssessments_PrePlanSeparateDocument").is(":checked")) {
        $("#mainTable").hide();

    }
    else {
      
        $("#mainTable").show();
    }
}


function showGardianInfo() {
    $("#divGardianInfo").show();
}

//Description:Function is used to Initialize medication for PsychosocialChild and PsychosocialAdult

function IntializeMedication(radioButton, textArea, divMedication, tableName, colomnName) {
    var colomnValue = GetColumnValueInXMLNodeByKeyValue(tableName, 'DocumentVersionId', DocumentVersionId, colomnName, AutoSaveXMLDom[0]);
   
    $(radioButton, $("#" + ParentUserControlName)).attr("checked", true);


    if (colomnValue == 'Y') {
        $(textArea, $("#" + ParentUserControlName)).attr("disabled", false);
    }
    else {
        $(textArea, $("#" + ParentUserControlName)).attr("disabled", true);
    }
    $(textArea, $("#" + ParentUserControlName)).show();
    $(textArea, $("#" + ParentUserControlName)).val('');
    $('#listMedication').hide();
    $('#tablecomments').show();
    SetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'PsMedicationsComment', '', AutoSaveXMLDom[0]);
    $(divMedication, $("#" + ParentUserControlName)).show();
   
    var fnName = 'GetInitializeMedications';
    $.post(GetRelativePath() + "AjaxScript.aspx?functionName=" + fnName, function(result) { onSuccessIntializeMedication(result, textArea); }
       );
}

function AddToPHQ9Total() {
    var PHQ9Total = 0;
    $('select[PHQ9="PHQ9DD"]').each(function() {
        PHQ9Total = PHQ9Total + parseInt(($(this).find('option:selected').text().trim() != '' ? $(this).find('option:selected').text().trim().substr(0, 1) : 0));
    });
    $('td[PHQ9="PHQ9Total"]').html(PHQ9Total);
}

function onSuccessIntializeMedication(result, textArea) {
   
    $(textArea, $("#" + ParentUserControlName)).val(result);
    CreateAutoSaveXml('CustomDocumentMHAssessments', 'PsMedicationsComment', result);
}
//Description:Function is used to Initialize medication for PsychosocialChild and PsychosocialAdult


function DisappearMedication(textArea, divMedication) {
    $(textArea, $("#" + ParentUserControlName)).removeAttr("disabled", true);
    $(textArea, $("#" + ParentUserControlName)).show();
    $(divMedication, $("#" + ParentUserControlName)).show();
    $('#listMedication').show();
    $('#tablecomments').hide();
}


//Description:Function is used to Initialize medication for PsychosocialChild and PsychosocialAdult

function DisableMedication(textArea, divMedication) {
    $(textArea, $("#" + ParentUserControlName)).attr("disabled", true);
    $(textArea, $("#" + ParentUserControlName)).hide();
    $(divMedication, $("#" + ParentUserControlName)).hide();
    $('#listMedication', $("#" + ParentUserControlName)).hide();
    $('#tablecomments').hide();
}


//Description:Function is used to disable MedicationsList in PsychosocialChild and PsychosocialAdult

function DisabledMedicationsList(radioButton, textArea) {
    if ($(radioButton, $("#" + ParentUserControlName)).is(":checked")) {
        $(textArea, $("#" + ParentUserControlName)).attr("disabled", true);
    }
    else {
        $(textArea, $("#" + ParentUserControlName)).removeAttr("disabled", true);
    }
}

//Description:Function is used to enable MedicationsList in PsychosocialChild and PsychosocialAdult

function EnabledMedicationsList(radioButton, textArea) {
    if ($(radioButton, $("#" + ParentUserControlName)).is(":checked")) {
        $(textArea, $("#" + ParentUserControlName)).removeAttr("disabled", true);
    }
    else {
        $(textArea, $("#" + ParentUserControlName)).attr("disabled", true);
    }
}


//Description:Function is used to Fill current client Values


function DivScaleMessageHide() {
    $('#DivScaleMessage').hide();
}


//DivFamilyHx

function FamilyHxDetails(DivFamilyHx, i, primaryKey, drugid, drugname, FamilyHistoty) {
    try {
      
        var FamilyHxtable = "";
        var key = primaryKey;
        var DrudID = drugid;
        var DrugName = drugname;
       
        var txtValue = $('CustomSubstanceUseHistory2 SubstanceUseHistoryId[text=' + primaryKey + ']', AutoSaveXMLDom[0]).siblings('FamilyHistory').text();

        FamilyHxtable += "<table width='100%'>";
        FamilyHxtable += "<tr>";
        FamilyHxtable += "<td >";
        FamilyHxtable += "<table width='100%'>";
        FamilyHxtable += "<tr>";
        FamilyHxtable += "<td width='24%'>";
        FamilyHxtable += "</td>";
        FamilyHxtable += "<td width='15%'>";
        FamilyHxtable += "<span class='form_label'>Comment</span>";
        FamilyHxtable += "</td>";
        FamilyHxtable += "</tr>";
        FamilyHxtable += "</table>";
        FamilyHxtable += "</td>";
        FamilyHxtable += "<td width='61%'>";
        FamilyHxtable += "<textarea ParentChildControls='True' BindAutoSaveEvents='False' id='TextArea_CustomSubstanceUseHistory2_FamilyHistory_" + i + "' name='TextArea_CustomSubstanceUseHistory2_FamilyHistory_" + i + "' spellcheck='True'  datatype='String'";
         FamilyHxtable += "rows='4' cols='1' style='width: 412px' onchange=\"javascript:GetFamilyHistoryText(this ," + key + " ," + DrudID + " ,'" + DrugName + "');\" >" + txtValue + "</textarea> ";
        FamilyHxtable += "</td>";
        FamilyHxtable += "</tr>";
        FamilyHxtable += "</table>";
        $("#DivFamilyHx_" + i).html(FamilyHxtable);
    }
    catch (ex) {
        throw ex;
    }
}

function GetFamilyHistoryText(FamilyHistory, primaryKey, drugid, drugname) {
    var key = primaryKey;
    var DrudID = drugid;
    var DrugName = drugname;
    var FamilyText;

    try {
        if (FamilyHistory.outerText == undefined) {
            FamilyText = $("#" + FamilyHistory).val();
        }
        else {
            
            FamilyText = FamilyHistory.value;
        }

       
        SetValues('CustomSubstanceUseHistory2', 'FamilyHistory', 'SubstanceUseHistoryId', key, FamilyText, DrudID, DrugName);
        
    }
    catch (ex) {
        throw ex;
    }


}

function GetDrugsDescrption(val) {
    var div = $("#divDrugDescPopUp");
    div[0].style.position = "absolute";
    div[0].style.left = 200; //250
    div[0].style.top = 170;

    $("#divDrugDescPopUp").show();
    $("#SpnDescprition").html(val);
}


//Set values for Dom Manipulation in SubstanceUseHistory
function SetValues(tableName, columnName, primaryKey, pkkeyValue, changeVal, drugid, drugname) {
    substanceUseHistory = true;
    AddToUnsavedTables(tableName);
    var changeValue;
    if (changeVal.checked == true || changeVal == true && columnName == 'InitiallyPrescribed') {
        changeValue = changeVal.checked;
        changeValue = 'Y';
    }
    else if (changeVal.checked == false || changeVal == false && columnName == 'InitiallyPrescribed') {
        changeValue = 'N';
    }
   
    else if ((columnName == 'AgeOfFirstUse' || columnName == 'Preference') && changeVal == '') {
        var xmlGetTable = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomSubstanceUseHistory2");
        if (xmlGetTable.length > 0 && GetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, AutoSaveXMLDom[0]) != null) {
            var GetColomnvalue = GetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, AutoSaveXMLDom[0]);
            if (GetColomnvalue != '') {
                changeValue = changeVal;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
   
    else {
        changeValue = changeVal;
    }
 
    if (pkkeyValue <= 0) {


       
        if (DocumentVersionId > 0) {
            fk = DocumentVersionId;
        }
        else {
           
            fk = DocumentVersionId;
        }
       
        var _xmlDom = GetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, AutoSaveXMLDom[0]);

        if (_xmlDom.length == 0) {

            
            AddToUnsavedTables(tableName);
            var _currentNode = "";
            if (AutoSaveXMLDom[0].childNodes[0].selectSingleNode(tableName) == null) {
                AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(tableName)); //Add table in the XML Dom

                _currentNode = AutoSaveXMLDom[0].childNodes[0].selectSingleNode(tableName).appendChild(AutoSaveXMLDom[0].createElement(columnName));

                var columnObject = $(columnName, _currentNode);
              
                if (changeValue == "") {
                     columnObject.attr("xsi:nil", 'true');
                }


                _currentNode.text = changeValue;

               
                _xmlDom = GetXMLParentNodeByTable(tableName, AutoSaveXMLDom[0]);
                if (_xmlDom[0].selectSingleNode('SubstanceUseHistoryId') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('SubstanceUseHistoryId'));

                    var nodepk = _xmlDom[0].selectSingleNode('SubstanceUseHistoryId');
                    nodepk.text = pkkeyValue;

                }
               
                if (_xmlDom[0].selectSingleNode('DocumentVersionId') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId'));

                    var nodefk = _xmlDom[0].selectSingleNode('DocumentVersionId');
                    nodefk.text = fk;

                }

                if (_xmlDom[0].selectSingleNode('SUDrugId') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('SUDrugId'));

                    var nodedrugid = _xmlDom[0].selectSingleNode('SUDrugId');
                    nodedrugid.text = drugid;
                }
                
                if (_xmlDom[0].selectSingleNode('DrugName') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('DrugName'));

                    var nodedrugname = _xmlDom[0].selectSingleNode('DrugName');
                    nodedrugname.text = drugname;
                }

            }

            else {
                
                _xmlDom = GetXMLParentNodeByColumnValue(tableName, primaryKey, pkkeyValue, AutoSaveXMLDom[0]);
                if (_xmlDom != null) {
                    if (_xmlDom.length > 0) {
                        if (_xmlDom[0].selectSingleNode(columnName) == null) {
                            _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement(columnName));
                            var nodecol = _xmlDom[0].selectSingleNode(columnName);

                            var columnObject = $(columnName, _xmlDom);
                          
                            if (changeValue == "") {
                                columnObject.attr("xsi:nil", 'true');
                            }

                            nodecol.text = changeValue;
                        }
                        else {
                            var nodecol = _xmlDom[0].selectSingleNode(columnName);

                            var columnObject = $(columnName, _xmlDom);
                           
                            if (changeValue == "") {
                                columnObject.attr("xsi:nil", 'true');
                            }

                            nodecol.text = changeValue;
                        }
                    }

                    else {
                        var i = 0;
                        var _currentxml = "";

                        _xmlDom = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(tableName)).xml; //Add table in the XML Dom

                        _xmlDom = GetXMLParentNodeByTable(tableName, AutoSaveXMLDom[0]);
                        for (i = 0; i < _xmlDom.length; i++) {

                            _currentxml = GetXMLParentNodeByColname(primaryKey, _xmlDom[i]);
                            if (_currentxml.length == 0) {
                                if (_xmlDom[i].selectSingleNode('SubstanceUseHistoryId') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('SubstanceUseHistoryId'));
                                    var nodepk = _xmlDom[i].selectSingleNode('SubstanceUseHistoryId');
                                    nodepk.text = pkkeyValue;
                                }
                                if (_xmlDom[i].selectSingleNode('DocumentVersionId') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId'));

                                    var nodefk = _xmlDom[i].selectSingleNode('DocumentVersionId');
                                    nodefk.text = fk;

                                }

                                if (_xmlDom[i].selectSingleNode('SUDrugId') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('SUDrugId'));

                                    var nodedrugid = _xmlDom[i].selectSingleNode('SUDrugId');
                                    nodedrugid.text = drugid;
                                }
                              
                                if (_xmlDom[i].selectSingleNode('DrugName') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('DrugName'));

                                    var nodedrugname = _xmlDom[i].selectSingleNode('DrugName');
                                    nodedrugname.text = drugname;
                                }

                              
                                if (_xmlDom[i].selectSingleNode(columnName) == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement(columnName));
                                    var nodeselected = _xmlDom[i].selectSingleNode(columnName);
                                    var columnObject = $(columnName, _xmlDom);
                                    
                                    if (changeValue == "") {
                                        columnObject.attr("xsi:nil", 'true');
                                    }

                                    nodeselected.text = changeValue;

                                }
                                CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

                            }

                        }
                    }
                }
            }
        }
        else {
            CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

        }
    }

    else {

        CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

    }

}

///get xml by table name

function GetXMLParentNodeByTable(tableName, xmlDom) {

    var expression = tableName;
    return $(expression, xmlDom);
}



//To close Drug description div
function CloseDrugsDescDiv() {
    $("#divDrugDescPopUp").hide();
}

//Set values for Dom Manipulation [RecordDeleted] in SubstanceUseHistory
function SetValuesforRecordDeleted(tableName, columnName, primaryKey, pkkeyValue, changeVal, sudrugid, drugname) {
    var Count = 0;
    var fk = 0;
    substanceUseHistory = true;

    var drugid = sudrugid;
    AddToUnsavedTables(tableName);
   
    if (changeVal.checked == false) {

        var val_string = (sudrugid - 1);
        var control_val = '';

        var _val = '';
        _val = $("[id$=TextBox_CustomSubstanceUseHistory2_AgeOfFirstUse_" + val_string + "]").val();
        if (_val != undefined)
            control_val = control_val + _val;

        _val = $("[id$=DropDownList_CustomSubstanceUseHistory2_Frequency_" + val_string + "]").val();
        if (_val != undefined)
            control_val = control_val + _val;

        _val = $("[id$=DropDownList_CustomSubstanceUseHistory2_Route_" + val_string + "]").val();
        if (_val != undefined)
            control_val = control_val + _val;

        _val = $("[id$=TextBox_CustomSubstanceUseHistory2_LastUsed_" + val_string + "]").val();
        if (_val != undefined)
            control_val = control_val + _val;

        _val = $("[id$=CheckBox_CustomSubstanceUseHistory2_InitiallyPrescribed_" + val_string + "_N]").val();
        if (_val != undefined)
            control_val = control_val + _val;

        _val = $("[id$=TextBox_CustomSubstanceUseHistory2_Preference_" + val_string + "]").val();
        if (_val != undefined)
            control_val = control_val + _val;

        _val = $("[id$=TextArea_CustomSubstanceUseHistory2_FamilyHistory_" + val_string + "]").val();
        if (_val != undefined)
            control_val = control_val + _val;


        if (control_val == '')
            changeValue = "Y";
        else
       
            changeValue = "Y";
    }
    else if (changeVal.checked == true) {
        changeValue = "N";
    }
    
    if (pkkeyValue > 0) {

        CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

    }

    
    else {
  
        if (DocumentVersionId > 0) {
            fk = DocumentVersionId;
        }
        else {
            fk = DocumentVersionId;
        }
      
        var _xmlDom = GetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, AutoSaveXMLDom[0]);
       

        if (_xmlDom.length == 0) {

            var _currentNode = "";
            if (AutoSaveXMLDom[0].childNodes[0].selectSingleNode(tableName) == null) {
                AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(tableName)); //Add table in the XML Dom

                _currentNode = AutoSaveXMLDom[0].childNodes[0].selectSingleNode(tableName).appendChild(AutoSaveXMLDom[0].createElement(columnName));
                _currentNode.text = changeValue;

                //Append PK and FK with values
                _xmlDom = GetXMLParentNodeByTable(tableName, AutoSaveXMLDom[0]);
                if (_xmlDom[0].selectSingleNode('SubstanceUseHistoryId') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('SubstanceUseHistoryId'));

                    var nodepk = _xmlDom[0].selectSingleNode('SubstanceUseHistoryId');
                    nodepk.text = pkkeyValue;

                }
                //Set value for DocumentVersionId and append
                if (_xmlDom[0].selectSingleNode('DocumentVersionId') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId'));

                    var nodefk = _xmlDom[0].selectSingleNode('DocumentVersionId');
                    nodefk.text = fk;

                }

                //append drugid
                if (_xmlDom[0].selectSingleNode('SUDrugId') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('SUDrugId'));

                    var nodedrugid = _xmlDom[0].selectSingleNode('SUDrugId');
                    nodedrugid.text = drugid;
                }
                //append drug name
                if (_xmlDom[0].selectSingleNode('DrugName') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('DrugName'));

                    var nodedrugname = _xmlDom[0].selectSingleNode('DrugName');
                    nodedrugname.text = drugname;
                }

            }
            else {

                //Check column name in this xml
                _xmlDom = GetXMLParentNodeByColumnValue(tableName, primaryKey, pkkeyValue, AutoSaveXMLDom[0]);
                if (_xmlDom != null) {
                    if (_xmlDom.length > 0) {
                        if (_xmlDom[0].selectSingleNode(columnName) == null) {
                            _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement(columnName));
                            var nodecol = _xmlDom[0].selectSingleNode(columnName);
                            nodecol.text = changeValue;


                        }
                    }


                    else {

                        var i = 0;
                        var _currentxml = "";

                        _xmlDom = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(tableName)).xml; //Add table in the XML Dom

                        _xmlDom = GetXMLParentNodeByTable(tableName, AutoSaveXMLDom[0]);
                        for (i = 0; i < _xmlDom.length; i++) {

                            _currentxml = GetXMLParentNodeByColname(primaryKey, _xmlDom[i]);
                            //append selected column

                            if (_currentxml.length == 0) {

                                //append primary key
                                if (_xmlDom[i].selectSingleNode('SubstanceUseHistoryId') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('SubstanceUseHistoryId'));
                                    var nodepk = _xmlDom[i].selectSingleNode('SubstanceUseHistoryId');
                                    nodepk.text = pkkeyValue;
                                }


                                //Set value for (FK) DocumentVersionId and append
                                if (_xmlDom[i].selectSingleNode('DocumentVersionId') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId'));

                                    var nodefk = _xmlDom[i].selectSingleNode('DocumentVersionId');
                                    nodefk.text = fk;

                                }

                                //append drugid
                                if (_xmlDom[i].selectSingleNode('SUDrugId') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('SUDrugId'));

                                    var nodedrugid = _xmlDom[i].selectSingleNode('SUDrugId');
                                    nodedrugid.text = drugid;
                                }
                                //append selected column
                                if (_xmlDom[i].selectSingleNode(columnName) == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement(columnName));

                                    var nodeselected = _xmlDom[i].selectSingleNode(columnName);
                                    nodeselected.text = changeValue;

                                }
                                //append drug name
                                if (_xmlDom[i].selectSingleNode('DrugName') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('DrugName'));

                                    var nodedrugname = _xmlDom[i].selectSingleNode('DrugName');
                                    nodedrugname.text = drugname;
                                }
                            }

                        }
                    }
                }


            }

        }
        //Update esiting row
        else {
            CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

        }


    }
    substanceUseHistory = true;
    CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

}


//Description:Function is used enable treatmentSection in Summary



function EnableTreatmentSection() {
    if ($("#RadioButton_CustomDocumentMHAssessments_ClientIsAppropriateForTreatment_N").is(":checked")) {

        ($("#TableClientTreatment").removeAttr("disabled"));
        ($("#TextArea_CustomDocumentMHAssessments_TreatmentNarrative").removeAttr("disabled"));
    }

}
function EnableSummaryTreatmentComment() {

    if ($("#RadioButton_CustomDocumentMHAssessments_SecondOpinionNoticeProvided_Y").is(":checked")) {
        ($("#TextArea_CustomDocumentMHAssessments_TreatmentNarrative").removeAttr("disabled"));

    }
}
function DisableSummaryTreatmentComment() {

    if ($("#RadioButton_CustomDocumentMHAssessments_SecondOpinionNoticeProvided_N").is(":checked")) {
        ($("#TextArea_CustomDocumentMHAssessments_TreatmentNarrative").attr("disabled", true));

    }
}

//Description:Function is used disable treatmentSection in Summary


function DisableTreatmentSection(dom) {
   
    if (dom != null && dom != '') {
        if (dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0) {
            SavetabControl = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            if (SavetabControl[0].selectSingleNode('ClientIsAppropriateForTreatment') != null) {
                if (SavetabControl[0].selectSingleNode('ClientIsAppropriateForTreatment').text == 'Y') {
                    $("#RadioButton_CustomDocumentMHAssessments_ClientIsAppropriateForTreatment_Y").attr("checked", true);
                }
            }
        }
    }

    if ($("#RadioButton_CustomDocumentMHAssessments_ClientIsAppropriateForTreatment_Y").is(":checked")) {
        $("#TableClientTreatment").attr("disabled", "disabled");
        $("#RadioButton_CustomDocumentMHAssessments_SecondOpinionNoticeProvided_Y").attr("checked", false);
        $("#RadioButton_CustomDocumentMHAssessments_SecondOpinionNoticeProvided_N").attr("checked", false);
        UpdateAutoSaveXmlNode("CustomDocumentMHAssessments", "SecondOpinionNoticeProvided", '');
    }
}

function SetValuesSuicidality(HRMNeedid) {
    var CheckboxlistDesc = "";
    if ($("#CheckBox_CustomDocumentMHAssessments_SuicideCurrent").is(":checked") == true) {

        var Identation = $("#Label_CustomDocumentMHAssessments_SuicideIdeation")[0].innerText;
        var Active = $("#Label_CustomDocumentMHAssessments_SuicideActive")[0].innerText;
        var Passive = $("#Label_CustomDocumentMHAssessments_SuicidePassive")[0].innerText;
        var Means = $("#Label_CustomDocumentMHAssessments_SuicideMeans")[0].innerText;
        var Plans = $("#Label_CustomDocumentMHAssessments_SuicidePlan")[0].innerText;

        var NeedName = "Suicidality";
        if ($("#CheckBox_CustomDocumentMHAssessments_SuicideIdeation").is(":checked")) {

            CheckboxlistDesc = Identation;

        }

        if ($("#CheckBox_CustomDocumentMHAssessments_SuicideActive").is(":checked")) {
            if (CheckboxlistDesc != "") {
                CheckboxlistDesc = CheckboxlistDesc + "," + Active;
            }
            else {
                CheckboxlistDesc = CheckboxlistDesc + Active;
            }


        }
        if ($("#CheckBox_CustomDocumentMHAssessments_SuicidePassive").is(":checked")) {

            if (CheckboxlistDesc != "") {
                CheckboxlistDesc = CheckboxlistDesc + "," + Passive;
            }
            else {
                CheckboxlistDesc = CheckboxlistDesc + Passive;
            }

        }
        if ($("#CheckBox_CustomDocumentMHAssessments_SuicideMeans").is(":checked")) {

            if (CheckboxlistDesc != "") {
                CheckboxlistDesc = CheckboxlistDesc + "," + Means;
            }
            else {
                CheckboxlistDesc = CheckboxlistDesc + Means;
            }



        }
        if ($("#CheckBox_CustomDocumentMHAssessments_SuicidePlan").is(":checked")) {
            if (CheckboxlistDesc != "") {
                CheckboxlistDesc = CheckboxlistDesc + "," + Plans;
            }
            else {
                CheckboxlistDesc = CheckboxlistDesc + Plans;
            }
        }

    }
    if ( $("#CheckBox_CustomDocumentMHAssessments_SuicideCurrent").is(":checked") == false) {

      //  CheckboxlistDesc = $("#TextArea_CustomDocumentMHAssessments_SuicideBehaviorsPastHistory").val().trim();
    }
    if (  $("#CheckBox_CustomDocumentMHAssessments_SuicideCurrent").is(":checked") == false) {

       // CheckboxlistDesc = $("#TextArea_CustomDocumentMHAssessments_SuicideBehaviorsPastHistory").val().trim();
    }

    return CheckboxlistDesc;
}






//================================================CODE BY ASHWANI KUMAR ANGRISH================================

function findLatestCustomHRMAssessmentNeedId() {


}


//Set values for Dom Manipulation in SubstanceUseHistory
function SetValuesForNeeds(tableName, columnName, primaryKey, pkkeyValue, changeVal) {

    substanceUseHistory = true;
    var changeValue = changeVal;

    AddToUnsavedTables(tableName);
    //for new mode
    if (pkkeyValue <= 0) {


        // start set value for FK      
        if (DocumentVersionId > 0) {
            fk = DocumentVersionId;
        }
        else {
            // set  DocumentVersionId
            fk = DocumentVersionId;
        }
        // end set value for FK  


        //Check nodexml with tablename and primary key
        var _xmlDom = GetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, AutoSaveXMLDom[0]);
        //  var _xmlDom = GetXMLParentNodeByColumnValue(tableName, columnName, changeValue, AutoSaveXMLDom[0])


        if (_xmlDom.length == 0) {

            //create table if not exist in xml
            //CreateAutoSaveXml(tableName, columnName, changeValue);
            AddToUnsavedTables(tableName);
            var _currentNode = "";
            if (AutoSaveXMLDom[0].childNodes[0].selectSingleNode(tableName) == null) {
                AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(tableName)); //Add table in the XML Dom

                //Append column key with value
                _currentNode = AutoSaveXMLDom[0].childNodes[0].selectSingleNode(tableName).appendChild(AutoSaveXMLDom[0].createElement(columnName));
                _currentNode.text = changeValue;

                //Append PK and FK with values
                _xmlDom = GetXMLParentNodeByTable(tableName, AutoSaveXMLDom[0]);
                if (_xmlDom[0].selectSingleNode(primaryKey) == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement(primaryKey));

                    var nodepk = _xmlDom[0].selectSingleNode(primaryKey);
                    nodepk.text = pkkeyValue;

                }
                //Set value for DocumentVersionId and append
                if (_xmlDom[0].selectSingleNode('DocumentVersionId') == null) {
                    _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId'));

                    var nodefk = _xmlDom[0].selectSingleNode('DocumentVersionId');
                    nodefk.text = fk;

                }




            }

            else {
                //If table already exist in xml
                //Create other parent node with this table

                //Check column name in this xml
                _xmlDom = GetXMLParentNodeByColumnValue(tableName, primaryKey, pkkeyValue, AutoSaveXMLDom[0]);
                if (_xmlDom != null) {
                    if (_xmlDom.length > 0) {
                        if (_xmlDom[0].selectSingleNode(columnName) == null) {
                            _xmlDom[0].appendChild(AutoSaveXMLDom[0].createElement(columnName));
                            var nodecol = _xmlDom[0].selectSingleNode(columnName);
                            nodecol.text = changeValue;


                        }
                    }


                    else {


                        var i = 0;
                        var _currentxml = "";

                        _xmlDom = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(tableName)).xml; //Add table in the XML Dom

                        _xmlDom = GetXMLParentNodeByTable(tableName, AutoSaveXMLDom[0]);
                        for (i = 0; i < _xmlDom.length; i++) {

                            _currentxml = GetXMLParentNodeByColname(primaryKey, _xmlDom[i]);
                            if (_currentxml.length == 0) {

                                //append primary key
                                if (_xmlDom[i].selectSingleNode(primaryKey) == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement(primaryKey));
                                    var nodepk = _xmlDom[i].selectSingleNode(primaryKey);
                                    nodepk.text = pkkeyValue;
                                }


                                //Set value for (FK) DocumentVersionId and append
                                if (_xmlDom[i].selectSingleNode('DocumentVersionId') == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId'));

                                    var nodefk = _xmlDom[i].selectSingleNode('DocumentVersionId');
                                    nodefk.text = fk;

                                }


                                //append selected column
                                if (_xmlDom[i].selectSingleNode(columnName) == null) {
                                    _xmlDom[i].appendChild(AutoSaveXMLDom[0].createElement(columnName));

                                    var nodeselected = _xmlDom[i].selectSingleNode(columnName);
                                    nodeselected.text = changeValue;

                                }
                            }

                        }
                    }
                }
            }
        }
        else {
            CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

        }
    }

    else {

        CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKey, pkkeyValue, columnName, changeValue, AutoSaveXMLDom[0], 'Y');

    }

}


//------------27 May 2010

function GetXmlHRMNeed() {
    alert("GetXmlHRMNeed=" + objectPageResponse.ScreenProperties.CustomHRMNeeds);
}


function CheckGoalAssociated(clientNeedId) {
    var returnValue = false;
    if (AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomClientNeeds").length > 0) {

        if ($(AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomClientNeeds")).find("ClientNeedId[text=" + clientNeedId + "]").parent().find('AssociatedGoalId').text().trim() != "")
            returnValue = true;

    }
  
    return returnValue;
}



//=================================================CODE BY ASHWANI KUMAR ANGRISH



function StoreTabstripClientObject(sender) {
    tabobject = sender;


    if (flag == 0) {
        if ($("#CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation").length > 0)
            $("#CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation")[0].checked = false;

        if ($("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation").length > 0)
            $("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation")[0].checked = false;

        if ($("#CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation").length > 0)
            $("#CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation")[0].checked = false;

        flag = 1;

    }

}


// Function Added by Damanpreet 
// created on 4th Feb 2010
function SetEnableDisableUncope(val, dom) {
    var RadioButtonUncopeQuestionU = $("input[type='radio'][name='RadioButton_CustomDocumentMHAssessments_UncopeQuestionU']");
    var RadioButtonUncopeQuestionN = $("input[type='radio'][name='RadioButton_CustomDocumentMHAssessments_UncopeQuestionN']");
    var RadioButtonUncopeQuestionC = $("input[type='radio'][name='RadioButton_CustomDocumentMHAssessments_UncopeQuestionC']");
    var RadioButtonUncopeQuestionO = $("input[type='radio'][name='RadioButton_CustomDocumentMHAssessments_UncopeQuestionO']");
    var RadioButtonUncopeQuestionP = $("input[type='radio'][name='RadioButton_CustomDocumentMHAssessments_UncopeQuestionP']");
    var RadioButtonUncopeQuestionE = $("input[type='radio'][name='RadioButton_CustomDocumentMHAssessments_UncopeQuestionE']");
    if (val == 'N') {

        RadioButtonUncopeQuestionC.attr("disabled", "disabled");
        RadioButtonUncopeQuestionE.attr("disabled", "disabled");
        RadioButtonUncopeQuestionN.attr("disabled", "disabled");
        RadioButtonUncopeQuestionO.attr("disabled", "disabled");
        RadioButtonUncopeQuestionP.attr("disabled", "disabled");
        RadioButtonUncopeQuestionU.attr("disabled", "disabled");       
    }
    if (val == 'Y') {

        RadioButtonUncopeQuestionC.removeAttr("disabled", "disabled");
        RadioButtonUncopeQuestionE.removeAttr("disabled", "disabled");
        RadioButtonUncopeQuestionN.removeAttr("disabled", "disabled");
        RadioButtonUncopeQuestionO.removeAttr("disabled", "disabled");
        RadioButtonUncopeQuestionP.removeAttr("disabled", "disabled");
        RadioButtonUncopeQuestionU.removeAttr("disabled", "disabled");
    }
  
    CreateAutoSaveXml('CustomDocumentMHAssessments', 'UncopeApplicable', val, dom);
}


///Author : Jitender Kumar Kamboj
///Purpose : This function will be called From Risk Assessment Page To open HRMOtherRiskFactors PopUp
///Date: 04 May,2010

function OpenOtherRiskFactorsLookupPopUp(RelativePath) {
   
    try { 
         ScreenCode ='CC0C17C7-3B40-460C-9DB4-1ED2959C5879';       
        OpenPage(5765, null, '', null, RelativePath, 'T', "dialogHeight: 400px; dialogWidth: 450px; dialogtitle:Other Risk Factors Lookup;",null,null,null,null,null,null,ScreenCode);
          }
    catch (err) {
        LogClientSideException(err, 'HRMAssesment');
    }
}


///Purpose : This function is used to Split ServiceLookup Details and create XML to bind grid on HRMSummary page
///Date: 05 May,2020

function SplitServiceLookupDetail(ServiceLookupDetail) {
    
    var splitIndex = 0;
    var splitArray = new Array();
    var separator = '||';
    var stringArray = ServiceLookupDetail.split(separator);
    var count = stringArray.length;
    var XML = new String("<MainDataSet  xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
    for (i = 0; i < count; i++) {
        var separatorNew = ':';
        var stringChildArray = stringArray[i].split(separatorNew);
        var HRMLevelOfCareOptionId = stringChildArray[0];
        var serviceChoiceLabel = stringChildArray[1];

        if (HRMLevelOfCareOptionId != "") {
            XML = XML + "<CustomHRMAssessmentLevelOfCareOptions>";
            
            XML = XML + "<HRMAssessmentLevelOfCareOptionId>" + HRMLevelOfCareOptionId + " </HRMAssessmentLevelOfCareOptionId>";
          
            XML += "<DocumentVersionId>" + DocumentVersionId + "</DocumentVersionId>";

            XML += "<HRMLevelOfCareOptionId>" + HRMLevelOfCareOptionId + "</HRMLevelOfCareOptionId>";

            XML += "<ServiceChoiceLabel>" + encodeTextForXML(serviceChoiceLabel) + "</ServiceChoiceLabel>";

            XML += "<RecordDeleted>N</RecordDeleted>";

            XML = XML + "</CustomHRMAssessmentLevelOfCareOptions>";
        }
    }
    XML = XML + "</MainDataSet>";
    gridTableName = 'CustomHRMAssessmentLevelOfCareOptions';
    CallAjaxGridControl(XML, '#TableChildControl_CustomHRMAssessmentLevelOfCareOptions', 'InsertGridServiceLookup', 'CustomGridServiceLookup', 'CustomHRMAssessmentLevelOfCareOptions');
}


///Purpose : This function is used to Split OtherRiskFactorsLookup Details and create XML to bind grid on HRMRiskAssessment page
///Date:05 May,2020

function SplitOtherRiskFactorsLookupDetail(OtherRiskFactorsLookupDetail) {
    
    var splitIndex = 0;
    var splitArray = new Array();
    var separator = '||';
    var stringArray = OtherRiskFactorsLookupDetail.split(separator);
    var count = stringArray.length;
    var XML = new String("<MainDataSet  xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
    for (i = 0; i < count; i++) {
        var separatorNew = ':';
        var stringChildArray = stringArray[i].split(separatorNew);
        var otherRiskFactor = stringChildArray[0];
        var codeName = stringChildArray[1];

        if (otherRiskFactor != "") {
            XML = XML + "<CustomOtherRiskFactors>";

            XML = XML + "<OtherRiskFactorId>" + encodeTextForXML(otherRiskFactor) + " </OtherRiskFactorId>";

            XML += "<DocumentVersionId>" + DocumentVersionId + "</DocumentVersionId>";

            XML += "<OtherRiskFactor>" + encodeTextForXML(otherRiskFactor) + "</OtherRiskFactor>";

            XML += "<CodeName>" + encodeTextForXML(codeName) + "</CodeName>";

            XML += "<RecordDeleted>N</RecordDeleted>";

            XML = XML + "</CustomOtherRiskFactors>"
        }

    }
    XML = XML + "</MainDataSet>";
    gridTableName = 'CustomOtherRiskFactors';
    CallAjaxGridControl(XML, '#TableChildControl_CustomOtherRiskFactorsLookup', 'InsertGridOtherRiskFactorsLookup', 'CustomGridOtherRiskFactorsLookup', 'CustomOtherRiskFactors');
}


///Purpose : This function is used to add Support section to HRMSupport page
///Date: 05 May,2020
///Global Variable Index is used to differentiate between controls

var index = 0;

function AddSupport() {
    try {
        
        var XmlhrmSupport;
        if (AutoSaveXMLDom == undefined || AutoSaveXMLDom == null)
            return;
        XmlhrmSupport = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomMHAssessmentSupports");
        if (XmlhrmSupport == undefined || XmlhrmSupport == null)
            return;
        if (XmlhrmSupport.length > 0) {
            var hRMSupportId = XmlhrmSupport[XmlhrmSupport.length - 1].selectNodes("MHAssessmentSupportId")[0].text;
        }
        else {
            return;
        }
        var newhRMhRMSupportId = -1;
        if (parseInt(hRMSupportId) > 0)
            newhRMhRMSupportId = -1;
        else
            newhRMhRMSupportId = parseInt(hRMSupportId) - 1;

        index = newhRMhRMSupportId;
      
        if ($("table[supportAtt=common]").length == 0) {

        }
        $.ajax(
        {
            type: "POST",
            url: GetRelativePath() + "Custom/MH Assessment/WebPages/AjaxHRMSupport.aspx?functionName=GetSupport",
            data: "Support=" + index,
            success: fillSupport
        });

    }
    catch (err) {
        LogClientSideException(err, 'HRMAssesment');
    }
}



/////Purpose : This function is used to add Support section to HRMSupport page
/////Date: 05 May,2020

function AddSupportSection() {
    try {
        PopupProcessing();
        
        //Logic of generating Primary Key has to be dependent on maximum MHAssessmentSupportId
        var XmlhrmSupport;
        XmlhrmSupport = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomMHAssessmentSupports");
        var newhRMhRMSupportId = -1;

        if (XmlhrmSupport != undefined && XmlhrmSupport != null && XmlhrmSupport.length > 0) {
            var hRMSupportId = XmlhrmSupport[XmlhrmSupport.length - 1].selectNodes("MHAssessmentSupportId")[0].text;
            var newhRMhRMSupportId = -1;
            if (parseInt(hRMSupportId) > 0)
                newhRMhRMSupportId = -1;
            else
                newhRMhRMSupportId = parseInt(hRMSupportId) - 1;
        }

        index = newhRMhRMSupportId;
      
        if ($("table[supportAtt=common]").length == 0) {
            
        }
        else if ($("table[supportAtt=common]").length > 0) {
        }


        $.ajax(
        {
            type: "POST",
            url: GetRelativePath() + "Custom/MH Assessment/WebPages/AjaxHRMSupport.aspx?functionName=GetSupportSection",
            data: "Support=" + index,
            success: fillSupportSection
        });


    }
    catch (err) {
        HidePopupProcessing();
        LogClientSideException(err, 'HRMAssesment');
    }
}



/////Purpose : This function is used to fill Support section
/////Date: 05 May,2020
function fillSupport(result) {
    try {
        ///Index is incrementing in function AddSupport() used for unique ids, here we create Support section first time.
        if (index == 1) {
            $('#DivSupport').html(result);
        }
        else {
            $('#DivSupport').append(result);
        }
        ValidationSupport();
        CreateInitializationImages(AutoSaveXMLDom);
    }
    catch (err) {
        LogClientSideException(err, 'HRMAssesment');
    }
}





///get xml by table name

function GetXMLParentNodeByTable(tableName, xmlDom) {
    var expression = tableName;
    return $(expression, xmlDom);
}

///get xml by Column name
function GetXMLParentNodeByColname(colname, xmlDom) {
    var expression = colname;
    return $(expression, xmlDom).parent();
}


///Purpose : This function is used to check and uncheck checkboxes on Support page
///Date: 05 May,2020
function UnCheckControls(columnValue, indexCount, primaryKeyValue) {
   
    var Parentnode = "";
    var childnode = "";
    if (columnValue == 'Y' || columnValue == 'N') {
        Parentnode = $("CustomMHAssessmentSupports MHAssessmentSupportId[text=" + primaryKeyValue + "]", AutoSaveXMLDom).parent();
    }
   
    if (columnValue == "Y") {
       
        $("[id^=CheckBox_CustomMHAssessmentSupports_ClinicallyRecommended_" + indexCount + "_]").removeAttr('checked');
        $("[id^=CheckBox_CustomMHAssessmentSupports_CustomerDesired_" + indexCount + "_]").removeAttr('checked');
        $("[id^=CheckBox_CustomMHAssessmentSupports_ClinicallyRecommended_" + indexCount + "_]").attr('disabled', true);
        $("[id^=CheckBox_CustomMHAssessmentSupports_CustomerDesired_" + indexCount + "_]").attr('disabled', true);
        $("[id^=CheckBox_CustomMHAssessmentSupports_PaidSupport_" + indexCount + "_]").attr('disabled', false);
        $("[id^=CheckBox_CustomMHAssessmentSupports_UnpaidSupport_" + indexCount + "_]").attr('disabled', false);
       
        childnode = $(Parentnode).find("ClinicallyRecommended");
        if (childnode.length > 0) {
            childnode.text('N');
        }
        childnode = $(Parentnode).find("CustomerDesired");
        if (childnode.length > 0) {
            childnode.text('N');
        }
     
    }
    else if (columnValue == "N") {
        
        $("[id^=CheckBox_CustomMHAssessmentSupports_ClinicallyRecommended_" + indexCount + "_]").attr('disabled', false);
        $("[id^=CheckBox_CustomMHAssessmentSupports_CustomerDesired_" + indexCount + "_]").attr('disabled', false);
        $("[id^=CheckBox_CustomMHAssessmentSupports_PaidSupport_" + indexCount + "_]").removeAttr('checked');
        $("[id^=CheckBox_CustomMHAssessmentSupports_UnpaidSupport_" + indexCount + "_]").removeAttr('checked');
        $("[id^=CheckBox_CustomMHAssessmentSupports_PaidSupport_" + indexCount + "_]").attr('disabled', true);
        $("[id^=CheckBox_CustomMHAssessmentSupports_UnpaidSupport_" + indexCount + "_]").attr('disabled', true);
        childnode = $(Parentnode).find("PaidSupport");
        if (childnode.length > 0) {
            childnode.text('N');
        }
        childnode = $(Parentnode).find("UnpaidSupport");
        if (childnode.length > 0) {
            childnode.text('N');
        }
        
    }
    AddToUnsavedTables("CustomMHAssessmentSupports");
}



///Purpose : This function is used to do validation on HRMSupport page

function ValidationSupport() {

    if (AutoSaveXMLDom != "" && AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomMHAssessmentSupports").length > 0) {
        var xmlCustomSupports2 = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomMHAssessmentSupports");
        for (var j = 0; j < AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomMHAssessmentSupports").length; j++) {

            if (xmlCustomSupports2[j].selectNodes("Current").length > 0) {
                var currentColumnValue = xmlCustomSupports2[j].selectNodes("Current")[0].text.trim();
                //Changes made by Mamta Gupta - Ref Task No. 634 - 31/Jan/2012 - primarykeyvalue paramerted pass to UnCheckControls method
                UnCheckControls(currentColumnValue, j + 1, "");
            }
        }
    }

}


/*------------------- End here -----------------------------*/


function deleteSupport(deleteSection, tableName, columnName, primaryKey, pkkeyValue, changeVal) {
    ShowMsgBox('Are you sure want to remove this Support?', ConfirmationMessageCaption, MessageBoxButton.OKCancel, MessageBoxIcon.Question, 'deleteSupportOnOkOption(\'' + deleteSection + '\',\'' + tableName + '\',\'' + columnName + '\',\'' + primaryKey + '\',\'' + pkkeyValue + '\',\'' + changeVal + '\');');
}


function deleteSupportOnOkOption(deleteSection, tableName, columnName, primaryKey, pkkeyValue, changeVal) {
    var deletingElement = $.find('table[supportDeleteAtt=' + deleteSection + ']');
    $(deletingElement).remove();

    var kount = 1;
    $("[id*=SupportText]").each(function() {
        (this).innerHTML = "Support " + kount;
        kount = kount + 1;
    });

    SetSupportValues(tableName, columnName, primaryKey, pkkeyValue, changeVal, '');

}




// Function to add Level of intensity to Needs list
function CalculateLevelOfIntensity(dom) {
    var XmlHrmNeed;
    var NeedDesc;
    if (dom[0] == null)
        return false;

    var IntensityHealth = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
    if (IntensityHealth.length > 0) {

    }
}




// Function to add Level of intensity to Needs list
function SetEnableDisableControls(selectedTabTitle, dom) {

    if (dom == undefined) {
        dom = AutoSaveXMLDom;
    }
    var IntensityHealth = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
   
}



//Purpose : This function is used to get ServiceChoiceLabel to HRMSummary page


function GetServiceLookupDetail(gridView) {
    var ServiceLookupDetail = "";
    var ServiceLookUp = $(window.frames["iframeWindowDialog"].document);
    var grid = ServiceLookUp.find("#" + gridView);
    $("input[type='checkbox']", grid).each(function() {
        if ($(this).attr("checked") == true) {
            ServiceLookupDetail += $(this).parent().find("input[type='hidden']:first").val() + ":";
            ServiceLookupDetail += $(this).parent().find("input[type='hidden']:last").val() + "||";
        }
    });
    ServiceLookupDetail = ServiceLookupDetail.substring(0, ServiceLookupDetail.length - 2);
    ProcessServiceLookupPopUp(ServiceLookupDetail);
}



function RefreshTabPageContents(tabControl, selectedTabTitle) {
    try {
        var _ddSelected = false;
        var _checkBoxClientInDDPopulation = 'N';
        var _checkBoxClientInSAPopulation = 'N';
        var _checkBoxClientInMHPopulation = 'N';
        var _DxTabDisabled = null;

        // selectedTabTitle in Chrome has new line Character at the end for Allegan 3.5 Implementation: #163 SC 
        selectedTabTitle = selectedTabTitle.trim();

        var xmlHrmAssessmentRow = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");

        if (tabUserControlName == "HRMNeedList") {
            FillNeedsTabTemplate();
            var DivNeedLists = $("#DivNeedLists");
            var LabelNeedErrorMsg = $("label[id$=LabelNeedErrorMsg]", DivNeedLists);
            if (UnsavedChangeId > 0) {
                if (LabelNeedErrorMsg.length > 0) {
                    LabelNeedErrorMsg.show();
                }
                StopSpellCheckProcess();
            }
            else {
                if (LabelNeedErrorMsg.length > 0) {
                    LabelNeedErrorMsg.hide();
                }
            }
        }
        if (xmlHrmAssessmentRow[0].selectNodes("ClientInDDPopulation").length > 0 && xmlHrmAssessmentRow[0].selectNodes("ClientInDDPopulation")[0].text.trim() == 'Y') {
            _checkBoxClientInDDPopulation = 'Y';
        }

        if (xmlHrmAssessmentRow[0].selectNodes("ClientInSAPopulation").length > 0 && xmlHrmAssessmentRow[0].selectNodes("ClientInSAPopulation")[0].text.trim() == 'Y') {
            _checkBoxClientInSAPopulation = 'Y';
        }
        else if (xmlHrmAssessmentRow[0].selectNodes("ClientInMHPopulation").length > 0 && xmlHrmAssessmentRow[0].selectNodes("ClientInMHPopulation")[0].text.trim() == 'Y') {
            _checkBoxClientInMHPopulation = 'Y';

        }

        if (selectedTabTitle == 'Dx') {

            DxTabEnableDisable(_checkBoxClientInDDPopulation, _checkBoxClientInSAPopulation, _checkBoxClientInMHPopulation, xmlHrmAssessmentRow);
            SetDiagnosisOrder(AutoSaveXMLDom);
        }

      
        if (selectedTabTitle == 'Psychosocial Adult') {
            SetFormValues(AutoSaveXMLDom, tabUserControlName);
            SetMedicationControls(AutoSaveXMLDom);
            EnableDisabeNeedListCheckBoxex(tabUserControlName);
            $('input[id$=HiddenField_CustomHRMAssessmentMedications_HRMAssessmentMedicationId]')[0].value = '';
        }

       

        if (selectedTabTitle == 'Psychosocial Child') {

            SetFormValues(AutoSaveXMLDom, tabUserControlName);
            SetMedicationControls(AutoSaveXMLDom);
            EnableDisabeNeedListCheckBoxex(tabUserControlName);
            $('input[id$=HiddenField_CustomHRMAssessmentMedications_HRMAssessmentMedicationId]')[0].value = '';
        }

       

        if (selectedTabTitle == 'UNCOPE') {

            callUncope();
        }
        if (selectedTabTitle == 'CRAFFT') {

            callCRAFFT();
        }



        if (selectedTabTitle == 'Initial') {
            SetGuardianInfoControl(AutoSaveXMLDom);
            AgeRadioButtonCheck(AutoSaveXMLDom);
            EnableDusableInitilaSection(AutoSaveXMLDom);

        }

        if (selectedTabTitle == 'Risk Assessment') {
            if (!$("#CheckBox_CustomDocumentMHAssessments_SuicideCurrent").is(":checked")) {

             //   $("#TextArea_CustomDocumentMHAssessments_SuicideBehaviorsPastHistory").attr('LocalDisableFunc', true);
            }

           
            CheckSuicideActivePassive();
            CheckHomicideActivePassive();

            
            DisabledHomicidality();
            DisabledSuicidality();
           
            DisabledPsychiatricAdvanceDirectives();
            
            EnableDisabeNeedListCheckBoxex(tabUserControlName);
        }

        if (selectedTabTitle == 'CAFAS') {
            BindPsychosocialstepper();
           
            GetCafasUrl(AutoSaveXMLDom);
           
            if (CAFASFlag != '') {
                var CAFAS_tab = tabobject.findTabByText('CAFAS');
                CalculateCafas(CAFAS_tab);
                var selectedTab = tabobject.findTabByText(CAFASFlag);
                selectedTab.select();
                CAFASFlag = '';
            }
        }
        if (selectedTabTitle == 'Needs List') {
        }
        if (selectedTabTitle == 'Pre Plan') {
            hideTable();

        }
      
        if (selectedTabTitle == 'Disposition') {

            if (DispositionControl != null) {
                DispositionControl.BindDispositionEvents("divDisposition");
            }
          

        }

       
    }
    catch (ex) {
        throw ex;
    }
}

function SetMedicationControls(AutoSaveXMLDom) {
    $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).attr("disabled", "disabled");

 

    $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).hide();

    $('#DivMedications', $("#" + ParentUserControlName)).hide();

   

    var radioMedicationsListRAPHealthToBeModified = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'PsMedicationsListToBeModified', AutoSaveXMLDom[0]);
    var radioRAPHealthHealthIssuesMedications = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'PsMedications', AutoSaveXMLDom[0]);

    if (radioRAPHealthHealthIssuesMedications == 'I') {
        $('#DivMedications', $("#" + ParentUserControlName)).show();
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).attr("disabled", true);
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).show();
    }
    if (radioMedicationsListRAPHealthToBeModified == 'Y' && radioRAPHealthHealthIssuesMedications == 'I') {
        $('#DivMedications', $("#" + ParentUserControlName)).show();
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).attr("disabled", false);
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).show();
    }
    else if (radioMedicationsListRAPHealthToBeModified == 'N') {
        $('#DivMedications', $("#" + ParentUserControlName)).show();
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).attr("disabled", true);
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).show();
    }

    if (radioRAPHealthHealthIssuesMedications == 'L') {
        $('#DivMedications', $("#" + ParentUserControlName)).show();
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).attr("disabled", false);
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).show();

    }
    else if (radioRAPHealthHealthIssuesMedications == 'N' || radioRAPHealthHealthIssuesMedications == 'U') {
        $('#DivMedications', $("#" + ParentUserControlName)).hide();
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).attr("disabled", true);
        $('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', $("#" + ParentUserControlName)).hide();
    }

}



///Purpose : This function is used to fill Support section

function fillSupportSection(result) {
    try {

        var primaryKeyValue;
     
        primaryKeyValue = index;

        SetSupportValues('CustomMHAssessmentSupports', 'RecordDeleted', 'MHAssessmentSupportId', primaryKeyValue, 'N', '', 'Y');

        if (index == 1) {
            $('#DivSupport').html(result);
        }
        else {
            $('#DivSupport').append(result);
        }

        var kount = 1;
        $("[id*=SupportText]").each(function() {
            (this).innerHTML = "Support " + kount;
            kount = kount + 1;
        });
        HidePopupProcessing();
    }
    catch (err) {
        HidePopupProcessing();
        LogClientSideException(err, 'HRMAssesment');
    }
}


/////Purpose : This function is used to set values for Dom Manipulation on HRMSupport page

function SetSupportValues(tableName, columnName, primaryKeyName, primaryKeyValue, columnValue, indexCount, newRowCase) {
    if (newRowCase == undefined) {
        newRowCase = 'N';
    }


    if (columnValue == "") {
        return;
    }
    else {
        if (columnValue.checked == true) {
            columnValue = "Y";
        }
        else if (columnValue.checked == false) {
            columnValue = "N";
        }
    }
    if (indexCount != undefined && indexCount != "" && columnName == "Current") {
        UnCheckControls(columnValue, indexCount, primaryKeyValue);
    }
    if (newRowCase == 'Y') {
         if (parseInt(primaryKeyValue) <= 0) {
            var _xmlDom = GetColumnValueInXMLNodeByKeyValue(tableName, primaryKeyName, primaryKeyValue, columnName, AutoSaveXMLDom[0]);

             AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(tableName)); //Add table in the XML Dom
            var _currentNode = "";
            _currentNode = AutoSaveXMLDom[0].childNodes[0].lastChild.appendChild(AutoSaveXMLDom[0].createElement(primaryKeyName));
            _currentNode.text = primaryKeyValue;
            primaryKeySet = true;
            Dirty = "True";
            CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKeyName, primaryKeyValue, 'DocumentVersionId', DocumentVersionId, AutoSaveXMLDom[0], 'Y');
            CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKeyName, primaryKeyValue, 'RecordDeleted', 'N', AutoSaveXMLDom[0], 'N');
        

        }
    }
    else {
        Dirty = "True";
        CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKeyName, primaryKeyValue, columnName, columnValue, AutoSaveXMLDom[0], 'Y');
    }
}



//Change column value in a specific Row values based on PrimaryKeyId
function CustomSetColumnValueInXMLNodeByKeyValue(tableName, primaryKeyColumnName, primaryKeyValue, changeColumnName, changeColumnValue, xmlDom, CallAutoSave) {

    SetColumnValueInXMLNodeByKeyValue(tableName, primaryKeyColumnName, primaryKeyValue, changeColumnName, changeColumnValue, xmlDom);
    if (CallAutoSave != undefined && CallAutoSave != 'undefined' && CallAutoSave == 'N') {
        return false;
    }
    else {
        CreateUnsavedInstanceOnDatasetChange();
    }
}



function DisableAssessmentScreenType(disableScreenType) {
    if (disableScreenType == true) {
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').attr("disabled", true);
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').attr("disabled", true);
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').attr("disabled", true);
       
    }
    else {
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').attr("disabled", false);
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').attr("disabled", false);
        $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').attr("disabled", false);
       
    }
}



// Function for select radion button Adult or child according to age.
function AgeRadioButtonCheck(AutoSaveXMLDom) {
    try {
       
        var CustomDocumentMHAssessments = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
        var _hrmAssessmentDocumentId = 0;
        if (AutoSaveXMLDom[0].childNodes[0].selectNodes("Documents").length > 0) {
            var xmlDocumentsRow = AutoSaveXMLDom[0].childNodes[0].selectNodes("Documents");
            _hrmAssessmentDocumentId = parseInt(xmlDocumentsRow[0].selectNodes("DocumentId")[0].text.trim());
        }
        if (_hrmAssessmentDocumentId > 0) {
            DisableAssessmentScreenType(true);
        }
        else
            DisableAssessmentScreenType(false);
        if (CustomDocumentMHAssessments[0].selectNodes("AdultOrChild").length > 0) {
            var AdultOrChild = CustomDocumentMHAssessments[0].selectNodes("AdultOrChild")[0].text;
            if (AdultOrChild == "") {
            }
            else {
                if (AdultOrChild == 'A') {
                    $("#RadioButton_CustomDocumentMHAssessments_AdultOrChild_A").attr("checked", true);
                     }
                else {
                    $("#RadioButton_CustomDocumentMHAssessments_AdultOrChild_C").attr("checked", true);
                    
                }
                ShowHideAdultChildTabsEvent();
            }
        }
    }
    catch (ex) {
        throw ex;
    }
}

function SetTabUcPath() {
    if (ParentUserControlName == "HRMDXDD")
        return Path = "/ICD10Diagnosis/Documents/ICDTenDiagnosis.ascx";
       else if (ParentUserControlName == "HRMPsychosocialAdult") {
        return Path = "/Custom/MH Assessment/WebPages/HRMPsychosocialAdult.ascx";
    }
    else if (ParentUserControlName == "HRMPsychosocialChild")
    { return Path = "/Custom/MH Assessment/WebPages/HRMPsychosocialChild.ascx"; }
    else if (ParentUserControlName == "HRMRiskAssessment")
    { return Path = "/Custom/MH Assessment/WebPages/HRMRiskAssessment.ascx"; }
    else
        return "";

}

function SetFieldsAfterDomInitialized() {


}


function SetScreenSpecificValues(dom, action) {
 
    dom = $.xmlDOM(objectPageResponse.PageDataSetXml);
    if (tabobject != null && tabobject != undefined) {//Surya.B Added code for Needs List Tab blank issue
        tabUserControlName = tabobject.get_selectedTab()._attributes.getAttribute("UcName");
    }
   
      AgencyName = $('input[id=HiddenAgencyName').val()

    if (AgencyName != undefined && AgencyName.indexOf("Woodlands") != -1) {
        ChangeSpanTextForWoodland();
    }
  
    if ($('input[id=RadioButton_CustomDocumentMHAssessments_ClientIsAppropriateForTreatment_Y]:checked').length > 0) {
        DisableTreatmentSection();
    }
    if ($('input[id=RadioButton_CustomDocumentMHAssessments_SecondOpinionNoticeProvided_N]:checked').length > 0) {
        DisableSummaryTreatmentComment();
    }
    if (action == pageActionEnum.TabRequest) {
        if (tabUserControlName == "HRMPsychosocialAdult" || tabUserControlName == "HRMPsychosocialChild" || tabUserControlName == "HRMDDPsychosocial") {
            SetFormValues(AutoSaveXMLDom, tabUserControlName);
        }

        
        if (tabUserControlName == "HRMUncope") {
            SetFormValues(AutoSaveXMLDom, tabUserControlName);
           
        }
        if (tabUserControlName == "CrafftAssessment") {
            SetFormValues(AutoSaveXMLDom, tabUserControlName);
           
        }
        if (tabUserControlName == "PrePlan") {
            var Meetintgtime = GetColumnValueInXMLNodeByKeyValue('CustomDocumentPrePlanningWorksheet', 'DocumentVersionId', DocumentVersionId, 'MeetingTime', AutoSaveXMLDom[0]);
            $("#TextBoxTime_CustomDocumentPrePlanningWorksheet_MeetingTime").val(Meetintgtime);
        }
        if (tabUserControlName == "HRMSummary") {
            ShowHideTextArea();
        }

        if (tabUserControlName == "HRMMentalStatus") {
          
            MentalStatusExamSetScreenSpecificValues(dom, action);
        }

        if (tabUserControlName == "CSSRSChildAdolescentSinceLT" || tabobject.get_selectedTab().get_text() == 'Columbia') {
            RefreshCSSRSChildAdolescentSinceLTHideandShow();
            $('#Img1').wTooltip({ content: $("input[id$=ActualLethalityMedicalDamage]").val() });
            $('#image_information').wTooltip({ content: $("input[id$=PotentialLethality]").val() });
        }
        if (tabUserControlName == "Disposition") {
            DispositionControl.BindDispositionEvents("divDisposition");
        }
        return false;
    }
    if (action == pageActionEnum.None) {

        ParentUserControlName = tabobject.get_selectedTab()._attributes.getAttribute("UcName");
         if ((AutoSaveXMLDom != undefined) && (CheckForBlankNeed(true, dom) == true)) {
        }
    }
    if (action == "update") {
        var tabName = tabobject.get_selectedTab()._attributes.getAttribute("UcName");
        if (tabName == "HRMNeedList") {
            tabUserControlName = tabName;
        }
        if (tabName == "PrePlan") {
            var Meetintgtime = GetColumnValueInXMLNodeByKeyValue('CustomDocumentPrePlanningWorksheet', 'DocumentVersionId', DocumentVersionId, 'MeetingTime', AutoSaveXMLDom[0]);
           
            $("#TextBoxTime_CustomDocumentPrePlanningWorksheet_MeetingTime").val(Meetintgtime);
        }

        //if (tabUserControlName == "HRMMentalStatus") {
           
        //    MentalStatusExamSetScreenSpecificValues();
        //}

    }
    var _hrmAssessmentDocumentId = -1;
    var xmlHrmAssessmentRow = null;
    // Code for  DX tab begin
    var _checkBoxClientInDDPopulation = 'N';
    var _checkBoxClientInSAPopulation = 'N';
    var _checkBoxClientInMHPopulation = 'N';

    var CSSRSAdultSinceLT = tabobject.findTabByText('Columbia');
    MentalStatusExamSetScreenSpecificValues(dom, action);
   
    var Check = GetFielValueFromXMLDom(AutoSaveXMLDom, "CustomDocumentMHAssessments", "AssessmentType");
    var TabStatus = GetFielValueFromXMLDom(AutoSaveXMLDom, "CustomDocumentMHAssessments", "AdultOrChild");
    xmlHrmAssessmentRow = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");


     if (xmlHrmAssessmentRow[0].selectNodes("ClientInDDPopulation").length > 0 && xmlHrmAssessmentRow[0].selectNodes("ClientInDDPopulation")[0].text.trim() == 'Y') {
        _checkBoxClientInDDPopulation = 'Y';
    }

    if (xmlHrmAssessmentRow[0].selectNodes("ClientInSAPopulation").length > 0 && xmlHrmAssessmentRow[0].selectNodes("ClientInSAPopulation")[0].text.trim() == 'Y') {
        _checkBoxClientInSAPopulation = 'Y';
    }
    else if (xmlHrmAssessmentRow[0].selectNodes("ClientInMHPopulation").length > 0 && xmlHrmAssessmentRow[0].selectNodes("ClientInMHPopulation")[0].text.trim() == 'Y') {
        _checkBoxClientInMHPopulation = 'Y';

    }
    AgeRadioButtonCheck(dom);
    if (objectPageResponse.ScreenProperties.CustomHrmActivities != undefined) {
        $("[id$=HiddenCustomHRMActivitiesDataTable]").val(unescape(objectPageResponse.ScreenProperties.CustomHrmActivities));
    }

    if (objectPageResponse.ScreenProperties.UpdateAsseeementType != undefined) {
        $('#HiddenUpdateAssessmentText').val(objectPageResponse.ScreenProperties.UpdateAsseeementType);
    }

 
    if ((action == pageActionEnum.Update || action == pageActionEnum.None) && tabobject != null) {
     
    }

    if ((dom != "" && dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0)) {
       
        if (xmlHrmAssessmentRow[0].selectNodes("ExistLatestSignedDocumentVersion").length > 0) {
            var existLatestSignedDocumentVersionId = xmlHrmAssessmentRow[0].selectNodes("ExistLatestSignedDocumentVersion")[0].text.trim();
            if (existLatestSignedDocumentVersionId == 'N') {
                $("#TdAssessmentTypeUpdate").hide();
                $("#TdAssessmentTypeLabelUpdate").hide();
                $("#TdAssessmentTypeAnnual").hide();
                $("#TdAssessmentTypeLabelAnnual").hide();

                if ($('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').is(':checked') || $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').is(':checked') || $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').is(':checked')) {

                }
                else {
                    $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]').click();
                }
            }
            else {
                $("#TdAssessmentTypeUpdate").show();
                $("#TdAssessmentTypeLabelUpdate").show();
                $("#TdAssessmentTypeAnnual").show();
                $("#TdAssessmentTypeLabelAnnual").show();

                if ($('#RadioButton_CustomDocumentMHAssessments_AssessmentType_I').is(':checked') || $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_U').is(':checked') || $('#RadioButton_CustomDocumentMHAssessments_AssessmentType_A').is(':checked')) {

                }
                else {
                    $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]').click();
                }
            }
        }
        if ((objectPageResponse.ScreenProperties != null && objectPageResponse.ScreenProperties.DeleteCustomHrmNeeds == "False") || action == pageActionEnum.TabRequest) {
            _DeleteAssessmentHrmNeeds = false;

        }
        else {
            _DeleteAssessmentHrmNeeds = true;

        }


        if ((dom != "" && dom[0].childNodes[0].selectNodes("Documents").length > 0)) {
            var xmlDocumentsRow = dom[0].childNodes[0].selectNodes("Documents");
            _hrmAssessmentDocumentId = parseInt(xmlDocumentsRow[0].selectNodes("DocumentId")[0].text.trim());
            if (_hrmAssessmentDocumentId > 0) {
                DisableAssessmentScreenType(true);
            }
            else
                DisableAssessmentScreenType(false);
        }

        if (dom != "" && dom[0].childNodes[0].selectNodes("CustomClientNeeds").length > 0) {
            var xmlNeedsFromTX = dom[0].childNodes[0].selectNodes("CustomClientNeeds");
            for (var j = 0; j < dom[0].childNodes[0].selectNodes("CustomClientNeeds").length; j++) {

                var needNameTx = xmlNeedsFromTX[j].selectNodes("NeedName")[0].text.trim();
                var needDescriptionTx = xmlNeedsFromTX[j].selectNodes("NeedDescription")[0].text.trim();
                var clientNeedIdTx = xmlNeedsFromTX[j].selectNodes("ClientNeedId")[0].text.trim();

            }
           
        }

     
        if (action == pageActionEnum.New || action == pageActionEnum.None) {
            SelectCheckBoxExist(dom);
        }

        if (_hrmAssessmentDocumentId > 0) {
            var uncopeApplicable = xmlHrmAssessmentRow[0].selectNodes("UncopeApplicable");
            if (uncopeApplicable.length > 0 && uncopeApplicable[0].text.trim() == 'Y') {
                SetEnableDisableUncope('Y', dom);
            }
            else if (uncopeApplicable.length > 0 && uncopeApplicable[0].text.trim() == 'N') {
                SetEnableDisableUncope('N', dom);
            }
            //Enable Disable Craff tab Radio based on value
            var _customDocumentCrafftRow = dom[0].childNodes[0].selectNodes("CustomDocumentMHCRAFFTs");
            if (_customDocumentCrafftRow.length > 0) {
                var crafftApplicable = _customDocumentCrafftRow[0].selectNodes("CrafftApplicable");
                if (crafftApplicable.length > 0 && crafftApplicable[0].text.trim() == 'Y') {
                    SetEnableDisableCrafft('Y', dom);
                }
                else if (crafftApplicable.length > 0 && crafftApplicable[0].text.trim() == 'N') {
                    SetEnableDisableCrafft('N', dom);
                }
            }
        }

    
        if (xmlHrmAssessmentRow[0].selectNodes("PrePlanSeparateDocument").length > 0 && xmlHrmAssessmentRow[0].selectNodes("PrePlanSeparateDocument")[0].text.trim() == 'Y') {
            hideTable();
        }
     

        SetTelerikControls(action, dom);
        DisableTreatmentSection(dom);
        EnableSummaryTreatmentComment();
        DisableSummaryTreatmentComment();
      
        EnableDusableInitilaSection(dom);
        if (tabobject != null) {
           
          if (tabobject.get_selectedTab().get_text().indexOf('Psychosocial Child') >= 0) {
                SetMedicationControls(dom);
              
                EnableDisabeNeedListCheckBoxex(tabobject.get_selectedTab()._properties._data._implPageViewID);
            }
            else if (tabobject.get_selectedTab().get_text().indexOf('Psychosocial Adult') >= 0) {
                SetMedicationControls(dom);
             
                EnableDisabeNeedListCheckBoxex(tabobject.get_selectedTab()._properties._data._implPageViewID);
            }
          
            else if (tabobject.get_selectedTab().get_text().indexOf('Risk Assessment') >= 0) {
                CheckSuicideActivePassive();
                CheckHomicideActivePassive();

               
                DisabledHomicidality(dom);
                DisabledSuicidality();

                 DisabledPsychiatricAdvanceDirectives();
                 EnableDisabeNeedListCheckBoxex(tabobject.get_selectedTab()._properties._data._implPageViewID);
            }
            
            else if (tabobject.get_selectedTab().get_text().indexOf('Dx') >= 0) {
                DxTabEnableDisable(_checkBoxClientInDDPopulation, _checkBoxClientInSAPopulation, _checkBoxClientInMHPopulation, xmlHrmAssessmentRow);
                SetDiagnosisOrder(dom);
            }
            else if (tabobject.get_selectedTab().get_text().indexOf('Disposition') >= 0) {
               
                if (DispositionControl != null) {
                    DispositionControl.BindDispositionEvents("divDisposition");
                }
               
            }
           
            else if (tabobject.get_selectedTab().get_text().indexOf('UNCOPE') >= 0) {
                EnableDisableCheckBox();
                
            }
            else if (tabobject.get_selectedTab().get_text().indexOf('CRAFFT') >= 0) {
                EnableDisableCheckBox();
               
            }
            
            
        }
      
        if (tabobject.get_selectedTab().get_text().indexOf('Initial') >= 0) {
            SetPreviousAssessmentType();
        }
       
        //Code for  DX tab End
        SetGuardianInfoControl(dom);

    }
    CSSRSHideAndShow();
    if (tabUserControlName == "CSSRSChildAdolescentSinceLT" || tabobject.get_selectedTab().get_text() == 'Columbia') {
        RefreshCSSRSChildAdolescentSinceLTHideandShow();
        $('#Img1').wTooltip({ content: $("input[id$=ActualLethalityMedicalDamage]").val() });
        $('#image_information').wTooltip({ content: $("input[id$=PotentialLethality]").val() });
    }
  
    try {

        if (tabobject != null && tabobject != undefined && tabobject.get_selectedTab().get_text() == 'Psychosocial Adult') {
            $('input[id$=HiddenField_CustomHRMAssessmentMedications_HRMAssessmentMedicationId]')[0].value = '';
        }
        else if (tabobject != null && tabobject != undefined && tabobject.get_selectedTab().get_text() == 'Psychosocial Child') {
            $('input[id$=HiddenField_CustomHRMAssessmentMedications_HRMAssessmentMedicationId]')[0].value = '';
        }
        
    } catch (e)
    {
       
    }
}




function ShowHideTextArea() {
    var ReductionInSymptoms = $("#CheckBox_CustomDocumentMHAssessments_ReductionInSymptoms");
    var AttainmentOfHigherFunctioning = $('#CheckBox_CustomDocumentMHAssessments_AttainmentOfHigherFunctioning');
    var TreatmentNotNecessary = $('#CheckBox_CustomDocumentMHAssessments_TreatmentNotNecessary');
    var OtherTransitionCriteria = $('#CheckBox_CustomDocumentMHAssessments_OtherTransitionCriteria');

    var ReductionInSymptomsDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_ReductionInSymptomsDescription]");
    var AttainmentOfHigherFunctioningDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_AttainmentOfHigherFunctioningDescription]");
    var TreatmentNotNecessaryDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_TreatmentNotNecessaryDescription]");
    var OtherTransitionCriteriaDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_OtherTransitionCriteriaDescription]");
    if (ReductionInSymptoms.length > 0 && $(ReductionInSymptomsDescriptionObject).length > 0) {
        if (ReductionInSymptoms.is(":checked")) {
            $(ReductionInSymptomsDescriptionObject).closest("tr").show();
        }
        else {
            $(ReductionInSymptomsDescriptionObject).closest("tr").hide();
        }
    }
    else {
        $(ReductionInSymptomsDescriptionObject).closest("tr").hide();
    }
    if (AttainmentOfHigherFunctioning.length > 0 && $(AttainmentOfHigherFunctioningDescriptionObject).length > 0) {
        if (AttainmentOfHigherFunctioning.is(":checked")) {
            $(AttainmentOfHigherFunctioningDescriptionObject).closest("tr").show();
        }
        else {
            $(AttainmentOfHigherFunctioningDescriptionObject).closest("tr").hide();
        }
    }
    else {
        $(AttainmentOfHigherFunctioningDescriptionObject).closest("tr").hide();
    }
    if (TreatmentNotNecessary.length > 0 && $(TreatmentNotNecessaryDescriptionObject).length > 0) {
        if (TreatmentNotNecessary.is(":checked")) {
            $(TreatmentNotNecessaryDescriptionObject).closest("tr").show();
        }
        else {
            $(TreatmentNotNecessaryDescriptionObject).closest("tr").hide();
        }
    }
    else {
        $(TreatmentNotNecessaryDescriptionObject).closest("tr").hide();

    }
    if (OtherTransitionCriteria.length > 0 && $(OtherTransitionCriteriaDescriptionObject).length > 0) {
        if (OtherTransitionCriteria.is(":checked")) {
            $(OtherTransitionCriteriaDescriptionObject).closest("tr").show();
        }
        else {
            $(OtherTransitionCriteriaDescriptionObject).closest("tr").hide();
        }
    }
    else {
        $(OtherTransitionCriteriaDescriptionObject).closest("tr").hide();
    }
}


function ShowHideDxDDSectionInDiagnosis(showDDSection) {
    if (showDDSection == true) {
        $('#TdDxDDSection')[0].visible = true;
        $('#TdDxDDSection')[0].style.display = 'block';
        $('#TdDxDDBottomSection')[0].visible = true;
        $('#TdDxDDBottomSection')[0].style.display = 'block';



    }
    else {
        $('#TdDxDDSection')[0].visible = false;
        $('#TdDxDDSection')[0].style.display = 'none';
        $('#TdDxDDBottomSection')[0].visible = true;
        $('#TdDxDDBottomSection')[0].style.display = 'none';

    }

}

function SetTabsType(Dom) {
   
    __DeleteAssessmentHrmNeeds = true;
    AssessmentType(Dom);
    if (AssessmentTypeI.checked || AssessmentTypeU.checked || AssessmentTypeA.checked) {
        var SAPopulation = $("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation")[0];
        var DDPopulation = $("#CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation")[0];
        var SUAssessment_tab = tabobject.findTabByText('Substance Abuse');
        var DiagnosisIDDEligibility_tab = tabobject.findTabByText('Diagnosis-IDD Eligibility');
        var FunctionalAssessment_tab = tabobject.findTabByText('Functional Assessment');
        var PHQ9_tab = tabobject.findTabByText('PHQ9');
       
        if (SAPopulation.checked) {
            SUAssessment_tab.set_visible(true);
        }
        else {
            SUAssessment_tab.set_visible(false);
            if ($("#RadioButton_CustomDocumentMHAssessments_AdultOrChild_A")[0].checked == true) {
                AddExtraTabUncopeEvent();
            }
            else {
                AddExtraTabCrafftEvent();
            }

        }
        if (DDPopulation.checked)
        {
            $('#Textbox_PHQ9Documents_PerformedDate').removeAttr('required');
            $('#Textbox_PHQ9Documents_PerformedTime').removeAttr('required');
            PHQ9_tab.set_visible(false);             
            DiagnosisIDDEligibility_tab.set_visible(true);
            FunctionalAssessment_tab.set_visible(true); 
        }
        else {
            if ($("#RadioButton_CustomDocumentMHAssessments_AdultOrChild_A")[0].checked == true) {
                // $('#Textbox_PHQ9Documents_PerformedDate').attr('required', 'required');
                // $('#Textbox_PHQ9Documents_PerformedTime').attr('required', 'required');
                PHQ9_tab.set_visible(true);
            } 
            DiagnosisIDDEligibility_tab.set_visible(false);
            FunctionalAssessment_tab.set_visible(false);
        }

    }
    //  SetTabs(Dom, undefined);

    else {
        $("#CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation")[0].checked = false;
        $("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation")[0].checked = false;
        $("#CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation")[0].checked = false;
        ShowMsgBox('Select Assessment type (Initial, Update, Annual).', ConfirmationMessageCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        return;
    }
}

//Function Added by Loveena in ref to Task#296 5.10 - HRM Assessment: Initial Tab: Adult/Child Radio buttons
//to handle click events of Adult and Child radio button
function ShowHideAdultChildTabsEvent(Obj) {
    RadioButtonAdultorChild = $("#RadioButton_CustomDocumentMHAssessments_AdultOrChild_A")[0];
    HideAdultChildTabs(RadioButtonAdultorChild);    
}

function OpenASASM() {
    if (Dirty == "True" || UnsavedChangeId > 0) {
        ShowMsgBox('Please save the existing unsaved record for this screen prior to Open the ASAM document', 'Confirmation', MessageBoxButton.OK, MessageBoxIcon.Information);
        return false;
    }
    else {
        OpenPage(5763, 2701, 'ClientID=' + ClientID, null, GetRelativePath(), null, null, null, 2, null, null);
    }
}

function HideAdultChildTabs(RadioButtonAdultorChild, Dom) {
    
    var CAFAS = tabobject.findTabByText('CAFAS');
    var PECFAS = tabobject.findTabByText('PECFAS');
    var CRAFFT_tab = tabobject.findTabByText('CRAFFT');
    var UNCOPE_tab = tabobject.findTabByText('UNCOPE');
    var SubstanceAbuse = tabobject.findTabByText('Substance Abuse');
    var PES = tabobject.findTabByText('PES');
    var Child_tab = tabobject.findTabByText('Psychosocial Child');
    var Adult_tab = tabobject.findTabByText('Psychosocial Adult');
    var NeedList_tab = tabobject.findTabByText('Needs List');
    var PsychoDD = tabobject.findTabByText('Psychosocial DD');
    var PHQ9 = tabobject.findTabByText('PHQ9');
    var PHQA = tabobject.findTabByText('PHQ-A');
    var DiagnosisIDDEligibility_tab = tabobject.findTabByText('Diagnosis-IDD Eligibility');
    var FunctionalAssessment_tab = tabobject.findTabByText('Functional Assessment');
    var AssessmentS = "N";
    var Adult = "C";
    var AssessmentTypeDD;
    var AssessmentDD ='N'
    AssessmentTypeS = $("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation")[0];
    AssessmentTypeDD = $("#CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation")[0];
    if (AssessmentTypeS == undefined) {
        var AssessmentXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
        if (AssessmentXml.length > 0) {
            var SANode = AssessmentXml[0].selectNodes("ClientInSAPopulation");
            if (SANode.length > 0) {
                var SAtext = SANode[0].text;
                if (SAtext == 'Y') {
                    AssessmentS = "Y";
                }
            }
        }
    }
    if (AssessmentTypeDD!=undefined)
    {
        if(AssessmentTypeDD.checked == true)
            AssessmentDD = "Y"
    }
    if (AssessmentTypeDD == undefined) {
        var AssessmentXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
        if (AssessmentXml.length > 0) {
            var DDNode = AssessmentXml[0].selectNodes("ClientInDDPopulation");
            if (DDNode.length > 0) {
                var DDtext = DDNode[0].text;
                if (DDtext == 'Y') {
                    AssessmentDD = "Y";
                }
            }
        }
    }
    if (RadioButtonAdultorChild == undefined) {
        var AssessmentXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
        if (AssessmentXml.length > 0) {
            var SANode = AssessmentXml[0].selectNodes("AdultOrChild");
            if (SANode.length > 0) {
                var SAtext = SANode[0].text;
                if (SAtext == 'A') {
                    Adult = "A";
                }
            }
        }
    }

    if (TabIndex != 5)
        ShowHideAssessmentHRMTab(SubstanceAbuse, false);

    if (PsychoDD != null) {
        ShowHideAssessmentHRMTab(PsychoDD, false);
    }
    if (DiagnosisIDDEligibility_tab != null) {
        ShowHideAssessmentHRMTab(DiagnosisIDDEligibility_tab, false);
    }
    if (FunctionalAssessment_tab != null) {
        ShowHideAssessmentHRMTab(FunctionalAssessment_tab, false);
    }
    if (NeedList_tab != null) {
        ShowHideAssessmentHRMTab(NeedList_tab, true);
    } 
    if (AssessmentDD == "Y" || AutoSaveXMLDom.find("CustomDocumentMHAssessments:first ClientInDDPopulation").text().trim() == "Y") {
        ShowHideAssessmentHRMTab(PHQ9, false);
        if (DiagnosisIDDEligibility_tab != null) {
            ShowHideAssessmentHRMTab(DiagnosisIDDEligibility_tab, true);
        }
        if (FunctionalAssessment_tab != null) {
            ShowHideAssessmentHRMTab(FunctionalAssessment_tab, true);
        }
    }
 
    if ((RadioButtonAdultorChild != undefined && RadioButtonAdultorChild.checked == true) || Adult == "A") { 
        
        if (PECFAS != null) {
            ShowHideAssessmentHRMTab(PECFAS, false);

        }
        if (CAFAS != null) {
            ShowHideAssessmentHRMTab(CAFAS, false);

        }
        if (CRAFFT_tab != null) {
            ShowHideAssessmentHRMTab(CRAFFT_tab, false);
            if ($('[id$=CrafftAssessment]').length > 0)
                $('[id$=CrafftAssessment]').html('');
        }
        if (UNCOPE_tab != null) {
            ShowHideAssessmentHRMTab(UNCOPE_tab, true);
            AddExtraTabUncopeEvent();
        }

        if (PES != null) {
            ShowHideAssessmentHRMTab(PES, true);
        }
        if (Child_tab != null) {
            ShowHideAssessmentHRMTab(Child_tab, false);
        }
        if (Adult_tab != null) {
            ShowHideAssessmentHRMTab(Adult_tab, true);
        }
        if (PHQA != null) {
            ShowHideAssessmentHRMTab(PHQA, false);
        } 
         
        if (PHQ9 != null && ( AssessmentDD == "Y")) {
            $('#Textbox_PHQ9Documents_PerformedDate').removeAttr('required');
            $('#Textbox_PHQ9Documents_PerformedTime').removeAttr('required');
            ShowHideAssessmentHRMTab(PHQ9, false);
        }
        else {            
            $('#Textbox_PHQ9Documents_PerformedDate').attr('required', 'required');
            $('#Textbox_PHQ9Documents_PerformedTime').attr('required', 'required');
            ShowHideAssessmentHRMTab(PHQ9, true);
        }       

    }
    else {
        var clientage;
        var _age;
        var _ageinYears;
        if ($('#Span_CustomDocumentMHAssessments_clientAge').length > 0) {
            clientage = $('#Span_CustomDocumentMHAssessments_clientAge');
            _age = parseInt(clientage.html().split(' ')[0]);
            _ageinYears = clientage.html().split(' ')[1].trim();
        }
        else {
            clientage = GetFielValueFromXMLDom(AutoSaveXMLDom, "CustomDocumentMHAssessments", "clientAge");
            _age = parseInt(clientage.split(' ')[0]);
            _ageinYears = clientage.split(' ')[1];
        }

        if (CAFAS != null) {
            
            if (_ageinYears == 'Years') {
                
                if ((clientage.length > 0 && _age >= 7) && _age <= 17) {
                    ShowHideAssessmentHRMTab(CAFAS, true);
                }
                else {  ShowHideAssessmentHRMTab(CAFAS, false);}
            }
            else {

                ShowHideAssessmentHRMTab(CAFAS, false);

            }
        }
        if (PECFAS != null) {
            if (_ageinYears == 'Years') {
                if ((clientage.length >= 0 && _age >= 0) && _age <= 6) {
                    ShowHideAssessmentHRMTab(PECFAS, true);
                }
                else { ShowHideAssessmentHRMTab(PECFAS, false); }
            }
            else {

                ShowHideAssessmentHRMTab(PECFAS, false);

            }
        }

        if (CRAFFT_tab != null) {
            ShowHideAssessmentHRMTab(CRAFFT_tab, true);
            AddExtraTabCrafftEvent();
        }
        if (UNCOPE_tab != null) {
            ShowHideAssessmentHRMTab(UNCOPE_tab, false);
            if ($('[id$=HRMUncope]').length > 0)
                $('[id$=HRMUncope]').html('');
        }

        if (PES != null) {
            ShowHideAssessmentHRMTab(PES, false);
        }
        if (Child_tab != null) {
            ShowHideAssessmentHRMTab(Child_tab, true);
        }
        if (Adult_tab != null) {
            ShowHideAssessmentHRMTab(Adult_tab, false);
        }
        if (PHQA != null) {
            ShowHideAssessmentHRMTab(PHQA, true);
        }
        if (PHQ9 != null) {
            ShowHideAssessmentHRMTab(PHQ9, false);
        }

    }
    if ((AssessmentTypeS != undefined && AssessmentTypeS.checked) || AssessmentS == "Y") {
        if (SubstanceAbuse != null) {
            ShowHideAssessmentHRMTab(SubstanceAbuse, true);
        }
    }
}

function ValidateClientDateOfBirth() {
    var CustomDocumentMHAssessments = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
    if (CustomDocumentMHAssessments.length > 0 && CustomDocumentMHAssessments[0].selectNodes("ClientDOB").length <= 0) {
        ShowHideErrorMessage('Client DOB Can not be empty', 'true');
        return false;
    }
    else if ($.xmlDOM(objectPageResponse.PageDataSetXml).find("CustomDocumentMHAssessments").length > 0 && $.xmlDOM(objectPageResponse.PageDataSetXml).find("CustomDocumentMHAssessments").find("ClientDOB").length <= 0) {
        ShowHideErrorMessage('Client DOB Can not be empty', 'true');
        return false;
    }
    else {
        return true;
    }
}



function ReInitializeAssessment(ControlID) {
    //Modified by Mamta Gupta - Ref Task No. 687 - 15/Feb/2012 - To show processing while radio button clicked
    parent.PopupProcessing();
    UpdateAutoSaveXmlNode('CustomDocumentMHAssessments', "AssessmentType", $("#" + ControlID).val());
    if (ValidateClientDateOfBirth() == false) {
        $("#" + ControlID).attr("checked", false);
        CreateAutoSaveXml('CustomDocumentMHAssessments', "AssessmentType", "");
        return false;
    }

    
    var fnName = 'GetPopUpOnUpdate';
    $.post(GetRelativePath() + "AjaxScript.aspx?functionName=" + fnName + "&AssessmentType=" + $("#" + ControlID).val(), function(result) { onSuccessPopUpOnUpdate(result, ControlID); }
       );
    
}



function onSuccessPopUpOnUpdate(result, ControlID) {
    var UpdateAssessmentText = result;
    var action = "Reinitilize";
    ConfirmMessageForCompleteDocumentOnOK(action);
   }
//Description:Function is used for adding extra tab for uncope

function AddExtraTabUncopeEvent() {
    try {
        var SUAssessment_tab = tabobject.findTabByText('Substance Abuse');
        var Count = 0;
        if (SUAssessment_tab != null) {
          
            if ($("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionU_Y").length > 0 && $("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionP_Y").length > 0) {
                if ($("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionU_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionN_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionC_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionO_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionP_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHAssessments_UncopeQuestionE_Y").attr("checked") == true) {
                    Count++;
                }
            }
            else {
                //if the radio buttons are not yet loaded
                var CrafftXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
                if (CrafftXml.length > 0) {
                    var CraftNode = CrafftXml[0].selectNodes("UncopeQuestionU");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("UncopeQuestionN");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("UncopeQuestionC");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("UncopeQuestionO");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("UncopeQuestionP");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("UncopeQuestionE");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                }
            }
            if (Count > 2) {
                if (SUAssessment_tab != null) {
                    SUAssessment_tab.show();
                    SUAssessment_tab.set_visible(true);
                }
            }
            else {
                
                if ($("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation").length > 0) {
                    if ($("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation").attr("checked") != true) {
                        if (SUAssessment_tab != null) {
                            SUAssessment_tab.hide();
                            SUAssessment_tab.set_visible(false);
                        }
                    }
                }
                //else if (SUAssessment_tab != null) {
                //    SUAssessment_tab.hide();
                //    SUAssessment_tab.set_visible(false);
                //}
            }


            if ($("#CheckBox_CustomDocumentMHAssessments_UncopeCompleteFullSUAssessment").length > 0) {
                if (($("#CheckBox_CustomDocumentMHAssessments_UncopeCompleteFullSUAssessment").attr("checked") == true) && (Count < 3)) {
                    if (SUAssessment_tab != null) {
                        SUAssessment_tab.show();
                        SUAssessment_tab.set_visible(true);
                    }
                }
            }
        }
    }
    catch (ex) {
        throw ex;
    }
}





function AssessmentType(dom) {
    AssessmentTypeI = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]');
    AssessmentTypeU = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]');
    AssessmentTypeA = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]');

  

    if (dom == undefined) {
        if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]')[0].checked)
            AssessmentTypeI.checked = true; 

        if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]')[0].checked)
            AssessmentTypeU.checked = true;

        if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]')[0].checked)
            AssessmentTypeA.checked = true;

       
    }
    else {
        if ((dom != "" && dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0)) {
            xmlAssessmentType = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");

           
            var AssessmentType = '';
            if (xmlAssessmentType[0].selectNodes("AssessmentType").length > 0)
                AssessmentType = xmlAssessmentType[0].selectNodes("AssessmentType")[0].text;
            if (AssessmentType == 'I') {
                AssessmentTypeI.checked = true;
            }
            if (AssessmentType == 'U') {
                AssessmentTypeU.checked = true;
            }
            if (AssessmentType == 'A') {
                AssessmentTypeA.checked = true;
            }
           
        }
    }
}

function AddEventHandlers() {
    try {
       
        if ($('#[id$=Image_SelfCareSkills],#[id$=Image_DailyLivingSkills],#[id$=Img_Social],#[id$=Img_Emotional],#[id$=Img_CommunityLivingSkills]').length > 0) {
            $('#[id$=Image_SelfCareSkills],#[id$=Image_DailyLivingSkills],#[id$=Img_Social],#[id$=Img_Emotional],#[id$=Img_CommunityLivingSkills]').wTooltip({
                content: "0 = Independent, no or minor reminders prompting. Individual can perform activity with no/minimal prompting (approx. 100% independence/skill)<br/>1 = Verbal prompts, reminders, limited hands on assistance. Individual can perform majority of activity (approx. 75% independence/skill)<br/>2 = Limited assistance, more verbal prompts and/or light physical prompts, encouragement, setting up activity, individual performs some of task/activity (approx. 50% independence/skill)<br/>3 = Moderate assistance, physical prompts, verbal step by step instructions, individual performs portion of task/activity (approx. 25% independence/skill)<br/>4 = Total assistance. Individual cannot perform any part of task without full staff assistance (no/minimal independence/skill)<br/>N/A = Not applicable/Not age appropriate. Only allowable for clients age 0-17."
            });
        }

        if ($('#[id$=Img_Behavioral]').length > 0) {
            $('#[id$=Img_Behavioral]').wTooltip({
                content: "0 = not present, no intervention required<br/>1 = minor and/or rare occurrences, limited verbal intervention<br/>2 = mild occurrences, regular physical, environmental and/or frequent verbal intervention required<br/>3= moderate occurrences, regular physical, environmental and/or frequent verbal intervention required<br/>4 = significant occurrences (intensity and/or frequency), daily and/or intensive intervention required<br/>N/A = Not assessed"
            });
        }
        if (tabobject != null && tabobject != undefined) {//Surya.B Added code for Needs List Tab blank issue
            tabUserNeeds = tabobject.get_selectedTab()._attributes.getAttribute("UcName");
        }
        if ($("#RadioButton_CustomDocumentMHAssessments_PsMedications_I").is(":checked")) {
            var colomnValue = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', DocumentVersionId, 'PsMedicationsListToBeModified', AutoSaveXMLDom[0]);
            var radioButton = '#RadioButton_CustomDocumentMHAssessments_PsMedications_I';
            var textArea = '#TextArea_CustomDocumentMHAssessments_PsMedicationsComment';
            var divMedication = '#DivMedications';
            $(radioButton, $("#" + ParentUserControlName)).attr("checked", true);


            if (colomnValue == 'Y') {
                $(textArea, $("#" + ParentUserControlName)).attr("disabled", false);
            }
            else {
                $(textArea, $("#" + ParentUserControlName)).attr("disabled", true);
            }
            $(textArea, $("#" + ParentUserControlName)).show();
            
            $('#listMedication').hide();
            $('#tablecomments').show();
           $(divMedication, $("#" + ParentUserControlName)).show();
        }

        else if ($("#RadioButton_CustomDocumentMHAssessments_PsMedications_L").is(":checked")) {
            DisappearMedication('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', '#DivMedications');
        }
        else {
            if ($("#RadioButton_CustomDocumentMHAssessments_PsMedications_L").length > 0 && $("#RadioButton_CustomDocumentMHAssessments_PsMedications_L") != undefined) {
                DisableMedication('#TextArea_CustomDocumentMHAssessments_PsMedicationsComment', '#DivMedications');
            }
        }

        if (tabUserNeeds == "HRMNeedList" || tabUserNeeds.endsWith("HRMNeedList")) {
            FillNeedsTabTemplate();
            var DivNeedLists = $("#DivNeedLists");

            var LabelNeedErrorMsg = $("label[id$=LabelNeedErrorMsg]", DivNeedLists);
            if (LabelNeedErrorMsg.length > 0) {
                LabelNeedErrorMsg.hide();
            }
        }
        if (tabUserNeeds == "PrePlan")
        {
            var Meetintgtime = GetColumnValueInXMLNodeByKeyValue('CustomDocumentPrePlanningWorksheet', 'DocumentVersionId', DocumentVersionId, 'MeetingTime', AutoSaveXMLDom[0]);
            $("#TextBoxTime_CustomDocumentPrePlanningWorksheet_MeetingTime").val(Meetintgtime);
        }

        if (tabUserNeeds == "HRMMentalStatus") {
            MentalStatusExamAddEventHandlers();
        }

        BindPsychosocialstepper();
        ShowHideTextArea();

        $("#TextBox_DiagnosesIAndII_DiagnosisOrder").each(function() {
            $(this).keyup(function() {
                RetainOrderForDiagnosisIandII(this);
            })
        });


        ShowHideAdultChildTabsEvent();
        CSSRSHideAndShow();


        if (tabUserControlName == "HRMSuAssessment") {
            if ($("#RadioButton_CustomSubstanceUseAssessments_MedicationAssistedTreatment_A").is(":checked")) {
                $('#TextArea_CustomSubstanceUseAssessments_MedicationAssistedTreatmentRefferedReason').attr("disabled", true);
            }
        }

       
        if (tabUserControlName == "CSSRSChildAdolescentSinceLT") {
            RefreshCSSRSChildAdolescentSinceLTHideandShow();
            $('#Img1').wTooltip({ content: $("input[id$=ActualLethalityMedicalDamage]").val() });
            $('#image_information').wTooltip({ content: $("input[id$=PotentialLethality]").val() });
        }

        var disablePHQ9Tabcalling ='N';
         if ($('[id$=CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation]')[0]!=undefined) {
             if ($('[id$=CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation]')[0].checked == true) { disablePHQ9Tabcalling = 'Y' }
        }
        else {
            var AssessmentXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            if (AssessmentXml.length > 0) {
                var DDNode = AssessmentXml[0].selectNodes("ClientInDDPopulation");
                if (DDNode.length > 0) {
                    var DDtext = DDNode[0].text;
                    if (DDtext == 'Y') {
                        disablePHQ9Tabcalling = "Y"; 
                    }
                }
            }
        } 
         var PHQ9_tab = tabobject.findTabByText('PHQ9');
         var AdultOrChildXML = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
         if (AdultOrChildXML.length > 0) {
             var AdultOrChildDD = AdultOrChildXML[0].selectNodes("AdultOrChild");
         }
         if (AdultOrChildDD.length > 0) {
             var AdultOrChildText = AdultOrChildDD[0].text;
         }
        if (disablePHQ9Tabcalling == 'Y') {            
            $('#Textbox_PHQ9Documents_PerformedDate').removeAttr('required');
            $('#Textbox_PHQ9Documents_PerformedTime').removeAttr('required');
            PHQ9_tab.set_visible(false);
        }
        else if (disablePHQ9Tabcalling == 'N' && AdultOrChildText == 'A') {
            $('#Textbox_PHQ9Documents_PerformedDate').attr('required', 'required');
            $('#Textbox_PHQ9Documents_PerformedTime').attr('required', 'required');
            BindControlChangeEventsPHQ9();
        }
        if (tabUserNeeds == "PHQA") {
            BindControlChangeEventsPHQA();
        }
        
    
        AssessmentRecordInitialization();
         
       
    }
    catch (err) {
        
        LogClientSideException(err, 'MentalStatus');
    }
}

function ChangeDomObject(action) {
    if (action == pageActionEnum.TabRequest)
        return AutoSaveXMLDom;

}



function ClientTabSelectingHandler(sender, eventArgs) {
    
        var AssessmentType = "";
        if ($("#RadioButton_CustomDocumentMHAssessments_AssessmentType_I").length > 0 && $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]').attr('checked')) {
            AssessmentType = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]').val();
        }
        else if ($("#RadioButton_CustomDocumentMHAssessments_AssessmentType_U").length > 0 && $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]').attr('checked')) {
            AssessmentType = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]').val();
        }
        else if ($("#RadioButton_CustomDocumentMHAssessments_AssessmentType_A").length > 0 &&  $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]').attr('checked')) {
            AssessmentType = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]').val();
        }
        else {
            if (AutoSaveXMLDom != "" && AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0) {
                var CustomDocumentMHAssessments = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
                if (CustomDocumentMHAssessments[0].selectNodes("AssessmentType").length > 0) {
                    AssessmentType = CustomDocumentMHAssessments[0].selectNodes("AssessmentType")[0].text;
                }
            }
        }
         
        if (AssessmentType == "" || AssessmentType == " ") {
            eventArgs.set_cancel(true);
            ShowHideErrorMessage('Please select any option from Initial,Update or Annual', 'true');
            return false;
        }
        else {
            var tabStrip = sender;
            var tab = eventArgs._tab;
            if (ParentUserControlName == "HRMNeedList") {
            }
        return true;
        }
}
    




//Code added by Loveena in ref to Task#916 5.7 - HRM Assessment: DD Fields on Mental Status tab missing
function DisappearSevereProfoundDisability(checkbox, trSevereProfoundDisability) {
   if ($(checkbox).is(":checked")) {
        $(trSevereProfoundDisability).show();
        $("#trHRMMentalStatus").find("input,button,textarea,div,select,label,span").attr("disabled", "disabled");
    }
    else {
        $(trSevereProfoundDisability).hide();
        $("#trHRMMentalStatus").find("input,button,textarea,div,select,label,span").removeAttr("disabled");
    }
}




function ShowHideMentalStatusDDSection(showDDSection) {
    if (showDDSection == true) {
        $('#TableServerProfoundDisability')[0].visible = true;
        $('#TableServerProfoundDisability')[0].style.display = 'block';
    }
    else {
        $('#TableServerProfoundDisability')[0].visible = false;
        $('#TableServerProfoundDisability')[0].style.display = 'none';

    }
}



///Purpose : This function is used to set values for Dom Manipulation on HRMSupport page

var primaryKeySet = false;

// Function to call enable disable DX controls
function DxTabEnableDisable(_checkBoxClientInDDPopulation, _checkBoxClientInSAPopulation, _checkBoxClientInMHPopulation, xmlHrmAssessmentRow) {
    var _AdultOrChild = null;
    var _screenType = null;
    if (xmlHrmAssessmentRow[0].selectNodes("AdultOrChild").length > 0 && xmlHrmAssessmentRow[0].selectNodes("AdultOrChild")[0].text.trim() != '') {
        _AdultOrChild = xmlHrmAssessmentRow[0].selectNodes("AdultOrChild")[0].text;
    }
   
    if (xmlHrmAssessmentRow[0].selectNodes("AssessmentType").length > 0 && xmlHrmAssessmentRow[0].selectNodes("AssessmentType")[0].text.trim() != '') {
        _screenType = xmlHrmAssessmentRow[0].selectNodes("AssessmentType")[0].text;
    }

    if (_checkBoxClientInDDPopulation == 'Y') {
        if (typeof ShowHideDiagnosesContent == 'function') {
            ShowHideDiagnosesContent('DXDD');
        }
       
        if (xmlHrmAssessmentRow[0].selectNodes("DxTabDisabled").length > 0 && xmlHrmAssessmentRow[0].selectNodes("DxTabDisabled")[0].text.trim() == 'Y') {
        }
        else {
            //DisableDXTab("DivDisableDX", '', false);
        }
    }

    else if ((_checkBoxClientInMHPopulation == 'Y' || _checkBoxClientInSAPopulation == 'Y') && (_checkBoxClientInDDPopulation == 'N')) {
        
        if (xmlHrmAssessmentRow[0].selectNodes("DxTabDisabled").length > 0 && xmlHrmAssessmentRow[0].selectNodes("DxTabDisabled")[0].text.trim() == 'Y') {
            
        }
        else {
            //DisableDXTab("DivDisableDX", '', false);
        }
        if (_AdultOrChild == 'A') {

            if (typeof ShowHideDiagnosesContent == 'function') {
                // Screen  AxisV should appear only Textboxe not Reason in case of Adult 
                if (_screenType != 'S')
                    ShowHideDiagnosesContent('DXSA');
                else
                    ShowHideDiagnosesContent('DXDD');
            }
        }
        else if (_AdultOrChild == 'C') {

            if (typeof ShowHideDiagnosesContent == 'function') {
                ShowHideDiagnosesContent('DXDD');
            }
        }
    }

}


//// Function to Enable disable DX controls
function DisableDXTab(DivDisableDX, DivDisabilityEligibility, TF) {
    if (DivDisableDX != "") {
        document.getElementById(DivDisableDX).disabled = document.getElementById(DivDisableDX).disabled ? true : TF;
    }
    if (DivDisabilityEligibility != "")
        document.getElementById(DivDisabilityEligibility).disabled = document.getElementById(DivDisabilityEligibility).disabled ? false : TF;
    if (TF == true) {
        DisableSpanButton('ButtonAxisIV');
        DisableSpanButton('ButtonAxisVRanges');
        DisableSpanButton('ButtonStaffAxisVRanges');
        $("[Id=AddICDCodes]").attr("disabled", true);
        $("[Id=TableChildControl_DiagnosesIAndII_ButtonInsert]").attr("disabled", true);
        $("[Id=ButtonClear]").attr("disabled", true);
        $("[Id=CustomGrid]").attr("disabled", true);
    }
}





//Code added by Loveena in ref to Task#916 5.7 - HRM Assessment: DD Fields on Mental Status tab missing
function DisappearSevereProfoundDisability(checkbox, trSevereProfoundDisability) {
    if ($(checkbox).is(":checked")) {
        $(trSevereProfoundDisability).show();
        $("#trHRMMentalStatus").find("input,button,textarea,div,select,label,span").attr("disabled", "disabled");
    }
    else {
        $(trSevereProfoundDisability).hide();
        $("#trHRMMentalStatus").find("input,button,textarea,div,select,label,span").removeAttr("disabled");
    }
}


//Description:To open the gurdian pop up window
//Author:Sandeep Singh
//CreatedOn:05-May-2010
function OpenGuardianInfoPopUp(RelativePath) {
    try {
        
       var _relativepath= RelativePath.trim();
        var chkbox = $("[id$=CheckBox_CustomDocumentMHAssessments_ClientHasGuardian]");
        if (chkbox.attr('checked')) {
            var _date = new Date();
            ScreenCode = 'B12360B8-94ED-4C33-90E6-BF50B233CC61';

                OpenPage(5761, null, '', 1, _relativepath, 'T', "dialogHeight:300px; dialogWidth:555px;", null, null, null, null, null, null, ScreenCode);
                $('#ButtonEditGuardian').removeAttr('disabled');
                var spanbutton = $("#ButtonEditGuardian");
                spanbutton.removeAttr('disabled');
                spanbutton.find("table:first").removeAttr('disabled');
            }
            else {

                $("[Id=ButtonEditGuardian]").attr("disabled", true);
                var textArea = $("#TextArea_CustomDocumentMHAssessments_GuardianAddressToDisplayOnly");
                textArea.val("");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianFirstName', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianLastName', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianAddress', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianCity', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'Guardianstate', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianStateText', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianZipcode', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianPhone', "");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'RelationWithGuardian', ""); 
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianTypeText', "");

            }
        //}
    }

    catch (err) {
        LogClientSideException(err, 'CustomDocumentMHAssessments');
    }
}



function SetTelerikControls(action, Dom) {
    var DDPopulation = false;
    var SAPopulation = false;
    var MHPopulation = false;
    if (Dom != "") {
        SavetabControl = Dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");

        if (SavetabControl[0].selectSingleNode('ClientInDDPopulation') != null) {
            if (SavetabControl[0].selectSingleNode('ClientInDDPopulation').text == 'Y') {

                if (action != pageActionEnum.New) {
                    $("input[type='checkbox'][id$='CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation']").attr("checked", true);
                    DDPopulation = true;

                }
                else if (action == pageActionEnum.New) {
                    //$("input[type='checkbox'][id$='CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation']").attr("checked", true);
                    DDPopulation = true;

                }
                else
                    DDPopulation = false;

            }
            else
                DDPopulation = false;
        }
        else {
            DDPopulation = false;
        }
        if (SavetabControl[0].selectSingleNode('ClientInSAPopulation') != null) {
            if (SavetabControl[0].selectSingleNode('ClientInSAPopulation').text == 'Y') {
                if (action != pageActionEnum.New) {
                    $("input[type='checkbox'][id$='CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation']").attr("checked", true);
                    SAPopulation = true;
                }
                else if (action == pageActionEnum.New) {
                    SAPopulation = true;
                }
                else
                    SAPopulation = false;
            }
            else
                SAPopulation = false;
        }
        else {
            SAPopulation = false;
        }
        if (SavetabControl[0].selectSingleNode('ClientInMHPopulation') != null) {
            if (SavetabControl[0].selectSingleNode('ClientInMHPopulation').text == 'Y') {
                if (action != pageActionEnum.New) {
                    $("input[type='checkbox'][id$='CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation']").attr("checked", true);
                    MHPopulation = true;
                }
                else if (action == pageActionEnum.New) {
                   MHPopulation = true;

                }
                else
                    MHPopulation = false;

            }
            else
                MHPopulation = false;
        }
        else {
            MHPopulation == false;
        }
    }


    if (CheckBoxDDPopulation == null) {
        CheckBoxDDPopulation = $("input[type='checkbox'][id$='CheckBox_CustomDocumentMHAssessments_ClientInDDPopulation']");
        if (CheckBoxDDPopulation == null) {
            CheckBoxDDPopulation[0].checked = DDPopulation;
        }
    }
    if (CheckBoxSAPopulation == null) {
        CheckBoxSAPopulation = $("input[type='checkbox'][id$='CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation']");
        if (CheckBoxSAPopulation == null) {
            CheckBoxSAPopulation[0].checked = SAPopulation;
        }
    }
    if (CheckBoxMHPopulation == null) {
        CheckBoxMHPopulation = $("input[type='checkbox'][id$='CheckBox_CustomDocumentMHAssessments_ClientInMHPopulation']");
        if (CheckBoxMHPopulation == null) {
            CheckBoxMHPopulation[0].checked = MHPopulation;
        }
    }

   
    if (DDPopulation == true || SAPopulation == true || MHPopulation == true) {
       
        isPopulationChecked = true;
        if (action != '' && action != 'new') {
            //  SetTabs(Dom, action);
        }

    }
    else {
        isPopulationChecked = false;
        //  HideTabs(tabobject);
    }
}

function DocumentCallbackComplete(objectPageResponse) {
   
    if ((objectPageResponse.Action == pageActionEnum.New || objectPageResponse.Action == '') && isPopulationChecked) {
       
        return false;
    }
}



///Purpose : This function is used to check Active and Passive value on Risk Assessment page

function CheckSuicideActivePassive() {

    if ($("#CheckBox_CustomDocumentMHAssessments_SuicideActive").attr("checked")) {
        $("#CheckBox_CustomDocumentMHAssessments_SuicidePassive").attr("disabled", true);
        $("#CheckBox_CustomDocumentMHAssessments_SuicideActive").attr("disabled", false);
    }
    else if ($("#CheckBox_CustomDocumentMHAssessments_SuicidePassive").attr("checked")) {
        $("#CheckBox_CustomDocumentMHAssessments_SuicideActive").attr("disabled", true);
        $("#CheckBox_CustomDocumentMHAssessments_SuicidePassive").attr("disabled", false);
    }
    else {
        $("#CheckBox_CustomDocumentMHAssessments_SuicidePassive").attr("disabled", false);
        $("#CheckBox_CustomDocumentMHAssessments_SuicideActive").attr("disabled", false);
    }

   
}


///Purpose : This function is used to check Active and Passive value on Risk Assessment page

function CheckHomicideActivePassive() {
    
    //Changes made by Mamta Gupta - Ref Task No. 640 SCWebPhaseII Bugs/Features - To enable and disable active and passive checkboxes
    if ($("#CheckBox_CustomDocumentMHAssessments_HomicideActive").attr("checked")) {
        $("#CheckBox_CustomDocumentMHAssessments_HomicidePassive").attr("disabled", true);
        $("#CheckBox_CustomDocumentMHAssessments_HomicideActive").attr("disabled", false);
    }
    else if ($("#CheckBox_CustomDocumentMHAssessments_HomicidePassive").attr("checked")) {
        $("#CheckBox_CustomDocumentMHAssessments_HomicideActive").attr("disabled", true);
        $("#CheckBox_CustomDocumentMHAssessments_HomicidePassive").attr("disabled", false);
    }
    else {
        $("#CheckBox_CustomDocumentMHAssessments_HomicidePassive").attr("disabled", false);
        $("#CheckBox_CustomDocumentMHAssessments_HomicideActive").attr("disabled", false);
    }

   
}


function DisabledHomicidality(dom) {
    var domObject = null;
    if (dom == undefined)
        domObject = AutoSaveXMLDom;
    else
        domObject = dom;

}



function SetGuardianInfoControl(dom) {
   
    var guardianFirstName = "", guardianLastName = "", guardianCity = "", guardianState = "", guardianZip = "", guardianAddress = "", guardianPhone = "", guardianInformation = "", GuardianTypeText = "", GuardianStateText="";
    var ClientHasGuardian = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'ClientHasGuardian', dom[0]);
   
    guardianFirstName = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianFirstName', dom[0]);
    guardianLastName = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianLastName', dom[0]);
    guardianAddress = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianAddress', dom[0]);
    guardianPhone = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianPhone', dom[0]);
    guardianCity = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianCity', dom[0]);
    guardianState = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianState', dom[0]);
    guardianZip = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianZipcode', dom[0]);
    GuardianTypeText = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianTypeText', dom[0]);
    GuardianStateText = GetColumnValueInXMLNodeByKeyValue('CustomDocumentMHAssessments', 'DocumentVersionId', $('#HiddenField_CustomDocumentMHAssessments_DocumentVersionId').val(), 'GuardianStateText', dom[0]);

    //guardianInformation = guardianName + "\n" + guardianAddress + "\n" + guardianPhone;
    if (ClientHasGuardian == 'Y') {
        $("[Id=ButtonEditGuardian]").attr("disabled", false);
        if ((guardianFirstName == "") && (guardianAddress == "") && (guardianPhone == "") && (guardianCity == "") && (guardianState == "") && (guardianZip == "") && (GuardianTypeText == "")) {//&& (GuardianTypeText == "")
            return;
        }
        else {
            var guardianInformation = guardianLastName + ", " + guardianFirstName + "\n" + guardianAddress + "\n" + guardianCity + ", " + guardianState + " " + guardianZip + "\n" + guardianPhone + "\n" + GuardianTypeText;//
            $('#TextArea_CustomDocumentMHAssessments_GuardianAddressToDisplayOnly').val(guardianInformation);

        }
    }
    else
        $("[Id=ButtonEditGuardian]").attr("disabled", true);
}

function ShowHideAssessmentHRMTab(tabInstance, showTab) {
    var selectedHRMTab = '';
    var sametab = false;
    if (typeof tabobject == 'undefined' || tabobject == undefined || tabobject == null || tabobject == "") {
    }
    else {
        historytabobject = tabobject._selectedIndex;
        if (historytabobject >= 0)
            selectedHRMTab = tabobject.get_selectedTab().get_text();
    }

    if (tabInstance != null) {
        if (tabInstance._text && selectedHRMTab) {
            if (tabInstance._text == selectedHRMTab)
                sametab = true;
        }

       
        if (sametab == false) {
            if (showTab == true) {
                tabInstance.show();
                tabInstance.set_visible(true);
            }
            else {
                tabInstance.hide();
                tabInstance.set_visible(false);
            }
        }
    }
}



function AddExtraTabUncope(dom, EventCheck) {
    try {
        var _eventCalled = EventCheck;
        if (EventCheck == undefined)
            _eventCalled = "";

        // Code for Su Tab Visibility From Code.
        if (_eventCalled != "" && EventCheck != "N") {
            //Call Extra Function
            AddExtraTabUncopeEvent();
            return;
        }

        if (dom == undefined)
            dom = AutoSaveXMLDom;
        var xmlHrmAssessmentRow = null;

        if ((dom != "" && dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0)) {
            xmlHrmAssessmentRow = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
        }
        var SUAssessment_tab = tabobject.findTabByText('Substance Abuse');
        var Count = 0;

        if (xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionU").length > 0 && xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionU")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionN").length > 0 && xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionN")[0].text.trim() == 'Y') {

            Count++;
        }
        if (xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionC").length > 0 && xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionC")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionO").length > 0 && xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionO")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionP").length > 0 && xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionP")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionE").length > 0 && xmlHrmAssessmentRow[0].selectNodes("UncopeQuestionE")[0].text.trim() == 'Y') {
            Count++;
        }

        var CheckBoxCompleteFullSUAssessmentValue = xmlHrmAssessmentRow[0].selectNodes("UncopeCompleteFullSUAssessment");
        if ((CheckBoxCompleteFullSUAssessmentValue.length > 0 && CheckBoxCompleteFullSUAssessmentValue[0].text.trim() == 'Y')) {
            if (SUAssessment_tab != null) {
                //SUAssessment_tab.show();
                ShowHideAssessmentHRMTab(SUAssessment_tab, true);
                UncopeCheck = true;
            }
        }
        else if (Count > 2) {
            if (SUAssessment_tab != null) {
                //SUAssessment_tab.show();
                ShowHideAssessmentHRMTab(SUAssessment_tab, true);
            }
        }
        else {

            if (SUAssessment_tab != null) {
                // SUAssessment_tab.hide();
                ShowHideAssessmentHRMTab(SUAssessment_tab, false);
                UncopeCheck = false;
            }

        }
      
        UncopeCountGlobal = Count;
    }
    catch (ex) {
        throw ex;
    }
}


function EnableDusableInitilaSection(dom) {

    if (dom != null && dom != '') {
        if (dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0) {
            CheckReasonForUpdate = dom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            if (CheckReasonForUpdate[0].selectSingleNode('AssessmentType') != null) {
                var AssessmentType = CheckReasonForUpdate[0].selectSingleNode('AssessmentType').text.trim();
                if (AssessmentType == 'I' || AssessmentType == '') {
                    $("#ReasonforUpdate").hide();
                    $("#SummaryOfProgress").hide();
                }
                else if (AssessmentType == 'U') {
                    $("#ReasonforUpdate").show();
                    $("#SummaryOfProgress").hide();
                    $("#SpanReasonforUpdate").text("Reason For Update");
                }
                else if (AssessmentType == 'A') {
                    $("#SummaryOfProgress").show();
                    $("#ReasonforUpdate").hide();
                    $("#SpanSummaryOfProgress").text("Summary of Progress");
                }

            }
        }
    }
}



//to disabled Psychiatric Advance Directives in child case.
function DisabledPsychiatricAdvanceDirectives(dom) {
    var domObject = null;
    var PsychiatricTable = $("#TablePsychiatricAdvanceDirective");
    if (dom == undefined)
        domObject = AutoSaveXMLDom;
    else
        domObject = dom;
    if (domObject != undefined) {
        if ($("CustomDocumentMHAssessments AdultOrChild", AutoSaveXMLDom).text() == 'C') {
            if (PsychiatricTable.length > 0)
                PsychiatricTable.hide();
           
        }
        else {
            if (PsychiatricTable.length > 0)
                PsychiatricTable.show();
            
        }
    }
    else {
        if (PsychiatricTable.length > 0)
            PsychiatricTable.show();
        
    }

}


function SetDiagnosisOrder(dom, action) {
    SetDiagnosisIAndIIHiddenOrderField(dom);
}



function FasProcessUnsaveRequest() {
    return;
}

//  to Populate the values of the Custom Cafas Tab through Dom.
//Response received from the Fas Services and the session Data Merge is finally loaded into the Dom for filling the controls.

function FasServicesCallBack(ResponseXml) {
    var dom = $.xmlDOM(ResponseXml);
    AutoSaveXMLDom = dom;
    if (AutoSaveXMLDom[0].childNodes[0].getAttribute("xmlns:xsi") == null) {
        AutoSaveXMLDom[0].childNodes[0].setAttribute("xmlns:xsi", 'http://www.w3.org/2001/XMLSchema-instance')
    }
    $('[id$=DropDownList_CustomDocumentMHAssessmentCAFASs_RaterClinician]')[0].selectedIndex = 0
    SetFormValues(AutoSaveXMLDom, "CustomDocumentMHAssessmentCAFASs");
    CreateUnsavedChangesInstance();
}




//To Show Level of Care description in div

//Purpose :  of UM-2 in order to remove ADT Criterion/ Provider Qualifications
function ShowLevelofCareDiv(colname) {
    var height = 100;
    var width = 200;
    var colvalueDeterminDesc = $('#HiddenField_CustomDocumentMHAssessments_DeterminationDescription').val();
    var colvalueLocDesc = $('#HiddenField_CustomDocumentMHAssessments_Description').val();

    if (colname == "Description") {
        if (colvalueLocDesc != "")
            ShowMsgBox(colvalueLocDesc, 'Level of Care Description', MessageBoxButton.OK, MessageBoxIcon.Information, undefined, undefined, undefined, height, width);

    }

    else if (colname == "DeterminationDescription") {
        if (colvalueDeterminDesc != "")
            ShowMsgBox(colvalueDeterminDesc, 'Determination Description', MessageBoxButton.OK, MessageBoxIcon.Information, undefined, undefined, undefined, height, width);

    }

}


function MentalStatusText(idAddToNeedsList) {

    try {
        var returnText = '';
        if (idAddToNeedsList.is(':checked')) {
            var id = idAddToNeedsList.attr('id');
            var blockId = idAddToNeedsList.attr('id').substring(8, id.indexOf('AddToNeedsList'));
            var controlCollection = $('[id*=' + blockId).not(idAddToNeedsList);
            var checkboxOther = 'CheckBox' + blockId + 'Other';

            if (controlCollection.length > 0) {

                controlCollection.each(function() {

                    var control = $(this);
                    if (control.attr('type') == 'checkbox') {
                        if (control.is(":checked") && checkboxOther != control.attr('id')) {

                            var label = control.parent().siblings(':first').find('label');
                            if (label.length > 0) {
                                if (returnText == '') {
                                    returnText = label.text();
                                }
                                else {
                                    returnText += ',' + label.text();
                                }
                            }
                        }
                    }
                    //Modified by vithobha, from .text to .val for Allegan 3.5 Implementation: #164 
                    else if (control.attr('type') == 'textarea') {
                        if (returnText == '') {
                            returnText = control.val();
                        }
                        else if (control.val() != '') {
                            returnText += ',' + control.val();
                        }
                    }
                });
            }
        }

        return returnText;
    }
    catch (err) {

    }
}




function SetValuesSUAssessment() {
    var needText = "";
    if ($("#CheckBox_CustomDocumentMHAssessments_SubstanceUseNeedsList").is(":checked")) {

        if ($("#TextArea_CustomSubstanceUseAssessments_VoluntaryAbstinenceTrial").val() != "") {
            needText = $("#TextArea_CustomSubstanceUseAssessments_VoluntaryAbstinenceTrial").val();
        }

    }

    return needText;
}

function SetValuesRiskAssessmentCrisisPlaning() {
    var needText = "";
    if ($("#CheckBox_CustomDocumentMHAssessments_CrisisPlanningNeedsList").is(":checked")) {

        if ($("#TextArea_CustomDocumentMHAssessments_CrisisPlanningNarrative").val() != "") {
            needText = $("#TextArea_CustomDocumentMHAssessments_CrisisPlanningNarrative").val();
        }

    }

    return needText;
}

function SetValuesRiskAssessmentAdvanceDirective() {
    var needText = "";
    if ($("#CheckBox_CustomDocumentMHAssessments_AdvanceDirectiveNeedsList").is(":checked")) {

        if ($("#TextArea_CustomDocumentMHAssessments_AdvanceDirectiveNarrative").val() != "") {
            needText = $("#TextArea_CustomDocumentMHAssessments_AdvanceDirectiveNarrative").val();
        }

    }

    return needText;
}




//This function added by Rakesh for Crafft tab
function SetEnableDisableCrafft(val, dom) {
    var RadioButtonCrafftQuestionC = $("input[type='radio'][name='RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionC']")
    var RadioButtonCrafftQuestionR = $("input[type='radio'][name='RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionR']")
    var RadioButtonCrafftQuestionA = $("input[type='radio'][name='RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionA']")
    var RadioButtonCrafftQuestionF = $("input[type='radio'][name='RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionF']")
    var RadioButtonCrafftQuestionFR = $("input[type='radio'][name='RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionFR']")
    var RadioButtonCrafftQuestionT = $("input[type='radio'][name='RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionT']")
    if (val == 'N') {
        RadioButtonCrafftQuestionC.attr("disabled", "disabled");
        RadioButtonCrafftQuestionR.attr("disabled", "disabled");
        RadioButtonCrafftQuestionA.attr("disabled", "disabled");
        RadioButtonCrafftQuestionF.attr("disabled", "disabled");
        RadioButtonCrafftQuestionFR.attr("disabled", "disabled");
        RadioButtonCrafftQuestionT.attr("disabled", "disabled");
    }
    if (val == 'Y') {
        RadioButtonCrafftQuestionC.removeAttr("disabled", "disabled");
        RadioButtonCrafftQuestionR.removeAttr("disabled", "disabled");
        RadioButtonCrafftQuestionA.removeAttr("disabled", "disabled");
        RadioButtonCrafftQuestionF.removeAttr("disabled", "disabled");
        RadioButtonCrafftQuestionFR.removeAttr("disabled", "disabled");
        RadioButtonCrafftQuestionT.removeAttr("disabled", "disabled");
    }
    }

//This function  for Crafft tab
function AddExtraTabCrafftEvent() {
    try {
        var SUAssessment_tab = tabobject.findTabByText('Substance Abuse');
        var Count = 0;
        
        if (SUAssessment_tab != null) {
          
            if ($("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionC_Y").length > 0 && $("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionT_Y").length > 0) {
                if ($("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionC_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionR_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionA_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionF_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionFR_Y").attr("checked") == true) {
                    Count++;
                }
                if ($("#RadioButton_CustomDocumentMHCRAFFTs_CrafftQuestionT_Y").attr("checked") == true) {
                    Count++;
                }
            }
            else {
                //if the radio buttons are not yet loaded
                var CrafftXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHCRAFFTs");
                if (CrafftXml.length > 0) {
                    var CraftNode = CrafftXml[0].selectNodes("CrafftQuestionC");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("CrafftQuestionR");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("CrafftQuestionA");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("CrafftQuestionF");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("CrafftQuestionFR");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                    CraftNode = CrafftXml[0].selectNodes("CrafftQuestionT");
                    if (CraftNode.length > 0) {
                        var Crafttext = CraftNode[0].text;
                        if (Crafttext == 'Y') {
                            Count++;
                        }
                    }
                }
            }


            if (Count > 2) {
                if (SUAssessment_tab != null) {
                    SUAssessment_tab.show();
                    SUAssessment_tab.set_visible(true);
                }
            }
            else {
                if ($("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation").length > 0) {
                    if ($("#CheckBox_CustomDocumentMHAssessments_ClientInSAPopulation").attr("checked") != true) {
                        if (SUAssessment_tab != null) {
                            SUAssessment_tab.hide();
                            SUAssessment_tab.set_visible(false);
                        }
                    }
                }
                //else if (SUAssessment_tab != null) {
                //    SUAssessment_tab.hide();
                //    SUAssessment_tab.set_visible(false);
                //}
            }

            if ($("#CheckBox_CustomDocumentMHCRAFFTs_CrafftCompleteFullSUAssessment").length > 0) {
                if (($("#CheckBox_CustomDocumentMHCRAFFTs_CrafftCompleteFullSUAssessment").attr("checked") == true) && (Count < 3)) {
                    if (SUAssessment_tab != null) {
                        SUAssessment_tab.show();
                        SUAssessment_tab.set_visible(true);
                    }
                }
            }
        }
    }
    catch (ex) {
        throw ex;
    }
}

//This function  for Crafft tab
function callCRAFFT() {
   
    var SUAssessment_tab = tabobject.findTabByText('Substance Abuse');
  
    if (SUAssessment_tab != null) {
       
    }
   
    if (Crafftflag == 0) {
        $('#RadioButton_CustomDocumentMHCRAFFTs_CrafftApplicable_Y').attr("checked", false);
        $('#RadioButton_CustomDocumentMHCRAFFTs_CrafftApplicable_N').attr("checked", false);
        Crafftflag = 1;
        var CrafftXml = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHCRAFFTs");
        if (CrafftXml.length > 0) {
            var CraftNode = CrafftXml[0].selectNodes("CrafftApplicable");
            if (CraftNode.length > 0) {
                var Crafttext = CraftNode[0].text;
                if (Crafttext == 'Y') {
                    $('#RadioButton_CustomDocumentMHCRAFFTs_CrafftApplicable_Y').attr("checked", true);
                    SetEnableDisableCrafft('Y', AutoSaveXMLDom);
                    CreateInitializationImages(AutoSaveXMLDom);
                }
                else {
                    $('#RadioButton_CustomDocumentMHCRAFFTs_CrafftApplicable_N').attr("checked", true);
                    SetEnableDisableCrafft('N', AutoSaveXMLDom);
                }
            }
        }

    }

}

//This function added by Rakesh for Crafft tab
function AddExtraTabCrafft(dom, EventCheck) {
    try {
        var _eventCalled = EventCheck;
        if (EventCheck == undefined)
            _eventCalled = "";

        // Code for Su Tab Visibility From Code.
        if (_eventCalled != "" && EventCheck != "N") {
            //Call Extra Function
            AddExtraTabCrafftEvent();
            return;
        }

        if (dom == undefined)
            dom = AutoSaveXMLDom;
        var xmlCustomDocumentMHCRAFFTsRow = null;
        if ((dom != "" && dom[0].childNodes[0].selectNodes("CustomDocumentMHCRAFFTs").length > 0)) {
            xmlCustomDocumentMHCRAFFTsRow = dom[0].childNodes[0].selectNodes("CustomDocumentMHCRAFFTs");
        }
        var SUAssessment_tab = tabobject.findTabByText('Substance Abuse');
        var Count = 0;

        if (xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionC").length > 0 && xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionC")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionR").length > 0 && xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionR")[0].text.trim() == 'Y') {

            Count++;
        }
        if (xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionA").length > 0 && xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionA")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionF").length > 0 && xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionF")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionFR").length > 0 && xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionFR")[0].text.trim() == 'Y') {
            Count++;
        }
        if (xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionT").length > 0 && xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftQuestionT")[0].text.trim() == 'Y') {
            Count++;
        }

        var CheckBoxCompleteFullSUAssessmentValue = xmlCustomDocumentMHCRAFFTsRow[0].selectNodes("CrafftCompleteFullSUAssessment");
        if ((CheckBoxCompleteFullSUAssessmentValue.length > 0 && CheckBoxCompleteFullSUAssessmentValue[0].text.trim() == 'Y')) {
            if (SUAssessment_tab != null) {
                //SUAssessment_tab.show();
                ShowHideAssessmentHRMTab(SUAssessment_tab, true);
                UncopeCheck = true;
            }
        }
        else if (Count > 2) {
            if (SUAssessment_tab != null) {
                //SUAssessment_tab.show();
                ShowHideAssessmentHRMTab(SUAssessment_tab, true);
            }
        }
        else {
            if (SUAssessment_tab != null) {
                // SUAssessment_tab.hide();
                ShowHideAssessmentHRMTab(SUAssessment_tab, false);
                UncopeCheck = false;
            }

        }
    }
    catch (ex) {
        throw ex;
    }
}

//This function for disable checkboxes for all in case screen
function EnableDisabeNeedListCheckBoxex(tabUserControlName) {
   

}

//  Disposition tab
function CustomAjaxRequestCallback(result, CustomAjaxRequest) {
    var response = result;
    if (result.indexOf("###StartDisposition###") >= 0) {
        var start = result.indexOf("###StartDisposition###") + 22;
        var end = result.indexOf("###EndDisposition###");
        var str = result.substr(start, end - start);
        if (DispositionControl != null)
            DispositionControl.FillHTMLToControl(str);
    }
    else
        if (result.indexOf("###StartDispositionHTML###") >= 0) {
        var start = result.indexOf("###StartDispositionHTML###") + 26;
        var end = result.indexOf("###EndDispositionHTML###");
        var str = result.substr(start, end - start);
        if (DispositionControl != null)
            DispositionControl.FillHTMLToDropDowns(str);
    }

    var outputHTML = '';
    var pageDataSetXml = '';
    if (response != null && response != undefined && response != "") {
        if (response.indexOf("^pageDataSetXML=") > 0) {
            var splitPageResponse = response.split("^pageDataSetXML=");
            if (splitPageResponse.length > 0) {
                outputHTML = splitPageResponse[0];
                pageDataSetXml = splitPageResponse[1];

                //update pagedataset xml after custom ajax
                if (pageDataSetXml != "" && pageDataSetXml.indexOf("</DataSetDocumentMaster>") > 0) {

                    pageDataSetXml = pageDataSetXml.substr(0, pageDataSetXml.indexOf("</DataSetDocumentMaster>") + 24);

                    AutoSaveXMLDom = $.xmlDOM(pageDataSetXml);
                    if (AutoSaveXMLDom[0].childNodes[0].getAttribute("xmlns:xsi") == null) {
                        AutoSaveXMLDom[0].childNodes[0].setAttribute("xmlns:xsi", 'http://www.w3.org/2001/XMLSchema-instance')
                    }
                    // trigger the xml update event
                    $(document).triggerHandler('xmlchange');
                }
            }
        }
    }

    if (outputHTML.indexOf("###StartEditNeedDiscription###") >= 0) {
        RefreshNeedsTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartDeleteNeedDiscription###") >= 0) {
        RefreshNeedsTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartAddNeedsPopUp###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
    else if (outputHTML.indexOf("###StartAssociateNeedPopUp###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
}


function OpenAsamPopup() {
    OpenPage(5761, 10690, '', 2, GetRelativePath(), 'T', 'dialogHeight:570px; dialogWidth:860px;dialogTitle:ASAM;dialogcrossbutton:hide;')
}

/// Function added by Rakesh w.rf to task 20 
function SetPreviousAssessmentType() {
   
    if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]')[0].checked == true) {
        previousAssessmentType = 'RadioButton_CustomDocumentMHAssessments_AssessmentType_I';
    }
    else if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]')[0].checked == true) {
        previousAssessmentType = 'RadioButton_CustomDocumentMHAssessments_AssessmentType_U';
    }
    else if ($('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]')[0].checked == true) {
        previousAssessmentType = 'RadioButton_CustomDocumentMHAssessments_AssessmentType_A';
    }
    
    else {
        previousAssessmentType = "";
    }
}




function CustomTableFilterForPencilIcon() {
    if (typeof tabobject != 'undefined' || tabobject != undefined || tabobject != null || tabobject != "") {
        if (tabobject.get_selectedTab())
            var getTableNameAsPerSelectedTab = tabobject.get_selectedTab().get_text();
    }
}

//Added by saurav Pande for Task# 18 and Task# 1605 in Project: woodland
function ChangeSpanTextForWoodland() {

}



function AddParentChildEventHandler(containerTableName, callBackName) {
    //if (containerTableName == 'TableChildControl_CustomSafetyCrisisPlanReviews') {
    //    $("#RadioButton_CustomSafetyCrisisPlanReviews_SafetyCrisisPlanReviewed_Y").attr('checked', 'checked');
    //    $('[section=CrisisDisposition]').hide();
    //}
}



function onChildTabSelected(sender, arg) {
  
}

function GridRenderCallBackComplete(action, mode, ParentChildInsertGridName) {
   
}

function InsertCustomSupportContactsGridData() {
    if ($("[id$=DropDownList_ClientContactInformation_Name]").val() == '') {
        ShowHideErrorMessage("Please Select the Dropdown Entry before Clicking Insert Button!", 'true');
        return false;
    }
    ShowHideErrorMessage("Please Select the Dropdown Entry before Clicking Insert Button!", 'false');

    var ContactId = $('[id$=DropDownList_ClientContactInformation_Name] option:selected').val();

    var counter = 0;
    var trobject = $('tr .dxgvDataRow[id*=CustomGridSupportContacts_GridViewInsert_DXDataRow]');
    trobject.each(function() {
        if ($(this).children().eq(14)[0].innerText != "") {
            if (parseInt($(this).children().eq(14)[0].innerText) == parseInt(ContactId)) {
                counter++;
            }
        }
    });

    if (parseInt(counter) > 0) {
        ShowHideErrorMessage('Contact already exists.', 'true');
        return false;
    }
    ShowHideErrorMessage('Contact already exists.', 'false');

    var NewXML = $('[id$=HiddenFieldClientContactInformation]').val();
    var ContactInformation = GetAutoSaveXMLDomNode('ClientContactInformation', $.xmlDOM(NewXML));

    var items = ContactInformation.length > 0 ? $(ContactInformation).XMLExtract() : [];
    if (items.length > 0) {
        var item = ArrayHelpers.GetItem(items, ContactId, 'ClientContactId');

        var ScreenDataSetXmlDom = $.xmlDOM(objectPageResponse.ScreenDataSetXml);

        var tableName = "CustomSupportContacts";
        tableObject = $(tableName, ScreenDataSetXmlDom);
        var maxOrderSetAttributeId = 0;
        if (tableObject.length > 0)
            maxOrderSetAttributeId = parseInt(tableObject[tableObject.length - 1].selectSingleNode("SupportContactId").text);
        if (maxOrderSetAttributeId <= 0) {
            SupportContactId = maxOrderSetAttributeId - 1;
        }
        else {
            SupportContactId = -1;
        }

        XML = new String("<MainDataSet  xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");

        XML = XML + "<CustomSupportContacts>";
        XML = XML + "<SupportContactId>" + SupportContactId + "</SupportContactId>";
        XML = XML + "<DocumentVersionId>" + GetCurrentDocumentVersionID() + "</DocumentVersionId>";
        XML = XML + "<ClientContactId>" + ContactId + "</ClientContactId>";
        if (item.Name != undefined) {
            XML = XML + "<Name>" + item.Name + "</Name>";
        }
        if (item.RelationshipText != undefined) {
            XML = XML + "<Relationship>" + item.RelationshipText + "</Relationship>";
        }
        if (item.Address != undefined) {
            XML = XML + "<Address>" + item.Address + "</Address>";
        }
        if (item.Phone != undefined) {
            XML = XML + "<Phone>" + item.Phone + "</Phone>";
        }
        XML = XML + "</CustomSupportContacts>";
        XML = XML + "</MainDataSet>";

        gridTableName = 'TableChildControl_CustomSupportContacts';

        CallAjaxGridControl(XML, '#TableChildControl_CustomSupportContacts', 'InsertGridSupportContacts', 'CustomGridSupportContacts', 'CustomSupportContacts', 'ButtonInsert', undefined, undefined);
    }
}

function OpenContacts() {
    if (Dirty == "True" || UnsavedChangeId > 0) {
        ShowMsgBox('Please save the existing unsaved record for this screen prior to Open the Contacts', 'Confirmation', MessageBoxButton.OK, MessageBoxIcon.Information);
        return false;
    }
    else {
        OpenPage(5761, 3, 'ClientID=' + ClientID, null, GetRelativePath(), null, null, null, 2, null, null);
    }
}

function showCrisisDisposition(obj) {
    if (obj.checked && obj.value == 'Y') {
        $('[section=CrisisDisposition]').hide();
    }
    else if (obj.checked && obj.value == 'N') {
        $('[section=CrisisDisposition]').show();
    }
}



function InsertCrisisPlanMedicalProviders() {

    $('#HiddenField_CustomCrisisPlanMedicalProviders_DocumentVersionId').val(AutoSaveXMLDom.find("CustomDocumentMHAssessments:first DocumentVersionId").text());
    //$('#HiddenField_CustomCrisisPlanMedicalProviders_AddressTypeText').val($('[id$=DropDownList_CustomCrisisPlanMedicalProviders_AddressType] :selected').text());
    var validatecount = 0;
    if (!$('#TextBox_CustomCrisisPlanMedicalProviders_Name').val())
        validatecount++;
    if (!$('[id$=DropDownList_CustomCrisisPlanMedicalProviders_AddressType] :selected').val())
        validatecount++;
    if (!$('#Textbox_CustomCrisisPlanMedicalProviders_Address').val())
        validatecount++;
    if (!$('#Textbox_CustomCrisisPlanMedicalProviders_Phone').val())
        validatecount++;
    if (validatecount == 4)
        return false;

    InsertGridData('TableChildControl_CustomCrisisPlanMedicalProviders', 'InsertGrid_CustomCrisisPlanMedicalProviders', 'CustomGrid_CustomCrisisPlanMedicalProviders', $('#TableChildControl_CustomCrisisPlanMedicalProviders_ButtonInsert')[0]);
}

function InsertCrisisPlanNetworkProviders() {
    $('#HiddenField_CustomCrisisPlanNetworkProviders_DocumentVersionId').val(AutoSaveXMLDom.find("CustomDocumentMHAssessments:first DocumentVersionId").text());
    //$('#HiddenField_CustomCrisisPlanNetworkProviders_AddressTypeText').val($('[id$=DropDownList_CustomCrisisPlanNetworkProviders_AddressType] :selected').text());
    var validatecount = 0;
    if (!$('#TextBox_CustomCrisisPlanNetworkProviders_Name').val())
        validatecount++;
    if (!$('[id$=DropDownList_CustomCrisisPlanNetworkProviders_AddressType] :selected').val())
        validatecount++;
    if (!$('#TextBox_CustomCrisisPlanNetworkProviders_Address').val())
        validatecount++;
    if (!$('#TextBox_CustomCrisisPlanNetworkProviders_Phone').val())
        validatecount++;
    if (validatecount == 4)
        return false;

    InsertGridData('TableChildControl_CustomCrisisPlanNetworkProviders', 'InsertGrid_CustomCrisisPlanNetworkProviders', 'CustomGrid_CustomCrisisPlanNetworkProviders', $('#TableChildControl_CustomCrisisPlanNetworkProviders_ButtonInsert')[0]);
}


function maxCheckLength(field, maxChars) {
    if (field.value.length >= maxChars) {
        event.returnValue = false;
        return false;
    }
}

function maxCheckLengthPaste(field, maxChars) {
    event.returnValue = false;
    if ((field.value.length + window.clipboardData.getData("Text").length) > maxChars) {
        return false;
    }
    event.returnValue = true;
}

function LoadTabPageCallBackComplete(tabClickSender, title, tabUserControlName, selectedTabId, functionname) {
    //if (SafetyCrisisPlanTabIndex == 0) {
    //    if (tabobject != null && tabobject != undefined) {
    //        GetTabIndexOfSafetyCrisisPlan(tabobject);
    //    }
    //}

    //if (selectedTabId == SafetyCrisisPlanTabIndex && SafetyCrisisPlanTabIndex > 0) {
    //    if (tabUserControlName.indexOf('PlanCrisisSafety') != -1) {
    //        PlanCrisisSafety(AutoSaveXMLDom);
    //    }

    //    if (tabUserControlName.indexOf('SafetyMultitabCrisis') != -1) {
    //        UpdateScreenHistoryNode(CurrentHistoryId, CurrentScreenId, "ScreenTabIndex", SafetyCrisisPlanTabIndex.toString());
    //        tabobject._selectedIndex = SafetyCrisisPlanTabIndex;
    //        TabIndex = SafetyCrisisPlanTabIndex;
    //        objectPageResponse.SelectedTabId = SafetyCrisisPlanTabIndex;
    //    }
    //}
}

function ValidateDataForParentChildGridEventHandler() {
    try {
        if (tabUserControlName == "FamilyHistory") {
            var FamilyMemberType = $('[id$=DropDownList_DocumentFamilyHistory_FamilyMemberType] option:selected').val();

            var counter = 0;
            var trobject = $('tr .dxgvDataRow[id*=CustomGridDocumentFamilyHistory_GridViewInsert_DXDataRow]');
            trobject.each(function() {
                if ($(this).children().eq(15)[0].innerText != "") {
                    if (parseInt($(this).children().eq(15)[0].innerText) == parseInt(FamilyMemberType)) {
                        counter++;
                    }
                }
            });

            if (parseInt(counter) == 0) {
                if ($('[id$=RadioButton_DocumentFamilyHistory_IsLiving_Y]').attr('checked')
        || $('[id$=RadioButton_DocumentFamilyHistory_IsLiving_N]').attr('checked')
        || $('[id$=RadioButton_DocumentFamilyHistory_IsLiving_U]').attr('checked')) {
                    ShowHideErrorMessage('Family Med Hx-Family history -living status is required.', 'false');
                }
                else {
                    ShowHideErrorMessage('Family Med Hx-Family history -living status is required.', 'true');
                    return false;
                }
            }

            if ($('[id$=RadioButton_DocumentFamilyHistory_IsLiving_N]').attr('checked')) {
                if ($('[id$=Textbox_DocumentFamilyHistory_CauseOfDeath]').val() == '') {
                    ShowHideErrorMessage('Family Med Hx-Family history- If Deceased, cause of death is required.', 'true');
                    return false;
                }
                else {
                    ShowHideErrorMessage('Family Med Hx-Family history- If Deceased, cause of death is required.', 'false');

                }
            }
            else {
                ShowHideErrorMessage('Family Med Hx-Family history- If Deceased, cause of death is required.', 'false');
            }

        }
        return true;
    }

    catch (err) {
        LogClientSideException(err);
    }

}

function EnableDisableTextArea(obj, dom) {
    var ReductionInSymptomsDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_ReductionInSymptomsDescription]");
    var AttainmentOfHigherFunctioningDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_AttainmentOfHigherFunctioningDescription]");
    var TreatmentNotNecessaryDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_TreatmentNotNecessaryDescription]");
    var OtherTransitionCriteriaDescriptionObject = $("textarea[id$=TextArea_CustomDocumentMHAssessments_OtherTransitionCriteriaDescription]");

    if (obj.id.toString() == 'CheckBox_CustomDocumentMHAssessments_ReductionInSymptoms') {
        if ($(ReductionInSymptomsDescriptionObject).length > 0) {
            if ($(obj).is(':checked')) {
                $(ReductionInSymptomsDescriptionObject).closest("tr").show();
            }
            else {
                $(ReductionInSymptomsDescriptionObject).val("");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'ReductionInSymptomsDescription', '');
                $(ReductionInSymptomsDescriptionObject).closest("tr").hide();
            }
        }
    }
    else if (obj.id.toString() == 'CheckBox_CustomDocumentMHAssessments_AttainmentOfHigherFunctioning') {
        if ($(AttainmentOfHigherFunctioningDescriptionObject).length > 0) {
            if ($(obj).is(':checked')) {
                $(AttainmentOfHigherFunctioningDescriptionObject).closest("tr").show();
            }
            else {
                $(AttainmentOfHigherFunctioningDescriptionObject).val("");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'AttainmentOfHigherFunctioningDescription', '');
                $(AttainmentOfHigherFunctioningDescriptionObject).closest("tr").hide();
            }
        }
    }
    else if (obj.id.toString() == 'CheckBox_CustomDocumentMHAssessments_TreatmentNotNecessary') {
        if ($(TreatmentNotNecessaryDescriptionObject).length > 0) {
            if ($(obj).is(':checked')) {
                $(TreatmentNotNecessaryDescriptionObject).closest("tr").show();
            }
            else {
                $(TreatmentNotNecessaryDescriptionObject).val("");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'TreatmentNotNecessaryDescription', '');
                $(TreatmentNotNecessaryDescriptionObject).closest("tr").hide();
            }
        }
    }
    else if (obj.id.toString() == 'CheckBox_CustomDocumentMHAssessments_OtherTransitionCriteria') {
        if ($(OtherTransitionCriteriaDescriptionObject).length > 0) {
            if ($(obj).is(':checked')) {
                $(OtherTransitionCriteriaDescriptionObject).closest("tr").show();
            }
            else {
                $(OtherTransitionCriteriaDescriptionObject).val("");
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'OtherTransitionCriteriaDescription', '');
                $(OtherTransitionCriteriaDescriptionObject).closest("tr").hide();
            }
        }
    }
}

function GotoGetASAM() {
    try {
        PopupProcessing();
        $.ajax({
            type: "POST",
            url: GetRelativePath() + "Custom/MH Assessment/WebPages/AjaxHRMSupport.aspx?functionName=GetASAM",
            data: '',
            success: function(result) {
                HidePopupProcessing();
                if (result != '') {
                    if (result != 'No ASAM') {
                        CreateAutoSaveXml('CustomDocumentMHAssessments', 'ClinicalSummary', result);
                        $("#TextArea_CustomDocumentMHAssessments_ClinicalSummary").val(result);
                    }
                }
                else {
                    GotoGetASAM();
                }
            }
        });
    }
    catch (err) { }
}

function ShowOrHideAdultLTOrChildLTTab(TabStatus) {
    var CSSRSAdultSinceLT = tabobject.findTabByText('Columbia');
    var Check = GetFielValueFromXMLDom(AutoSaveXMLDom, "CustomDocumentMHAssessments", "AssessmentType");    
}
function UpdateNeedsXML(needid, value) {
}

function enableTextArea(obj) {
    if (obj.id.toString() == 'RadioButton_CustomSubstanceUseAssessments_MedicationAssistedTreatment_Y') {
        if ($(obj).is(':checked')) {
            if ($('#TextArea_CustomSubstanceUseAssessments_MedicationAssistedTreatmentRefferedReason').is(':disabled')) {
                $('#TextArea_CustomSubstanceUseAssessments_MedicationAssistedTreatmentRefferedReason').attr("disabled", false);
            }
        }
    }
    else if (obj.id.toString() == 'RadioButton_CustomSubstanceUseAssessments_MedicationAssistedTreatment_N') {
        if ($(obj).is(':checked')) {
            if ($('#TextArea_CustomSubstanceUseAssessments_MedicationAssistedTreatmentRefferedReason').is(':disabled')) {
                $('#TextArea_CustomSubstanceUseAssessments_MedicationAssistedTreatmentRefferedReason').attr("disabled", false);
            }
        }
    }
    else if (obj.id.toString() == 'RadioButton_CustomSubstanceUseAssessments_MedicationAssistedTreatment_A') {
        if ($(obj).is(':checked')) {
            CreateAutoSaveXml('CustomSubstanceUseAssessments', 'MedicationAssistedTreatmentRefferedReason', "");
            $('[id$=TextArea_CustomSubstanceUseAssessments_MedicationAssistedTreatmentRefferedReason]').val("");
            $('#TextArea_CustomSubstanceUseAssessments_MedicationAssistedTreatmentRefferedReason').attr("disabled", true);
        }
    }
    else {
    }
}


function CSSRSHideAndShow() {
    var CSSRSAdultSinceLT = tabobject.findTabByText('Columbia');
    var Check = GetFielValueFromXMLDom(AutoSaveXMLDom, "CustomDocumentMHAssessments", "AssessmentType");
    var TabStatus = GetFielValueFromXMLDom(AutoSaveXMLDom, "CustomDocumentMHAssessments", "AdultOrChild");
   
}


AssessmentRecordInitialization = (function() {
    var notedocumentversionid = AutoSaveXMLDom.find("DocumentVersions:first DocumentVersionId").text();
    if (notedocumentversionid == undefined || notedocumentversionid == null || notedocumentversionid == 0) {
        notedocumentversionid = -1;
    }

    var _documentversionid;
    var _createdby;
    var _createddate;
    var _modifiedby;
    var _modifieddate;

   

    var TableLength = AutoSaveXMLDom.find("CustomDocumentMHColumbiaAdultSinceLastVisits").length;
    if (TableLength == 0) {
        var _xmltable = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement('CustomDocumentMHColumbiaAdultSinceLastVisits')); //Add Table
        _documentversionid = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId')); //Add Column
        _documentversionid.text = notedocumentversionid;
        _createdby = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedBy')); //Add Column
        _createdby.text = objectPageResponse.LoggedInUserCode;
        _createddate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedDate')); //Add Column
        _createddate.text = ISODateString(new Date());
        _modifiedby = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedBy')); //Add Column
        _modifiedby.text = objectPageResponse.LoggedInUserCode;
        _modifieddate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedDate')); //Add Column
        _modifieddate.text = ISODateString(new Date());
        AddToUnsavedTables("CustomDocumentMHColumbiaAdultSinceLastVisits");
    }

  
});


ISODateString = (function(dateIn) {
    var d;
    if ((typeof (dateIn) === 'date') ? true : (typeof (dateIn) === 'object') ? dateIn.constructor.toString().match(/date/i) !== null : false) {
        d = dateIn;
    } else {
        d = new Date(dateIn);
    }
    function pad(n) {
        n = parseInt(n, 10);
        return n < 10 ? '0' + n : n;
    }
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' +
        pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
});





function AddParentChildRadioClickEventHandler(key) {

    
}

function CheckAssessmentType(obj,columnName)
{
   
    AssessmentTypeI = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_I]');
    AssessmentTypeU = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_U]');
    AssessmentTypeA = $('[id$=RadioButton_CustomDocumentMHAssessments_AssessmentType_A]');
    if (AssessmentTypeI.attr('checked') || AssessmentTypeU.attr('checked') || AssessmentTypeA.attr('checked')) {

    }
    else{
        var AssessmentType;
        if (AutoSaveXMLDom != "" && AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments").length > 0) {
            var CustomDocumentMHAssessments = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
            if (CustomDocumentMHAssessments[0].selectNodes("AssessmentType").length > 0) {
                AssessmentType = CustomDocumentMHAssessments[0].selectNodes("AssessmentType")[0].text;
            }
        }
        if (AssessmentType != "") { }
        else {
            if (obj != null && obj != undefined && obj != '') {
                $(obj).val('');
                CreateAutoSaveXml('CustomDocumentMHAssessments', columnName, '');
            }
            ShowHideErrorMessage('Please select any option from Initial,Update or Annual', 'true');
            return false;
        }
}
}

//Purpose: Bind Needs Template by Json
function FillNeedsTabTemplate() {
    var domainNeedsData = "";
    var domainNeedsDataString = "";
    var DivNeedLists = $("#DivNeedLists");
    domainNeedsData = $('input[id$=HiddenFieldNeeds]', DivNeedLists).val();
    domainNeedsDataString = eval('(' + domainNeedsData + ')');
    if (domainNeedsData.length > 0) {
        $("#tblid").html('');
        $("#tableTemplate").tmpl(domainNeedsDataString.objectListDomain).appendTo("#tblid");
        BindTextAreaKeyPhrase();
    }
}
function CreateFunLimitationCheckbox(e, Code) {
    try {
        var globalcode = e.getAttribute("globalcodeid");
        var now = new Date();
        var xmlIJE = AutoSaveXMLDom.find("CustomAssessmentDiagnosisIDDCriteria SubstantialFunctional[text=" + globalcode + "]").parent();
        if (xmlIJE.length == 0 && $(e).attr("checked") == true) {
            var AssessmentDiagnosisIDDCriteriaId = 0;
            AutoSaveXMLDom.find("CustomAssessmentDiagnosisIDDCriteria").each(function () {
                $(this).children().each(function () {
                    if (this.tagName == "AssessmentDiagnosisIDDCriteriaId") {
                        if (parseInt($(this).text()) < 0 && AssessmentDiagnosisIDDCriteriaId <= 0 && AssessmentDiagnosisIDDCriteriaId > parseInt($(this).text())) {
                            AssessmentDiagnosisIDDCriteriaId = parseInt($(this).text());
                        }
                    }
                });
            });

            if (AssessmentDiagnosisIDDCriteriaId == 0)
                AssessmentDiagnosisIDDCriteriaId = -1;
            else
                AssessmentDiagnosisIDDCriteriaId = AssessmentDiagnosisIDDCriteriaId + (-1);
            var _AssessmentDiagnosisIDDCriteriaId;
            var _CreatedBy;
            var _CreatedDate;
            var _ModifiedBy;
            var _ModifiedDate;
            var _DocumentVersionId;
            var _SubstantialFunctional;
            var _IsChecked;
            var _xmltable = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement('CustomAssessmentDiagnosisIDDCriteria')); //Add Table
            _AssessmentDiagnosisIDDCriteriaId = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('AssessmentDiagnosisIDDCriteriaId')); //Add Column
            _AssessmentDiagnosisIDDCriteriaId.text = AssessmentDiagnosisIDDCriteriaId;
            _CreatedBy = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedBy')); //Add Column
            _CreatedBy.text = objectPageResponse.LoggedInUserCode;
            _CreatedDate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedDate')); //Add Column
            _CreatedDate.text = now.toDateString();
            _ModifiedBy = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedBy')); //Add Column
            _ModifiedBy.text = objectPageResponse.LoggedInUserCode;
            _ModifiedDate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedDate')); //Add Column
            _ModifiedDate.text = now.toDateString();
            _DocumentVersionId = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId')); //Add Column
            _DocumentVersionId.text = AutoSaveXMLDom.find("DocumentVersions:first DocumentVersionId").text();
            _SubstantialFunctional = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('SubstantialFunctional')); //Add Column
            _SubstantialFunctional.text = parseInt(globalcode);
            _IsChecked = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('IsChecked')); //Add Column
            if ($(e).attr("checked") == true) {
                _IsChecked.text = 'Y';
            }
            else {
                _IsChecked.text = 'N';
            }
            AddToUnsavedTables("CustomAssessmentDiagnosisIDDCriteria");
            CreateUnsavedInstanceOnDatasetChange();

        }
        else if (xmlIJE.length > 0) {
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentDiagnosisIDDCriteria", "SubstantialFunctional", globalcode, "RecordDeleted", $(e).attr("checked") == false ? "Y" : "N", AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentDiagnosisIDDCriteria", "SubstantialFunctional", globalcode, "DeletedBy", $(e).attr("checked") == false ? objectPageResponse.LoggedInUserCode : "", AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentDiagnosisIDDCriteria", "SubstantialFunctional", globalcode, "DeletedDate", $(e).attr("checked") == false ? now.toDateString() : "", AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentDiagnosisIDDCriteria", "SubstantialFunctional", globalcode, "ModifiedBy", objectPageResponse.LoggedInUserCode, AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentDiagnosisIDDCriteria", "SubstantialFunctional", globalcode, "ModifiedDate", now.toDateString(), AutoSaveXMLDom[0]);
            CreateUnsavedInstanceOnDatasetChange();

        }
    }
    catch (err) {
        LogClientSideException(err, 'Assessment.js - CreateFunLimitationCheckbox()');
    }
}
function CreateCommunicationCheckboxControls(e, Code) {
    try {
        var globalcode = e.getAttribute("globalcodeid");
        var now = new Date();
        var xmlIJE = AutoSaveXMLDom.find("CustomAssessmentFunctionalCommunications Communication[text=" + globalcode + "]").parent();
        if (xmlIJE.length == 0 && $(e).attr("checked") == true) {
            var AssessmentFunctionalCommunicationId = 0;
            AutoSaveXMLDom.find("CustomAssessmentFunctionalCommunications").each(function () {
                $(this).children().each(function () {
                    if (this.tagName == "AssessmentFunctionalCommunicationId") {
                        if (parseInt($(this).text()) < 0 && AssessmentFunctionalCommunicationId <= 0 && AssessmentFunctionalCommunicationId > parseInt($(this).text())) {
                            AssessmentFunctionalCommunicationId = parseInt($(this).text());
                        }
                    }
                });
            });

            if (AssessmentFunctionalCommunicationId == 0)
                AssessmentFunctionalCommunicationId = -1;
            else
                AssessmentFunctionalCommunicationId = AssessmentFunctionalCommunicationId + (-1);
            var _AssessmentFunctionalCommunicationId;
            var _CreatedBy;
            var _CreatedDate;
            var _ModifiedBy;
            var _ModifiedDate;
            var _DocumentVersionId;
            var _Communication;
            var _IsChecked;
            var _xmltable = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement('CustomAssessmentFunctionalCommunications')); //Add Table
            _AssessmentFunctionalCommunicationId = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('AssessmentFunctionalCommunicationId')); //Add Column
            _AssessmentFunctionalCommunicationId.text = AssessmentFunctionalCommunicationId;
            _CreatedBy = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedBy')); //Add Column
            _CreatedBy.text = objectPageResponse.LoggedInUserCode;
            _CreatedDate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedDate')); //Add Column
            _CreatedDate.text = now.toDateString();
            _ModifiedBy = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedBy')); //Add Column
            _ModifiedBy.text = objectPageResponse.LoggedInUserCode;
            _ModifiedDate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedDate')); //Add Column
            _ModifiedDate.text = now.toDateString();
            _DocumentVersionId = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId')); //Add Column
            _DocumentVersionId.text = AutoSaveXMLDom.find("DocumentVersions:first DocumentVersionId").text();
            _Communication = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('Communication')); //Add Column
            _Communication.text = parseInt(globalcode);
            _IsChecked = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('IsChecked')); //Add Column
            if ($(e).attr("checked") == true) {
                _IsChecked.text = 'Y';
            }
            else {
                _IsChecked.text = 'N';
            }
            AddToUnsavedTables("CustomAssessmentFunctionalCommunications");
            CreateUnsavedInstanceOnDatasetChange();

        }
        else if (xmlIJE.length > 0) {
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentFunctionalCommunications", "Communication", globalcode, "RecordDeleted", $(e).attr("checked") == false ? "Y" : "N", AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentFunctionalCommunications", "Communication", globalcode, "DeletedBy", $(e).attr("checked") == false ? objectPageResponse.LoggedInUserCode : "", AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentFunctionalCommunications", "Communication", globalcode, "DeletedDate", $(e).attr("checked") == false ? now.toDateString() : "", AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentFunctionalCommunications", "Communication", globalcode, "ModifiedBy", objectPageResponse.LoggedInUserCode, AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue("CustomAssessmentFunctionalCommunications", "Communication", globalcode, "ModifiedDate", now.toDateString(), AutoSaveXMLDom[0]);
            CreateUnsavedInstanceOnDatasetChange();

        }
    }
    catch (err) {
        LogClientSideException(err, 'Assessment.js - CreateCommunicationCheckboxControls()');
    }
}