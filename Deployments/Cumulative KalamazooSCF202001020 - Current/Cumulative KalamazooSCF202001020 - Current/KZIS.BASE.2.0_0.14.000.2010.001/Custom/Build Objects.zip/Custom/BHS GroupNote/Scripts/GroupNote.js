﻿
function CustomValidateUpdateMyClientNotes() {
    if ($.trim($('#TextBox_CustomBHSGroupNotes_NumberOfClientsInSession').val()) == "") {
        ShowHideErrorMessage('Group Note-Shift note- Number of clients in session is required', 'true');
        return false;
    }
    if ($.trim($('#TextArea_CustomBHSGroupNotes_GroupDescription').val()) == "") {
        ShowHideErrorMessage('Group Note-Shift note- Describe providers intention is required', 'true');
        return false;
    }
    return true;
}

