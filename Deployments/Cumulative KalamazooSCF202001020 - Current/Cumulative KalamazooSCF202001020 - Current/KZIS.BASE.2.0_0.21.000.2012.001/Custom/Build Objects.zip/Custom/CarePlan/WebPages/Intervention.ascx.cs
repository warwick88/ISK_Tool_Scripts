﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SHS.BaseLayer;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using SHS.DataServices;

namespace SHS.SmartCare
{
    public partial class Custom_CarePlan_WebPages_Intervention : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        SqlParameter[] _objectSqlParmeters = null;
        public void Dispose()
        {
            this.DisposeObject();
        }
        public void DisposeObject()
        {
            _objectSqlParmeters = null;
        }

        //  public string RelativePath;
        string CarePlanPrescribedServiceIdVal = string.Empty;
        List<InteractionAuthorizationCodesIntervention> _InteractionAuthorizationCodesHRMTxPlan = new List<InteractionAuthorizationCodesIntervention>();
        SHS.UserBusinessServices.Document _objectDocuments = null;
        string agencyName = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// <Description></Description>
        /// <Author></Author>
        /// <CreatedOn></CreatedOn>
        /// </summary>
        public override void BindControls()
        {
            _objectDocuments = new SHS.UserBusinessServices.Document();
            agencyName = _objectDocuments.GetAgencyName();
            _objectDocuments = null;
            BuildIntervention();
            if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens != null)
            {
                HiddenField_CarePlanPopUpScreenId.Value = Convert.ToString(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens
                                .Where(x => (x.Field<string>("Code") == "823BF8A6-80AF-4473-8AB8-DE179672944D"))
                                .Select(y => y.ScreenId).FirstOrDefault());
            }
        }

        /// <summary>
        /// <Description>This method is used to Read Data from TPNeeds and Create Goal Section </Description>
        /// <Author>Vikas Vyas</Author>       
        /// <CreatedOn></CreatedOn>
        /// <Modified By >Anuj Tomat</Author>
        /// <Modified On>12 oct,2009</CreatedOn>
        /// </summary>
        private void BuildIntervention()
        {
            DataSet dataSetIntervention = null;
            DataView dataViewIntervention = null;
            DataRowView dataRowViewIntervention = null;
            StringBuilder stringBuilderHTML = null;
            try
            {
                PanelInterventionPlanMain.Controls.Clear();

                using (dataSetIntervention = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
                {
                    if (dataSetIntervention != null && dataSetIntervention.Tables.Count > 0)
                    {
                        if (dataSetIntervention.Tables.Contains("CustomCarePlanPrescribedServices") && dataSetIntervention.Tables["CustomCarePlanPrescribedServices"].Rows.Count > 0)
                        {
                            dataViewIntervention = new DataView(dataSetIntervention.Tables["CustomCarePlanPrescribedServices"]);
                            //dataViewIntervention.Sort = "CarePlanPrescribedServiceId";
                            dataViewIntervention.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'";
                            //Set Need Count in the hidden field
                            HiddenFiedInterventionCount.Value = Convert.ToString(dataViewIntervention.Count);
                            //Loop how many rows exists in the TPNeeds table for creating Goal
                            stringBuilderHTML = new StringBuilder();

                            stringBuilderHTML.Append("<table Id='TableInterventionMain1'  style='width:100%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");

                            for (int interventionCount = 0; interventionCount < dataViewIntervention.Count; interventionCount++)
                            {
                                CarePlanPrescribedServiceIdVal = dataViewIntervention[interventionCount]["CarePlanPrescribedServiceId"].ToString();
                                dataRowViewIntervention = dataViewIntervention[interventionCount]; //Create DataRowView 

                                stringBuilderHTML.Append("<tr id='tr_MainIntervention" + CarePlanPrescribedServiceIdVal + "'>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table style='width:100%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");


                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                #region Main Table
                                stringBuilderHTML.Append("<table id='tbl_Sub_Intervention_" + CarePlanPrescribedServiceIdVal + "'  style='width:100%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");


                                //Start -- New Code Added By Damanpreet For Create a Section
                                #region First TR of Main Table (start Section)
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table cellspacing='0'  cellpadding='0' border='0' width='100%'>");

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td align='left' nowrap='nowrap' class='content_tab_left'>");
                                stringBuilderHTML.Append("<span name='Span_InterventionNo_" + CarePlanPrescribedServiceIdVal + "'  id='Span_InterventionNo_" + CarePlanPrescribedServiceIdVal + "' style='color:Black;font-size:11px;' BindAutoSaveEvents ='False'  BindSetFormData='False' >Interventions # " + (interventionCount + 1) + "</span>");// 
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td width='17'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='17' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_sep.gif />");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td width='100%' class='content_tab_top'>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td width='7'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='7' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_right.gif />");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append(" </tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion First TR Main Table (start Section)

                                #region 3 TR for Main Table
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td class='right_contanier_bg'>");

                                #region TabContent Table

                                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%' id='tbl_" + CarePlanPrescribedServiceIdVal + "'>");
                                stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");

                                PanelInterventionPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style='width:8%;'>&nbsp;</td>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table border='0' cellpadding='0' style='width:100%'  cellspacing='0' >"); //Create

                                CreateIntervention(CarePlanPrescribedServiceIdVal, ref dataSetIntervention);

                                stringBuilderHTML = new StringBuilder();

                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");


                                stringBuilderHTML.Append("</table>");
                                #endregion TabContent Table
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion 3 TR for Main Table

                                #region 4 TR for Main Table
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                                stringBuilderHTML.Append("<tr>");

                                stringBuilderHTML.Append("<td width='2' class='right_bottom_cont_bottom_bg'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_left.gif /> ");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td width='100%' class='right_bottom_cont_bottom_bg'>");

                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td align='right' width='2' class='right_bottom_cont_bottom_bg'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_right.gif />");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                #endregion 4 TR for Main Table


                                stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");


                                //----NewLY Commented 2 JULY
                                //stringBuilderHTML.Append("</table>");
                                //----END NewLY Commented 2 JULY
                                #endregion MainTable
                                PanelInterventionPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                            }

                            stringBuilderHTML = new StringBuilder();

                            stringBuilderHTML.Append("<tr id='MainInterventionEnd_" + CarePlanPrescribedServiceIdVal + "'>");
                            stringBuilderHTML.Append("<td style='width:3%;height:3px;' colspan='3'>&nbsp;</td>");
                            stringBuilderHTML.Append("</tr>");

                            stringBuilderHTML.Append("<tr>"); //8th Row Open Tag                           
                            stringBuilderHTML.Append("<td colspan='3' align='left'>");
                            stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td width='9%' >");
                            stringBuilderHTML.Append("&nbsp;"); //Create
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("<td align='left'  >");
                            stringBuilderHTML.Append("<span name='Span_AddIntervention_" + CarePlanPrescribedServiceIdVal + "'  id='Span_AddIntervention_" + CarePlanPrescribedServiceIdVal + "'  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"AddNewCarePlanIntervention('" + CarePlanPrescribedServiceIdVal + "','Add Intervention');\" >Add Intervention</span>"); //Create
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                            dataSetIntervention.Tables["CustomCarePlanPrescribedServices"].DefaultView.RowFilter = "";
                            PanelInterventionPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Exception exx = new Exception();
                string dxml = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.GetXml().ToString();
                exx = new Exception(ex.Message + ex.StackTrace + dxml);
                throw new Exception(ex.Message + ex.StackTrace + dxml, ex.InnerException);
            }
            finally
            {

            }
        }

        /// <summary>
        /// <Description>Method is used to Read Data from TPInterventionProcedure and Create Intervention Section</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>16th-Sept-2009</CreatedOn>
        /// </summary>
        /// <param name="carePlanPrescribedServiceId"></param>
        /// <param name="dataSetInterventionPlan"></param>
        private void CreateIntervention(string carePlanPrescribedServiceId, ref DataSet dataSetInterventionPlan)
        {
            StringBuilder stringBuilderHTML = null;
            DataRow[] dataRowInterventionPlan = null;
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionFrequency = null;
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionProvider = null;
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionPersonResponsible = null;

            //All references of 'dropdownListinterVentionService' in current function commented by shifali
            // in ref to task# 4 of UM - Part two on 29th sept,2010
            //DropDownList dropdownListinterVentionService = null;
            DataRow[] dataRowTPInterventionPObjective = null;
            DataRow dataRowTPProcedures = null;
            DataTable dataTableTPObjective = null;
            bool disableProcedureProvider = false;
            int siteID = -1;
            int totalUnits = 0;
            string documentCodeId = string.Empty;
            string documentStatus = string.Empty;
            string fromDate = string.Empty;

            try
            {
                if (dataSetInterventionPlan.Tables.Contains("CustomCarePlanPrescribedServices"))
                {
                    if (BaseCommonFunctions.CheckRowExists(dataSetInterventionPlan, "Documents", 0))
                    {
                        documentCodeId = Convert.ToString(dataSetInterventionPlan.Tables["Documents"].Rows[0]["DocumentCodeId"]);
                        documentStatus = Convert.ToString(dataSetInterventionPlan.Tables["Documents"].Rows[0]["Status"]);
                        fromDate = Convert.ToString(dataSetInterventionPlan.Tables["Documents"].Rows[0]["EffectiveDate"]);
                        HiddenField_EndDate.Value = DateTime.Parse(fromDate.ToString()).AddMonths(12).ToString("MM/dd/yyyy");
                    }

                    if (dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServices"].Rows.Count > 0)
                    {
                        stringBuilderHTML = new StringBuilder();
                        dataRowInterventionPlan = dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServices"].Select("Isnull(RecordDeleted,'N')<>'Y' and CarePlanPrescribedServiceId='" + carePlanPrescribedServiceId + "'");
                        if (dataRowInterventionPlan.Length > 0)
                        {
                            DataView dataViewTPInterventionProcedures = new DataView(dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServices"]);
                            //dataViewTPInterventionProcedures.Sort = "CarePlanPrescribedServiceId";

                            dataViewTPInterventionProcedures.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'and CarePlanPrescribedServiceId=" + carePlanPrescribedServiceId;

                            stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");

                            stringBuilderHTML.Append("<tr>");  
                            stringBuilderHTML.Append("<td align='left'>");
                            stringBuilderHTML.Append("<table style='width:100%;' border='0' cellpadding='0' cellspacing='3' id='tbl_InterventionSection_" + carePlanPrescribedServiceId + "'>");
                            if (dataViewTPInterventionProcedures.Count > 0)
                            {
                                for (int interventionCount = 0; interventionCount < dataViewTPInterventionProcedures.Count; interventionCount++)
                                {
                                    stringBuilderHTML.Append("<tr class='tr_InterventionProcedures_" + carePlanPrescribedServiceId + "'>");
                                    stringBuilderHTML.Append("<td style='width:10px;color:Black;font-size:11px;' valign='top'>");
                                    stringBuilderHTML.Append("<img style='cursor:hand;' id='ImgDelete_" + carePlanPrescribedServiceId + "' src=" + RelativePath + "App_Themes/Includes/Images/deleteIcon.gif  onClick= \"DeleteIntervention('" + carePlanPrescribedServiceId + "','true');\" />");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td align='left' class='form_label'>Provider</td>");
                                    stringBuilderHTML.Append("<td valign='top'>");

                                    PanelInterventionPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                    string tpProcedureId = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"]);
                                    string authorizationCodeId = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]);
                                    totalUnits = dataViewTPInterventionProcedures[interventionCount]["TotalUnits"] != DBNull.Value ? Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TotalUnits"]) : 0;

                                    stringBuilderHTML = new StringBuilder();
                                    dropdownListinterVentionProvider = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionProvider.Width = 120;
                                    dropdownListinterVentionProvider.CssClass = "form_dropdown";

                                    dropdownListinterVentionProvider.ID = "DropDownList_CustomCarePlanPrescribedServices_ProviderId_" + carePlanPrescribedServiceId;
                                    if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers != null)
                                    {
                                        DataView dataViewProviders = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers);
                                        dataViewProviders.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y' and isnull(RenderingProvider,'N')<>'Y' ";
                                        dropdownListinterVentionProvider.DataTextField = "ProviderName";
                                        dropdownListinterVentionProvider.DataValueField = "SiteId";
                                        dropdownListinterVentionProvider.DataSource = dataViewProviders;
                                        dropdownListinterVentionProvider.DataBind();
                                        dropdownListinterVentionProvider.Items.Insert(0, new ListItem(agencyName, "-1"));
                                        dropdownListinterVentionProvider.Items.Insert(1, new ListItem("Community/Natural Support", "-2"));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["ProviderId"] != DBNull.Value)
                                    {
                                        siteID = Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["ProviderId"]);
                                        dropdownListinterVentionProvider.SelectedValue = Convert.ToString(siteID);
                                    }
                                    else
                                    {
                                        siteID = -1;
                                    }
                                    dropdownListinterVentionProvider.Attributes.Add("onChange", "ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','ProviderId','" + dropdownListinterVentionProvider.ClientID + "','Edit','CarePlanPrescribedServiceId');");
                                    dropdownListinterVentionProvider.Attributes.Add("GoalNo", dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"].ToString());
                                    dropdownListinterVentionProvider.Attributes.Add("SiteId", siteID.ToString());
                                    dropdownListinterVentionProvider.Attributes.Add("BindAutoSaveEvents", "False");
                                    dropdownListinterVentionProvider.Attributes.Add("BindSetFormData", "False");

                                    PanelInterventionPlanMain.Controls.Add(dropdownListinterVentionProvider);
                                    stringBuilderHTML = new StringBuilder();
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td align='center' class='form_label'>From Date</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>To Date</td>");
                                    stringBuilderHTML.Append("<td align='left' class='form_label'># Units</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>Frequency</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>Requested</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label'>Person Responsible</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;' valign='top'></td>");
                                    stringBuilderHTML.Append("<td align='left' class='form_label'>Intervention</td>");
                                    stringBuilderHTML.Append("<td>");
                                    stringBuilderHTML.Append("<span id='Span_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceId + "' name='Span_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceId + "'>" + CreateServiceDropDownList(carePlanPrescribedServiceId, disableProcedureProvider, tpProcedureId, authorizationCodeId, siteID, "") + "</span>");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("<td valign='top' align='center'>");
                                    stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0'>");
                                    stringBuilderHTML.Append("<tr class='date_Container'>");
                                    stringBuilderHTML.Append("<td style='padding-left:3px;'>");

                                    if (dataViewTPInterventionProcedures[interventionCount]["FromDate"] == DBNull.Value)
                                    {
                                        dataViewTPInterventionProcedures[interventionCount]["FromDate"] = fromDate;
                                    }
                                    stringBuilderHTML.Append("<input type='text'  BindAutoSaveEvents ='False'  BindSetFormData='False' datatype='Date' value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["FromDate"]).ToString("MM/dd/yyyy") + "' name='Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "' id='Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "' class='form_textbox' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','FromDate','" + "Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "','Edit','CarePlanPrescribedServiceId');\" />");

                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td align='center'>");
                                    stringBuilderHTML.Append("&nbsp;<img id='Img_FromDate_" + carePlanPrescribedServiceId + "' name=Img_FromDate_" + carePlanPrescribedServiceId + "  src=" + RelativePath + "App_Themes/Includes/Images/calender_grey.gif  style='cursor:hand;' onclick=\"return showCalendar('Text_CustomCarePlanPrescribedServices_FromDate_" + carePlanPrescribedServiceId + "','%m/%d/%Y');\"/>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("</table>");
                                    stringBuilderHTML.Append("</td>");


                                    stringBuilderHTML.Append("<td valign='top' align='center'>");
                                    stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0'>");
                                    stringBuilderHTML.Append("<tr class='date_Container'>");
                                    stringBuilderHTML.Append("<td style='padding-left:3px;'>");
                                    if (dataViewTPInterventionProcedures[interventionCount]["ToDate"] != DBNull.Value)
                                    {
                                        stringBuilderHTML.Append("<input type='text' BindAutoSaveEvents ='False'  BindSetFormData='False' datatype='Date' value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["ToDate"]).ToString("MM/dd/yyyy") + "'   name='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "'  id='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "' class='form_textbox' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','ToDate','" + "Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input type='text' BindAutoSaveEvents ='False'  BindSetFormData='False' datatype='Date'  name='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "'  id='Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "' class='form_textbox' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','ToDate','" + "Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td align='center'>");
                                    stringBuilderHTML.Append("&nbsp;<img id='Img_ToDate_" + carePlanPrescribedServiceId + "' name='Img_ToDate_" + carePlanPrescribedServiceId + "'  src=" + RelativePath + "App_Themes/Includes/Images/calender_grey.gif  style='cursor:hand;' onclick=\"return showCalendar('Text_CustomCarePlanPrescribedServices_ToDate_" + carePlanPrescribedServiceId + "','%m/%d/%Y');\"/>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("</table>");
                                    stringBuilderHTML.Append("</td>");


                                    stringBuilderHTML.Append("<td align='left' class='form_label' valign='top'>");
                                    if (dataViewTPInterventionProcedures[interventionCount]["Units"] == DBNull.Value)
                                    {
                                        stringBuilderHTML.Append("<input BindAutoSaveEvents ='False' class='dateTextBoxWidth form_textbox' style='width:30px;' datatype='Numeric' BindSetFormData='False' type='text' id='Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Units','" + "Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input BindAutoSaveEvents ='False' class='dateTextBoxWidth form_textbox' style='width:30px;' datatype='Numeric' BindSetFormData='False' type='text' id='Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "' value='" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Units"]) + "' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Units','" + "Text_CustomCarePlanPrescribedServices_Units_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }

                                    stringBuilderHTML.Append("<span style='margin-left: 10px;'>per</span>");

                                    stringBuilderHTML.Append("</td>");
                                    
                                    stringBuilderHTML.Append("<td align='center' class='form_label' valign='top'>");
                                    PanelInterventionPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                    
                                    //Error Start
                                    dropdownListinterVentionFrequency = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionFrequency.Enabled = true;
                                    dropdownListinterVentionFrequency.Width = 100;
                                    dropdownListinterVentionFrequency.CssClass = "form_dropdown";
                                    dropdownListinterVentionFrequency.ID = "DropDownList_CustomCarePlanPrescribedServices_Frequency_" + carePlanPrescribedServiceId;
                                    using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPFREQUENCYTYPE", true, "", "SortOrder", false))
                                    {
                                        dropdownListinterVentionFrequency.DataTextField = "CodeName";
                                        dropdownListinterVentionFrequency.DataValueField = "GlobalCodeId";
                                        dropdownListinterVentionFrequency.DataSource = DataViewGlobalCodes;
                                        dropdownListinterVentionFrequency.DataBind();
                                        dropdownListinterVentionFrequency.Items.Insert(0, new ListItem("", ""));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["Frequency"] != DBNull.Value)
                                    {
                                        if (Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Frequency"]) != string.Empty)
                                        {
                                            dropdownListinterVentionFrequency.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Frequency"]);
                                        }
                                    }
                                    dropdownListinterVentionFrequency.Attributes.Add("onChange", "ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Frequency','" + dropdownListinterVentionFrequency.ClientID + "','Edit','CarePlanPrescribedServiceId');");
                                    dropdownListinterVentionFrequency.Attributes.Add("GoalNo", dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"].ToString());
                                    dropdownListinterVentionFrequency.Attributes.Add("SiteId", siteID.ToString());
                                    dropdownListinterVentionFrequency.Attributes.Add("BindAutoSaveEvents", "False");
                                    dropdownListinterVentionFrequency.Attributes.Add("BindSetFormData", "False");

                                    PanelInterventionPlanMain.Controls.Add(dropdownListinterVentionFrequency);
                                    stringBuilderHTML = new StringBuilder();
                                    stringBuilderHTML.Append("</td>");


                                    stringBuilderHTML.Append("<td align='center' class='form_label' valign='top'>");
                                    if (dataViewTPInterventionProcedures[interventionCount]["TotalUnits"] == DBNull.Value)
                                    {
                                        stringBuilderHTML.Append("<input BindAutoSaveEvents ='False' class='dateTextBoxWidth form_textbox' style='width:30px;' datatype='Numeric' BindSetFormData='False' type='text' id='Text_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','TotalUnits','" + "Text_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input BindAutoSaveEvents ='False' class='dateTextBoxWidth form_textbox' style='width:30px;' datatype='Numeric' BindSetFormData='False' type='text' id='Text_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' value='" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TotalUnits"]) + "' onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','TotalUnits','" + "Text_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\" />");
                                    }
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td align='center' class='form_label' valign='top'>");

                                    PanelInterventionPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));


                                    dropdownListinterVentionPersonResponsible = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionPersonResponsible.Enabled = true;
                                    dropdownListinterVentionPersonResponsible.Width = 100;
                                    dropdownListinterVentionPersonResponsible.CssClass = "form_dropdown";
                                    dropdownListinterVentionPersonResponsible.ID = "DropDownList_CustomCarePlanPrescribedServices_PersonResponsible_" + carePlanPrescribedServiceId;
                                    using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("PRESCRIBEDRESP", true, "", "SortOrder", false))
                                    {
                                        dropdownListinterVentionPersonResponsible.DataTextField = "CodeName";
                                        dropdownListinterVentionPersonResponsible.DataValueField = "GlobalCodeId";
                                        dropdownListinterVentionPersonResponsible.DataSource = DataViewGlobalCodes;
                                        dropdownListinterVentionPersonResponsible.DataBind();
                                        dropdownListinterVentionPersonResponsible.Items.Insert(0, new ListItem("", ""));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["PersonResponsible"] != DBNull.Value)
                                    {
                                        if (Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["PersonResponsible"]) != string.Empty)
                                        {
                                            dropdownListinterVentionPersonResponsible.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["PersonResponsible"]);
                                        }
                                    }
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("onChange", "ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','PersonResponsible','" + dropdownListinterVentionPersonResponsible.ClientID + "','Edit','CarePlanPrescribedServiceId');");
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("GoalNo", dataViewTPInterventionProcedures[interventionCount]["CarePlanPrescribedServiceId"].ToString());
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("SiteId", siteID.ToString());
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("BindAutoSaveEvents", "False");
                                    dropdownListinterVentionPersonResponsible.Attributes.Add("BindSetFormData", "False");

                                    PanelInterventionPlanMain.Controls.Add(dropdownListinterVentionPersonResponsible);
                                    stringBuilderHTML = new StringBuilder();
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td><span>1 Unit = </span>");
                                    if (string.IsNullOrEmpty(authorizationCodeId))
                                    {
                                        stringBuilderHTML.Append("<span id='Label_UnitValue_" + carePlanPrescribedServiceId + "'>&nbsp;1</span>");
                                        stringBuilderHTML.Append("<span id='Label_UnitType_" + carePlanPrescribedServiceId + "'>&nbsp;Encounter</span>");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append(GetUnitTypeAndValue(authorizationCodeId, carePlanPrescribedServiceId));
                                    }
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td colspan='5'>&nbsp;</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr class='tr_LCMCCM_" + carePlanPrescribedServiceId + "'>");
                                    
                                    stringBuilderHTML.Append("<td colspan='9'>");
                                    stringBuilderHTML.Append("<table style='width:99%;' border='0' cellpadding='0' cellspacing='3'>");

                                    int LCMValue, CCMValue, sumPreviousValue, totalUnitRequested = 0;
                                    stringBuilderHTML.Append(ShowValueInAuthCodeSection(authorizationCodeId, siteID, carePlanPrescribedServiceId, totalUnits, out LCMValue, out CCMValue, out sumPreviousValue));

                                    stringBuilderHTML.Append("</table>");
                                    stringBuilderHTML.Append("</td>");

                                    stringBuilderHTML.Append("</tr>");

                                    totalUnitRequested = sumPreviousValue + totalUnits;

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td colspan='7'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td align='center'>");
                                    if ((LCMValue > 0) && (totalUnitRequested > LCMValue))
                                        stringBuilderHTML.Append("<label style='color:red;' id='Label_LCM_Over_" + carePlanPrescribedServiceId + "'>" + (totalUnitRequested - LCMValue) + "</label>");
                                    else
                                        stringBuilderHTML.Append("<label style='visibility:hidden;color:red;' id='Label_LCM_Over_" + carePlanPrescribedServiceId + "'></label>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td align='center'>");
                                    if ((CCMValue > 0) && (totalUnitRequested > CCMValue))
                                        stringBuilderHTML.Append("<label style='color:red;' id='Label_CCM_Over_" + carePlanPrescribedServiceId + "'>" + (totalUnitRequested - CCMValue) + "</label>");
                                    else
                                        stringBuilderHTML.Append("<label style='visibility:hidden;color:red;' id='Label_CCM_Over_" + carePlanPrescribedServiceId + "'></label>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td colspan='9'>");
                                    if (((LCMValue > 0) || (CCMValue > 0)) && ((totalUnitRequested > LCMValue) || (totalUnitRequested > CCMValue)))
                                        stringBuilderHTML.Append("<span id='spnLCMAndCCMOver_" + carePlanPrescribedServiceId + "' style='color:red;'>Your current request equals or exceeds the amount allowed for auto approval.  Additional review will be needed to approve the authorization request.</span>");
                                    else
                                        stringBuilderHTML.Append("<span id='spnLCMAndCCMOver_" + carePlanPrescribedServiceId + "' style='color:red; display:none;'>Your current request equals or exceeds the amount allowed for auto approval.  Additional review will be needed to approve the authorization request.</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");


                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td colspan='2'>");
                                    stringBuilderHTML.Append("<span id='Span_" + carePlanPrescribedServiceId + "' class='span_textunderline_cursor' style='text-decoration: underline; color: blue;' onclick=\"OpenModelDialogueforEditViewObjectives(" + carePlanPrescribedServiceId + ",'')\" ");
                                    stringBuilderHTML.Append("tabindex='0' onfocus=\"this.style.fontWeight='bold'\" onblur=\"this.style.fontWeight='normal'\" onkeypress=\"if(event.keyCode==13){ OpenModelDialogueforEditViewObjectives(" + carePlanPrescribedServiceId + ",'')  }\">  ");
                                    stringBuilderHTML.Append("Link/Unlink Objectives</<span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td colspan='6'>");
                                    stringBuilderHTML.Append("<div id='Div_EditViewObjectives_" + carePlanPrescribedServiceId + "' class='form_textareaWithoutWidth' style='margin-left: 4px;width:580px;border:1px solid #ccc;background:#f2f2f2;padding:4px;'>");

                                    if (dataSetInterventionPlan.Tables.Contains("CustomCarePlanPrescribedServiceObjectives"))
                                    {
                                        if (SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServiceObjectives"], 0))
                                        {
                                            DataView dataRowPrescribedServiceObjectivesArray = new DataView(dataSetInterventionPlan.Tables["CustomCarePlanPrescribedServiceObjectives"]);
                                            dataRowPrescribedServiceObjectivesArray.RowFilter = "CarePlanPrescribedServiceId=" + carePlanPrescribedServiceId + "AND ISNULL(RecordDeleted,'N')<>'Y'";
                                            dataRowPrescribedServiceObjectivesArray.Sort = "CarePlanPrescribedServiceId DESC";

                                            string htmlObjectiveSection = string.Empty;
                                            string objectiveDesc = string.Empty;
                                            string ObjectiveNum = string.Empty;

                                            for (int rowCounter = 0; rowCounter < dataRowPrescribedServiceObjectivesArray.Count; rowCounter++)
                                            {
                                                string objectiveId = Convert.ToString(dataRowPrescribedServiceObjectivesArray[rowCounter]["CarePlanObjectiveId"]);
                                                DataView dataViewCarePlanObjectives = new DataView(dataSetInterventionPlan.Tables["CarePlanObjectives"]);
                                                dataViewCarePlanObjectives.RowFilter = "CarePlanObjectiveId=" + objectiveId + "AND ISNULL(RecordDeleted,'N')<>'Y'";
                                                if (dataViewCarePlanObjectives.Count > 0)
                                                {
                                                    ObjectiveNum = Convert.ToString(dataViewCarePlanObjectives[0]["ObjectiveNumber"]);

                                                    if (rowCounter == dataRowPrescribedServiceObjectivesArray.Count - 1)
                                                    {
                                                        htmlObjectiveSection = ObjectiveNum;
                                                    }
                                                    else
                                                    {
                                                        htmlObjectiveSection = ObjectiveNum + ",";
                                                    }
                                                    htmlObjectiveSection = HttpUtility.HtmlDecode(htmlObjectiveSection);
                                                }
                                            }
                                            stringBuilderHTML.Append(htmlObjectiveSection);
                                        }
                                    }

                                    stringBuilderHTML.Append("</div>");
                                    stringBuilderHTML.Append("</td>");

                                    
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:10px;'>&nbsp;</td>");
                                    stringBuilderHTML.Append("<td colspan='8'>");
                                    stringBuilderHTML.Append("<textarea spellcheck='True' bindautosaveevents='False' bindsetformdata='False' data-preventexpand='1' id='TextArea_CarePlanPrescribedServices_Detail_" + carePlanPrescribedServiceId + "' name='TextArea_CarePlanPrescribedServices_Detail_" + carePlanPrescribedServiceId + "' ");
                                    stringBuilderHTML.Append("onChange=\"ModifyInterventionValueInDataSet('" + carePlanPrescribedServiceId + "','CustomCarePlanPrescribedServices','Detail','" + "TextArea_CarePlanPrescribedServices_Detail_" + carePlanPrescribedServiceId + "','" + "Edit" + "','CarePlanPrescribedServiceId');\"  ");
                                    stringBuilderHTML.Append("rows='4' cols='114' style='width: 99%' class='form_textareaWithoutWidth'>" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Detail"]) + "</textarea> ");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr><td>&nbsp;</td></tr>");

                                }
                            }
                            stringBuilderHTML.Append("</table>");

                            stringBuilderHTML.Append("</td>");//1st Row 3rd Col Close Tag
                            stringBuilderHTML.Append("</tr>");


                            PanelInterventionPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            finally
            {
                dataRowInterventionPlan = null;
                dataRowTPInterventionPObjective = null;
            }
        }

        /// <summary>
        /// <Description>Method is used to calculate unit on the selection</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>09 Oct,2009</CreatedOn>
        /// </summary>
        private string DisplayUnitType(DropDownList dropdownlistFrequency)
        {
            string selectedValue = string.Empty;
            string strCodeName = string.Empty;
            string[] parameterCollection = null;
            DataSet dataSetAuthorization = null;
            DataSet dataSetTemp = null;
            DataView dataViewAuthorization = null;
            DataRow[] dataRowAuthorizationCodeName = null;
            DataRow[] dataRowGlobalCodes = null;
            Int32 unitTypeValue = 0;
            Int32 units = 0;
            string unitCounterText = string.Empty;
            try
            {
                // selectedValue = Request.Form["selectedValue"];
                char[] cSpilt = new char[1];
                cSpilt[0] = ',';
                if (Request.Form["UnitCount"] != null)
                {
                    parameterCollection = Request.Form["UnitCount"].Split(cSpilt);
                }
                dataRowAuthorizationCodeName = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("Active='Y'", "AuthorizationCodeName");
                dataSetAuthorization = new DataSet();
                dataSetAuthorization.EnforceConstraints = false;//Need to Check Anuj forcefully  enforced constraints false.
                dataSetAuthorization.Merge(dataRowAuthorizationCodeName);

                dataViewAuthorization = new DataView(dataSetAuthorization.Tables[0]);

                dataViewAuthorization.RowFilter = "AuthorizationCodeId=" + Convert.ToInt32(dropdownlistFrequency.SelectedValue);
                if (dataViewAuthorization.Count > 0 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != -1 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != 0)
                {
                    if (dataViewAuthorization[0]["UnitType"] != null && dataViewAuthorization[0]["UnitType"] != System.DBNull.Value)
                        unitTypeValue = Convert.ToInt32(dataViewAuthorization[0]["UnitType"]);
                    if (dataViewAuthorization[0]["Units"] != null && dataViewAuthorization[0]["Units"] != System.DBNull.Value)
                        units = Convert.ToInt32(dataViewAuthorization[0]["Units"]);

                }

                dataRowGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitTypeValue);

                dataSetTemp = new DataSet();

                if (dataRowGlobalCodes.Length > 0)
                {
                    dataSetTemp.Merge(dataRowGlobalCodes);

                    if (unitTypeValue == 120 || unitTypeValue == 110)
                    {
                        // modified by Piyush on 6th March 2007 as per comment on "3/2/2007 8:08:07 AM " on task 390
                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 6);
                        if (units != 1)
                            unitCounterText = "(1 Unit = " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit = " + units + " " + strCodeName + ")";
                    }
                    else if (unitTypeValue == 124)
                    {

                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 9);
                        if (units != 1)
                            unitCounterText = "(1 Unit =  " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit =  " + units + " " + strCodeName + ")";
                    }
                    else
                    {
                        unitCounterText = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    }
                }

                return unitCounterText;
            }

            finally
            {

                selectedValue = string.Empty;
                strCodeName = string.Empty;
                parameterCollection = null;
                dataSetAuthorization = null;
                dataSetTemp = null;
                dataViewAuthorization = null;
                dataRowAuthorizationCodeName = null;
                dataRowGlobalCodes = null;

            }
        }

        /// <Description>Method is used to Create Service Dropdownlist for 'CreateIntervention' section of TxPlan</Description>
        /// <Author>Shifali</Author>
        /// <Purpose>Added by shifali on 29 sept,2010 in ref to task# 4 of UM - Part two</Purpose>
        /// <ModifiedBy> Rakesh Garg </ModifiedBy>
        /// <ModifiedDate> 23 Nove 2010 </ModifiedDate>
        /// </summary>
        /// <returns></returns>
        private StringBuilder CreateServiceDropDownList(string carePlanPrescribedServiceIdValue, bool disableProcedureProvider, string tpProcedureId, string authorizationCodeId, int siteID, string InitializedFromPreviousPlan)
        {
            StringBuilder strHtml = new StringBuilder();
            DataSet _dsAuthorizationCodes = null;

            if (_dsAuthorizationCodes == null)
            {
                SHS.UserBusinessServices.TreatmentPlan objectTreatmentPlan = new SHS.UserBusinessServices.TreatmentPlan();
                try
                {
                    _dsAuthorizationCodes = GetAuthorizationCodeTxPlanMain(siteID);
                    _InteractionAuthorizationCodesHRMTxPlan.Add(new InteractionAuthorizationCodesIntervention() { dsAuthorizationCodes = _dsAuthorizationCodes, siteid = siteID });
                }
                catch (Exception ex)
                {

                }
            }
            if (_dsAuthorizationCodes.Tables.Count > 0 && _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Rows.Count > 0)
            {
                //if (disableProcedureProvider == false)
                //{
                //    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' goalNo='" + CarePlanPrescribedServiceIdVal + "' TPProcedureId='" + tpProcedureId + "' SiteId='" + siteID + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                //else
                //{
                    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;'  goalNo='" + CarePlanPrescribedServiceIdVal + "' TPProcedureId='" + tpProcedureId + "' SiteId='" + siteID + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}

                //For Filling Core Services
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                DataRow[] drCoreServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Core Services'", "DisplayAs asc");
                for (int loopCounter = 0; loopCounter < drCoreServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {   //By Vikas Vyas in ref. to task #679
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option selected='selected' title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }


                //For Filling Speciality Services
                strHtml.Append("</optgroup>");

                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");

                DataRow[] drSpecialityServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Speciality Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drSpecialityServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }

                //For Filling Other Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");

                DataRow[] drOtherServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Other Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drOtherServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }
                strHtml.Append("</optgroup>");

                strHtml.Append("</select>");
                return strHtml;
            }
            else
            {
                //if (disableProcedureProvider == false)
                //{
                //    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                //else
                //{
                    strHtml.Append("<select id='DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "' class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyInterventionValueInDataSet(" + carePlanPrescribedServiceIdValue + ",'CustomCarePlanPrescribedServices','AuthorizationCodeId','DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + carePlanPrescribedServiceIdValue + "','Edit','CarePlanPrescribedServiceId');\"  style='height:20px;color: Black;width:120px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                //}
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                //For Filling Speciality Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("</select>");
            }

            return strHtml;
            

        }

        public DataSet GetAuthorizationCodeTxPlanMain(int SiteID)
        {
            DataSet dataSetAuthorizationCodeTxPlanMain = null;
            try
            {
                DataSet dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                if (dsCurrentScreen == null)
                    dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

                int ClientId = 0;
                int DocumentVersionId = 0;
                if (dsCurrentScreen.IsDataTableFound("Documents"))
                {
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                }
                if (ClientId <= 0)
                    ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                dataSetAuthorizationCodeTxPlanMain = new DataSet();
                System.Data.SqlClient.SqlParameter[] _objectSqlParmeters = new System.Data.SqlClient.SqlParameter[3];
                _objectSqlParmeters[0] = new System.Data.SqlClient.SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new System.Data.SqlClient.SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[2] = new System.Data.SqlClient.SqlParameter("@SiteID", SiteID);
                Microsoft.ApplicationBlocks.Data.SqlHelper.FillDataset(SHS.DataServices.Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCGetTPServiceUMAuthorization", dataSetAuthorizationCodeTxPlanMain, new string[] { "TPServiceAuthorizationCodes" }, _objectSqlParmeters);

            }
            catch
            {

            }
            return dataSetAuthorizationCodeTxPlanMain;
        }


        private string ShowValueInAuthCodeSection(string authorizationCodeId, int siteId, string carePlanPrescribedServiceId, int totalUnits, out int LCMVal, out int CCmVal, out int sumPreviousVal)
        {
            StringBuilder stringBuilderHTMLLCMCCM = null;
            LCMVal = 0;
            CCmVal = 0;
            sumPreviousVal = 0;
            int sumPreviousCount=0;
            stringBuilderHTMLLCMCCM = new StringBuilder();
            stringBuilderHTMLLCMCCM.Append("<tr>");
            stringBuilderHTMLLCMCCM.Append("<td style='width:10px;'>&nbsp;</td>");
            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
            stringBuilderHTMLLCMCCM.Append("<td align='center' style='font-weight: bold'>");
            stringBuilderHTMLLCMCCM.Append("<span class='form_label'>Requested</span>");
            stringBuilderHTMLLCMCCM.Append("</td>");
            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
            stringBuilderHTMLLCMCCM.Append("<td align='center' style='font-weight: bold'>");
            stringBuilderHTMLLCMCCM.Append("<span class='form_label'>Previously Requested</span>");
            stringBuilderHTMLLCMCCM.Append("</td>");
            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
            stringBuilderHTMLLCMCCM.Append("<td align='center' style='font-weight: bold'>");
            stringBuilderHTMLLCMCCM.Append("<span class='form_label'>Total</span>");
            stringBuilderHTMLLCMCCM.Append("</td>");
            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
            stringBuilderHTMLLCMCCM.Append("<td align='center' style='font-weight: bold'>");
            stringBuilderHTMLLCMCCM.Append("<span class='form_label'>LCM Cap</span>");
            stringBuilderHTMLLCMCCM.Append("</td>");
            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
            stringBuilderHTMLLCMCCM.Append("<td align='center' style='font-weight: bold'>");
            stringBuilderHTMLLCMCCM.Append("<span class='form_label'>CCM Cap</span>");
            stringBuilderHTMLLCMCCM.Append("</td>");
            stringBuilderHTMLLCMCCM.Append("</tr>");

            if (!string.IsNullOrEmpty(authorizationCodeId))
            {
                SHS.UserBusinessServices.TreatmentPlan objectTreatmentPlan = null;
                objectTreatmentPlan = new SHS.UserBusinessServices.TreatmentPlan();
                try
                {
                    DataRow[] drAuthCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("ISNULL(RecordDeleted,'N')<>'Y' and AuthorizationCodeId=" + authorizationCodeId);
                    int UMCodeId = 0;
                    DataSet dataSetLCMAndCCM = GetLCMAndCCM(Convert.ToInt32(authorizationCodeId));
                    if (dataSetLCMAndCCM != null)
                    {
                        if (dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows.Count > 0)
                        {
                            int.TryParse(Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["UMCodeId"]), out UMCodeId);
                            stringBuilderHTMLLCMCCM.Append("<tr>");
                            stringBuilderHTMLLCMCCM.Append("<td style='width:10px;'>&nbsp;</td>");
                            stringBuilderHTMLLCMCCM.Append("<td><span id='Span_UMCode_" + carePlanPrescribedServiceId + "'>" + BaseCommonFunctions.TrancateElementText(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CodeName"].ToString(), 20) + "</span></td>");
                            stringBuilderHTMLLCMCCM.Append("<td><span id='Span_ServiceCategory_" + carePlanPrescribedServiceId + "'>" + BaseCommonFunctions.TrancateElementText(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["ServiceCategoryName"].ToString(), 20) + "</span></td>");
                            stringBuilderHTMLLCMCCM.Append(CalculatePreviousRequested(siteId, Convert.ToInt32(authorizationCodeId), UMCodeId, carePlanPrescribedServiceId, totalUnits,out sumPreviousCount));
                            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
                            stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_LCM_" + carePlanPrescribedServiceId + "' class='form_label'>" + Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["LCM12MonthMax"]) + "</label></td>");
                            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
                            stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CCM_" + carePlanPrescribedServiceId + "' class='form_label'>" + Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CCM12MonthMax"]) + "</label></td>");
                            stringBuilderHTMLLCMCCM.Append("</tr>");
                            LCMVal = Convert.ToInt32(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["LCM12MonthMax"]);
                            CCmVal = Convert.ToInt32(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CCM12MonthMax"]);
                            sumPreviousVal = sumPreviousCount;
                        }
                        else
                        {
                            stringBuilderHTMLLCMCCM.Append("<tr>");
                            stringBuilderHTMLLCMCCM.Append("<td style='width:10px;'>&nbsp;</td>");
                            stringBuilderHTMLLCMCCM.Append("<td><span id='Span_UMCode_" + carePlanPrescribedServiceId + "'></span></td>");
                            stringBuilderHTMLLCMCCM.Append("<td><span id='Span_ServiceCategory_" + carePlanPrescribedServiceId + "'></span></td>");
                            stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' class='form_label'>" + totalUnits + "</label></td>");
                            stringBuilderHTMLLCMCCM.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>+</span></td>");
                            stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_PreviouslyRequested_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                            stringBuilderHTMLLCMCCM.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>=</span></td>");
                            stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalRequestedYTD_" + carePlanPrescribedServiceId + "' class='form_label'>" + totalUnits + "</label></td>");
                            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
                            stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_LCM_" + carePlanPrescribedServiceId + "' class='form_label'></label></td>");
                            stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
                            stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CCM_" + carePlanPrescribedServiceId + "' class='form_label'></label></td>");
                            stringBuilderHTMLLCMCCM.Append("</tr>");
                        }
                    }
                }
                finally
                {
                    objectTreatmentPlan = null;
                }
            }
            else
            {
                stringBuilderHTMLLCMCCM.Append("<tr>");
                stringBuilderHTMLLCMCCM.Append("<td style='width:10px;'>&nbsp;</td>");
                stringBuilderHTMLLCMCCM.Append("<td><span id='Span_UMCode_" + carePlanPrescribedServiceId + "'></span></td>");
                stringBuilderHTMLLCMCCM.Append("<td><span id='Span_ServiceCategory_" + carePlanPrescribedServiceId + "'></span></td>");
                stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                stringBuilderHTMLLCMCCM.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>+</span></td>");
                stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_PreviouslyRequested_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                stringBuilderHTMLLCMCCM.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>=</span></td>");
                stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalRequestedYTD_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
                stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_LCM_" + carePlanPrescribedServiceId + "' class='form_label'></label></td>");
                stringBuilderHTMLLCMCCM.Append("<td>&nbsp;</td>");
                stringBuilderHTMLLCMCCM.Append("<td align='center'><label id='Label_CCM_" + carePlanPrescribedServiceId + "' class='form_label'></label></td>");
                stringBuilderHTMLLCMCCM.Append("</tr>");
            }
            return stringBuilderHTMLLCMCCM.ToString();
        }

        private string CalculatePreviousRequested(int siteId, int authorizationCodeId, int UMCodeId, string carePlanPrescribedServiceId, int totalUnits, out int sumPrevious)
        {
            sumPrevious = 0;
            StringBuilder stringBuilderHTMLPrevReq = null;
            stringBuilderHTMLPrevReq = new StringBuilder();
            try
            {
                using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
                {
                    int sumPrev = 0;

                    DataRow[] drTPInterventions = null;
                    if (siteId != -1)
                    {
                        drTPInterventions = dataSetTreatmentPlanHRM.Tables["CustomCarePlanPrescribedServices"].Select("AuthorizationCodeId=" + authorizationCodeId + " and  ProviderId=" + siteId + " and CarePlanPrescribedServiceId <> " + carePlanPrescribedServiceId);
                    }
                    else
                    {
                        drTPInterventions = dataSetTreatmentPlanHRM.Tables["CustomCarePlanPrescribedServices"].Select("AuthorizationCodeId=" + authorizationCodeId + " and  ((ProviderId is null or ProviderId = -1) or (ProviderId=" + siteId + ")) and CarePlanPrescribedServiceId <> " + carePlanPrescribedServiceId);
                    }

                    if (drTPInterventions.Length > 0)
                    {
                        foreach (DataRow drTPInt in drTPInterventions)
                        {
                            int totalSumInterven = 0;
                            int.TryParse(Convert.ToInt32(drTPInt["TotalUnits"] == DBNull.Value ? 0 : drTPInt["TotalUnits"]).ToString(), out totalSumInterven);
                            sumPrev += totalSumInterven;
                        }
                    }

                    if (BaseCommonFunctions.CheckRowExists(dataSetTreatmentPlanHRM, "PreviouslyRequested"))
                    {
                        DataRow[] dr = dataSetTreatmentPlanHRM.Tables["PreviouslyRequested"].Select("UMCodeId=" + UMCodeId);
                        if (dr.Length > 0)
                        {
                            sumPrev += Convert.ToInt32(dr[0]["TotalRequested"]);
                        }

                    }
                    if (sumPrev > 0)
                    {
                        stringBuilderHTMLPrevReq.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' class='form_label'>" + totalUnits + "</label></td>");
                        stringBuilderHTMLPrevReq.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>+</span></td>");
                        stringBuilderHTMLPrevReq.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_PreviouslyRequested_" + carePlanPrescribedServiceId + "' class='form_label'>" + sumPrev.ToString() + "</label></td>");
                        stringBuilderHTMLPrevReq.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>=</span></td>");
                        stringBuilderHTMLPrevReq.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalRequestedYTD_" + carePlanPrescribedServiceId + "' class='form_label'>" + (totalUnits + sumPrev).ToString() + "</label></td>");
                        sumPrevious = sumPrev;
                    }
                    else
                    {
                        stringBuilderHTMLPrevReq.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServiceId + "' class='form_label'>" + totalUnits + "</label></td>");
                        stringBuilderHTMLPrevReq.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>+</span></td>");
                        stringBuilderHTMLPrevReq.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_PreviouslyRequested_" + carePlanPrescribedServiceId + "' class='form_label'>0</label></td>");
                        stringBuilderHTMLPrevReq.Append("<td><span style='font-size: 18px; font-weight: bold' class='form_label'>=</span></td>");
                        stringBuilderHTMLPrevReq.Append("<td align='center'><label id='Label_CustomCarePlanPrescribedServices_TotalRequestedYTD_" + carePlanPrescribedServiceId + "' class='form_label'>" + totalUnits + "</label></td>");
                    }
                }
            }
            catch (Exception Ex)
            { 
            }
            return stringBuilderHTMLPrevReq.ToString();

        }

        public DataSet GetLCMAndCCM(int AuthorizationCodeId)
        {
            DataSet DataSetLCMAndCCM = null;
            SqlParameter[] _objectSqlParmeters = new SqlParameter[2];
            try
            {
                DataSet dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                if (dsCurrentScreen == null)
                    dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

                int ClientId = 0;
                int DocumentVersionId = 0;
                if (dsCurrentScreen.IsDataTableFound("Documents"))
                {
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                }
                if (ClientId <= 0)
                    ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                DataSetLCMAndCCM = new DataSet();
                _objectSqlParmeters = new SqlParameter[3];
                _objectSqlParmeters[0] = new SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[2] = new SqlParameter("@AuthorizationCodeId", AuthorizationCodeId);
                SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCWebGetLCMAndCCM", DataSetLCMAndCCM, new string[] { "LCMAndCCM" }, _objectSqlParmeters);
                return DataSetLCMAndCCM;
            }
            finally
            {
                if (DataSetLCMAndCCM != null)
                    DataSetLCMAndCCM.Dispose();
                _objectSqlParmeters = null;
            }

        }

        public string GetUnitTypeAndValue(string AuthorizationCodeId, string carePlanPrescribedServiceIdVal)
        {
            StringBuilder stringBuilderHTMLUnit = null;
            stringBuilderHTMLUnit = new StringBuilder();
            decimal units = 0;
            int unitType = 0;
            try
            {
                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes != null && SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Rows.Count > 0)
                {
                    DataRow[] drAuthorizationCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("AuthorizationCodeId=" + AuthorizationCodeId);
                    if (drAuthorizationCode.Length > 0)
                    {
                        int.TryParse(Convert.ToString(drAuthorizationCode[0]["UnitType"]), out unitType);
                        decimal.TryParse(Convert.ToString(drAuthorizationCode[0]["Units"]), out units);

                        DataRow[] drGlobalCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitType);
                        stringBuilderHTMLUnit.Append("<span id='Label_UnitValue_" + carePlanPrescribedServiceIdVal + "'>" + Convert.ToString(Math.Floor(Convert.ToDecimal(units))) + "</span>");
                        if (drGlobalCode.Length > 0)
                            stringBuilderHTMLUnit.Append("<span id='Label_UnitType_" + carePlanPrescribedServiceIdVal + "'>&nbsp;" + Convert.ToString(drGlobalCode[0]["CodeName"]) + "</span>");
                        else
                            stringBuilderHTMLUnit.Append("<span id='Label_UnitType_" + carePlanPrescribedServiceIdVal + "'>&nbsp;Encounter</span>");
                    }
                    else
                    {
                        stringBuilderHTMLUnit.Append("<span id='Label_UnitValue_" + carePlanPrescribedServiceIdVal + "'>&nbsp;1</span>");
                        stringBuilderHTMLUnit.Append("<span id='Label_UnitType_" + carePlanPrescribedServiceIdVal + "'>&nbsp;Encounter</span>");
                    }
                }
                else
                {
                    stringBuilderHTMLUnit.Append("<span id='Label_UnitValue_" + carePlanPrescribedServiceIdVal + "'>&nbsp;1</span>");
                    stringBuilderHTMLUnit.Append("<span id='Label_UnitType_" + carePlanPrescribedServiceIdVal + "'>&nbsp;Encounter</span>");
                }
            }
            catch (Exception ex)
            {
 
            }
            return stringBuilderHTMLUnit.ToString();
        }



    }

    public class InteractionAuthorizationCodesIntervention
    {
        public int siteid { get; set; }
        public DataSet dsAuthorizationCodes { get; set; }
    }

    public class EditViewObjectives
    {
        public string ObjectiveNumber = string.Empty;
        public string ObjectiveDescription = string.Empty;
        public string RowXML = string.Empty;
    }



}