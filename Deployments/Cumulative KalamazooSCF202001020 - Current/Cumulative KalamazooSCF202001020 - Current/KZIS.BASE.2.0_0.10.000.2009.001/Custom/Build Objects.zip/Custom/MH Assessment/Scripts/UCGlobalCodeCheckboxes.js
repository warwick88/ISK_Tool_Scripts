﻿function UpdateUCCheckBoxToXML(obj, PrimayKeyTableName, PrimayKeyColumnName, ForeignKeyTableName, ForeignKeyColumnName, GlobalCodeId, CheckBoxValueColumn, GlobalCodeColumnName) {

    var _PKColumnId = 0;
    var RowExists = true;
    if (AutoSaveXMLDom.find(PrimayKeyTableName).length == 0)
        RowExists = false;
        //else if (AutoSaveXMLDom.find(PrimayKeyTableName + ">GlobalCodeId").length == 0)
        //    RowExists = false;
        //else if (AutoSaveXMLDom.find(PrimayKeyTableName + ">GlobalCodeId[text='" + GlobalCodeId + "']").length == 0)
        //    RowExists = false;
    else if (AutoSaveXMLDom.find(PrimayKeyTableName + ">" + GlobalCodeColumnName + "[text='" + GlobalCodeId + "']").length == 0)
        RowExists = false;

    if (RowExists == false) {
        AutoSaveXMLDom.find(PrimayKeyTableName).each(function () {
            $(this).children().each(function () {
                if (this.tagName == PrimayKeyColumnName) {
                    if (parseInt($(this).text()) < 0 && _PKColumnId <= 0 && _PKColumnId > parseInt($(this).text())) {
                        _PKColumnId = parseInt($(this).text());
                    }
                }
            });
        });

        if (_PKColumnId == 0)
            _PKColumnId = -1
        else
            _PKColumnId = _PKColumnId + (-1);

        var _columnid;
        var _createdby;
        var _createddate;
        var _modifiedby;
        var _modifieddate;
        var _foreignkey;
        var _globalcodeid;

        var _xmltable = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement(PrimayKeyTableName)); //Add Table
        _columnid = _xmltable.appendChild(AutoSaveXMLDom[0].createElement(PrimayKeyColumnName)); //Add Column
        _columnid.text = _PKColumnId;

        _createdby = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedBy')); //Add Column
        _createdby.text = objectPageResponse.LoggedInUserCode;

        _createddate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedDate')); //Add Column
        _createddate.text = UCCheckBoxDateString(new Date());

        _modifiedby = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedBy')); //Add Column
        _modifiedby.text = objectPageResponse.LoggedInUserCode;

        _modifieddate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedDate')); //Add Column
        _modifieddate.text = UCCheckBoxDateString(new Date());

        _globalcodeid = _xmltable.appendChild(AutoSaveXMLDom[0].createElement(GlobalCodeColumnName)); //Add Column
        _globalcodeid.text = GlobalCodeId;

        if (AutoSaveXMLDom.find(ForeignKeyTableName).length > 0) {
            if (AutoSaveXMLDom.find(ForeignKeyTableName + ">" + ForeignKeyColumnName).length > 0) {
                _foreignkey = _xmltable.appendChild(AutoSaveXMLDom[0].createElement(ForeignKeyColumnName)); //Add Column
                _foreignkey.text = AutoSaveXMLDom.find(ForeignKeyTableName + ":first " + ForeignKeyColumnName).text();
            }
        }
    }

    var CtrlValue = "N";
    if ($(obj).length > 0) {
        if ($(obj).attr('checked'))
            CtrlValue = 'Y';
    }

    //SetColumnValueInXMLNodeByKeyValue(PrimayKeyTableName, "GlobalCodeId", GlobalCodeId, CheckBoxValueColumn, CtrlValue, AutoSaveXMLDom[0]);
    //SetColumnValueInXMLNodeByKeyValue(PrimayKeyTableName, "GlobalCodeId", GlobalCodeId, "ModifiedBy", objectPageResponse.LoggedInUserCode, AutoSaveXMLDom[0]);
    //SetColumnValueInXMLNodeByKeyValue(PrimayKeyTableName, "GlobalCodeId", GlobalCodeId, "ModifiedDate", UCCheckBoxDateString(new Date()), AutoSaveXMLDom[0]);
    //CreateUnsavedInstanceOnDatasetChange();
    //AddToUnsavedTables(PrimayKeyTableName);

    SetColumnValueInXMLNodeByKeyValue(PrimayKeyTableName, GlobalCodeColumnName, GlobalCodeId, CheckBoxValueColumn, CtrlValue, AutoSaveXMLDom[0]);
    SetColumnValueInXMLNodeByKeyValue(PrimayKeyTableName, GlobalCodeColumnName, GlobalCodeId, "ModifiedBy", objectPageResponse.LoggedInUserCode, AutoSaveXMLDom[0]);
    SetColumnValueInXMLNodeByKeyValue(PrimayKeyTableName, GlobalCodeColumnName, GlobalCodeId, "ModifiedDate", UCCheckBoxDateString(new Date()), AutoSaveXMLDom[0]);
    CreateUnsavedInstanceOnDatasetChange();
    AddToUnsavedTables(PrimayKeyTableName);


    //Start - #103 - Four Winds - Customizations 

    var textArray = [];
    var textVal = "";
    var finaltext = "";
    textVal = $(obj).attr('labels')[0].innerText;

    //if (CtrlValue == 'Y') {  //If checkbox is checked.
    //    if ($('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val() == "") {
    //        $('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val(textVal + '\n')
    //    }
    //    else {
    //        var str = $('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val();
    //        $('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val(str + textVal + '\n');
    //    }
    //}

    //else { //If checkbox is Unchecked.

    //    var lines = $('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val().split('\n');
    //    for (var i = 0; i < lines.length; i++) {
    //        textArray.push(lines[i]);
    //    }
    //    var valIndex = textArray.indexOf(textVal);
    //    if (valIndex != -1) {
    //        textArray.splice(valIndex, 1);
    //    }

    //    textArray.pop();
    //    $('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val('');
    //    for (var i = 0; i < textArray.length; i++) {
    //        finaltext = finaltext + textArray[i] + '\n';
    //    }
    //    $('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val(finaltext);
    //}
   // CreateAutoSaveXml("CustomInquiryMedicals", "ReleventMedicalHistoryComments", $('[id$=TextArea_CustomInquiryMedicals_ReleventMedicalHistoryComments]').val());
    //End - #103 - Four Winds - Customizations

}

function UCCheckBoxDateString(dateIn) {
    var d;
    if ((typeof (dateIn) === 'date') ? true : (typeof (dateIn) === 'object') ? dateIn.constructor.toString().match(/date/i) !== null : false) {
        d = dateIn;
    } else {
        d = new Date(dateIn);
    }
    function pad(n) {
        n = parseInt(n, 10);
        return n < 10 ? '0' + n : n;
    }
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' +
        pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}