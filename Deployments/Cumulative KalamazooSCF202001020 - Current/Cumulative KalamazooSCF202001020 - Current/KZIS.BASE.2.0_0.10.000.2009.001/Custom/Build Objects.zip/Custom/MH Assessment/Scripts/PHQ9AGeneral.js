﻿var count = 0;
function SetScorePHQ9A(pObject) {
    count = 0;
    $('#tablePHQ9AIdDropDown').find('select :selected').each(function () {
        if ($(this).text() == 'Not at all') {
            count = count + 0;
        }
        if ($(this).text() == 'Several Days') {
            count = count + 1;
        }
        if ($(this).text() == 'More than half the days') {
            count = count + 2;
        }
        if ($(this).text() == 'Nearly every day') {
            count = count + 3;
        }
    });
    $('#Textbox_PHQ9ADocuments_TotalScore').val(count);
    DepressionSeverityPHQ9A();
}


function DepressionSeverityPHQ9A() {
    if (count >= 0 && count <= 4)
        $('[id$=Textbox_PHQ9ADocuments_SeverityScore]').val('');
    if (count >= 5 && count <= 9)
        $('[id$=Textbox_PHQ9ADocuments_SeverityScore]').val('Mild');
    if (count >= 10 && count <= 14)
        $('[id$=Textbox_PHQ9ADocuments_SeverityScore]').val('Moderate');
    if (count >= 15 && count <= 19)
        $('[id$=Textbox_PHQ9ADocuments_SeverityScore]').val('Moderately severe');
    if (count >= 20 && count <= 27)
        $('[id$=Textbox_PHQ9ADocuments_SeverityScore]').val('Severe');
    CreateAutoSaveXml("PHQ9ADocuments", "SeverityScore", $('#Textbox_PHQ9ADocuments_SeverityScore').val());
    CreateAutoSaveXml("PHQ9ADocuments", "TotalScore", count);
}

function ClientDeclinedPHQAOnClick(CreateAutoSave) {

    var $PHQAClientDeclinedToParticipate = "N";

    if (AutoSaveXMLDom && GetAutoSaveXMLDomNode("PHQ9ADocuments").length > 0) {
        $PHQAClientDeclinedToParticipate = GetColumnValueInXMLNodeByKeyValue('PHQ9ADocuments', 'DocumentVersionId',
            GetCurrentDocumentVersionID(), 'ClientDeclinedToParticipate', AutoSaveXMLDom[0]);
    }

    if ($('#CheckBox_PHQ9ADocuments_ClientDeclinedToParticipate').attr('checked') == true || ($PHQAClientDeclinedToParticipate == "Y" && CreateAutoSave == false)) {
        $('#divPHQA').find('input[type=text],input[type=radio],input[type=checkbox],select,textarea').attr('disabled', 'disabled').val('');

        $('#Button_PerformedTime_Now').attr('disabled', 'disabled');

        $('[id*=RadioButton_PHQ9ADocuments_]').removeAttr('checked');

        $('#Textbox_PHQ9ADocuments_PerformedDate').removeAttr('required');
        $('#Textbox_PHQ9ADocuments_PerformedTime').removeAttr('required');

        if (CreateAutoSave == true) {

            CreateAutoSaveXmlObj([{
                "PHQ9ADocuments": {
                    "FeelingDown": '', "LittleInterest": '', "PerformedAt": '', "PerformedDate": '', "TroubleFalling": '', "PoorAppetite": '', "FeelingTired": ''
                    , "FeelingBad": '', "TroubleConcentrating": '', "MovingOrSpeakingSlowly": '', "HurtingYourself": '', "PastYear": '', "ProblemDifficulty": ''
                    , "PastMonth": '', "SuicideAttempt": '', "TotalScore": '', "SeverityScore": '', "Comments": '', "ClientRefusedOrContraIndicated": ''
                }
            }]);

        }
    }
    else {
        $('#divPHQA').find('input[type=text],input[type=radio],input[type=checkbox],select,textarea').removeAttr('disabled');

        $('#Button_PerformedTime_Now').removeAttr('disabled');

        $('#Textbox_PHQ9ADocuments_PerformedDate').attr('required', 'required');
        $('#Textbox_PHQ9ADocuments_PerformedTime').attr('required', 'required');

    }
    $('#Textbox_PHQ9ADocuments_TotalScore').attr('disabled', 'disabled');
    $('#Textbox_PHQ9ADocuments_SeverityScore').attr('disabled', 'disabled');
    $('#CheckBox_PHQ9ADocuments_ClientDeclinedToParticipate').removeAttr('disabled');

}
function setTimeNowPHQ9A() {
    var timeControl = $('#Textbox_PHQ9ADocuments_PerformedTime');
    var dateControl = $('#Textbox_PHQ9ADocuments_PerformedDate');

    var dt = new Date();

    dateControl.val(dt.format("MM/dd/yyyy"));

    var timeDate = new Date();
    var time = timeDate.format("hh:mm tt")
    timeControl.val(time);

    onPerformedAtChangePHQ9A('true');
    return false;
}

function onPerformedAtChangePHQ9A(AutoSave) {
    var date = $('#Textbox_PHQ9ADocuments_PerformedDate');
    var time = $('#Textbox_PHQ9ADocuments_PerformedTime');
    if (time.length > 0 && time.val() != 'undefined') {
        FormatTimeatClientSide(document.getElementById('Textbox_PHQ9ADocuments_PerformedTime'));
    }
    if (date.length > 0 && date.val() != 'undefined' && time.val() != "" && time.val() != 'undefined') {
        if (ValidateDate(document.getElementById('Textbox_PHQ9ADocuments_PerformedDate')) && time.val() !== "") {
            var dateTime = new Date(date.val() + ' ' + time.val());
            if (dateTime && date.val() && time.val()) {

                ShowHideErrorMessage("Performed At is a required field.", "false");
                if (AutoSave == 'true') {
                    CreateAutoSaveXml('PHQ9ADocuments', 'PerformedAt', ISODateString(dateTime));
                }
                else {
                    var DocumentVersionId = AutoSaveXMLDom.find("PHQ9ADocuments:first DocumentVersionId").text();
                    SetColumnValueInXMLNodeByKeyValue("PHQ9ADocuments", "DocumentVersionId", DocumentVersionId, "PerformedAt", ISODateString(dateTime), AutoSaveXMLDom[0]);
                }
                AddToUnsavedTables("PHQ9ADocuments");
                return;
            }
        }
    }
    ShowHideErrorMessage("Performed At is a required field.", "true");
    return;

}
function initPerformedAtPHQ9A() {

    var $PHQAClientDeclinedToParticipate = "N";

    if (AutoSaveXMLDom && GetAutoSaveXMLDomNode("PHQ9ADocuments").length > 0) {
        $PHQAClientDeclinedToParticipate = GetColumnValueInXMLNodeByKeyValue('PHQ9ADocuments', 'DocumentVersionId',
            GetCurrentDocumentVersionID(), 'ClientDeclinedToParticipate', AutoSaveXMLDom[0]);
    }
    
    var dateControl = $('#Textbox_PHQ9ADocuments_PerformedDate');
    var timeControl = $('#Textbox_PHQ9ADocuments_PerformedTime');
    var nowControl = $('#Button_PerformedTime_Now');

    dateControl.unbind('change').change(function () { onPerformedAtChangePHQ9A('true'); });
    timeControl.unbind('change').change(function () { onPerformedAtChangePHQ9A('true'); });

    if (nowControl) {
        nowControl.unbind('click').click(function () { setTimeNowPHQ9A(); });
    }

    if (!($PHQAClientDeclinedToParticipate == "Y")) {
        if (AutoSaveXMLDom && GetAutoSaveXMLDomNode("PHQ9ADocuments").length > 0) {
            var performedAt = GetColumnValueInXMLNodeByKeyValue('PHQ9ADocuments', 'DocumentVersionId',
                GetCurrentDocumentVersionID(), 'PerformedAt', AutoSaveXMLDom[0]);

            if (performedAt !== "") {

                if (dateControl) {
                    var d = new Date(performedAt.split("T")[0].replace("-", "/"));
                    dateControl.val(d.format("MM/dd/yyyy"));
                }
                if (timeControl) {
                    //Get the time without the timestamp
                    //SmartCare always assumes the timezone is what the server is set to, if you are in a different timezone than the server
                    //when a time is loaded, it is adjusted to the computers local time zone.. when saved it is saved as the timezone of the server .. no timezone information is saved it is always assumed server
                    //time zone server side
                    var time = performedAt.split("T")[1].split("-")[0];
                    var tempDate = "01/01/2999" + " " + time;

                    var d = new Date(tempDate);
                    if (d == "Invalid Date") {
                        var _time = performedAt.split("T")[1].split("+")[0];
                        var time = _time.split(".");
                        var tempDate = "01/31/2070" + " " + time[0];
                        d = new Date(tempDate);
                    }
                    timeControl.val(d.format("hh:mm tt"));
                }
            } else {
                var dt = new Date();
                dateControl.val(dt.format("MM/dd/yyyy"));
                var timeDate = new Date();
                var time = timeDate.format("hh:mm tt")
                timeControl.val(time);
                onPerformedAtChangePHQ9A('false');
            }
        }
    }
    return;
}
$(document).ready(function () {
    //this value will be set to "Y" if the document is a standalone, if it is embedded in another control, the value will be "" as the hiddenfield will note exist
    var standalonePHQ9 = "N";
    standalonePHQ9 = $('#StandalonePHQ9A').length ? "Y" : "N";
    if (standalonePHQ9 === "Y") {
        return;
    }
    BindControlChangeEventsPHQA();
});

function BindControlChangeEventsPHQA() {

    $('[id$=DropDownList_PHQ9ADocuments_FeelingDown]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_LittleInterest]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_TroubleFalling]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_FeelingTired]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_PoorAppetite]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_FeelingBad]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_TroubleConcentrating]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_MovingOrSpeakingSlowly]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    $('[id$=DropDownList_PHQ9ADocuments_HurtingYourself]').unbind('change').bind('change', function () { SetScorePHQ9A($(this)); });
    ClientDeclinedPHQAOnClick(false);

    initPerformedAtPHQ9A();
}
