﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;
using System.Data.SqlClient;
using SHS.DataServices;

namespace SHS.SmartCare
{

    public partial class ActivityPages_Client_Detail_Assessment_HRMMentalStatus : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        int MSEFormID;
        public override void BindControls()
        {
            SqlParameter[] _objectSqlParmeters;
            _objectSqlParmeters = new SqlParameter[1];
            String FormGUID = "1ACAF7C6-1084-47D5-BC87-D35D45147228";
            _objectSqlParmeters[0] = new SqlParameter("@FormGUID", FormGUID);
            MSEFormID = (int)DBManager.ExecuteScalar(Connection.ConnectionString, "csp_SCGetFormFormId", _objectSqlParmeters);

            DynamicForms_MHMentalStatus.FormId = MSEFormID;
            DynamicForms_MHMentalStatus.Activate();
        }
    }
}
