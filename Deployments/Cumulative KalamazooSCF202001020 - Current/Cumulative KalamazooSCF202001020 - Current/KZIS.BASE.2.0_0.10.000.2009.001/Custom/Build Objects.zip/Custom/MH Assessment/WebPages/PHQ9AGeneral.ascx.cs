﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SHS.BaseLayer;

public partial class Modules_PHQ9A_WebPages_PHQ9AGeneral : SHS.BaseLayer.ActivityPages.DataActivityTab
{
    public override string[] TablesUsedInTab
    {
        get
        {
            return new string[] { "PHQ9ADocuments" };
        }
    }
    public override void BindControls()
    {
        DropDownList_PHQ9ADocuments_FeelingDown.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_FeelingDown.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_LittleInterest.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_LittleInterest.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_TroubleFalling.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_TroubleFalling.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_PoorAppetite.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_PoorAppetite.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_FeelingTired.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_FeelingTired.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_FeelingBad.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_FeelingBad.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_TroubleConcentrating.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_TroubleConcentrating.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_MovingOrSpeakingSlowly.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_MovingOrSpeakingSlowly.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_HurtingYourself.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_HurtingYourself.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9ADocuments_ProblemDifficulty.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9ADocuments_ProblemDifficulty.FillDropDownDropGlobalCodes();

        //DropDownList_CustomDocumentPsychiatricNoteAIMs_LipsPerioralArea.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        //DropDownList_CustomDocumentPsychiatricNoteAIMs_LipsPerioralArea.FillDropDownDropGlobalCodes();
                 
    }


    
}