﻿$("document").ready(function () {
    try {        
        SetScreenData();
        ClientGuardianinfo();
        return false;

    }
    catch (err) {
        LogClientSideException(err, 'Summary'); 
    }
});




function SetParentReturnValue(val) {
    try {
       
        if (val == 'ok') {
            var Firstname = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianFirstName]").val();
            var Lastname = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianLastName]").val(); 
            var address = $("[id$=TextArea_CustomDocumentMHAssessments_GuardianAddress]").val(); 
            var phone = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianPhone]").val();
            var City = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianCity]").val();
            var relation = $("[id$=DropDownList_CustomDocumentMHAssessments_RelationWithGuardian option:selected]").text();
            var State = $("[id$=DropDownList_CustomDocumentMHAssessments_GuardianState option:selected]").text();
            var Zip = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianZipcode]").val();
            //-------------
          
            var type = $("[id$=DropDownList_CustomDocumentMHAssessments_RelationWithGuardian]").val();
            var StateCode = $("[id$=DropDownList_CustomDocumentMHAssessments_GuardianState]").val();
          
            retValue = Firstname + " \n" + Lastname + " \n" + address + " \n" + "State: " + State + " \n" + "Phone:  " + phone + " \n" + "City: " + City +"\n"+"State:"+StateCode+ " \n" + "Zip:" + Zip + " \n" + " \n" + "Text: " + type
            window.returnValue = retValue;
        }
        else if (val == 'cancel') {
            window.returnValue = "";
        }
        window.close();
    }
    catch (err) {
        LogClientSideException(err, 'GuardianInfo'); //Code added by Damanpreet 
    }
}

function SetScreenData() {
    //Modified by sourabh with ref to task#452
    var newDom = $.xmlDOM(parent.window.AutoSaveXMLDom[0].xml);
    AutoSaveXMLDom = newDom;
    
    var xmlHrmAssessmentRow = AutoSaveXMLDom[0].childNodes[0].selectNodes("CustomDocumentMHAssessments");
    if (xmlHrmAssessmentRow[0].selectNodes("GuardianFirstName").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianFirstName")[0].text.trim() != '') {
        $("input[id$=TextBox_CustomDocumentMHAssessments_GuardianFirstName]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianFirstName")[0].text);

    }
    if (xmlHrmAssessmentRow[0].selectNodes("GuardianLastName").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianLastName")[0].text.trim() != '') {
        $("input[id$=TextBox_CustomDocumentMHAssessments_GuardianLastName]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianLastName")[0].text);

    }
    if (xmlHrmAssessmentRow[0].selectNodes("GuardianAddress").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianAddress")[0].text.trim() != '') {
        $("textarea[id$=TextArea_CustomDocumentMHAssessments_GuardianAddress]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianAddress")[0].text);
    }
    if (xmlHrmAssessmentRow[0].selectNodes("GuardianCity").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianCity")[0].text.trim() != '') {
        $("input[id$=TextBox_CustomDocumentMHAssessments_GuardianCity]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianCity")[0].text);
    }
    if (xmlHrmAssessmentRow[0].selectNodes("GuardianState").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianState")[0].text.trim() != '') {
        $("select:[id$=DropDownList_CustomDocumentMHAssessments_Guardianstate]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianState")[0].text);
    }
    if (xmlHrmAssessmentRow[0].selectNodes("GuardianZipcode").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianZipcode")[0].text.trim() != '') {
        $("input[id$=TextBox_CustomDocumentMHAssessments_GuardianZipcode]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianZipcode")[0].text);
    }
 
    if (xmlHrmAssessmentRow[0].selectNodes("GuardianPhone").length > 0 && xmlHrmAssessmentRow[0].selectNodes("GuardianPhone")[0].text.trim() != '') {
        $("input[id$=TextBox_CustomDocumentMHAssessments_GuardianPhone]").val(xmlHrmAssessmentRow[0].selectNodes("GuardianPhone")[0].text);
    }


    if (xmlHrmAssessmentRow[0].selectNodes("RelationWithGuardian").length > 0 && xmlHrmAssessmentRow[0].selectNodes("RelationWithGuardian")[0].text.trim() != '') {
        $("select:[id$=DropDownList_CustomDocumentMHAssessments_RelationWithGuardian]").val(xmlHrmAssessmentRow[0].selectNodes("RelationWithGuardian")[0].text);
    }


}


 //Checks Max length of address textarea
//UpdateScreen(buttonClicked, isExternalURL, isPopUp)
function CheckAddressMaxLength(buttonClicked, isExternalURL, isPopUp) {   
    if ($("[id$=TextArea_CustomDocumentMHAssessments_GuardianAddress]").val().length <= 100) {
        UpdateScreen(buttonClicked, isExternalURL, isPopUp);
    }
    else {
        ShowHideErrorMessage('Address can not be more than 100 characters', 'true');
        return;
    }
}


function validateZIP(field) {
    /*Modified By Sumanta, Use regular expression for US zip code*/
    var reZip = new RegExp(/(^\d{5}$)|(^\d{5}-\d{4}$)/);
    return reZip.test(field);
}
function ClientGuardianinfo() {
    try {
          $("[id$=TextBox_CustomDocumentMHAssessments_GuardianFirstName]").change(function () {
            var GuardianFirstName = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianFirstName]").val();
            if (GuardianFirstName != "") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianFirstName', GuardianFirstName);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianFirstName', '');
        });
        $("[id$=TextBox_CustomDocumentMHAssessments_GuardianLastName]").change(function () {
            var GuardianLastName = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianLastName]").val();
            if (GuardianLastName != "") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianLastName', GuardianLastName);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianLastName', '');
        });

        $("[id$=TextArea_CustomDocumentMHAssessments_GuardianAddress]").change(function () {
            var GuardianAddress = $("[id$=TextArea_CustomDocumentMHAssessments_GuardianAddress]").val();
            if (GuardianAddress != "") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianAddress', GuardianAddress);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianAddress', '');
        });

        $("[id$=TextBox_CustomDocumentMHAssessments_GuardianPhone]").change(function () {
            PhoneFormatCheck(this);
            var GuardianPhone = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianPhone]").val();
            if (GuardianPhone != "") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianPhone', GuardianPhone);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianPhone', '');
        });
        $("[id$=TextBox_CustomDocumentMHAssessments_GuardianCity]").change(function () {
            var GuardianCity = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianCity]").val();
            if (GuardianCity != "") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianCity', GuardianCity);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianCity', '');
        });
        $("[id$=DropDownList_CustomDocumentMHAssessments_Guardianstate]").change(function () {
            var StateOfGuardianText = $("[id$=DropDownList_CustomDocumentMHAssessments_Guardianstate] option:selected").text();
            if (StateOfGuardianText != "" && StateOfGuardianText != "Select State") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianStateText', StateOfGuardianText);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianStateText', '');

            var GuardianState = $("[id$=DropDownList_CustomDocumentMHAssessments_Guardianstate] option:selected").val();
            if (GuardianState != "" && GuardianState != "Select State") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianState', GuardianState);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianState', '');
        });

        $("[id$=TextBox_CustomDocumentMHAssessments_GuardianZipcode]").change(function () {

            var returnStatus = true;
            var GuardianZipcode = $("[id$=TextBox_CustomDocumentMHAssessments_GuardianZipcode]").val();
           // returnStatus = validateZIP(GuardianZipcode)
            //if (returnStatus == true) {
                if (GuardianZipcode != "") {
                    CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianZipcode', GuardianZipcode);
                }
                else
                    CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianZipcode', '');
            // }
            //else {
             //   CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianZipcode', '');
              //  ShowHideErrorMessage('Invalid Zipcode', 'true');
              //  return;
                //CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianZipcode', '');
            //}
        });

        $("[id$=DropDownList_CustomDocumentMHAssessments_RelationWithGuardian]").change(function () {
            var RelationWithGuardianText = $("[id$=DropDownList_CustomDocumentMHAssessments_RelationWithGuardian] option:selected").text();
            if (RelationWithGuardianText != "") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianTypeText', RelationWithGuardianText);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'GuardianTypeText', '');

            var RelationWithGuardianType = $("[id$=DropDownList_CustomDocumentMHAssessments_RelationWithGuardian] option:selected").val();
            if (RelationWithGuardianType != "") {
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'RelationWithGuardian', RelationWithGuardianType);
            }
            else
                CreateAutoSaveXml('CustomDocumentMHAssessments', 'RelationWithGuardian', '');

        });

    }
    catch (err) {
        LogClientSideException(err, 'CustomDocumentMHAssessments');
    }
}