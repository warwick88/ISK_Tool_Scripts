﻿function CSSRSChildAdolescentSinceLTHideandShow(obj) {
    if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                .text()) == "Yes") {

            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDeadDescription')
                .attr("disabled", false);

            $('#SB1').hide();
            $('#SB2').hide();

            $('#IID').show();

        } else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'WishToBeDeadDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDeadDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDeadDescription')
              .attr("disabled", true);

            if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == "No") {

                $('#SB1').show();
                $('#SB2').show();

                $('#IID').hide();
            }
            else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
           .text()) == '') {
                $('#IID').hide();
            }
            else { }

        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'WishToBeDeadDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDeadDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDeadDescription')
                   .attr("disabled", true);

            $('#SB1').hide();
            $('#SB2').hide();
            if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == '') {
                $('#IID').hide();
            }
        }

    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == "Yes") {

            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughtsDescription')
                .attr("disabled", false);

            $('#3').show();
            $('#4').show();
            $('#5').show();

            $('#SB1').hide();
            $('#SB2').hide();

            $('#IID').show();

        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'NonSpecificActiveSuicidalThoughtsDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughtsDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughtsDescription')
                .attr("disabled", true);

            $('#3').hide();
            $('#4').hide();
            $('#5').hide();

            if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                .text()) == "No") {

                $('#SB1').show();
                $('#SB2').show();

                $('#IID').hide();

            }
            else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
           .text()) == '') {
                $('#IID').hide();
                $('#3').hide();
                $('#4').hide();
                $('#5').hide();

                $('#SB1').hide();
                $('#SB2').hide();
            }
            else {
            }
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'NonSpecificActiveSuicidalThoughtsDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughtsDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughtsDescription')
                  .attr("disabled", true);

            $('#3').hide();
            $('#4').hide();
            $('#5').hide();

            $('#SB1').hide();
            $('#SB2').hide();
            if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                 .text()) == '') {
                $('#IID').hide();
            }
        }
    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct] option:selected")
                .text()) == "Yes") {
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription')
                .attr("disabled", false);

        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription')
                .attr("disabled", true);

        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription')
                    .attr("disabled", true);
        }
    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan] option:selected")
                .text()) == "Yes") {
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription')
                .attr("disabled", false);

        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription')
                .attr("disabled", true);

        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription')
                   .attr("disabled", true);
        }
    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent] option:selected")
                .text()) == "Yes") {
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntentDescription')
                .attr("disabled", false);
        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'AciveSuicidalIdeationWithSpecificPlanAndIntentDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntentDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntentDescription')
                .attr("disabled", true);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'AciveSuicidalIdeationWithSpecificPlanAndIntentDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntentDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntentDescription')
                   .attr("disabled", true);
        }
    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt] option:selected")
                .text()) == "Yes") {
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttempts')
                .attr("disabled", false);
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttemptDescription')
                .attr("disabled", false);

        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberOfAttempts', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttempts]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttempts')
                .attr("disabled", true);

            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'ActualAttemptDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttemptDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttemptDescription')
                .attr("disabled", true);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberOfAttempts', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttempts]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttempts')
                   .attr("disabled", true);
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'ActualAttemptDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttemptDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttemptDescription')
                .attr("disabled", true);
        }
    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt] option:selected")
                .text()) == "Yes") {
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttemptsInterrupted')
                .attr("disabled", false);
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttemptDescription')
                .attr("disabled", false);

        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberOfAttemptsInterrupted', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttemptsInterrupted]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttemptsInterrupted')
                .attr("disabled", true);

            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'InterruptedAttemptDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttemptDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttemptDescription')
                .attr("disabled", true);

        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberOfAttemptsInterrupted', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttemptsInterrupted]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttemptsInterrupted')
                  .attr("disabled", true);

            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'InterruptedAttemptDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttemptDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttemptDescription')
                .attr("disabled", true);
        }
    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt] option:selected")
                .text()) == "Yes") {
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberAttemptsAbortedOrSelfInterrupted')
                .attr("disabled", false);
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttemptDescription')
                .attr("disabled", false);

        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberAttemptsAbortedOrSelfInterrupted', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberAttemptsAbortedOrSelfInterrupted]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberAttemptsAbortedOrSelfInterrupted')
                .attr("disabled", true);

            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'AbortedOrSelfInterruptedAttemptDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttemptDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttemptDescription')
                .attr("disabled", true);

        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberAttemptsAbortedOrSelfInterrupted', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberAttemptsAbortedOrSelfInterrupted]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberAttemptsAbortedOrSelfInterrupted')
                   .attr("disabled", true);

            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'AbortedOrSelfInterruptedAttemptDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttemptDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttemptDescription')
                .attr("disabled", true);
        }
    } else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior') {
        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior] option:selected")
                .text()) == "Yes") {
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfPreparatoryActs')
                .attr("disabled", false);
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehaviorDescription')
                .attr("disabled", false);
        }
        else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior] option:selected")
                .text()) == "No") {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberOfPreparatoryActs', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfPreparatoryActs]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfPreparatoryActs')
                .attr("disabled", true);

            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'PreparatoryActsOrBehaviorDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehaviorDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehaviorDescription')
                .attr("disabled", true);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'TotalNumberOfPreparatoryActs', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfPreparatoryActs]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfPreparatoryActs')
                   .attr("disabled", true);

            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'PreparatoryActsOrBehaviorDescription', '');
            $('[id$=TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehaviorDescription]').val("");
            $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehaviorDescription')
                .attr("disabled", true);
        }
    }
    else if (obj == 'DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation') {
        if ($('[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation]').val()) {
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeationDescription')
                .attr("disabled", false);
        }
        else {
            CreateAutoSaveXml('CustomDocumentMHColumbiaAdultSinceLastVisits', 'MostSevereIdeationDescription', '');
            $('[id$=TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeationDescription]').val("");
            $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeationDescription')
                .attr("disabled", true);
        }
    }
}

function RefreshCSSRSChildAdolescentSinceLTHideandShow() {
    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                  .text()) == "Yes") {
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDeadDescription')
             .attr("disabled", false);

        $('#SB1').hide();
        $('#SB2').hide();

        $('#IID').show();

    }
    else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                .text()) == "No") {

        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == "No") {

            $('#SB1').show();
            $('#SB2').show();

            $('#IID').hide();

        }

    }

    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == "Yes") {
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughtsDescription')
                .attr("disabled", false);
        $('#3').show();
        $('#4').show();
        $('#5').show();

        $('#SB1').hide();
        $('#SB2').hide();

        $('#IID').show();
    }
    else if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == "No") {

        $('#3').hide();
        $('#4').hide();
        $('#5').hide();

        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                .text()) == "No") {

            $('#SB1').show();
            $('#SB2').show();

            $('#IID').hide();

        }
    }
    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead] option:selected")
                  .text()) == '') {
        $('#SB1').hide();
        $('#SB2').hide();

        if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts] option:selected")
                .text()) == '') {
            $('#IID').hide();
            $('#3').hide();
            $('#4').hide();
            $('#5').hide();
        }
    }

    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct] option:selected")
               .text()) == "Yes") {
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToActDescription')
             .attr("disabled", false);
    }
    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan] option:selected")
              .text()) == "Yes") {
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlanDescription')
             .attr("disabled", false);
    }
    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent] option:selected")
              .text()) == "Yes") {
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntentDescription')
             .attr("disabled", false);
    }
    if ($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation] option:selected").val()) {
        $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeationDescription')
             .attr("disabled", false);
    }
    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt] option:selected")
              .text()) == "Yes") {
        $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttempts')
             .attr("disabled", false);
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttemptDescription')
            .attr("disabled", false);
    }

    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt] option:selected")
             .text()) == "Yes") {
        $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfAttemptsInterrupted')
             .attr("disabled", false);
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttemptDescription')
            .attr("disabled", false);
    }

    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt] option:selected")
            .text()) == "Yes") {
        $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberAttemptsAbortedOrSelfInterrupted')
             .attr("disabled", false);
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttemptDescription')
            .attr("disabled", false);
    }

    if ($.trim($("[id$=DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior] option:selected")
            .text()) == "Yes") {
        $('#TextBox_CustomDocumentMHColumbiaAdultSinceLastVisits_TotalNumberOfPreparatoryActs')
             .attr("disabled", false);
        $('#TextArea_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehaviorDescription')
            .attr("disabled", false);
    }
}

