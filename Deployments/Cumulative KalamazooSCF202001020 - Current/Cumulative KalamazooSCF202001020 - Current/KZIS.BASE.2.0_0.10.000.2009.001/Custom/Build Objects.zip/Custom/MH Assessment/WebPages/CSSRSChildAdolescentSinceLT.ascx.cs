﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;
using SHS.BaseLayer.ActivityPages;
namespace SHS.SmartCare
{
    public partial class Custom_Assessment_WebPages_CSSRSChildAdolescentSinceLT : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        public override void BindControls()
        {
            DataSet ds = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("XCSSRSYESNO", true, "", "", false))
            {
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_WishToBeDead.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_NonSpecificActiveSuicidalThoughts.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithAnyMethodsWithoutIntentToAct.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActiveSuicidalIdeationWithSomeIntentToActWithoutSpecificPlan.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AciveSuicidalIdeationWithSpecificPlanAndIntent.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualAttempt.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInNonSuicidalSelfInjuriousBehavior.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInNonSuicidalSelfInjuriousBehavior.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInNonSuicidalSelfInjuriousBehavior.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInNonSuicidalSelfInjuriousBehavior.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInNonSuicidalSelfInjuriousBehavior.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInSelfInjuriousBehaviorIntentUnknown.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInSelfInjuriousBehaviorIntentUnknown.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInSelfInjuriousBehaviorIntentUnknown.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInSelfInjuriousBehaviorIntentUnknown.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_HasSubjectEngagedInSelfInjuriousBehaviorIntentUnknown.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_InterruptedAttempt.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_AbortedOrSelfInterruptedAttempt.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PreparatoryActsOrBehavior.Items.Insert(0, new ListItem("", ""));

                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_SuicidalBehavior.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_SuicidalBehavior.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_SuicidalBehavior.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_SuicidalBehavior.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_SuicidalBehavior.Items.Insert(0, new ListItem("", ""));
            }
            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("XCSSRSCASLTSEVERE", true, "", "", false))
            {
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_MostSevereIdeation.Items.Insert(0, new ListItem("", ""));
            }
            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("XCSSRSCASLTFREQUENCY", true, "", "", false))
            {
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_Frequency.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_Frequency.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_Frequency.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_Frequency.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_Frequency.Items.Insert(0, new ListItem("", ""));
            }

            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("XActualLethality", true, "", "", false))
            {
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualLethalityMedicalDamage.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualLethalityMedicalDamage.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualLethalityMedicalDamage.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualLethalityMedicalDamage.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_ActualLethalityMedicalDamage.Items.Insert(0, new ListItem("", ""));
            }

            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("XPotentialLethality", true, "", "", false))
            {
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PotentialLethality.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PotentialLethality.DataValueField = "GlobalCodeID";
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PotentialLethality.DataSource = DataViewGlobalCodes;
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PotentialLethality.DataBind();
                DropDownList_CustomDocumentMHColumbiaAdultSinceLastVisits_PotentialLethality.Items.Insert(0, new ListItem("", ""));
            }
        }

    }
}