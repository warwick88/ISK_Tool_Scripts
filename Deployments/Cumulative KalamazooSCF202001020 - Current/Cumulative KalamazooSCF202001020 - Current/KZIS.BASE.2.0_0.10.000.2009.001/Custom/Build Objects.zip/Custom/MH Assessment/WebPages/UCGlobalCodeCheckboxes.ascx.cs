﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Custom_MH_Assessment_WebPages_UCGlobalCodeCheckboxes : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public string UCCheckBoxHTML = string.Empty;
    public string UCCategory = string.Empty;
    public string UCTableName = string.Empty;
    public string UCColumns = string.Empty;
    public string UCColumnsWidth = string.Empty;
    public string RelativePath = string.Empty;
    public string PrimayKeyColumnName = string.Empty;
    public string ForeignKeyTableName = string.Empty;
    public string ForeignKeyColumnName = string.Empty;
    public string CheckBoxValueColumn = string.Empty;

    public string GlobalCodeColumnName = string.Empty;

    public void Activate()
    {
        RelativePath = Page.ResolveUrl("~");
        if (!string.IsNullOrEmpty(Attributes["Category"]))
            UCCategory = Attributes["Category"].Trim();
        if (!string.IsNullOrEmpty(Attributes["PrimayKeyTableName"]))
            UCTableName = Attributes["PrimayKeyTableName"].Trim();
        if (!string.IsNullOrEmpty(Attributes["ColumnSplitter"]))
            UCColumns = Attributes["ColumnSplitter"].Trim();
        if (!string.IsNullOrEmpty(Attributes["ColumnWidthSplitter"]))
            UCColumnsWidth = Attributes["ColumnWidthSplitter"].Trim();
        if (!string.IsNullOrEmpty(Attributes["PrimayKeyColumnName"]))
            PrimayKeyColumnName = Attributes["PrimayKeyColumnName"].Trim();
        if (!string.IsNullOrEmpty(Attributes["ForeignKeyTableName"]))
            ForeignKeyTableName = Attributes["ForeignKeyTableName"].Trim();
        if (!string.IsNullOrEmpty(Attributes["ForeignKeyColumnName"]))
            ForeignKeyColumnName = Attributes["ForeignKeyColumnName"].Trim();
        if (!string.IsNullOrEmpty(Attributes["CheckBoxValueColumn"]))
            CheckBoxValueColumn = Attributes["CheckBoxValueColumn"].Trim();

        DataSet dsCurrent = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();


        if (!string.IsNullOrEmpty(UCCategory) && !string.IsNullOrEmpty(UCTableName))
        {
            DataRow[] drGlobalCodes;
            DataRow[] drTableName;
            drGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.Select("Category='" + UCCategory + "' AND ISNULL(Active, 'N') = 'Y' AND ISNULL(RecordDeleted, 'N') = 'N'", "SortOrder");
            if (drGlobalCodes.Length > 0)
            {
                int IndexCount = 0;
                int ColumnCount = UCColumns.Split(':').Length;
                int RowCount = 0;
                string chkRowCount = string.Empty;
                string GlobalCodeId = string.Empty;
                string CodeName = string.Empty;
                string[] arrTDwidth = UCColumnsWidth.Split(':');
                int widthindex = 0;
                string TDwidth = string.Empty;

                if ((drGlobalCodes.Length % ColumnCount) == 0)
                    RowCount = (drGlobalCodes.Length / ColumnCount);
                else
                {
                    chkRowCount = ((double)drGlobalCodes.Length / ColumnCount).ToString();
                    int.TryParse(chkRowCount.Split('.')[0], out RowCount);
                    RowCount = RowCount + 1;
                }

                UCCheckBoxHTML = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 100%\">";
                for (int i = 0; i < RowCount; i++)
                {
                    UCCheckBoxHTML = UCCheckBoxHTML + "<tr>";
                    widthindex = 0;
                    for (int j = 0; j < ColumnCount; j++)
                    {
                        if (IndexCount < drGlobalCodes.Length)
                        {
                            GlobalCodeId = drGlobalCodes[IndexCount]["GlobalCodeId"].ToString().Trim();
                            CodeName = drGlobalCodes[IndexCount]["CodeName"].ToString().Trim();
                        }
                        else
                        {
                            GlobalCodeId = string.Empty;
                            CodeName = string.Empty;
                        }

                        if (widthindex < arrTDwidth.Length)
                        {
                            TDwidth = arrTDwidth[widthindex].ToString().Trim();
                            if (!string.IsNullOrEmpty(TDwidth))
                            {
                                TDwidth = TDwidth.Replace("%", "");
                                UCCheckBoxHTML = UCCheckBoxHTML + "<td style=\"width: " + TDwidth + "%\">";
                            }
                        }

                        if (string.IsNullOrEmpty(TDwidth))
                            UCCheckBoxHTML = UCCheckBoxHTML + "<td>";
                        UCCheckBoxHTML = UCCheckBoxHTML + "<div style=\"float: left; width: 100%\">";
                        if (!string.IsNullOrEmpty(GlobalCodeId))
                        {
                            UCCheckBoxHTML = UCCheckBoxHTML + "<div style=\"float: left; padding-top: 3px;\">";
                            UCCheckBoxHTML = UCCheckBoxHTML + "<input type=\"checkbox\"";
                            if (dsCurrent.IsDataTableFound(UCTableName))
                            {
                                ////Task #4  Four Winds - Customizations
                                //if (UCTableName == "CustomInquiryMedicalIssues")
                                //{
                                //    if (dsCurrent.Tables[UCTableName].Columns.Contains("MedicalIssues") && dsCurrent.Tables[UCTableName].Columns.Contains(CheckBoxValueColumn))
                                //    {
                                //        drTableName = dsCurrent.Tables[UCTableName].Select("MedicalIssues = " + GlobalCodeId + " AND ISNULL(RecordDeleted, 'N') = 'N' AND ISNULL(" + CheckBoxValueColumn + ", 'N') = 'Y'");
                                //        if (drTableName.Length > 0)
                                //            UCCheckBoxHTML = UCCheckBoxHTML + " checked = \"checked\" ";
                                //    }
                                //}
                                ////END
                                if (dsCurrent.Tables[UCTableName].Columns.Contains(GlobalCodeColumnName) && dsCurrent.Tables[UCTableName].Columns.Contains(CheckBoxValueColumn))
                                {
                                    drTableName = dsCurrent.Tables[UCTableName].Select(GlobalCodeColumnName + "= " + GlobalCodeId + " AND ISNULL(RecordDeleted, 'N') = 'N' AND ISNULL(" + CheckBoxValueColumn + ", 'N') = 'Y'");
                                    if (drTableName.Length > 0)
                                        UCCheckBoxHTML = UCCheckBoxHTML + " checked = \"checked\" ";
                                }
                            }
                            UCCheckBoxHTML = UCCheckBoxHTML + " onclick=\"UpdateUCCheckBoxToXML(this,'" + UCTableName + "','" + PrimayKeyColumnName + "','" + ForeignKeyTableName + "','" + ForeignKeyColumnName + "','" + GlobalCodeId + "','" + CheckBoxValueColumn + "','" + GlobalCodeColumnName + "')\" id=\"CheckBox_" + UCTableName + "_" + GlobalCodeId + "\" name=\"CheckBox_" + UCTableName + "_" + GlobalCodeId + "\" style=\"cursor: default\" bindsetformdata=\"False\" bindautosaveevents=\"False\"/>";
                            UCCheckBoxHTML = UCCheckBoxHTML + "</div>";
                            UCCheckBoxHTML = UCCheckBoxHTML + "<div style=\"float: left; padding-top: 3px; padding-left: 3px;\">";
                            UCCheckBoxHTML = UCCheckBoxHTML + "<label for=\"CheckBox_" + UCTableName + "_" + GlobalCodeId + "\" id=\"lbl" + GlobalCodeId + "UC\" style=\"cursor: pointer\">" + CodeName + "</label>";
                            UCCheckBoxHTML = UCCheckBoxHTML + "</div>";
                        }
                        UCCheckBoxHTML = UCCheckBoxHTML + "</div>";
                        UCCheckBoxHTML = UCCheckBoxHTML + "</td>";
                        IndexCount = IndexCount + 1;
                        widthindex = widthindex + 1;
                    }
                    UCCheckBoxHTML = UCCheckBoxHTML + "</tr><tr><td colspan=\"" + ColumnCount + "\" class=\"height2\"></td></tr>";
                }
                UCCheckBoxHTML = UCCheckBoxHTML + "</table>";
            }
        }
    }
}