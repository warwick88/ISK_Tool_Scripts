﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI;
using SHS.BaseLayer;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using SHS.UserBusinessServices;
using System.Xml.Serialization;
using SHS.BaseLayer.ActivityPages;
using System.Web;
using System.Data.Linq.SqlClient;
using Newtonsoft.Json;
using Telerik.Web.UI;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using SHS.DataServices;
using System.Web.UI.WebControls;

public partial class Custom_MH_Assessment_WebPages_PecafasAjaxScript : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string functionName = string.Empty;
        functionName = Request.QueryString["FunctionName"].ToString();

        switch (functionName)
        {
            case "GotoOnlinePecafas":
                GotoOnlinePecafas();
                break;
            case "ProcessFasServiceRequestForPecafas":
                ProcessFasServiceRequestForPecafas();
                break;
        }
    }
    public void ProcessFasServiceRequestForPecafas()
    {
        com.fasoutcomes.staging.FASService objectFasoutcomesStaging = null;

        try
        {
            string responseXml = string.Empty;
            string messageReturned = string.Empty;
            string XmlString = Request.Form["xmlString"].ToString();
            string DocumentVersionID = Request.Form["DocumentVersionID"].ToString();
            int outDocumentVersionID = 0;

            if (!string.IsNullOrEmpty(DocumentVersionID) && DocumentVersionID != "undefined")
            {
                int.TryParse(Request.Form["DocumentVersionID"].ToString(), out outDocumentVersionID);
            }

            MergeUnsavedChangesWithSessionDataSetForPecafas(XmlString);
            objectFasoutcomesStaging = new com.fasoutcomes.staging.FASService();
            messageReturned = GetAssessmentsFasServiceDataForPecafas(objectFasoutcomesStaging, outDocumentVersionID);

            responseXml = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.GetXml() + "^#^" + messageReturned;
            Response.Write(responseXml);
            try { Response.End(); }
            catch (System.Threading.ThreadAbortException) { }
        }
        finally
        {
            if (objectFasoutcomesStaging != null)
                objectFasoutcomesStaging.Dispose();
        }
    }


    private void GotoOnlinePecafas()
    {
        com.fasoutcomes.staging.FASService objectFasoutcomesStaging = null;
        try
        {
            DataSet dataSetValues = new DataSet();
            string keyValue = string.Empty;
            string errorMsg = string.Empty;
            objectFasoutcomesStaging = new com.fasoutcomes.staging.FASService();
            dataSetValues = GetBeginAssessmentsFasServiceDataForPecafas(objectFasoutcomesStaging);
            if (dataSetValues.Tables.Count == 0)
            {

                //errorMsg = "ErrorMessage=" + "Error Occurred - Contact your system administrator";
                errorMsg = SHS.BaseLayer.BaseCommonFunctions.GetApplicationMessageFromMessageCode("ERROROCCURRED", 0, "Error Occurred - Please Contact the help desk");
                keyValue = "Key=";
            }
            else
            {
                keyValue = "Key=" + dataSetValues.Tables[0].Rows[0]["value"].ToString();
                if (dataSetValues.Tables[0].Rows[0]["userId"] != null)
                    keyValue += "&IdKey=" + dataSetValues.Tables[0].Rows[0]["userId"].ToString();
                if (dataSetValues.Tables[0].Rows[0]["msg"].ToString() != string.Empty)
                    errorMsg = "ErrorMassage=" + dataSetValues.Tables[0].Rows[0]["msg"].ToString();
            }
            if (keyValue != "Key=")
            {
                if (errorMsg.Trim() != string.Empty)
                    Response.Write(errorMsg);
                else
                    Response.Write(keyValue);
                try { Response.End(); }
                catch (System.Threading.ThreadAbortException) { }
            }
            else
            {
                Response.Write(errorMsg);
                try { Response.End(); }
                catch (System.Threading.ThreadAbortException) { }
            }
        }
        finally
        {
            if (objectFasoutcomesStaging != null)
                objectFasoutcomesStaging.Dispose();
        }
    }


    /// <summary>
    /// <Description>To Merge the Dom Xml with the Session DataSet after Creating the Dataset of the Xml.</Description>
    /// <Author>Mahesh</Author>
    /// <CreatedOn>13th-Oct-2010</CreatedOn>
    /// </summary>
    /// <param name="XmlString">The Xml string received from the DOM.</param>
    private void MergeUnsavedChangesWithSessionDataSetForPecafas(string XmlString)
    {
        //using (DataSet datasetXMLReader = new DataSet())
        //{

        XmlString = XmlString.Replace("xmlns=\"\"", "");

        DataSet datasetScreen = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
        //Added by Shifali on 11June2012
        //Purpose - Called Architecture function instead of Custom code
        BaseCommonFunctions.MergeXMLInDataSet(ref datasetScreen, XmlString);

    }


    private DataSet GetBeginAssessmentsFasServiceDataForPecafas(com.fasoutcomes.staging.FASService objectFasoutcomesStaging)
    {
        System.Data.SqlClient.SqlDataReader DataReader = null;
        SHS.UserBusinessServices.PecafasAssessment PecafasAssessment = null;
        SHS.UserBusinessServices.HRMAssesment HrmAssessment = null;
        try
        {
            string resultXML = string.Empty;
            string LoginName = string.Empty;
            string Password = string.Empty;
            string AffiliateID = string.Empty;
            string OrgSoftwareID = string.Empty;
            decimal requestId = 0;
            DataSet GetValues = new DataSet();
            LoginName = System.Configuration.ConfigurationManager.AppSettings["FASLoginName"];
            Password = System.Configuration.ConfigurationManager.AppSettings["FASLoginPassword"];
            AffiliateID = System.Configuration.ConfigurationManager.AppSettings["AffiliateID"];
            OrgSoftwareID = System.Configuration.ConfigurationManager.AppSettings["SoftwareOrgID"];
            PecafasAssessment = new SHS.UserBusinessServices.PecafasAssessment();
            HrmAssessment = new SHS.UserBusinessServices.HRMAssesment();
            DataReader = PecafasAssessment.GetFasServiceRequestsForPecafas(OrgSoftwareID, "beginAssessment", BaseCommonFunctions.ApplicationInfo.Client.ClientId.ToString(), BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId.ToString());
            while (DataReader.Read())
            {
                string assessmentRequest = string.Empty;
                assessmentRequest = DataReader.GetString(0);
                requestId = Convert.ToDecimal(DataReader.GetValue(1));
                objectFasoutcomesStaging = new com.fasoutcomes.staging.FASService();

                objectFasoutcomesStaging.AuthHeaderValue = new com.fasoutcomes.staging.AuthHeader();
                objectFasoutcomesStaging.AuthHeaderValue.sUsername = LoginName;
                objectFasoutcomesStaging.AuthHeaderValue.sPassword = Password;
                try
                {
                    resultXML = objectFasoutcomesStaging.ProcessInteropRequest(assessmentRequest);
                }
                catch (Exception ex)
                {
                    return GetValues;
                }

            }
            GetValues = HrmAssessment.UpdateCustomFASRequestLog(resultXML, requestId);
            return GetValues;
        }
        finally
        {
            if (DataReader != null)
                DataReader.Close();
            if (PecafasAssessment != null)
                PecafasAssessment.Dispose();
        }
    }

    /// <summary>
    /// <Description>To execute the whole process of FasServices. It calls all the submethods required for the process.</Description>
    /// <Author>Mahesh</Author>
    /// <CreatedOn>13th-Oct-2010</CreatedOn>
    /// </summary>
    /// <param name="_objectFasoutcomesStaging">Proxy of the FasService.</param>
    /// <param name="DocumentVersionID">Version ID of the Current Document.</param>
    public string GetAssessmentsFasServiceDataForPecafas(com.fasoutcomes.staging.FASService objectFasoutcomesStaging, int documentVersionID)
    {
        string messageReturned = string.Empty;
        System.Data.SqlClient.SqlDataReader DataReader = null;
        SHS.UserBusinessServices.PecafasAssessment PecafasAssessment = null;
        try
        {
            string LoginName = string.Empty;
            string Password = string.Empty;
            string AffiliateID = string.Empty;
            string OrgSoftwareID = string.Empty;
            LoginName = System.Configuration.ConfigurationManager.AppSettings["FASLoginName"];
            Password = System.Configuration.ConfigurationManager.AppSettings["FASLoginPassword"];
            AffiliateID = System.Configuration.ConfigurationManager.AppSettings["AffiliateID"];
            OrgSoftwareID = System.Configuration.ConfigurationManager.AppSettings["SoftwareOrgID"];
            PecafasAssessment = new SHS.UserBusinessServices.PecafasAssessment();
            DataReader = PecafasAssessment.GetFasServiceRequestsForPecafas(OrgSoftwareID, "Assessment", BaseCommonFunctions.ApplicationInfo.Client.ClientId.ToString(), BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId.ToString());
            while (DataReader.Read())
            {
                string assessmentRequest = string.Empty;
                string resultXML = string.Empty;
                assessmentRequest = DataReader.GetString(0);
                decimal requestId = Convert.ToDecimal(DataReader.GetValue(1));
                objectFasoutcomesStaging = new com.fasoutcomes.staging.FASService();

                objectFasoutcomesStaging.AuthHeaderValue = new com.fasoutcomes.staging.AuthHeader();
                objectFasoutcomesStaging.AuthHeaderValue.sUsername = LoginName;
                objectFasoutcomesStaging.AuthHeaderValue.sPassword = Password;
                try
                {
                    resultXML = objectFasoutcomesStaging.ProcessInteropRequest(assessmentRequest);
                }

                catch (Exception ex)
                {
                    messageReturned = "Error Occurred - Please Contact Your System Administrator";
                    return messageReturned;
                }
                DateTime CreatedDate = Convert.ToDateTime(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CustomDocumentAssessmentPECFASs"].Rows[0]["CreatedDate"].ToString());
                DateTime ModifiedDate = Convert.ToDateTime(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CustomDocumentAssessmentPECFASs"].Rows[0]["ModifiedDate"].ToString());
                messageReturned = MergeFasServicesWithSessionDataForPecafas(Convert.ToInt32(requestId), resultXML, documentVersionID, CreatedDate, ModifiedDate, PecafasAssessment);
            }
            return messageReturned;
        }
        finally
        {
            if (DataReader != null)
                DataReader.Close();
            if (PecafasAssessment != null)
                PecafasAssessment.Dispose();
        }

    }

    public string MergeFasServicesWithSessionDataForPecafas(int requestId, string responseXml, int documentVersionID, DateTime createdDate, DateTime modifiedDate, SHS.UserBusinessServices.PecafasAssessment PecafasAssessment)
    {
        string messageReturned = string.Empty;
        using (DataSet dsFasServices = PecafasAssessment.GetDatasetFasServicesAssessmentForPecafas(requestId, responseXml, documentVersionID, createdDate, modifiedDate, BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserCode.ToString()))
        {
            messageReturned = PecafasAssessment.MergeManualyFasServicesCustomPecafas(dsFasServices, BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CustomDocumentAssessmentPECFASs"]);
            return messageReturned;
        }

    }

}