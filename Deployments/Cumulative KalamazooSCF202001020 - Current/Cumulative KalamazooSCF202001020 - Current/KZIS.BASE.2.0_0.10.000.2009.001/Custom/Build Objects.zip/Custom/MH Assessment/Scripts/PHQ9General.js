﻿var count = 0;
function SetScorePHQ9(pObject) {
    var count = 0;
    $('#tablePHQ9IdDropDown').find('select :selected').each(function () {
        if ($(this).text() == 'Not at all') {
            count = count + 0;
        }
        if ($(this).text() == 'Several Days') {
            count = count + 1;
        }
        if ($(this).text() == 'More than half the days') {
            count = count + 2;
        }
        if ($(this).text() == 'Nearly every day') {
            count = count + 3;
        }
    });
    $('[id$=Textbox_PHQ9Documents_TotalScore]').val(count);
    CreateAutoSaveXml("PHQ9Documents", "TotalScore", $('[id$=Textbox_PHQ9Documents_TotalScore]').val());
    DepressionSeverityPHQ9();
}

function ClientDeclinedOnClickPHQ9(CreateAutoSave) {

    var $PHQ9ClientDeclinedToParticipate = "N";

    if (AutoSaveXMLDom && GetAutoSaveXMLDomNode("PHQ9Documents").length > 0) {
        $PHQ9ClientDeclinedToParticipate = GetColumnValueInXMLNodeByKeyValue('PHQ9Documents', 'DocumentVersionId',
            GetCurrentDocumentVersionID(), 'ClientDeclinedToParticipate', AutoSaveXMLDom[0]);
    }

    if ($('#CheckBox_PHQ9Documents_ClientDeclinedToParticipate').attr('checked') == true || ($PHQ9ClientDeclinedToParticipate == "Y" && CreateAutoSave == false)) {
        $('#divPHQ9').find('input[type=text],input[type=radio],input[type=checkbox],select,textarea').attr('disabled', 'disabled').val('');

        $('#Button_PerformedTime_Now').attr('disabled', 'disabled');

        $('[id*=CheckBox_PHQ9Documents_]').removeAttr('checked');
        $('#CheckBox_PHQ9Documents_ClientDeclinedToParticipate').attr('checked', 'checked');
        $('[id*=RadioButton_PHQ9Documents_]').removeAttr('checked');

        $('#Textbox_PHQ9Documents_PerformedDate').removeAttr('required');
        $('#Textbox_PHQ9Documents_PerformedTime').removeAttr('required');

        if (CreateAutoSave == true) {
            CreateAutoSaveXmlObj([{
                "PHQ9Documents": {
                    "LittleInterest": '', "PerformedAt": '', "PerformedDate": '', "FeelingDown": '', "TroubleFalling": '', "FeelingTired": '', "PoorAppetite": '',
                    "FeelingBad": '', "TroubleConcentrating": '', "MovingOrSpeakingSlowly": '', "HurtingYourself": '', "GetAlongOtherPeople": '',
                    "Comments": '', "DocumentationFollowUp": '', "TotalScore": '', "DepressionSeverity": '', "AdditionalEvalForDepressionPerformed": '',
                    "ReferralForDepressionOrdered": '', "DepressionMedicationOrdered": '', "SuicideRiskAssessmentPerformed": '', "PharmacologicalIntervention": '', "OtherInterventions": '',
                    "ClientRefusedOrContraIndicated": ''
                }
            }]);
        }

    }
    else {
        $('#divPHQ9').find('input[type=text],input[type=radio],input[type=checkbox],select,textarea').removeAttr('disabled');

        $('#Button_PerformedTime_Now').removeAttr('disabled');

        $('#Textbox_PHQ9Documents_PerformedDate').attr('required', 'required');
        $('#Textbox_PHQ9Documents_PerformedTime').attr('required', 'required');
    }
    $('#Textbox_PHQ9Documents_TotalScore').attr('disabled', 'disabled');
    $('#TextBox_PHQ9Documents_DepressionSeverity').attr('disabled', 'disabled');
    $('#CheckBox_PHQ9Documents_ClientDeclinedToParticipate').removeAttr('disabled');
}
function TotalScorePHQ9() {
    var totalcount = 0;
    var total = $('[id$=Textbox_PHQ9Documents_TotalScore]').val();
    $("select[count]").each(function () {
        totalcount = Number(totalcount) + Number($(this).attr('count'));
    });
    $('[id$=Textbox_PHQ9Documents_TotalScore]').val(totalcount);
}
function DepressionSeverityPHQ9() {
    if ($('[id$=Textbox_PHQ9Documents_TotalScore]').length > 0) {
        var Severity = $('[id$=Textbox_PHQ9Documents_TotalScore]').val();
        if (Severity >= 0 && Severity <= 4)
            $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').val('');
        if (Severity >= 5 && Severity <= 9)
            $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').val('Mild depression');
        if (Severity >= 10 && Severity <= 14)
            $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').val('Moderate depression');
        if (Severity >= 15 && Severity <= 19)
            $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').val('Moderately severe depression');
        if (Severity >= 20 && Severity <= 27)
            $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').val('Severe depression');
        CreateAutoSaveXml("PHQ9Documents", "DepressionSeverity", $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').val());
    }
}
function setTimeNowPHQ9() {
    var timeControl = $('#Textbox_PHQ9Documents_PerformedTime');
    var dateControl = $('#Textbox_PHQ9Documents_PerformedDate');

    var dt = new Date();

    dateControl.val(dt.format("MM/dd/yyyy"));

    var timeDate = new Date();
    var time = timeDate.format("hh:mm tt")
    timeControl.val(time);

    onPerformedAtChangePHQ9('true');
    return false;
}

function onPerformedAtChangePHQ9(AutoSave) {
    var date = $('[id$=Textbox_PHQ9Documents_PerformedDate]'); 
    var time = $('[id$=Textbox_PHQ9Documents_PerformedTime]');
    if (time.length > 0 && time.val() != 'undefined') {
        FormatTimeatClientSide(document.getElementById('Textbox_PHQ9Documents_PerformedTime'));
    }
    if (date.length > 0 && date.val() != 'undefined' && time.val() != "" && time.val() != 'undefined') {
        if (ValidateDate(document.getElementById('Textbox_PHQ9Documents_PerformedDate')) && time.val() !== "") {
            var dateTime = new Date(date.val() + ' ' + time.val());
            if (dateTime && date.val() && time.val()) {
                ShowHideErrorMessage("Performed At is a required field.", "false");
                if (AutoSave == 'true') {
                    CreateAutoSaveXml('PHQ9Documents', 'PerformedAt', ISODateString(dateTime));
                }
                else {
                    var DocumentVersionId = AutoSaveXMLDom.find("PHQ9Documents:first DocumentVersionId").text();
                    SetColumnValueInXMLNodeByKeyValue("PHQ9Documents", "DocumentVersionId", DocumentVersionId, "PerformedAt", ISODateString(dateTime), AutoSaveXMLDom[0]);
                }
                AddToUnsavedTables("PHQ9Documents");
                return;
            }
        }
    }
    // if (date != undefined && time != undefined) {
        // ShowHideErrorMessage("Performed At is a required field.", "true");
    // }
    return;

}
function initPerformedAtPHQ9() {
    var $PHQ9ClientDeclinedToParticipate = "N";

    if (AutoSaveXMLDom && GetAutoSaveXMLDomNode("PHQ9Documents").length > 0) {
        $PHQ9ClientDeclinedToParticipate = GetColumnValueInXMLNodeByKeyValue('PHQ9Documents', 'DocumentVersionId',
            GetCurrentDocumentVersionID(), 'ClientDeclinedToParticipate', AutoSaveXMLDom[0]);
    }

    var dateControl = $('#Textbox_PHQ9Documents_PerformedDate');
    var timeControl = $('#Textbox_PHQ9Documents_PerformedTime');
    var nowControl = $('#Button_PerformedTime_Now');


    dateControl.unbind('change').change(function () { onPerformedAtChangePHQ9('true'); });
    timeControl.unbind('change').change(function () { onPerformedAtChangePHQ9('true'); });

    if (nowControl) {
        nowControl.unbind('click').click(function () { setTimeNowPHQ9(); });
    }

    if (!($PHQ9ClientDeclinedToParticipate == "Y")) {
        if (AutoSaveXMLDom && GetAutoSaveXMLDomNode("PHQ9Documents").length > 0) {
            var performedAt = GetColumnValueInXMLNodeByKeyValue('PHQ9Documents', 'DocumentVersionId',
                GetCurrentDocumentVersionID(), 'PerformedAt', AutoSaveXMLDom[0]);

            if (performedAt !== "") {

                if (dateControl) {
                    var d = new Date(performedAt.split("T")[0].replace("-", "/"));
                    dateControl.val(d.format("MM/dd/yyyy"));
                }
                if (timeControl) {
                    //Get the time without the timestamp
                    //SmartCare always assumes the timezone is what the server is set to, if you are in a different timezone than the server
                    //when a time is loaded, it is adjusted to the computers local time zone.. when saved it is saved as the timezone of the server .. no timezone information is saved it is always assumed server
                    //time zone server side
                    var time = performedAt.split("T")[1].split("-")[0];
                    var tempDate = "01/01/2999" + " " + time;
                    var d = new Date(tempDate);
                    if (d == "Invalid Date") {
                        var _time = performedAt.split("T")[1].split("+")[0];
                        var time = _time.split(".");
                        var tempDate = "01/31/2070" + " " + time[0];
                        d = new Date(tempDate);
                    }
                    timeControl.val(d.format("hh:mm tt"));
                }
            } else {
                var dt = new Date();
                dateControl.val(dt.format("MM/dd/yyyy"));
                var timeDate = new Date();
                var time = timeDate.format("hh:mm tt");
                timeControl.val(time);
                onPerformedAtChangePHQ9('false');
            }
        }
    }
    return;
}
$(document).ready(function () {
    //this value will be set to "Y" if the document is a standalone, if it is embedded in another control, the value will be "" as the hiddenfield will note exist
    var standalonePHQ9 = "N";
    standalonePHQ9 = $('#StandalonePHQ9').length ? "Y" : "N";
    if (standalonePHQ9 === "Y") {
        return;
    }
    BindControlChangeEventsPHQ9();
});


function BindControlChangeEventsPHQ9() {
    $('[id$=Textbox_PHQ9Documents_TotalScore]').attr("disabled", true);
    $('[id$=TextBox_PHQ9Documents_DepressionSeverity]').attr("disabled", true);
    $('[id$=DropDownList_PHQ9Documents_LittleInterest]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_FeelingDown]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_TroubleFalling]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_FeelingTired]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_PoorAppetite]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_FeelingBad]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_TroubleConcentrating]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_MovingOrSpeakingSlowly]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    $('[id$=DropDownList_PHQ9Documents_HurtingYourself]').unbind('change').bind('change', function () { SetScorePHQ9($(this)); });
    // DepressionSeverity();
    ClientDeclinedOnClickPHQ9(false);
    initPerformedAtPHQ9();
}

//# sourceURL=PHQ9General.js