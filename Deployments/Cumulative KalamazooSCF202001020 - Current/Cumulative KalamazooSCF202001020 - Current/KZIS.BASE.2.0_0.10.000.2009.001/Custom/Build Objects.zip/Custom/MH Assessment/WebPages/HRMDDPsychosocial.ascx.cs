﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;

namespace SHS.SmartCare
{

    public partial class ActivityPages_Client_Detail_Assessment_HRMDDPsychosocial : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        public override void BindControls()
        {
            using (DataView dataViewGlobalCodes = BaseCommonFunctions.FillDropDown("XPSDDRISKDUETO", true, "", "SortOrder", true))
            {                                                                       
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfPlacementDueTo.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfPlacementDueTo.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfPlacementDueTo.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfPlacementDueTo.DataBind();

                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfSupportDueTo.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfSupportDueTo.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfSupportDueTo.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfSupportDueTo.DataBind();

                DropDownList_CustomDocumentMHAssessments_PsRiskExpulsionFromSchoolDueTo.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHAssessments_PsRiskExpulsionFromSchoolDueTo.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentMHAssessments_PsRiskExpulsionFromSchoolDueTo.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentMHAssessments_PsRiskExpulsionFromSchoolDueTo.DataBind();

                DropDownList_CustomDocumentMHAssessments_PsRiskHospitalizationDueTo.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHAssessments_PsRiskHospitalizationDueTo.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentMHAssessments_PsRiskHospitalizationDueTo.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentMHAssessments_PsRiskHospitalizationDueTo.DataBind();

                DropDownList_CustomDocumentMHAssessments_PsRiskCriminalJusticeSystemDueTo.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHAssessments_PsRiskCriminalJusticeSystemDueTo.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentMHAssessments_PsRiskCriminalJusticeSystemDueTo.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentMHAssessments_PsRiskCriminalJusticeSystemDueTo.DataBind();

                DropDownList_CustomDocumentMHAssessments_PsRiskElopementFromHomeDueTo.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHAssessments_PsRiskElopementFromHomeDueTo.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentMHAssessments_PsRiskElopementFromHomeDueTo.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentMHAssessments_PsRiskElopementFromHomeDueTo.DataBind();

                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfFinancialStatusDueTo.DataTextField = "CodeName";
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfFinancialStatusDueTo.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfFinancialStatusDueTo.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentMHAssessments_PsRiskLossOfFinancialStatusDueTo.DataBind();
            }
        }
    }
}