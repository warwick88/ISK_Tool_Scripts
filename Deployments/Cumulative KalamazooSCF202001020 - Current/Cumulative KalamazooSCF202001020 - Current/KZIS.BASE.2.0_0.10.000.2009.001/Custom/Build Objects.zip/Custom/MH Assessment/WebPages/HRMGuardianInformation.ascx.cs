﻿using System;
using System.Data;
using SHS.BaseLayer;
using System.Linq;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SHS.SmartCare
{

    public partial class ActivityPages_Client_Detail_Assessment_HRMGuardianInformation : SHS.BaseLayer.ActivityPages.DataActivityPage
    {
        public string externalURL = BaseCommonFunctions.ApplicationInfo.ExternalURL.ToString();
        public string isPopUp = BaseCommonFunctions.IsPopup.ToString();

        public override string PageDataSetName
        {
            get { return "DataSetMHAssessment"; }
        }

        public override string[] TablesToBeInitialized
        {
            get { return new string[] { "CustomDocumentMHAssessments" }; }
        }

        public override void BindControls()
        {
           
            BindControl();
        }

        private void BindControl()
        {
            
            DataSet dataSetDocumentDataSet = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
           
            DataTable datatableClientContactsRelationship = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
            DataView DataViewClientContactsRelationshipGlobalCodes = datatableClientContactsRelationship.DefaultView;
            
            DropDownList_CustomDocumentMHAssessments_RelationWithGuardian.Category = "RELATIONSHIP";
            DataViewClientContactsRelationshipGlobalCodes.RowFilter = "Active='Y' and ISNULL(RecordDeleted,'N')<>'Y' and CodeName <> 'Self'";
           
            DataViewClientContactsRelationshipGlobalCodes.Sort = "CodeName ASC";
            DropDownList_CustomDocumentMHAssessments_RelationWithGuardian.DataTableGlobalCodes = DataViewClientContactsRelationshipGlobalCodes.ToDataTable();
            DropDownList_CustomDocumentMHAssessments_RelationWithGuardian.FillDropDownDropGlobalCodes();

            DataView dViewState = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.States);
            DropDownList_CustomDocumentMHAssessments_Guardianstate.DataTextField = "StateName";
            DropDownList_CustomDocumentMHAssessments_Guardianstate.DataValueField = "StateAbbreviation";
            DropDownList_CustomDocumentMHAssessments_Guardianstate.DataSource = dViewState;
            DropDownList_CustomDocumentMHAssessments_Guardianstate.DataBind();
           // ListItem item = new ListItem("Select State", "Select State");
            //DropDownList_CustomDocumentMHAssessments_Guardianstate.Items.Insert(0, new ListItem("Select State", "0"));
            //DropDownList_CustomDocumentMHAssessments_Guardianstate.Items.Insert(0, item);
           // DropDownList_CustomDocumentMHAssessments_Guardianstate.SelectedValue = "";
            //end

        }


       
        /// Purpose - This function will be overridden at the inherited child class
        
        /// </summary>
        public override void PopUpButtonClicked(string buttonName)
        {
            DataSet ScreenDataset = new DataSet();
            DataSet PopUpDataSet = new DataSet();
            ScreenDataset = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
            PopUpDataSet = SHS.BaseLayer.BaseCommonFunctions.GetPopUpScreenInfoDataSet();
            try
            {
                  ScreenDataset.Tables["CustomDocumentMHAssessments"].Merge(PopUpDataSet.Tables["CustomDocumentMHAssessments"], false, MissingSchemaAction.Ignore);
            }
            catch (Exception)
            {
                ScreenDataset.Tables["CustomDocumentMHAssessments"].Merge(PopUpDataSet.Tables["CustomDocumentMHAssessments"], false, MissingSchemaAction.Ignore);
            }
               SHS.BaseLayer.BaseCommonFunctions.SetScreenInfoDataSet(ScreenDataset);
        }



        public override DataSet GetData()
        {
            //Page Title property will be set at base class but same can be overridden at control level
            PageTitle = "Guardian Information";
            DataSet dataSetLatest = new DataSet();
            
            dataSetLatest = SHS.BaseLayer.BaseCommonFunctions.GetPageDataSet("DataSetMHAssessment");
            
            DataRow[] dr = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet().Tables["CustomDocumentMHAssessments"].Select("DocumentVersionId Is Not Null");
            if (dr.Length > 0)
            {
                using (DataSet ds = new DataSet())
                {
                    ds.Merge(dr);
                    dataSetLatest.Tables["CustomDocumentMHAssessments"].Merge(ds.Tables[0]);
                }
            }
            SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet = dataSetLatest;

            return dataSetLatest;
        }


    }
}
