﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SHS.BaseLayer;
using System.Data.SqlClient;
using SHS.DataServices;

namespace SHS.SmartCare
{

    public partial class ActivityPages_Client_Detail_Assessment_HRMPrePlan : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        int PrePlanFormID;
        public override void BindControls()
        {
            SqlParameter[] _objectSqlParmeters;
            _objectSqlParmeters = new SqlParameter[1];
            String FormGUID = "2C489D56-66EF-4C48-939C-501A5449D387";
            _objectSqlParmeters[0] = new SqlParameter("@FormGUID", FormGUID);
            PrePlanFormID = (int)DBManager.ExecuteScalar(Connection.ConnectionString, "csp_SCGetFormFormId", _objectSqlParmeters);
            DynamicFormsPrePlan.FormId = PrePlanFormID;
            DynamicFormsPrePlan.Activate();
            
        }
    }
}
