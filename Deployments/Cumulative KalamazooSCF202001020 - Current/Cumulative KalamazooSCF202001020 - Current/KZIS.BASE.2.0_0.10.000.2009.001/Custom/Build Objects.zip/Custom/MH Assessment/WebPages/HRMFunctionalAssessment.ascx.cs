﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SHS.BaseLayer;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using SHS.DataServices;
using System.Text;
using System.Text.RegularExpressions;


public partial class Custom_Assessment_WebPages_HRMFunctionalAssessment : SHS.BaseLayer.ActivityPages.DataActivityTab
{ 
    string checkboxfiltervalues = "[";
    string tablehtml = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id =\"tblAPMDCount\"><td style=\"width: 60%\"><table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\"><tr class=\"RadioText\"><td align=\"left\"><table><tr>";

    public override void BindControls()
    {
        using (DataView dataViewGlobalCodes = SHS.BaseLayer.BaseCommonFunctions.FillDropDown("XFA5PointScale", true, "", "SortOrder", true))
        {
            DropDownList_CustomDocumentFunctionalAssessments_Dressing.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_Dressing.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_Dressing.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_Dressing.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_PersonalHygiene.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_PersonalHygiene.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_PersonalHygiene.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_PersonalHygiene.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_Bathing.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_Bathing.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_Bathing.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_Bathing.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_Eating.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_Eating.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_Eating.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_Eating.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_SleepHygiene.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_SleepHygiene.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_SleepHygiene.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_SleepHygiene.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_FinancialTransactions.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_FinancialTransactions.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_FinancialTransactions.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_FinancialTransactions.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_ManagesPersonalFinances.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_ManagesPersonalFinances.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_ManagesPersonalFinances.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_ManagesPersonalFinances.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_CookingMealPreparation.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_CookingMealPreparation.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_CookingMealPreparation.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_CookingMealPreparation.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_KeepingRoomTidy.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_KeepingRoomTidy.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_KeepingRoomTidy.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_KeepingRoomTidy.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_HouseholdTasks.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_HouseholdTasks.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_HouseholdTasks.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_HouseholdTasks.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_LaundryTasks.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_LaundryTasks.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_LaundryTasks.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_LaundryTasks.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_HomeSafetyAwareness.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_HomeSafetyAwareness.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_HomeSafetyAwareness.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_HomeSafetyAwareness.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_ComfortableInteracting.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_ComfortableInteracting.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_ComfortableInteracting.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_ComfortableInteracting.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_ComfortableLargerGroups.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_ComfortableLargerGroups.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_ComfortableLargerGroups.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_ComfortableLargerGroups.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_AppropriateConversations.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_AppropriateConversations.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_AppropriateConversations.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_AppropriateConversations.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_AdvocatesForSelf.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_AdvocatesForSelf.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_AdvocatesForSelf.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_AdvocatesForSelf.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_CommunicatesDailyLiving.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_CommunicatesDailyLiving.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_CommunicatesDailyLiving.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_CommunicatesDailyLiving.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFamily.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFamily.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFamily.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFamily.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFriendships.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFriendships.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFriendships.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_MaintainsFriendships.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_DemonstratesEmpathy.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_DemonstratesEmpathy.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_DemonstratesEmpathy.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_DemonstratesEmpathy.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_ManageEmotions.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_ManageEmotions.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_ManageEmotions.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_ManageEmotions.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_RentArrangements.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_RentArrangements.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_RentArrangements.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_RentArrangements.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_PayRentBillsOnTime.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_PayRentBillsOnTime.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_PayRentBillsOnTime.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_PayRentBillsOnTime.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_PersonalItems.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_PersonalItems.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_PersonalItems.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_PersonalItems.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_AttendSocialOutings.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_AttendSocialOutings.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_AttendSocialOutings.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_AttendSocialOutings.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_CommunityTransportation.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_CommunityTransportation.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_CommunityTransportation.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_CommunityTransportation.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_DangerousSituations.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_DangerousSituations.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_DangerousSituations.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_DangerousSituations.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_AdvocateForSelf.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_AdvocateForSelf.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_AdvocateForSelf.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_AdvocateForSelf.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_ManageChangesDailySchedule.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_ManageChangesDailySchedule.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_ManageChangesDailySchedule.DataSource = dataViewGlobalCodes;
            DropDownList_CustomDocumentFunctionalAssessments_ManageChangesDailySchedule.DataBind(); 
             
        }

        using (DataView dataViewGlobalCodes1 = SHS.BaseLayer.BaseCommonFunctions.FillDropDown("XFAB5PointScale", true, "", "SortOrder", true))
        {
            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToSelf.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToSelf.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToSelf.DataSource = dataViewGlobalCodes1;
            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToSelf.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToOthers.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToOthers.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToOthers.DataSource = dataViewGlobalCodes1;
            DropDownList_CustomDocumentFunctionalAssessments_RiskHarmToOthers.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_PropertyDestruction.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_PropertyDestruction.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_PropertyDestruction.DataSource = dataViewGlobalCodes1;
            DropDownList_CustomDocumentFunctionalAssessments_PropertyDestruction.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_Elopement.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_Elopement.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_Elopement.DataSource = dataViewGlobalCodes1;
            DropDownList_CustomDocumentFunctionalAssessments_Elopement.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_MentalIllnessSymptoms.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_MentalIllnessSymptoms.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_MentalIllnessSymptoms.DataSource = dataViewGlobalCodes1;
            DropDownList_CustomDocumentFunctionalAssessments_MentalIllnessSymptoms.DataBind(); 

            DropDownList_CustomDocumentFunctionalAssessments_RepetitiveBehaviors.DataTextField = "CodeName";
            DropDownList_CustomDocumentFunctionalAssessments_RepetitiveBehaviors.DataValueField = "GlobalCodeId";
            DropDownList_CustomDocumentFunctionalAssessments_RepetitiveBehaviors.DataSource = dataViewGlobalCodes1;
            DropDownList_CustomDocumentFunctionalAssessments_RepetitiveBehaviors.DataBind(); 
             
        }
        CreateCheckboxControls();
    }

    public override string[] TablesUsedInTab
    {
        get
        {
            return new string[] { "CustomDocumentFunctionalAssessments", "CustomAssessmentFunctionalCommunications" };
        }

    }

    private void CreateCheckboxControls()
    {
        string[] checkboxGC = (from pc in SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.AsEnumerable()
                               where pc.Field<string>("Category").Trim() == "XCommunication"
                               orderby pc.Field<int?>("SortOrder") ascending
                               select CreateCheckboxContainer(pc.Field<string>("CodeName") == null ? "" : pc.Field<string>("CodeName").ToString(), pc.Field<int>("GlobalCodeId"), pc.Field<string>("Code") == null ? "" : pc.Field<string>("Code").ToString())

                         ).ToArray();
        tablehtml = tablehtml + "</tr></table></td></tr></table></td></table>";
        checkboxfiltervalues = checkboxfiltervalues.Trim().TrimEnd(',') + "]";
        divAPMDRadioButtonList.InnerHtml = tablehtml;
        divAPMDRadioButtonValues.InnerHtml = checkboxfiltervalues;
    }

    private string CreateCheckboxContainer(string CodeName, int CodeId, string Code)
    {

        DataSet dataSetDiagnosisEligibility = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
        string checkboxname = Regex.Replace(Regex.Replace(CodeName, @"[^0-9a-zA-Z]+", ""), @"\s+", "");
        string checkbox = string.Empty;
        string StyleWidth = string.Empty;
        DataRow[] drSelectcheck = null;

        checkbox = checkbox + "<td><input type=\"checkbox\" id=\"CheckBox_CustomAssessmentFunctionalCommunications_Communication_" + CodeId + "\"  name=\"CheckBox_CustomAssessmentFunctionalCommunications_Communication" + "\"  globalcodeid=\"" + CodeId + "\" Code=\"" + Code + "\" ";

        if (dataSetDiagnosisEligibility.IsRowExists("CustomAssessmentFunctionalCommunications", 0))
        {
            drSelectcheck = dataSetDiagnosisEligibility.Tables["CustomAssessmentFunctionalCommunications"].Select("Communication =" + CodeId + "and ISNULL(RecordDeleted,'N') =  'N'");

            if (drSelectcheck != null && drSelectcheck.Count() > 0)
            {
                checkbox = checkbox + "checked='checked'";
            }
        }
        checkbox = checkbox + "onclick=\"CreateCommunicationCheckboxControls(this)" + "\" style=\"cursor: default;margin-left:3px\"  parentchildcontrols=\"True\"/>";
        if (CodeName.Trim().Contains("English is second")) StyleWidth =" style=\"width:100px;\"";
        checkbox = checkbox + "</td><td" + StyleWidth +"><label for=\"CheckBox_CustomAssessmentFunctionalCommunications_Communication_" + CodeId + "\"  style=\"cursor: default\">" + CodeName.Trim() + "</label></td>";
        tablehtml = tablehtml + checkbox;
        return checkboxname;
    }
}