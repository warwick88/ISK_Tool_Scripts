﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SHS.BaseLayer;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using SHS.DataServices;
using System.Text;
using System.Text.RegularExpressions;

public partial class Custom_Assessment_WebPages_HRMDiagnosisIDDEligibility : SHS.BaseLayer.ActivityPages.DataActivityTab
{ 
    string checkboxfiltervalues = "[";
    string tablehtml = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id =\"tblAPMDCount\"><td style=\"width: 60%\"><table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\"><tr class=\"RadioText\"><td align=\"left\"><table><tr>";

    public override void BindControls()
    {
        CreateCheckboxControls();
    }

    public override string[] TablesUsedInTab
    {
        get
        {
            return new string[] { "CustomDocumentAssessmentDiagnosisIDDEligibilities", "CustomAssessmentDiagnosisIDDCriteria" };
        }
    }

    private void CreateCheckboxControls()
    { 
        string[] checkboxGC = (from pc in SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.AsEnumerable()
                               where pc.Field<string>("Category").Trim() == "XSubstantialFunction"
                               orderby pc.Field<int?>("SortOrder") ascending
                               select CreateCheckboxContainer(pc.Field<string>("CodeName") == null ? "" : pc.Field<string>("CodeName").ToString(), pc.Field<int>("GlobalCodeId"), pc.Field<string>("Code") == null ? "" : pc.Field<string>("Code").ToString())

                         ).ToArray();
        tablehtml = tablehtml + "</tr></table></td></tr></table></td></table>";
        checkboxfiltervalues = checkboxfiltervalues.Trim().TrimEnd(',') + "]";
        divAPMDRadioButtonList.InnerHtml = tablehtml;
        divAPMDRadioButtonValues.InnerHtml = checkboxfiltervalues;
    }

    private string CreateCheckboxContainer(string CodeName, int CodeId, string Code)
    {

        DataSet dataSetDiagnosisEligibility = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
        string checkboxname = Regex.Replace(Regex.Replace(CodeName, @"[^0-9a-zA-Z]+", ""), @"\s+", "");
        string checkbox = string.Empty;
        DataRow[] drSelectcheck = null;

        checkbox = checkbox + "<td><input type=\"checkbox\" id=\"CheckBox_CustomAssessmentDiagnosisIDDCriteria_SubstantialFunctional_" + CodeId + "\"  name=\"CheckBox_CustomAssessmentDiagnosisIDDCriteria_SubstantialFunctional" + "\"  globalcodeid=\"" + CodeId + "\" Code=\"" + Code + "\" ";

        if (dataSetDiagnosisEligibility.IsRowExists("CustomAssessmentDiagnosisIDDCriteria", 0))
        {
            drSelectcheck = dataSetDiagnosisEligibility.Tables["CustomAssessmentDiagnosisIDDCriteria"].Select("SubstantialFunctional =" + CodeId + "and ISNULL(RecordDeleted,'N') =  'N'");

            if (drSelectcheck != null && drSelectcheck.Count() > 0)
            {
                checkbox = checkbox + "checked='checked'";
            }
        }
        checkbox = checkbox + "onclick=\"CreateFunLimitationCheckbox(this)" + "\" style=\"cursor: default;margin-left:3px\"  parentchildcontrols=\"True\"/>";
        checkbox = checkbox + "</td><td><label for=\"CheckBox_CustomAssessmentDiagnosisIDDCriteria_SubstantialFunctional_" + CodeId + "\"  style=\"cursor: default; margin-left:2px;\">" + CodeName.Trim() + "</label></td>";
        tablehtml = tablehtml + checkbox;
        return checkboxname;
    }
}
