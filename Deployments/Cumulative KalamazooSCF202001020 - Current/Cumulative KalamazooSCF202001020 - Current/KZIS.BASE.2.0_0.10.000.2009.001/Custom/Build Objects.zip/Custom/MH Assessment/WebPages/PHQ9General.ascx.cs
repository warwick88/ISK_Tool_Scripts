﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SHS.BaseLayer;

public partial class Modules_PHQ9_WebPages_PHQ9General : SHS.BaseLayer.ActivityPages.DataActivityTab
{
    public override string[] TablesUsedInTab
    {
        get
        {
            return new string[] { "PHQ9Documents" };
        }
    }
    public override void BindControls()
    {
        DropDownList_PHQ9Documents_LittleInterest.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_LittleInterest.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_FeelingDown.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_FeelingDown.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_TroubleFalling.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_TroubleFalling.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_FeelingTired.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_FeelingTired.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_PoorAppetite.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_PoorAppetite.FillDropDownDropGlobalCodes();



        DropDownList_PHQ9Documents_FeelingBad.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_FeelingBad.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_TroubleConcentrating.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_TroubleConcentrating.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_MovingOrSpeakingSlowly.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_MovingOrSpeakingSlowly.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_HurtingYourself.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_HurtingYourself.FillDropDownDropGlobalCodes();

        DropDownList_PHQ9Documents_GetAlongOtherPeople.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_PHQ9Documents_GetAlongOtherPeople.FillDropDownDropGlobalCodes();

        //DropDownList_CustomDocumentPsychiatricNoteAIMs_LipsPerioralArea.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        //DropDownList_CustomDocumentPsychiatricNoteAIMs_LipsPerioralArea.FillDropDownDropGlobalCodes();
                 
    }


    
}