﻿function SetCurrentTab(sender, e) {

    try {
        TabIndex = sender.activeTabIndex;

    }
    catch (err) { }
}

function StoreTabstripClientObject(sender) {

    tabobject = sender;
}

function RefreshTabPageContents(tabControl, selectedTabTitle) {

}
function SetScreenSpecificValues(dom, action) {

    var GeneralAppearanceOhter = dom.find("CustomDocumentMentalStatusExams:first GeneralAppearanceOthers").text();
    if (GeneralAppearanceOhter == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_GeneralAppearanceOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_GeneralAppearanceOtherComments').hide();
    }

    var SpeechOther = dom.find("CustomDocumentMentalStatusExams:first SpeechOthers").text();
    if (SpeechOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_SpeechOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_SpeechOtherComments').hide();
    }

    var LanguageOther = dom.find("CustomDocumentMentalStatusExams:first LanguageOthers").text();
    if (LanguageOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_LanguageOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_LanguageOtherComments').hide();
    }

    var MoodOther = dom.find("CustomDocumentMentalStatusExams:first MoodOthers").text();
    if (MoodOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_MoodOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_MoodOtherComments').hide();
    }

    var AffectOther = dom.find("CustomDocumentMentalStatusExams:first AffectOthers").text();
    if (AffectOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_AffectOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_AffectOtherComments').hide();
    }

    var AttentionSpanOther = dom.find("CustomDocumentMentalStatusExams:first AttentionSpanOthers").text();
    if (AttentionSpanOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_AttentionSpanOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_AttentionSpanOtherComments').hide();
    }

    var ThoughtProcessOther = dom.find("CustomDocumentMentalStatusExams:first ThoughtProcessOthers").text();
    if (ThoughtProcessOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_ThoughtProcessOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_ThoughtProcessOtherComments').hide();
    }

    var ThoughtContentOther = dom.find("CustomDocumentMentalStatusExams:first ThoughtContentOthers").text();
    if (ThoughtContentOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_ThoughtContentOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_ThoughtContentOtherComments').hide();
    }

    var CognitiveAbnormalities = dom.find("CustomDocumentMentalStatusExams:first CognitiveAbnormalitiesOthers").text();
    if (CognitiveAbnormalities == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOtherComments').hide();
    }

    var CognitiveAbnormalities = dom.find("CustomDocumentMentalStatusExams:first AssociationsOthers").text();
    if (CognitiveAbnormalities == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_AssociationsOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_AssociationsOtherComments').hide();
    }

    var CognitiveAbnormalities = dom.find("CustomDocumentMentalStatusExams:first AbnormalPsychoticOthers").text();
    if (CognitiveAbnormalities == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthersComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthersComments').hide();
    }

    var OrientationOther = dom.find("CustomDocumentMentalStatusExams:first OrientationOthers").text();
    if (OrientationOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_OrientationOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_OrientationOtherComments').hide();
    }

    var FundOfKnowledgeOther = dom.find("CustomDocumentMentalStatusExams:first FundOfKnowledgeOthers").text();
    if (FundOfKnowledgeOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOtherComments').hide();
    }

    var FundEvidenceOther = dom.find("CustomDocumentMentalStatusExams:first FundEvidenceOthers").text();
    if (FundEvidenceOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_FundEvidenceOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_FundEvidenceOtherComments').hide();
    }

    var InsightAndJudgementOther = dom.find("CustomDocumentMentalStatusExams:first InsightAndJudgementOthers").text();
    if (InsightAndJudgementOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_InsightAndJudgementOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_InsightAndJudgementOtherComments').hide();
    }

    var InsightEvidenceOther = dom.find("CustomDocumentMentalStatusExams:first InsightEvidenceOthers").text();
    if (InsightEvidenceOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_InsightEvidenceOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_InsightEvidenceOtherComments').hide();
    }

    var MemoryOther = dom.find("CustomDocumentMentalStatusExams:first MemoryOthers").text();
    if (MemoryOther == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_MemoryOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_MemoryOtherComments').hide();
    }

    var MuscleStrengthOthers = dom.find("CustomDocumentMentalStatusExams:first MuscleStrengthOthers").text();
    if (MuscleStrengthOthers == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_MuscleStrengthOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_MuscleStrengthOtherComments').hide();
    }

    var GaitAndStationOthers = dom.find("CustomDocumentMentalStatusExams:first GaitAndStationOthers").text();
    if (GaitAndStationOthers == 'Y') {
        $('#TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments').show();
    }
    else {
        $('#TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments').hide();
    }

    var MemoryRadios = dom.find("CustomDocumentMentalStatusExams:first Memory").text();
    if (MemoryRadios == 'A') {
        EnableMemoryCheckBoxes();
    }
    else {
        DisableMemoryCheckBoxes();
    }
    var GeneralAppreance = dom.find("CustomDocumentMentalStatusExams:first GeneralAppearance").text();
    if (GeneralAppreance == 'N' || GeneralAppreance == 'G') {
        DisableGeneralAppearanceCheckBoxes();
    }
    var Speech = dom.find("CustomDocumentMentalStatusExams:first Speech").text();
    if (Speech == 'N' || Speech == 'W') {
        DisableSpeechCheckBoxes();
    }
    var PsychiatricNoteExamLanguage = dom.find("CustomDocumentMentalStatusExams:first PsychiatricNoteExamLanguage").text();
    if (PsychiatricNoteExamLanguage == 'N' || PsychiatricNoteExamLanguage == 'W') {
        DisableLanguageCheckBoxes();
    }
    var MoodAndAffect = dom.find("CustomDocumentMentalStatusExams:first MoodAndAffect").text();
    if (MoodAndAffect == 'N' || MoodAndAffect == 'W') {
        DisableMoodAndAffectCheckBoxes();
    }
    var AttensionSpanAndConcentration = dom.find("CustomDocumentMentalStatusExams:first AttensionSpanAndConcentration").text();
    if (AttensionSpanAndConcentration == 'N' || AttensionSpanAndConcentration == 'W') {
        DisableAttensionSpanAndConcentrationCheckBoxes();
    }
    var ThoughtContentCognision = dom.find("CustomDocumentMentalStatusExams:first ThoughtContentCognision").text();
    if (ThoughtContentCognision == 'N' || ThoughtContentCognision == 'W') {
        DisableThoughtContentCognisionCheckBoxes();
    }
    var Associations = dom.find("CustomDocumentMentalStatusExams:first Associations").text();
    if (Associations == 'N' || Associations == 'W') {
        DisableAssociationsCheckBoxes();
    }
    var AbnormalorPsychoticThoughts = dom.find("CustomDocumentMentalStatusExams:first AbnormalorPsychoticThoughts").text();
    if (AbnormalorPsychoticThoughts == 'N') {
        DisableAbnormalorPsychoticThoughtsCheckBoxes();
    }
    var Orientation = dom.find("CustomDocumentMentalStatusExams:first Orientation").text();
    if (Orientation == 'N' || Orientation == 'W') {
        DisableOrientationCheckBoxesTextBoxes();
    }
    var FundOfKnowledge = dom.find("CustomDocumentMentalStatusExams:first FundOfKnowledge").text();
    if (FundOfKnowledge == 'N' || FundOfKnowledge == 'W') {
        DisableFundOfKnowledgeCheckBoxes();
    }
    var InsightAndJudgement = dom.find("CustomDocumentMentalStatusExams:first InsightAndJudgement").text();
    if (InsightAndJudgement == 'N') {
        DisableInsightAndJudgementCheckBoxes();
    }
    var MuscleStrengthorTone = dom.find("CustomDocumentMentalStatusExams:first MuscleStrengthorTone").text();
    if (MuscleStrengthorTone == 'N' || MuscleStrengthorTone == 'W') {
        DisableMuscleStrengthorToneCheckBoxes();
    }
    var GaitandStation = dom.find("CustomDocumentMentalStatusExams:first GaitandStation").text();
    if (GaitandStation == 'N' || GaitandStation == 'W') {
        DisableGaitandStationCheckBoxes();
    }
}

function AddEventHandlers() {

    //GeneralAppearance
    $('#RadioButton_CustomDocumentMentalStatusExams_GeneralAppearance_A').bind('click', function () {
        EnableGeneralAppearanceCheckBoxes();
    });
    $('[id$= RadioButton_CustomDocumentMentalStatusExams_GeneralAppearance_N],[id$= RadioButton_CustomDocumentMentalStatusExams_GeneralAppearance_G]').click(function () {
        UncheckGeneralAppearanceCheckBoxes();

    });

    $('span:contains(General Appearance)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var GeneralAppearanceCheckbox = $('span:contains(General Appearance)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (GeneralAppearanceCheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_GeneralAppearance_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralAppearance", 'A');
        }
        else if (GeneralAppearanceCheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_GeneralAppearance_N').attr('checked', 'checked');
            UncheckGeneralAppearanceCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralAppearance", 'N');
        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_GeneralAppearanceOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_GeneralAppearanceOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_GeneralAppearanceOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_GeneralAppearanceOtherComments]').val("");
          CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralAppearanceOtherComments", '');
        }
    });
    //Speech
    $('#RadioButton_CustomDocumentMentalStatusExams_Speech_A').bind('click', function () {
        EnableSpeechCheckBoxes();
    });
    $('[id$= RadioButton_CustomDocumentMentalStatusExams_Speech_N],[id$= RadioButton_CustomDocumentMentalStatusExams_Speech_W]').click(function () {
        UncheckSpeechCheckBoxes();
    });

    $('span:contains(Speech)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Speechcheckbox = $('span:contains(Speech)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Speechcheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Speech_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Speech", 'A');
        }
        else if (Speechcheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Speech_N').attr('checked', 'checked');
            UncheckSpeechCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Speech", 'N');
        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_SpeechOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_SpeechOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_SpeechOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_SpeechOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechOtherComments", '');
        }
    });

    //Language
    $("[id$=RadioButton_CustomDocumentMentalStatusExams_PsychiatricNoteExamLanguage_A]").unbind('click').bind('click', function () {
        EnableLanguageCheckBoxes();
    });
    $('[id$= RadioButton_CustomDocumentMentalStatusExams_PsychiatricNoteExamLanguage_N],[id$= RadioButton_CustomDocumentMentalStatusExams_PsychiatricNoteExamLanguage_W]').click(function () {
        UncheckLanguageCheckBoxes();

    });

    $('span:contains(Language)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Languagecheckbox = $('span:contains(Language)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Languagecheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_PsychiatricNoteExamLanguage_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PsychiatricNoteExamLanguage", 'A');
        }
        else if (Languagecheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_PsychiatricNoteExamLanguage_N').attr('checked', 'checked');
            UncheckLanguageCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PsychiatricNoteExamLanguage", 'N');

        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_LanguageOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_LanguageOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_LanguageOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_LanguageOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "LanguageOtherComments", '');
        }
    });
    //Mood and affect
    $('#RadioButton_CustomDocumentMentalStatusExams_MoodAndAffect_A').bind('click', function () {
        EnableMoodAndAffectCheckBoxes();
    });

    $('[id$= RadioButton_CustomDocumentMentalStatusExams_MoodAndAffect_N],[id$= RadioButton_CustomDocumentMentalStatusExams_MoodAndAffect_W]').click(function () {
        UncheckMoodAndAffectCheckBoxes();
    });

    $('span:contains(Mood and Affect)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Moodcheckbox = $('span:contains(Mood and Affect)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Moodcheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_MoodAndAffect_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodAndAffect", 'A');
        }
        else if (Moodcheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_MoodAndAffect_N').attr('checked', 'checked');
            UncheckMoodAndAffectCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodAndAffect", 'N');
        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_MoodOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_MoodOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_MoodOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_MoodOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodOtherComments", '');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_AffectOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_AffectOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_AffectOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_AffectOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectOtherComments", '');
        }
    });

    //attention
    $('#RadioButton_CustomDocumentMentalStatusExams_AttensionSpanAndConcentration_A').bind('click', function () {
        EnableAttensionSpanAndConcentrationCheckBoxes();
    });

    $('[id$= RadioButton_CustomDocumentMentalStatusExams_AttensionSpanAndConcentration_N],[id$= RadioButton_CustomDocumentMentalStatusExams_AttensionSpanAndConcentration_W]').click(function () {
        UncheckAttensionSpanAndConcentrationCheckBoxes();
    });

    $('span:contains(Attention Span and Concentration)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Attentioncheckbox = $('span:contains(Attention Span and Concentration)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Attentioncheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_AttensionSpanAndConcentration_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttensionSpanAndConcentration", 'A');
        }
        else if (Attentioncheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_AttensionSpanAndConcentration_N').attr('checked', 'checked');
            UncheckAttensionSpanAndConcentrationCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttensionSpanAndConcentration", 'N');
        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_AttentionSpanOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_AttentionSpanOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_AttentionSpanOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_AttentionSpanOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttentionSpanOtherComments", '');
        }
    });
    //ThoughtContentCognision
    $('#RadioButton_CustomDocumentMentalStatusExams_ThoughtContentCognision_A').bind('click', function () {
        EnableThoughtContentCognisionCheckBoxes();
    });

    $('[id$= RadioButton_CustomDocumentMentalStatusExams_ThoughtContentCognision_N],[id$= RadioButton_CustomDocumentMentalStatusExams_ThoughtContentCognision_W]').click(function () {
        UncheckThoughtContentCognisionCheckBoxes();
    });

    $('span:contains(Thought Content and Process; Cognition)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Thoughtcheckbox = $('span:contains(Thought Content and Process; Cognition)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Thoughtcheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_ThoughtContentCognision_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtContentCognision", 'A');
        }
        else if (Thoughtcheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_ThoughtContentCognision_N').attr('checked', 'checked');
            UncheckThoughtContentCognisionCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtContentCognision", 'N');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_ThoughtProcessOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_ThoughtProcessOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_ThoughtProcessOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_ThoughtProcessOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtProcessOtherComments", '');
        }


        if ($('#CheckBox_CustomDocumentMentalStatusExams_ThoughtContentOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_ThoughtContentOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_ThoughtContentOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_ThoughtContentOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtContentOtherComments", '');
        }


        if ($('#CheckBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "CognitiveAbnormalitiesOtherComments", '');
        }
    });
    //_Associations
    $('#RadioButton_CustomDocumentMentalStatusExams_Associations_A').bind('click', function () {
        EnableAssociationsCheckBoxes();
    });

    $('[id$= RadioButton_CustomDocumentMentalStatusExams_Associations_N],[id$= RadioButton_CustomDocumentMentalStatusExams_Associations_W]').click(function () {
        UncheckAssociationsCheckBoxes();
    });

    $('span:contains(Associations)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Associationscheckbox = $('span:contains(Associations)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Associationscheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Associations_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Associations", 'A');
        }
        else if (Associationscheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Associations_N').attr('checked', 'checked');
            UncheckAssociationsCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Associations", 'N');
        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_AssociationsOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_AssociationsOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_AssociationsOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_AssociationsOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsOtherComments", '');
        }
    });
    //PsychoticThoughts

    $('span:contains(Abnormal/Psychotic Thoughts)').parents('table[id^=Section]').find('input[type = checkbox],input[type = radio]').unbind('click').bind('click', function () {

        if ($(this).attr('id') == 'RadioButton_CustomDocumentMentalStatusExams_AbnormalorPsychoticThoughts_A') {
            EnableAbnormalorPsychoticThoughtsCheckBoxes();
        }

        else if ($(this).attr('id') == 'RadioButton_CustomDocumentMentalStatusExams_AbnormalorPsychoticThoughts_N') {
            UncheckAbnormalorPsychoticThoughtsCheckBoxes();
        }

        var Psychoticcheckbox = $('span:contains(Abnormal/Psychotic Thoughts)').parents('table[id^=Section]').find('input[type = checkbox]');
        var PsychoticRadio = $('span:contains(Abnormal/Psychotic Thoughts)').parents('table[id^=Section]').find('input[type = radio]');
        var PsychoticRadioremoved = $.grep(PsychoticRadio, function (PsychoticRadio) {
            return PsychoticRadio.name != 'RadioButton_CustomDocumentMentalStatusExams_AbnormalorPsychoticThoughts';
        });

        var count = 0;
        if ($(this).attr('name') != 'RadioButton_CustomDocumentMentalStatusExams_AbnormalorPsychoticThoughts') {
            if (!Psychoticcheckbox.is(":checked")) {
                for (var i = 0; i <= PsychoticRadioremoved.length - 1; i++) {

                    if (PsychoticRadioremoved[i].checked) {
                        count = count + 1;
                    }
                }
            }
            if (Psychoticcheckbox.is(":checked") && count >= 0) {
                $('#RadioButton_CustomDocumentMentalStatusExams_AbnormalorPsychoticThoughts_A').attr('checked', 'checked');
                EnableAbnormalorPsychoticThoughtsCheckBoxes();
                CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AbnormalorPsychoticThoughts", 'A');
            }

            if (!Psychoticcheckbox.is(":checked") && count <= 0) {
                $('#RadioButton_CustomDocumentMentalStatusExams_AbnormalorPsychoticThoughts_N').attr('checked', 'checked');
                UncheckAbnormalorPsychoticThoughtsCheckBoxes();
                CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AbnormalorPsychoticThoughts", 'N');
            }
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthersComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthersComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthersComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AbnormalPsychoticOthersComments", '');
        }
    });

    //Orientation
    $('#RadioButton_CustomDocumentMentalStatusExams_Orientation_A').bind('click', function () {
        EnableOrientationCheckBoxes();
    });

    $('#RadioButton_CustomDocumentMentalStatusExams_Orientation_N').bind('click', function () {
        UncheckOrientationCheckBoxes();
        DisableOrientationCheckBoxesTextBoxes();
    });
    $('#RadioButton_CustomDocumentMentalStatusExams_Orientation_W').bind('click', function () {
        UncheckOrientationCheckBoxes();
        DisableOrientationCheckBoxes();
    });

    $('span:contains(Orientation)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Orientationcheckbox = $('span:contains(Orientation)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Orientationcheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Orientation_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Orientation", 'A');
        }
        else if (Orientationcheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Orientation_N').attr('checked', 'checked');
            UncheckOrientationCheckBoxes();
            DisableOrientationCheckBoxesTextBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Orientation", 'N');
        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_OrientationOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_OrientationOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_OrientationOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_OrientationOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationOtherComments", '');
        }
    });

    //Fund of knowlwdge
    $('#RadioButton_CustomDocumentMentalStatusExams_FundOfKnowledge_A').bind('click', function () {
        EnableFundOfKnowledgeCheckBoxes();
    });

    $('[id$= RadioButton_CustomDocumentMentalStatusExams_FundOfKnowledge_N],[id$= RadioButton_CustomDocumentMentalStatusExams_FundOfKnowledge_W]').click(function () {
        UncheckFundOfKnowledgeCheckBoxes();
        DisableFundOfKnowledgeCheckBoxes();
    });
    $('span:contains(Fund of Knowledge)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Fundcheckbox = $('span:contains(Fund of Knowledge)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Fundcheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_FundOfKnowledge_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledge", 'A');
        }
        else if (Fundcheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_FundOfKnowledge_N').attr('checked', 'checked');
            UncheckFundOfKnowledgeCheckBoxes();
            DisableFundOfKnowledgeCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledge", 'N');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledgeOtherComments", '');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_FundEvidenceOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_FundEvidenceOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_FundEvidenceOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceOtherComments", '');
        }
    });

    //Insight

    var InsightRadio = $('[name$=RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgementStatus]');

    $('span:contains(Insight and Judgement)').parents('table[id^=Section]').find('input[type = checkbox],input[type = radio]').unbind('click').bind('click', function () {

        if ($(this).attr('id') == 'RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgement_A') {
            EnableInsightAndJudgementCheckBoxes();
        }

        else if ($(this).attr('id') == 'RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgement_N') {
            UncheckInsightAndJudgementCheckBoxes();
        }

        var Insightcheckbox = $('span:contains(Insight and Judgement)').parents('table[id^=Section]').find('input[type = checkbox]');

        if (Insightcheckbox.is(":checked") || InsightRadio.is(":checked") && ($(this).attr('name') != 'RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgement')) {
            $('#RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgement_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightAndJudgement", 'A');
        }
        else if (Insightcheckbox.attr('checked', false) && InsightRadio.attr('checked', false) && ($(this).attr('name') != 'RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgement')) {
            $('#RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgement_N').attr('checked', 'checked');
            UncheckInsightAndJudgementCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightAndJudgement", 'N');
        }
        if ($('#CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_InsightAndJudgementOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_InsightAndJudgementOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_InsightAndJudgementOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightAndJudgementOtherComments", '');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_InsightEvidenceOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_InsightEvidenceOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_InsightEvidenceOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceOtherComments", '');
        }
    });
    //Memory
    $('#RadioButton_CustomDocumentMentalStatusExams_Memory_A').bind('click', function () {
        EnableMemoryCheckBoxes();
    });
    $('[id$= RadioButton_CustomDocumentMentalStatusExams_Memory_W],[id$= RadioButton_CustomDocumentMentalStatusExams_Memory_N]').click(function () {
        UncheckMemoryCheckBoxes();
        DisableMemoryCheckBoxes();
    });

    $('span:contains(Memory)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Memorycheckbox = $('span:contains(Memory)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Memorycheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Memory_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Memory", 'A');
        }
        else if (Memorycheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_Memory_N').attr('checked', 'checked');
            UncheckMemoryCheckBoxes();
            DisableMemoryCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "Memory", 'N');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_MemoryOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_MemoryOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_MemoryOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryOtherComments", '');
        }
    });
    //muscle
    $('#RadioButton_CustomDocumentMentalStatusExams_MuscleStrengthorTone_A').bind('click', function () {
        EnableMuscleStrengthorToneCheckBoxes();
    });

    $('[id$= RadioButton_CustomDocumentMentalStatusExams_MuscleStrengthorTone_N],[id$= RadioButton_CustomDocumentMentalStatusExams_MuscleStrengthorTone_W]').click(function () {
        UncheckMuscleStrengthorToneCheckBoxes();
    });

    $('span:contains(Muscle Strength/Tone)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Musclecheckbox = $('span:contains(Muscle Strength/Tone)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Musclecheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_MuscleStrengthorTone_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MuscleStrengthorTone", 'A');
        }
        else if (Musclecheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_MuscleStrengthorTone_N').attr('checked', 'checked');
            UncheckMuscleStrengthorToneCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MuscleStrengthorTone", 'N');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_MuscleStrengthOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_MuscleStrengthOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_MuscleStrengthOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MuscleStrengthOtherComments", '');
        }
    });
    //Gait
    $('#RadioButton_CustomDocumentMentalStatusExams_GaitandStation_A').bind('click', function () {
        EnableGaitandStationCheckBoxes();
    });

    $('[id$= RadioButton_CustomDocumentMentalStatusExams_GaitandStation_N],[id$= RadioButton_CustomDocumentMentalStatusExams_GaitandStation_W]').click(function () {
        UncheckGaitandStationCheckBoxes();
    });

    $('#CheckBox_CustomDocumentMentalStatusExams_GaitAndStationOthers').unbind('click').bind('click', function () {
        if ($(this).attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitAndStationOtherComments", '');
        }
    });


    $('span:contains(Gait and Station)').parents('table[id^=Section]').find('input[type = checkbox]').unbind('click').bind('click', function () {
        var Musclecheckbox = $('span:contains(Gait and Station)').parents('table[id^=Section]').find('input[type = checkbox]');
        if (Musclecheckbox.is(":checked")) {
            $('#RadioButton_CustomDocumentMentalStatusExams_GaitandStation_A').attr('checked', 'checked');
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitandStation", 'A');
        }
        else if (Musclecheckbox.attr('checked', false)) {
            $('#RadioButton_CustomDocumentMentalStatusExams_GaitandStation_N').attr('checked', 'checked');
            UncheckGaitandStationCheckBoxes();
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitandStation", 'N');
        }

        if ($('#CheckBox_CustomDocumentMentalStatusExams_GaitAndStationOthers').attr('checked'))
            $('#TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments').show();
        else {
            $('#TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments').hide();
            $('[id$=TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments]').val("");
            CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitAndStationOtherComments", '');
        }
    });

}

function EnableGeneralAppearanceCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorlyAddresses').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorlyGroomed').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralDisheveled').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralOdferous').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralDeformities').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorNutrion').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralRestless').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPsychometer').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralHyperActive').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralEvasive').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralInAttentive').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorEyeContact').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralHostile').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralAppearanceOthers').attr("disabled", false);

}
function DisableGeneralAppearanceCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorlyAddresses').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorlyGroomed').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralDisheveled').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralOdferous').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralDeformities').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorNutrion').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralRestless').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPsychometer').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralHyperActive').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralEvasive').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralInAttentive').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorEyeContact').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralHostile').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralAppearanceOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_GeneralAppearanceOtherComments').hide();
}
function UncheckGeneralAppearanceCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorlyAddresses').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorlyGroomed').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralDisheveled').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralOdferous').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralDeformities').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorNutrion').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralRestless').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPsychometer').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralHyperActive').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralEvasive').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralInAttentive').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralPoorEyeContact').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralHostile').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GeneralAppearanceOthers').attr('checked', '');

    DisableGeneralAppearanceCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralPoorlyAddresses", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralPoorlyGroomed", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralDisheveled", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralOdferous", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralDeformities", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralPoorNutrion", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralRestless", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralPsychometer", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralHyperActive", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralEvasive", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralInAttentive", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralPoorEyeContact", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralHostile", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralAppearanceOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_GeneralAppearanceOthers', 'Textbox_CustomDocumentMentalStatusExams_GeneralAppearanceOtherComments', 'CustomDocumentMentalStatusExams', 'GeneralAppearanceOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GeneralAppearanceOtherComments", '');
}
function EnableSpeechCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechIncreased').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechDecreased').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPaucity').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechHyperverbal').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPoorArticulations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechLoud').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechSoft').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechMute').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechStuttering').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechImpaired').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPressured').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechFlight').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechOthers').attr("disabled", false);

}
function UncheckSpeechCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechIncreased').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechDecreased').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPaucity').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechHyperverbal').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPoorArticulations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechLoud').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechSoft').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechMute').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechStuttering').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechImpaired').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPressured').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechFlight').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechOthers').attr('checked', '');

    DisableSpeechCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechIncreased", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechDecreased", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechPaucity", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechHyperverbal", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechPoorArticulations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechLoud", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechSoft", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechMute", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechStuttering", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechImpaired", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechPressured", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechFlight", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_SpeechOthers', 'Textbox_CustomDocumentMentalStatusExams_SpeechOtherComments', 'CustomDocumentMentalStatusExams', 'SpeechOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "SpeechOtherComments", '');
}
function DisableSpeechCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechIncreased').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechDecreased').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPaucity').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechHyperverbal').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPoorArticulations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechLoud').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechSoft').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechMute').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechStuttering').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechImpaired').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechPressured').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechFlight').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_SpeechOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_SpeechOtherComments').hide();
}
function UncheckLanguageCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageDifficultyNaming').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageDifficultyRepeating').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageOthers').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageNonVerbal').attr('checked', '');

    DisableLanguageCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "LanguageDifficultyNaming", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "LanguageDifficultyRepeating", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "LanguageOthers", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "LanguageNonVerbal", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_LanguageOthers', 'Textbox_CustomDocumentMentalStatusExams_LanguageOtherComments', 'CustomDocumentMentalStatusExams', 'LanguageOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "LanguageOtherComments", '');
}
function EnableLanguageCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageDifficultyNaming').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageDifficultyRepeating').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageOthers').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageNonVerbal').attr("disabled", false);
}
function DisableLanguageCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageDifficultyNaming').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageDifficultyRepeating').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageOthers').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_LanguageNonVerbal').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_LanguageOtherComments').hide();
}
function EnableMoodAndAffectCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodHappy').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodSad').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodAnxious').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodAngry').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodIrritable').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodElation').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodNormal').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodOthers').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectEuthymic').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectDysphoric').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectAnxious').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectIrritable').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectBlunted').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectLabile').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectEuphoric').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectCongruent').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectOthers').attr("disabled", false);
}
function DisableMoodAndAffectCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodHappy').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodSad').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodAnxious').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodAngry').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodIrritable').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodElation').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodNormal').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodOthers').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectEuthymic').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectDysphoric').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectAnxious').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectIrritable').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectBlunted').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectLabile').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectEuphoric').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectCongruent').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_MoodOtherComments').hide();
    $('#TextBox_CustomDocumentMentalStatusExams_AffectOtherComments').hide();
}
function UncheckMoodAndAffectCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_MoodHappy').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodSad').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodAnxious').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodAngry').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodIrritable').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodElation').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodNormal').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MoodOthers').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectEuthymic').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectDysphoric').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectAnxious').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectIrritable').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectBlunted').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectLabile').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectEuphoric').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectCongruent').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AffectOthers').attr('checked', '');

    DisableMoodAndAffectCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodHappy", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodSad", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodAnxious", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodAngry", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodIrritable", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodElation", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodNormal", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodOthers", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectEuthymic", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectDysphoric", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectAnxious", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectIrritable", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectBlunted", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectLabile", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectEuphoric", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectCongruent", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectOthers", '');



    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_MoodOthers', 'Textbox_CustomDocumentMentalStatusExams_MoodOtherComments', 'CustomDocumentMentalStatusExams', 'MoodOtherComments');
    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_AffectOthers', 'Textbox_CustomDocumentMentalStatusExams_AffectOtherComments', 'CustomDocumentMentalStatusExams', 'AffectOtherComments');

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MoodOtherComments", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AffectOtherComments", '');
}

function EnableAttensionSpanAndConcentrationCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionPoorConcentration').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionPoorAttension').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionDistractible').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AttentionSpanOthers').attr("disabled", false);
}

function DisableAttensionSpanAndConcentrationCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionPoorConcentration').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionPoorAttension').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionDistractible').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AttentionSpanOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_AttentionSpanOtherComments').hide();
}

function UncheckAttensionSpanAndConcentrationCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionPoorConcentration').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionPoorAttension').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AttensionDistractible').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AttentionSpanOthers').attr('checked', '');

    DisableAttensionSpanAndConcentrationCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttensionPoorConcentration", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttensionPoorAttension", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttensionDistractible", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttentionSpanOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_AttentionSpanOthers', 'Textbox_CustomDocumentMentalStatusExams_AttentionSpanOtherComments', 'CustomDocumentMentalStatusExams', 'AttentionSpanOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AttentionSpanOtherComments", '');
}


function EnableThoughtContentCognisionCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_TPDisOrganised').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPBlocking').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPPersecution').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPBroadCasting').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPDetrailed').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPThoughtInsertion').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPIncoherent').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPRacing').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TPIllogical').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_ThoughtProcessOthers').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCDelusional').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCParanoid').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCIdeas').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtInsertion').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtWithdrawal').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtBroadcasting').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCReligiosity').attr("disabled", false);

    $('#CheckBox_CustomDocumentMentalStatusExams_TCGrandiosity').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCPerserveration').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCObsessions').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCWorthlessness').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCLoneliness').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCGuilt').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_TCHopelessness').attr("disabled", false);


    $('#CheckBox_CustomDocumentMentalStatusExams_TCHelplessness').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_ThoughtContentOthers').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_CAConcrete').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_CAUnable').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_CAPoorComputation').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOthers').attr("disabled", false);
}
function DisableThoughtContentCognisionCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_TPDisOrganised').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPBlocking').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPPersecution').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPBroadCasting').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPDetrailed').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPThoughtInsertion').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPIncoherent').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPRacing').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TPIllogical').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_ThoughtProcessOthers').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCDelusional').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCParanoid').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCIdeas').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtInsertion').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtWithdrawal').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtBroadcasting').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCReligiosity').attr("disabled", "disabled");

    $('#CheckBox_CustomDocumentMentalStatusExams_TCGrandiosity').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCPerserveration').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCObsessions').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCWorthlessness').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCLoneliness').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCGuilt').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_TCHopelessness').attr("disabled", "disabled");

    $('#CheckBox_CustomDocumentMentalStatusExams_TCHelplessness').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_ThoughtContentOthers').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_CAConcrete').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_CAUnable').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_CAPoorComputation').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOthers').attr("disabled", "disabled");

    $('#TextBox_CustomDocumentMentalStatusExams_ThoughtProcessOtherComments').hide();
    $('#TextBox_CustomDocumentMentalStatusExams_ThoughtContentOtherComments').hide();
    $('#TextBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOtherComments').hide();

}
function UncheckThoughtContentCognisionCheckBoxes() {


    $('#CheckBox_CustomDocumentMentalStatusExams_TPDisOrganised').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPBlocking').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPPersecution').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPBroadCasting').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPDetrailed').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPThoughtInsertion').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPIncoherent').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPRacing').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TPIllogical').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_ThoughtProcessOthers').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCDelusional').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCParanoid').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCIdeas').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtInsertion').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtWithdrawal').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCThoughtBroadcasting').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCReligiosity').attr('checked', '');

    $('#CheckBox_CustomDocumentMentalStatusExams_TCGrandiosity').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCPerserveration').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCObsessions').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCWorthlessness').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCLoneliness').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCGuilt').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_TCHopelessness').attr('checked', '');


    $('#CheckBox_CustomDocumentMentalStatusExams_TCHelplessness').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_ThoughtContentOthers').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_CAConcrete').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_CAUnable').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_CAPoorComputation').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOthers').attr('checked', '');

    DisableThoughtContentCognisionCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPDisOrganised", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPBlocking", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPPersecution", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPBroadCasting", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPDetrailed", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPThoughtInsertion", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPIncoherent", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPRacing", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TPIllogical", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtProcessOthers", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCDelusional", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCParanoid", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCIdeas", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCThoughtInsertion", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCThoughtWithdrawal", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCThoughtBroadcasting", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCReligiosity", '');

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCGrandiosity", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCPerserveration", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCObsessions", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCWorthlessness", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCLoneliness", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCGuilt", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCHopelessness", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "TCHelplessness", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtContentOthers", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "CAConcrete", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "CAUnable", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "CAPoorComputation", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "CognitiveAbnormalitiesOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_ThoughtProcessOthers', 'Textbox_CustomDocumentMentalStatusExams_ThoughtProcessOtherComments', 'CustomDocumentMentalStatusExams', 'ThoughtProcessOtherComments');
    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_ThoughtContentOthers', 'Textbox_CustomDocumentMentalStatusExams_ThoughtContentOtherComments', 'CustomDocumentMentalStatusExams', 'ThoughtContentOtherComments');
    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOthers', 'Textbox_CustomDocumentMentalStatusExams_CognitiveAbnormalitiesOtherComments', 'CustomDocumentMentalStatusExams', 'CognitiveAbnormalitiesOtherComments');

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtProcessOtherComments", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "ThoughtContentOtherComments", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "CognitiveAbnormalitiesOtherComments", '');
}
function EnableAssociationsCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsLoose').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsClanging').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsWordsalad').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsCircumstantial').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsTangential').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsOthers').attr("disabled", false);

}


function DisableAssociationsCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsLoose').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsClanging').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsWordsalad').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsCircumstantial').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsTangential').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_AssociationsOtherComments').hide();
}

function UncheckAssociationsCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsLoose').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsClanging').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsWordsalad').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsCircumstantial').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsTangential').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AssociationsOthers').attr('checked', '');

    DisableAssociationsCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsLoose", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsClanging", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsWordsalad", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsCircumstantial", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsTangential", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_AssociationsOthers', 'Textbox_CustomDocumentMentalStatusExams_AssociationsOtherComments', 'CustomDocumentMentalStatusExams', 'AssociationsOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AssociationsOtherComments", '');
}


function EnableAbnormalorPsychoticThoughtsCheckBoxes(Assessed, isChecked) {

    $('#CheckBox_CustomDocumentMentalStatusExams_PDAuditoryHallucinations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDVisualHallucinations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDCommandHallucinations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDDelusions').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDPreoccupation').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDOlfactoryHallucinations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDGustatoryHallucinations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDTactileHallucinations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDSomaticHallucinations').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_PDIllusions').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthers').attr("disabled", false);

    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PsychosisOrDisturbanceOfPerception]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicideIdeation]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicidalIntent]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalIdeation]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalIntent]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicidalPlan]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDMeansToCarry]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalPlans]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDMeansToCarryNew]').attr("disabled", false);

}
function DisableAbnormalorPsychoticThoughtsCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_PDAuditoryHallucinations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDVisualHallucinations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDCommandHallucinations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDDelusions').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDPreoccupation').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDOlfactoryHallucinations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDGustatoryHallucinations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDTactileHallucinations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDSomaticHallucinations').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_PDIllusions').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthers').attr("disabled", "disabled");

    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PsychosisOrDisturbanceOfPerception]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicideIdeation]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicidalIntent]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalIdeation]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalIntent]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicidalPlan]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDMeansToCarry]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalPlans]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDMeansToCarryNew]').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthersComments').hide();

}


function UncheckAbnormalorPsychoticThoughtsCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_PDAuditoryHallucinations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDVisualHallucinations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDCommandHallucinations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDDelusions').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDPreoccupation').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDOlfactoryHallucinations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDGustatoryHallucinations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDTactileHallucinations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDSomaticHallucinations').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_PDIllusions').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthers').attr('checked', '');

    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PsychosisOrDisturbanceOfPerception]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicideIdeation]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicidalIntent]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalIdeation]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalIntent]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentSuicidalPlan]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDMeansToCarry]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDCurrentHomicidalPlans]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_PDMeansToCarryNew]').attr('checked', '');

    DisableAbnormalorPsychoticThoughtsCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDAuditoryHallucinations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDVisualHallucinations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDCommandHallucinations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDDelusions", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDPreoccupation", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDOlfactoryHallucinations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDGustatoryHallucinations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDTactileHallucinations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDSomaticHallucinations", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDIllusions", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AbnormalPsychoticOthers", '');

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PsychosisOrDisturbanceOfPerception", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDCurrentSuicideIdeation", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDCurrentSuicidalIntent", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDCurrentHomicidalIdeation", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDCurrentHomicidalIntent", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDCurrentSuicidalPlan", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDMeansToCarry", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDCurrentHomicidalPlans", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "PDMeansToCarryNew", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthers', 'Textbox_CustomDocumentMentalStatusExams_AbnormalPsychoticOthersComments', 'CustomDocumentMentalStatusExams', 'AbnormalPsychoticOthersComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "AbnormalPsychoticOthersComments", '');
}

function EnableOrientationCheckBoxes(Assessed, isChecked) {

    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPerson').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPlace').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationTime').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationSituation').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationOthers').attr("disabled", false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationDescribeSituation').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationFullName').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationEvidencedPlace').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationFullDate').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationDescribeSituation').attr('disabled', false);

}
function DisableOrientationCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPerson').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPlace').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationTime').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationSituation').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationOthers').attr("disabled", "disabled");
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationDescribeSituation').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationFullName').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationEvidencedPlace').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationFullDate').attr('disabled', false);
    $('#Textbox_CustomDocumentMentalStatusExams_OrientationDescribeSituation').attr('disabled', false);
    $('#TextBox_CustomDocumentMentalStatusExams_OrientationOtherComments').hide();
}


function DisableOrientationCheckBoxesTextBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPerson').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPlace').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationTime').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationSituation').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationOthers').attr("disabled", "disabled");
    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationDescribeSituation]').attr("disabled", "disabled");
    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationFullName]').attr("disabled", "disabled");
    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationEvidencedPlace]').attr("disabled", "disabled");
    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationFullDate]').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_OrientationOtherComments').hide();
}

function UncheckOrientationCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPerson').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationPlace').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationTime').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationSituation').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_OrientationOthers').attr('checked', '');

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationPerson", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationPlace", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationTime", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationSituation", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationOthers", '');

    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationDescribeSituation]').val("");
    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationFullName]').val("");
    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationEvidencedPlace]').val("");
    $('[id$=Textbox_CustomDocumentMentalStatusExams_OrientationFullDate]').val("");

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationDescribeSituation", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationFullName", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationEvidencedPlace", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationFullDate", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_OrientationOthers', 'Textbox_CustomDocumentMentalStatusExams_OrientationOtherComments', 'CustomDocumentMentalStatusExams', 'OrientationOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "OrientationOtherComments", '');
}

function EnableFundOfKnowledgeCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeCurrentEvents').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgePastHistory').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeVocabulary').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOthers').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceVocabulary').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceKnowledge').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceResponses').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceSchool').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceIQ').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceOthers').attr("disabled", false);
}

function DisableFundOfKnowledgeCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeCurrentEvents').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgePastHistory').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeVocabulary').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOthers').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceVocabulary').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceKnowledge').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceResponses').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceSchool').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceIQ').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOtherComments').hide();
    $('#TextBox_CustomDocumentMentalStatusExams_FundEvidenceOtherComments').hide();
}

function UncheckFundOfKnowledgeCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeCurrentEvents').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgePastHistory').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeVocabulary').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOthers').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceVocabulary').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceKnowledge').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceResponses').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceSchool').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceIQ').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_FundEvidenceOthers').attr('checked', '');

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledgeCurrentEvents", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledgePastHistory", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledgeVocabulary", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledgeOthers", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceVocabulary", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceKnowledge", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceResponses", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceSchool", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceIQ", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_FundOfKnowledgeOthers', 'Textbox_CustomDocumentMentalStatusExams_FundOfKnowledgeOtherComments', 'CustomDocumentMentalStatusExams', 'FundOfKnowledgeOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundOfKnowledgeOtherComments", '');
    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_FundEvidenceOthers', 'Textbox_CustomDocumentMentalStatusExams_FundEvidenceOtherComments', 'CustomDocumentMentalStatusExams', 'FundEvidenceOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "FundEvidenceOtherComments", '');
}

function EnableInsightAndJudgementCheckBoxes() {


    $('[name$=RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgementStatus]').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementSubstance').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementOthers').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceAwareness').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceAcceptance').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceUnderstanding').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceSelfDefeating').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceDenial').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceOthers').attr("disabled", false);
}
function DisableInsightAndJudgementCheckBoxes() {
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgementStatus]').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementSubstance').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementOthers').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceAwareness').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceAcceptance').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceUnderstanding').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceSelfDefeating').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceDenial').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceOthers').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgementStatus]').attr("disabled", "disabled");


    $('#TextBox_CustomDocumentMentalStatusExams_InsightAndJudgementOtherComments').hide();
    $('#TextBox_CustomDocumentMentalStatusExams_InsightEvidenceOtherComments').hide();
}


function UncheckInsightAndJudgementCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementSubstance').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementOthers').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_InsightAndJudgementStatus]').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceAwareness').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceAcceptance').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceUnderstanding').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceSelfDefeating').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceDenial').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceOthers').attr('checked', '');

    $('#CheckBox_CustomDocumentMentalStatusExams_Awarenessofproblem').attr("checked", '');
    $('#CheckBox_CustomDocumentMentalStatusExams_Acceptanceofhelp').attr("checked", '');
    $('#CheckBox_CustomDocumentMentalStatusExams_Understandingcauseandeffect').attr("checked", '');


    DisableInsightAndJudgementCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightAndJudgementSubstance", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightAndJudgementOthers", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightAndJudgementStatus", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceAwareness", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceAcceptance", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceUnderstanding", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceSelfDefeating", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceDenial", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceUnderstanding", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceOthers", '');


    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_InsightAndJudgementOthers', 'Textbox_CustomDocumentMentalStatusExams_InsightAndJudgementOtherComments', 'CustomDocumentMentalStatusExams', 'InsightAndJudgementOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightAndJudgementOtherComments", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_InsightEvidenceOthers', 'Textbox_CustomDocumentMentalStatusExams_InsightEvidenceOtherComments', 'CustomDocumentMentalStatusExams', 'InsightEvidenceOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "InsightEvidenceOtherComments", '');
}

function EnableMemoryCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_MemoryOthers').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryImmediate]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryRecent]').attr("disabled", false);
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryRemote]').attr("disabled", false);
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryImmediateEvidencedBy]').attr("disabled", false);
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryRecentEvidencedBy]').attr('disabled', false);
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryRemoteEvidencedBy]').attr('disabled', false);

}
function DisableMemoryCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_MemoryOthers').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryImmediate]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryRecent]').attr("disabled", "disabled");
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryRemote]').attr("disabled", "disabled");
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryImmediateEvidencedBy]').attr("disabled", "disabled");
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryRecentEvidencedBy]').attr('disabled', 'disabled');
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryRemoteEvidencedBy]').attr('disabled', 'disabled');

    $('#TextBox_CustomDocumentMentalStatusExams_MemoryOtherComments').hide();
}



function UncheckMemoryCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_MemoryOthers').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryImmediate]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryRecent]').attr('checked', '');
    $('[name$=RadioButton_CustomDocumentMentalStatusExams_MemoryRemote]').attr('checked', '');
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryImmediateEvidencedBy]').val("");
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryRecentEvidencedBy]').val("");
    $('[id$=TextBox_CustomDocumentMentalStatusExams_MemoryRemoteEvidencedBy]').val("");


    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryOthers", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryImmediate", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryRecent", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryRemote", '');

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryImmediateEvidencedBy", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryRecentEvidencedBy", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryRemoteEvidencedBy", '');


    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_MemoryOthers', 'Textbox_CustomDocumentMentalStatusExams_MemoryOtherComments', 'CustomDocumentMentalStatusExams', 'MemoryOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MemoryOtherComments", '');
}

function EnableMuscleStrengthorToneCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthorToneAtrophy').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthorToneAbnormal').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthOthers').attr("disabled", false);

}
function DisableMuscleStrengthorToneCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthorToneAtrophy').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthorToneAbnormal').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_MuscleStrengthOtherComments').hide();
}


function UncheckMuscleStrengthorToneCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthorToneAtrophy').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthorToneAbnormal').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthOthers').attr('checked', '');

    DisableMuscleStrengthorToneCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MuscleStrengthorToneAtrophy", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MuscleStrengthorToneAbnormal", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MuscleStrengthOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_MuscleStrengthOthers', 'Textbox_CustomDocumentMentalStatusExams_MuscleStrengthOtherComments', 'CustomDocumentMentalStatusExams', 'MuscleStrengthOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "MuscleStrengthOtherComments", '');
}

function EnableGaitandStationCheckBoxes() {

    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationRestlessness').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationStaggered').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationShuffling').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationUnstable').attr("disabled", false);
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitAndStationOthers').attr("disabled", false);

}
function DisableGaitandStationCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationRestlessness').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationStaggered').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationShuffling').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationUnstable').attr("disabled", "disabled");
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitAndStationOthers').attr("disabled", "disabled");
    $('#TextBox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments').hide();
}


function UncheckGaitandStationCheckBoxes() {
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationRestlessness').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationStaggered').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationShuffling').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitandStationUnstable').attr('checked', '');
    $('#CheckBox_CustomDocumentMentalStatusExams_GaitAndStationOthers').attr('checked', '');

    DisableGaitandStationCheckBoxes();

    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitandStationRestlessness", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitandStationStaggered", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitandStationShuffling", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitandStationUnstable", '');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitAndStationOthers", '');

    ShowCommentBoxTextArea('CheckBox_CustomDocumentMentalStatusExams_GaitAndStationOthers', 'Textbox_CustomDocumentMentalStatusExams_GaitAndStationOtherComments', 'CustomDocumentMentalStatusExams', 'GaitAndStationOtherComments');
    CreateAutoSaveXml("CustomDocumentMentalStatusExams", "GaitAndStationOtherComments", '');
}

function ShowCommentBoxTextArea(checkbox, textbox, table, column) {

    if ($('[id$=' + checkbox + ']').attr("checked")) {
        $('[id$=' + textbox + ']').show();
    }
    else {
        $('[id$=' + textbox + ']').hide();
    }
}
