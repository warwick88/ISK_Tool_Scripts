﻿AddEventHandlers = (function () {
    try {
        $("input[type=radio].radChildYes").click(function () {
            UpdateAceScore('AddEventHandlers');
        });

        $("input[type=radio].radChildNo").click(function () {
            UpdateAceScore('AddEventHandlers');
        });

        $("#CheckBox_CustomDocumentAdverseChildhoodExperiences_UnableToComplete").click(function () {
            UnableToComplete('AddEventHandlers');
        });
    }
    catch (ex) {
    }
});

UpdateAceScore = (function (mode) {
    try {
        var DocumentVersionId = AutoSaveXMLDom.find("CustomDocumentAdverseChildhoodExperiences:first DocumentVersionId").text();
        var YesCount = $('.radChildYes:checked').length;
        $('#TextBox_CustomDocumentAdverseChildhoodExperiences_AceScore').val(YesCount);
        if (mode == 'AddEventHandlers')
            CreateAutoSaveXml("CustomDocumentAdverseChildhoodExperiences", "AceScore", YesCount);
        else if (mode == 'DocumentCallbackComplete') {
            var AceScore = AutoSaveXMLDom.find("CustomDocumentAdverseChildhoodExperiences:first AceScore").text();
            if (!AceScore)
                AceScore = 0;
            if (parseInt(AceScore) != YesCount)
                SetColumnValueInXMLNodeByKeyValue("CustomDocumentAdverseChildhoodExperiences", "DocumentVersionId", DocumentVersionId, "AceScore", YesCount, AutoSaveXMLDom[0]);
        }

        if ($('.radChildYes:checked').length > 0 || $('.radChildNo:checked').length) {
            $('#CheckBox_CustomDocumentAdverseChildhoodExperiences_UnableToComplete').removeAttr('checked');
            $('#CheckBox_CustomDocumentAdverseChildhoodExperiences_UnableToComplete').attr('disabled', 'disabled');
            if (mode == 'AddEventHandlers')
                CreateAutoSaveXml("CustomDocumentAdverseChildhoodExperiences", "UnableToComplete", "N");
            else if (mode == 'DocumentCallbackComplete') {
                var UnableToComplete = AutoSaveXMLDom.find("CustomDocumentAdverseChildhoodExperiences:first UnableToComplete").text();
                if (!UnableToComplete)
                    UnableToComplete = "N";
                if (UnableToComplete != "N")
                    SetColumnValueInXMLNodeByKeyValue("CustomDocumentAdverseChildhoodExperiences", "DocumentVersionId", DocumentVersionId, "UnableToComplete", "N", AutoSaveXMLDom[0]);
            }
        }
    }
    catch (ex) {
    }
});

DocumentCallbackComplete = (function (obj) {
    UpdateAceScore('DocumentCallbackComplete');
    UnableToComplete('DocumentCallbackComplete');
});

UnableToComplete = (function (mode) {
    if ($("#CheckBox_CustomDocumentAdverseChildhoodExperiences_UnableToComplete").attr('checked')) {
        $("input[type=radio].radChildYes").removeAttr('checked');
        $("input[type=radio].radChildYes").attr('disabled', 'disabled');
        $("input[type=radio].radChildNo").removeAttr('checked');
        $("input[type=radio].radChildNo").attr('disabled', 'disabled');
        $('#TextBox_CustomDocumentAdverseChildhoodExperiences_AceScore').val('');
        $('#TextBox_CustomDocumentAdverseChildhoodExperiences_AceScore').attr('disabled', 'disabled');
        $('#TextBox_CustomDocumentAdverseChildhoodExperiences_AceScore').css('background-color', '#e5e5e5');

        if (mode == 'AddEventHandlers') {
            CreateAutoSaveXmlObj([{ "CustomDocumentAdverseChildhoodExperiences": { "Humiliate": "", "Injured": "", "Touch": "", "Support": "", "EnoughToEat": "", "ParentsSeparated": "", "Pushed": "", "DrinkerProblem": "", "Suicide": "", "Prison": "", "AceScore": "" } }]);
        }
    }
    else {
        $("input[type=radio].radChildYes").removeAttr('disabled');
        $("input[type=radio].radChildNo").removeAttr('disabled');
        $('#TextBox_CustomDocumentAdverseChildhoodExperiences_AceScore').removeAttr('disabled');
        $('#TextBox_CustomDocumentAdverseChildhoodExperiences_AceScore').css('background-color', '');
        UpdateAceScore(mode);
    }
});