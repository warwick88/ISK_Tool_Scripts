﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SHS.SmartCare
{
    public partial class Custom_AdverseChildhoodExperience_WebPages_AdverseChildhoodExperience : SHS.BaseLayer.ActivityPages.DocumentDataActivityPage
    {

        public override string PageDataSetName
        {
            get { return "DataSetCustomChildExperiences"; }
        }

        public override string[] TablesToBeInitialized
        {
            get { return new string[] { "CustomDocumentAdverseChildhoodExperiences" }; }
        }

        public override void BindControls()
        {

        }
    }
}