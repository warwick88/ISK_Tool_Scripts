﻿function SetCurrentObjectiveStatus(checkbox) {
    var currentObjectivesStatus = $(checkbox)[0].checked;

    if (currentObjectivesStatus) {
        $('#hidden_CurrentObjectives').val('Y');
    }
    else {
        $('#hidden_CurrentObjectives').val('N');
    }
}

function IncludeRequestParametersValues() {
    var filterString = "";
    filterString += GetFilterValues();
    filterString = filterString.substring(1, filterString.length);
    filterString = filterString.replace(/#/gi, "&") + "&ExportUsingPageDataSet=Y"
    return filterString;
}

function AddEventHandlers() {
    if ($('[id$=hidden_CurrentObjectives]').val() == "Y") {
        $('[id$=checkbox_CurrentObjectivesOnly]').attr("checked", true);
    }
    else {
        $('[id$=checkbox_CurrentObjectivesOnly]').removeAttr("checked");
    }
}