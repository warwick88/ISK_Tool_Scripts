﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using SHS.BaseLayer;

///<summary>
///<Description>Care Plan General Tab Document</Description>
///</summary>
namespace SHS.SmartCare
{
    public partial class CarePlanGeneral : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        public string Screenname { get; private set; }
        ///<summary>
        ///<Description>Bind Controls on Page</Description>
        ///</summary>
        public override void BindControls()
        {
            using (DataView dataViewGlobalCodes = BaseCommonFunctions.FillDropDown("AUTHORIZATIONTEAM", true, "", "", false))
            {
                dataViewGlobalCodes.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')='N'";
                dataViewGlobalCodes.Sort = "CodeName";
                DropDownList_CustomDocumentCarePlans_UMArea.DataTextField = "CodeName";
                DropDownList_CustomDocumentCarePlans_UMArea.DataValueField = "GlobalCodeId";
                DropDownList_CustomDocumentCarePlans_UMArea.DataSource = dataViewGlobalCodes;
                DropDownList_CustomDocumentCarePlans_UMArea.DataBind();
                DropDownList_CustomDocumentCarePlans_UMArea.Items.Insert(0, new ListItem("", "0"));
            }
            
            Screenname = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.FindByScreenId(SHS.BaseLayer.BaseCommonFunctions.ScreenId).ScreenName.ToString();
            UserControl uc = (UserControl)Page.LoadControl("~/Custom/MichiganLOC/LOC/WebPages/UCLevelOfCareSection.ascx");
            divLevelOfCareSection.Controls.Add(uc);
        }
        //public override string[] TablesUsedInTab
        //{
        //    get { return new string[] { "DocumentCarePlans," }; }
        //}
    }
}
