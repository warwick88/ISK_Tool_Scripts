﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SHS.BaseLayer;

namespace SHS.SmartCare
{
    public partial class ObjectivesProgressPlanHistory : SHS.BaseLayer.ActivityPages.ListActivityPage
    {
        #region Bind Dropdowns

        public override void BindFilters()
        {
            BindAllStatuses();
            BindStaff();
            BindReviewSource();
            BindReviewStatus();
        }
        private void BindStaff()
        {
            DropDownList_StaffName.DataSource = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff;
            DropDownList_StaffName.DataTextField = "StaffName";
            DropDownList_StaffName.DataValueField = "StaffId";
            DropDownList_StaffName.DataBind();
        }
        private void BindReviewSource()
        {
            DropDownList_ReviewSource.Items.Add(new ListItem("All Review Source", "-1"));
            DropDownList_ReviewSource.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
            DropDownList_ReviewSource.FillDropDownDropGlobalCodes();
        }
        private void BindReviewStatus()
        {
            DropDownList_ReviewStatus.Items.Add(new ListItem("All Review Status", "-1"));
            DropDownList_ReviewStatus.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
            DropDownList_ReviewStatus.FillDropDownDropGlobalCodes();
        }
        protected void BindAllStatuses()
        {
            ListItemCollection allScores = new ListItemCollection();
            allScores.Add(new ListItem() { Text = "-1", Value = "D" });
            allScores.Add(new ListItem() { Text = "0", Value = "N" });
            allScores.Add(new ListItem() { Text = "1", Value = "S" });
            allScores.Add(new ListItem() { Text = "2", Value = "M" });
            allScores.Add(new ListItem() { Text = "3", Value = "A" });
            DropDownList_Scores.DataSource = allScores;
            DropDownList_Scores.DataBind();
        }

        #endregion

        #region DefaultSortExpression
        public override string DefaultSortExpression
        {
            get
            {
                return "Goal";
            }
        }
        #endregion

        #region Bind Grid
        public override System.Data.DataTable BindGrid()
        {

            using (SHS.UserBusinessServices.CoreCarePlan objectProgressPlan = new SHS.UserBusinessServices.CoreCarePlan())
            {
                DataSet dataSet = null;
                int clientId = -1;
                string startDate = null;
                string endDate = null;
                int reviewSource = -1;
                string CurrentObjectives = String.Empty;
                string scoreFromDate = null;
                string scoreToDate = null;
                int scores = -1;
                string goalObjective = "";
                int revieweBy = -1;
                int reviewStatus = -1;
                int otherFilter = -1;
                clientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;
                GetSelectedValueFromDropdown(DropDownList_ReviewSource, "ReviewSource", out reviewSource);
                GetSelectedValueFromDropdown(DropDownList_Scores, "Scores", out scores);
                GetSelectedValueFromDropdown(DropDownList_StaffName, "StaffName", out revieweBy);
                GetSelectedValueFromDropdown(DropDownList_ReviewStatus, "ReviewStatus", out reviewStatus);

                if (GetFilterValue("GoalObjective") != "")
                {
                    goalObjective = GetFilterValue("GoalObjective").Trim();
                }
                else
                {
                    goalObjective = TextBox_GoalObjective.Value;
                }
                if (GetFilterValue("ObjectivesProgressPlanHistoryStartDate") == "")
                {
                    startDate = null;
                }
                else
                {
                    startDate = GetFilterValue("ObjectivesProgressPlanHistoryStartDate");
                }
                if (GetFilterValue("ObjectivesProgressPlanHistoryEndDate") == "")
                {
                    endDate = null;
                }
                else
                {
                    endDate = GetFilterValue("ObjectivesProgressPlanHistoryEndDate");
                }
                if (GetFilterValue("ObjectivesProgressPlanHistoryScoreFromDate") == "")
                {
                    scoreFromDate = null;
                }
                else
                {
                    scoreFromDate = GetFilterValue("ObjectivesProgressPlanHistoryScoreFromDate");
                }
                if (GetFilterValue("ObjectivesProgressPlanHistoryScoreToDate") == "")
                {
                    scoreToDate = null;
                }
                else
                {
                    scoreToDate = GetFilterValue("ObjectivesProgressPlanHistoryScoreToDate");
                }
                if (GetFilterValue("CurrentObjectives") == "")
                {
                    CurrentObjectives = null;
                }
                else
                {
                    CurrentObjectives = GetFilterValue("CurrentObjectives");
                }
                dataSet = GetGridData(objectProgressPlan, clientId, startDate, endDate, reviewSource, CurrentObjectives, scoreFromDate, scoreToDate, scores, goalObjective, revieweBy, reviewStatus, otherFilter);

                if (dataSet != null)
                {
                    if (dataSet.Tables.Count > 0)
                    {
                        if (dataSet.Tables.Contains("CarePlanObjectiveHistory") == true)
                        {
                            lvObjectivesProgressPlanHistory.DataSource = dataSet.Tables["CarePlanObjectiveHistory"];
                            lvObjectivesProgressPlanHistory.DataBind();
                        }
                    }
                }

                return dataSet.Tables["TablePagingInformation"];
            }
        }

        private DataSet GetGridData(SHS.UserBusinessServices.CoreCarePlan objectProgressPlan,
          int clientId, string startDate, string endDate, int reviewSource, string currentObjects, string scoreFromDate, string scoreToDate, int scores, string goalObjective, int revieweBy
            , int reviewStatus, int otherFilter)
        {
            DataSet dataSet = null;

            int pageNumber = ParentPageListObject.CurrentPage;
            int pageSize = ParentPageListObject.PageSize == 0 ? 1 : ParentPageListObject.PageSize;
            string sortExpression = ParentPageListObject.SortExpression;

            dataSet = objectProgressPlan.GetObjectiveProgressPlanHistory(pageNumber, pageSize, sortExpression,
                                                                     clientId, startDate, endDate, reviewSource, currentObjects, scoreFromDate, scoreToDate, scores, goalObjective, revieweBy, reviewStatus, otherFilter);


            return dataSet;


        }
        #endregion

        #region Export
        public override DataTable GetExportDataSet()
        {
            DataSet dataSet = null;
            int clientId = -1;
            string startDate = null;
            string endDate = null;
            int reviewSource = -1;
            string CurrentObjectives = String.Empty;
            string scoreFromDate = null;
            string scoreToDate = null;
            int scores = -1;
            string goalObjective = "";
            int revieweBy = -1;
            int reviewStatus = -1;
            int otherFilter = -1;
            clientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

            startDate = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "ObjectivesProgressPlanHistoryStartDate", ParentPageObject.PageFiltersXML);
            endDate = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "ObjectivesProgressPlanHistoryEndDate", ParentPageObject.PageFiltersXML);
            reviewSource = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "ReviewSource", ParentPageObject.PageFiltersXML);
            CurrentObjectives = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "CurrentObjectives", ParentPageObject.PageFiltersXML);

            scoreFromDate = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "ObjectivesProgressPlanHistoryScoreFromDate", ParentPageObject.PageFiltersXML);
            scoreToDate = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "ObjectivesProgressPlanHistoryScoreToDate", ParentPageObject.PageFiltersXML);
            scores = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "Scores", ParentPageObject.PageFiltersXML);
            goalObjective = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "GoalObjective", ParentPageObject.PageFiltersXML);
            revieweBy = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "StaffName", ParentPageObject.PageFiltersXML);
            reviewStatus = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "ReviewStatus", ParentPageObject.PageFiltersXML);
            otherFilter = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "OtherFilter", ParentPageObject.PageFiltersXML);

            using (SHS.UserBusinessServices.CoreCarePlan objectProgressPlan = new SHS.UserBusinessServices.CoreCarePlan())
            {
                startDate = startDate == "" ? null : startDate;
                endDate = endDate == "" ? null : endDate;
                scoreFromDate = scoreFromDate == "" ? null : scoreFromDate;
                scoreToDate = scoreToDate == "" ? null : scoreToDate;
                CurrentObjectives = CurrentObjectives == "" ? "N" : CurrentObjectives;

                dataSet = GetGridData(objectProgressPlan, clientId, startDate, endDate, reviewSource, CurrentObjectives,
                    scoreFromDate, scoreToDate, scores, goalObjective, revieweBy, reviewStatus, otherFilter);
            }
            return dataSet.Tables["CarePlanObjectiveHistory"];
        }
        #endregion

        #region Common Methods
        private void GetSelectedValueFromDropdown(DropDownList dropDown, string key, out int value)
        {
            if (dropDown.Items.Count > 0)
            {
                int.TryParse(GetFilterValue(key, dropDown.SelectedItem.Value.ToString()), out value);
            }
            else
            {
                int.TryParse(GetFilterValue(key), out value);
            }
        }
        protected void LayoutCreated(object sender, EventArgs e)
        {
            var SortExpression = ParentPageListObject.SortExpression;
            string[] Sort = SortExpression.Split(' ');

            Panel divHeader = (Panel)lvObjectivesProgressPlanHistory.FindControl("divHeader");
            foreach (Control ctrl in divHeader.Controls)
            {
                if (ctrl.GetType() == typeof(Panel))
                {
                    string SortId = ((Panel)ctrl).Attributes["SortId"];
                    if (SortId != null)
                    {
                        ((Panel)ctrl).Attributes.Add("onclick", "SortListPage(" + ParentPageListObject.ScreenId.ToString() + ",'" + SortId + "');");
                        if (Sort.Count() > 0)
                        {
                            if (Sort[0] == SortId)
                            {
                                if (Sort.Count() == 1)
                                {
                                    ((Panel)ctrl).CssClass = "SortUp";
                                }
                                else
                                {
                                    ((Panel)ctrl).CssClass = "SortDown";
                                }
                            }
                        }

                    }
                }
            }
            Panel divContent = (Panel)lvObjectivesProgressPlanHistory.FindControl("divListPageContent");
            divContent.Attributes.Add("onscroll", "fnScroll('#" + divHeader.ClientID + "','#" + divContent.ClientID + "');");
        }
        #endregion
    }
}