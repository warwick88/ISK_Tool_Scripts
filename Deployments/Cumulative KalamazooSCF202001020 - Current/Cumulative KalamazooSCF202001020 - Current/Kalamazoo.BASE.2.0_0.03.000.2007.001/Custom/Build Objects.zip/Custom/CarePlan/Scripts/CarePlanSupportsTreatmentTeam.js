﻿//Description: Open CarePlan Add Treatment Team Pop Up
var PopUpScreenId = 0;
PopUpScreenId = $('[id$=HiddenFieldPopUpScreenId]').val();
if (PopUpScreenId) PopUpScreenId = parseInt(PopUpScreenId); else PopUpScreenId = 0;

var MainScreenId = 0;
MainScreenId = $('[id$=HiddenFieldMainScreenId]').val();
if (MainScreenId) MainScreenId = parseInt(MainScreenId); else MainScreenId = 0;

function OpenModelDialogueforAddTreatmentTeam(CarePlanTeamId) {
    var actionName = "treatmentteam"; 
    var PopUpScreenId = 0;
    PopUpScreenId = $('[id$=HiddenFieldPopUpScreenId]').val();
    if (PopUpScreenId) PopUpScreenId = parseInt(PopUpScreenId); else PopUpScreenId = 0;
    if (PopUpScreenId > 0) {
        OpenPage(5765, PopUpScreenId, "PopUpAction=" + actionName + "^CarePlanTeamId=" + CarePlanTeamId, null, GetRelativePath(), 'T', "dialogHeight: 220px; dialogWidth: 600px;dialogTitle:Add Needs");
    }
}

//Purpose: Bind Treatment Team Section Template by JsonSerializer
function FillTreatmentTeamTemplate() {
    var TreatmentTeamData = "";
    var TreatmentTeamString = "";
    TreatmentTeamData = $('[id$=HiddenFieldTreatmentTeam]').val();
    TreatmentTeamString = eval('(' + TreatmentTeamData + ')');
    if (TreatmentTeamData.length > 0) {
        $("#DivTreatmentTeamTemplate").html('');
        $("#TreatmentTeamScript").tmpl(TreatmentTeamString.objectListTreatmentTeamData).appendTo("#DivTreatmentTeamTemplate");
    }

    ShowHideEntireCarePlanOptions();
    $('input[name=Radio_DocumentCarePlans_ReviewEntireCareType]').unbind('click').bind('click', function () { ReviewDatesRadioSelection(this); });
}

//Enable/Disable and initialize the value from addendum
function SetReviewDateSection() {
   
    if ($('input[id=RadioButton_DocumentCarePlans_CarePlanType_A]').is(':checked')) {
        $('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').attr('disabled', 'disabled');
        //  $('input[id=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').attr("disabled", "disabled");
        $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_D]').attr("disabled", "disabled");
        $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_S]').attr("disabled", "disabled");
        if ($('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_D]').attr("checked") == true) {
            if (!$('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').val() == "")
                $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').attr("disabled", "disabled");
            else
                $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').attr("disabled", "");
        }
        else
            $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').attr("disabled", "disabled");
    }
    else {
        ShowHideEntireCarePlanOptions();
    }
}

function SetReviewBasedonType(dom) {
  
    if (dom[0].childNodes[0].selectNodes("DocumentCarePlans").length > 0) {
        var xmlDocumentsRow = dom[0].childNodes[0].selectNodes("DocumentCarePlans");
        _hrmAssessmentDocumentId = parseInt(xmlDocumentsRow[0].selectNodes("DocumentVersionId")[0].text.trim());
    }
    if (!(_hrmAssessmentDocumentId > 0)) {
        var rewtype = $('[id$=HiddenField_ReviewEntireCareType]').val();
        var rewdate = $('[id$=HiddenField_ReviewEntireCarePlanDate]').val();
        var rewplan = $('[id$=HiddenField_ReviewEntireCarePlan]').val();
        if ($('input[id=RadioButton_DocumentCarePlans_CarePlanType_A]').is(':checked')) {
            if (rewtype == "D") {
                $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_D]').attr("checked", "checked");
                $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_S]').removeAttr('checked');
                $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').val(rewdate);
                $('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').val('-1');

            }
            else {
                $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').val('');
                $('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').val(rewplan);
                $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_S]').attr("checked", "checked");
                $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_D]').removeAttr('checked');

            }
        }
        else {
            $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').val('');
            $('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').val('-1');
            $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_S]').attr("checked", "checked");
            $('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_D]').removeAttr('checked');
        }
        //SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCarePlanDate', $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').val(), AutoSaveXMLDom[0]);
        //SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCarePlan', $('[id=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').val(), AutoSaveXMLDom[0]);
        if ($('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_S]').attr("checked") == true) {
            SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCareType', 'S', AutoSaveXMLDom[0]);
            if ($('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').length > 0) {
                SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCarePlan', $('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]').val(), AutoSaveXMLDom[0]);
            }
            SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCarePlanDate', '', AutoSaveXMLDom[0]);

        }
        else if ($('input[id=Radio_DocumentCarePlans_ReviewEntireCareType_D]').attr("checked") == true) {
            SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCareType', 'D', AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCarePlanDate', $('input[id=TextBox_DocumentCarePlans_ReviewEntireCarePlanDate]').val(), AutoSaveXMLDom[0]);
            SetColumnValueInXMLNodeByKeyValue('DocumentCarePlans', 'DocumentVersionId', _hrmAssessmentDocumentId, 'ReviewEntireCarePlan', '', AutoSaveXMLDom[0]);

        }
        SetReviewDateSection();
    }
}

//Purpose : To refresh Support/Treatment Team tab data on Add Or Edit
function RefreshTreatmentTeamTemplate(response) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";
    var splitResponse = "";
    var primaryKey = "";
    var fieldValue = "";

    if (response.indexOf("###StartAddEditTreatmentTeam###") >= 0) {
        startIndex = response.indexOf("###StartAddEditTreatmentTeam###") + 31;
        endIndex = response.indexOf("###EndAddEditTreatmentTeam###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        AppendNewTreatmentTeam(outputHTML);
        CreateUnsavedInstanceOnDatasetChange();
    }
    else if (response.indexOf("###StartDeleteTreatmentTeam###") >= 0) {
        startIndex = response.indexOf("###StartDeleteTreatmentTeam###") + 30;
        endIndex = response.indexOf("###EndDeleteTreatmentTeam###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        if (outputHTML.indexOf("CarePlanTeamId=") >= 0) {
            CreateUnsavedInstanceOnDatasetChange();
            var CarePlanTeamIdToDelete = outputHTML.substr(outputHTML.indexOf("CarePlanTeamId=") + 15);
            $("tr#TRTreatmentTeam_" + CarePlanTeamIdToDelete).remove();
            $("tr#TRTreatmentTeam_Top_" + CarePlanTeamIdToDelete).remove();
            $("tr#TRTreatmentTeam_Bottom_" + CarePlanTeamIdToDelete).remove();
        }
    }
}

//Purpose :Append New Treatment Team
function AppendNewTreatmentTeam(outputHTML) {
    var TreatmentTeamData = "";
    var TreatmentTeamString = "";
    TreatmentTeamData = outputHTML;
    TreatmentTeamString = eval('(' + TreatmentTeamData + ')');
    
    if (TreatmentTeamData.length > 0) {
        var CarePlanProgramId = TreatmentTeamString.objectListTreatmentTeamData[0].CarePlanProgramId;
        RemoveDeletedXMLNode("CarePlanPrograms", "CarePlanProgramId", CarePlanProgramId);
        AppendNewRowTOAutoSaveXML(decodeText(TreatmentTeamString.objectListTreatmentTeamData[0].RowXML));
        if ($('tr#TRTreatmentTeam_' + CarePlanProgramId).length > 0) {
            $('tr#TRTreatmentTeam_' + CarePlanProgramId).html('');

            $('tr#TRTreatmentTeam_' + CarePlanProgramId).html($("#TreatmentTeamScript").tmpl(TreatmentTeamString.objectListTreatmentTeamData)[2].innerHTML);
        }
        else {
            $("#TreatmentTeamScript").tmpl(TreatmentTeamString.objectListTreatmentTeamData).appendTo("#DivTreatmentTeamTemplate");
        }
    }
}

//Purpose   : Set Delete Treatment Team Value OnChange Event
function SetDeleteTreatmentTeam(sender, CarePlanTeamId) {
    if (isInteger($(sender).val()) == false) {
        RemoveDeletedXMLNode("CarePlanPrograms", "CarePlanProgramId", CarePlanTeamId);
        var data = 'CustomAction=DeleteTreatmentTeam^CarePlanTeamId=' + CarePlanTeamId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
        var MainScreenId = 0;
        MainScreenId = $('[id$=HiddenFieldMainScreenId]').val();
        if (MainScreenId) MainScreenId = parseInt(MainScreenId); else MainScreenId = 0;
        if (MainScreenId > 0) {
            OpenPage(5763, MainScreenId, data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
        }
    }
}

//Purpose   : Set Edit Treatment Team Value OnChange Event
function SetEditTreatmentTeam(sender, CarePlanTeamId, ProgramId, StaffId, AssignForContribution) {
    if (isInteger($(sender).val()) == false) {
        var actionName = "treatmentteam";
        var PopUpScreenId = 0;
        PopUpScreenId = $('[id$=HiddenFieldPopUpScreenId]').val();
        if (PopUpScreenId) PopUpScreenId = parseInt(PopUpScreenId); else PopUpScreenId = 0;
        if (PopUpScreenId > 0) {
            OpenPage(5765, PopUpScreenId, "PopUpAction=" + actionName + "^CarePlanTeamId=" + CarePlanTeamId + "^ProgramId=" + ProgramId + "^StaffId=" + StaffId + "^AssignForContribution=" + AssignForContribution + "^flagValueForEdit=Y", null, GetRelativePath(), 'T', "dialogHeight: 220px; dialogWidth: 600px;dialogTitle:Add Treatment Team");
        }
    }
}


//Description: Add and Edit TreatmentTeam
function SetValueTreatmentTeam(ctrl) {
    var test = $('[id$=' + ctrl + ']').id;
    var nameArray = ctrl.id.split("_");
    if (nameArray.length > 0) {
        var columnname = nameArray[nameArray.length - 2];
        var primaryKeyValue = nameArray[nameArray.length - 1];
        var sourceFieldNewValue = GetControlValue(ctrl, undefined);
        SetColumnValueInXMLNodeByKeyValue("CarePlanPrograms", "CarePlanProgramId", primaryKeyValue, columnname, sourceFieldNewValue, AutoSaveXMLDom[0]);
        var data = 'CustomAction=UpdateTreatmentTeamFieldValue^ColumnName=' + columnname + '^PrimaryKeyValue=' + primaryKeyValue + "^SourceFieldNewValue=" + sourceFieldNewValue + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
        var MainScreenId = 0;
        MainScreenId = $('[id$=HiddenFieldMainScreenId]').val();
        if (MainScreenId) MainScreenId = parseInt(MainScreenId); else MainScreenId = 0;
        if (MainScreenId > 0)
            OpenPage(5763, MainScreenId, data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    }
}

//Description: Handle Callback for Non-Author Staff saving the Care Plan, If so we need an insert record in table CarePlanPrograms
function ProcessResponseOfTreatmentTeamForNonAuthorStaff(response) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";

    if (response.indexOf("###StartCheckNonAuthorStaffPrograms###") >= 0) {
        startIndex = response.indexOf("###StartCheckNonAuthorStaffPrograms###") + 38;
        endIndex = response.indexOf("###EndCheckNonAuthorStaffPrograms###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);

        if (parseInt(outputHTML) > 1) {
            OpenModelDialogueforAddProgramInTreatmentTeam();
        }
        else if (outputHTML == "1" || outputHTML == "0") {
            nonAuthorLogInProcessDone = true;
            SavePageData(undefined);
        }

    }
    else if (response.indexOf("###StartAddNewTreatmentTeamMember###") >= 0) {
        startIndex = response.indexOf("###StartAddNewTreatmentTeamMember###") + 36;
        endIndex = response.indexOf("###EndAddNewTreatmentTeamMember###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        if (outputHTML == "AddNewTreatmentTeamMember") {
            nonAuthorLogInProcessDone = true;
            SavePageData(undefined);
        }
    }
}


//Description: Open CarePlan Add Treatment Team Pop Up when Non-author saving Care Plan document
function OpenModelDialogueforAddProgramInTreatmentTeam() {
    
    var actionName = "addtreatmenteammember";
    var PopUpScreenId = 0;
    PopUpScreenId = $('[id$=HiddenFieldPopUpScreenId]').val();
    if (PopUpScreenId) PopUpScreenId = parseInt(PopUpScreenId); else PopUpScreenId = 0;
    if (PopUpScreenId > 0) {
        OpenPage(5765, PopUpScreenId, "PopUpAction=" + actionName, null, GetRelativePath(), 'T', "dialogHeight: 150px; dialogWidth: 450px;dialogTitle:Add Treatment Team Member");
    }
}

function ReviewDatesRadioSelection(obj) {
   
    var radioValue=$(obj).val();    
    if (radioValue) {
        var $ddReviewEntireCarePlan = $('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]');
        var $textboxReviewCarePlanDate = $('#TextBox_DocumentCarePlans_ReviewEntireCarePlanDate');
        if (radioValue == "S") {
            $textboxReviewCarePlanDate.attr('disabled', 'disabled');
            $textboxReviewCarePlanDate.val("");
            $ddReviewEntireCarePlan.removeAttr('disabled');
            $ddReviewEntireCarePlan.val("");
            CreateAutoSaveXml("DocumentCarePlans", "ReviewEntireCarePlanDate", "");
        }
        else if (radioValue == "D") {
            $textboxReviewCarePlanDate.removeAttr('disabled');
            $ddReviewEntireCarePlan.attr('disabled', 'disabled');
            $ddReviewEntireCarePlan.val("");
            CreateAutoSaveXml("DocumentCarePlans", "ReviewEntireCarePlan", "");
        }
    }
}
function ShowHideEntireCarePlanOptions() {
    var $radioReviewEntireCarePlan = $('input[name=Radio_DocumentCarePlans_ReviewEntireCareType]:checked');
    var radioValue = $radioReviewEntireCarePlan.val();
    var $ddReviewEntireCarePlan = $('[id$=DropDownList_DocumentCarePlans_ReviewEntireCarePlan]');
    var $textboxReviewCarePlanDate = $('#TextBox_DocumentCarePlans_ReviewEntireCarePlanDate');

    if (radioValue == "S") {
        $textboxReviewCarePlanDate.attr('disabled', 'disabled');
        $ddReviewEntireCarePlan.removeAttr('disabled');
    }
    else if (radioValue == "D") {
        $textboxReviewCarePlanDate.removeAttr('disabled');
        $ddReviewEntireCarePlan.attr('disabled', 'disabled');
    }
}