﻿//Purpose : Show Hide TextArea  on Page Load
function ShowHideTextArea(dom, CarePlanTabPageInstance) {
    var ReductionInSymptoms = $('DocumentCarePlans ReductionInSymptoms', dom);
    var AttainmentOfHigherFunctioning = $('DocumentCarePlans AttainmentOfHigherFunctioning', dom);
    var TreatmentNotNecessary = $('DocumentCarePlans TreatmentNotNecessary', dom);
    var OtherTransitionCriteria = $('DocumentCarePlans OtherTransitionCriteria', dom);

    var $ReductionInSymptomsDescriptionObject = $("#TextArea_DocumentCarePlans_ReductionInSymptomsDescription");
    var $AttainmentOfHigherFunctioningDescriptionObject = $("#TextArea_DocumentCarePlans_AttainmentOfHigherFunctioningDescription");
    var $TreatmentNotNecessaryDescriptionObject = $("#TextArea_DocumentCarePlans_TreatmentNotNecessaryDescription");
    var $OtherTransitionCriteriaDescriptionObject = $("#TextArea_DocumentCarePlans_OtherTransitionCriteriaDescription");


    if (ReductionInSymptoms.length > 0 && $ReductionInSymptomsDescriptionObject.length > 0) {
        if (ReductionInSymptoms.text() == 'Y') {
            $ReductionInSymptomsDescriptionObject.show();
        }
        else if (ReductionInSymptoms.text() == 'N') {
            $ReductionInSymptomsDescriptionObject.hide();
        }
    }
    else {
        $ReductionInSymptomsDescriptionObject.hide();
    }
    if (AttainmentOfHigherFunctioning.length > 0 && $AttainmentOfHigherFunctioningDescriptionObject.length > 0) {
        if (AttainmentOfHigherFunctioning.text() == 'Y') {
            $AttainmentOfHigherFunctioningDescriptionObject.show();
        }
        else if (AttainmentOfHigherFunctioning.text() == 'N') {
        $AttainmentOfHigherFunctioningDescriptionObject.hide();
        }
    }
    else {
        $AttainmentOfHigherFunctioningDescriptionObject.hide();
    }
    if (TreatmentNotNecessary.length > 0 && $TreatmentNotNecessaryDescriptionObject.length > 0) {
        if (TreatmentNotNecessary.text() == 'Y' ) {
            $TreatmentNotNecessaryDescriptionObject.show();
        }
        else if (TreatmentNotNecessary.text() == 'N') {
        $TreatmentNotNecessaryDescriptionObject.hide();
        }
    }
    else {
        $TreatmentNotNecessaryDescriptionObject.hide();

    }
    if (OtherTransitionCriteria.length > 0 && $OtherTransitionCriteriaDescriptionObject.length > 0) {
        if (OtherTransitionCriteria.text() == 'Y' ) {
            $OtherTransitionCriteriaDescriptionObject.show();
        }
        if (OtherTransitionCriteria.text() == 'N') {
            $OtherTransitionCriteriaDescriptionObject.hide();
        }
    }
    else {
        $OtherTransitionCriteriaDescriptionObject.hide();
    }

    var carePlanIntitalized = $('DocumentCarePlans CarePlanType', dom).text();
    if (carePlanIntitalized == "IN") {
        var CarePlanType_I = $("input[id$=RadioButton_DocumentCarePlans_CarePlanType_I]");
        $(CarePlanType_I).attr('checked', true);
    }
    //What: Added code to show hide the text area as per CarePlanType
    var SystemKeyValue = $('[id$=HiddenField_ReviewSettngs]').val();
    if (SystemKeyValue == "Y") {
        //What: Added code to show hide the text area as per CarePlanType
        var CarePlanTypeText = $('DocumentCarePlans PreviousCP', dom);
        var $CarePlanAddendumInfo = $("#TextArea_DocumentCarePlans_CarePlanAddendumInfo");
        var CarePlanType_A = $("input[id$=RadioButton_DocumentCarePlans_CarePlanType_A]");
        var CarePlanType_R = $("input[id$=RadioButton_DocumentCarePlans_CarePlanType_R]");
        $CarePlanAddendumInfo.hide();
        if (CarePlanTypeText.length > 0) {
            if (CarePlanTypeText.text() == 'Y') {
                CarePlanType_A.removeAttr("disabled");
                CarePlanType_R.removeAttr("disabled");
            }
            else {
                CarePlanType_A.attr("disabled", "disabled");
                CarePlanType_R.attr("disabled", "disabled");
            }

        }
        else {
            $CarePlanAddendumInfo.hide();
        }
      
    }
    else {
        var CarePlanTypeText = $('DocumentCarePlans CarePlanType', dom);
        var $CarePlanAddendumInfo = $("#TextArea_DocumentCarePlans_CarePlanAddendumInfo");
        var CarePlanType_A = $("input[id$=RadioButton_DocumentCarePlans_CarePlanType_A]");
        $CarePlanAddendumInfo.hide();

        var carePlanIntitalized = $('DocumentCarePlans CarePlanType', dom).text();
        if (carePlanIntitalized == "IN") {
            var CarePlanType_I = $("input[id$=RadioButton_DocumentCarePlans_CarePlanType_I]");
            $(CarePlanType_I).attr('checked', true);
        }

        if (CarePlanTypeText.length > 0) {
            if (CarePlanTypeText.text() == 'AD') {
                CarePlanType_A.removeAttr("disabled");
                $CarePlanAddendumInfo.show();
            }
            else if (CarePlanTypeText.text() == 'IN') {
                $CarePlanAddendumInfo.hide();
                CarePlanType_A.attr("disabled", "disabled");
            }
            else {
                $CarePlanAddendumInfo.hide();
            }
        }
        else {
            $CarePlanAddendumInfo.hide();
        }
    }
}

//Description:Enabling and disabling the  TextArea 
function EnableDisableTextArea(obj) {
    if (obj.id.toString() == 'CheckBox_DocumentCarePlans_ReductionInSymptoms') {
        var $ReductionInSymptomsDescriptionObject = $("#TextArea_DocumentCarePlans_ReductionInSymptomsDescription");
        if ($ReductionInSymptomsDescriptionObject.length > 0) {
            if ($(obj).is(':checked')) {
                $ReductionInSymptomsDescriptionObject.show();
            }
            else {
                $ReductionInSymptomsDescriptionObject.val("");
                $ReductionInSymptomsDescriptionObject.hide();
            }
        }
    }
    else if (obj.id.toString() == 'CheckBox_DocumentCarePlans_AttainmentOfHigherFunctioning') {
        var $AttainmentOfHigherFunctioningDescriptionObject = $("#TextArea_DocumentCarePlans_AttainmentOfHigherFunctioningDescription");
        if ($AttainmentOfHigherFunctioningDescriptionObject.length > 0) {
            if ($(obj).is(':checked')) {
                $AttainmentOfHigherFunctioningDescriptionObject.show();
            }
            else {
                $AttainmentOfHigherFunctioningDescriptionObject.val("");
                $AttainmentOfHigherFunctioningDescriptionObject.hide();
            }
        }
    }
    else if (obj.id.toString() == 'CheckBox_DocumentCarePlans_TreatmentNotNecessary') {
        var $TreatmentNotNecessaryDescriptionObject = $("#TextArea_DocumentCarePlans_TreatmentNotNecessaryDescription");
        if ($TreatmentNotNecessaryDescriptionObject.length > 0) {
            if ($(obj).is(':checked')) {
                $TreatmentNotNecessaryDescriptionObject.show();
            }
            else {
                $TreatmentNotNecessaryDescriptionObject.val("");
                $TreatmentNotNecessaryDescriptionObject.hide();
            }
        }
    }
    else if (obj.id.toString() == 'CheckBox_DocumentCarePlans_OtherTransitionCriteria') {
        var $OtherTransitionCriteriaDescriptionObject = $("#TextArea_DocumentCarePlans_OtherTransitionCriteriaDescription");
        if ($OtherTransitionCriteriaDescriptionObject.length > 0) {
            if ($(obj).is(':checked')) {
                $OtherTransitionCriteriaDescriptionObject.show();
            }
            else {
                $OtherTransitionCriteriaDescriptionObject.val("");
                $OtherTransitionCriteriaDescriptionObject.hide();
            }
        }
    }
    else if (obj.id.toString() == 'RadioButton_DocumentCarePlans_CarePlanType_I') {
        if ($(obj).is(':checked')) {
            var $CarePlanAddendumInfo = $("#TextArea_DocumentCarePlans_CarePlanAddendumInfo");
            var $CarePlanStrength = $("#TextArea_DocumentCarePlans_Strengths");
            var $CarePlanBarriers = $("#TextArea_DocumentCarePlans_Barriers");
            var $CarePlanAbilities = $("#TextArea_DocumentCarePlans_Abilities");            
            $CarePlanStrength.val('');
            $CarePlanBarriers.val('');
            $CarePlanAbilities.val('');
            CreateAutoSaveXml('DocumentCarePlans', 'Strengths', '');
            CreateAutoSaveXml('DocumentCarePlans', 'Barriers', '');
            CreateAutoSaveXml('DocumentCarePlans', 'Abilities', '');
            $CarePlanAddendumInfo.hide();
        }
    }
    else if (obj.id.toString() == 'RadioButton_DocumentCarePlans_CarePlanType_A') {
        if ($(obj).is(':checked')) {
            var SystemKeyValue = $('[id$=HiddenField_ReviewSettngs]').val();
            var $CarePlanAddendumInfo = $("#TextArea_DocumentCarePlans_CarePlanAddendumInfo");
            if (SystemKeyValue == "Y")
                $CarePlanAddendumInfo.hide();
            else
                $CarePlanAddendumInfo.show();
        }
    }
    else if (obj.id.toString() == 'RadioButton_DocumentCarePlans_CarePlanType_R') {
        if ($(obj).is(':checked')) {
            var $CarePlanAddendumInfo = $("#TextArea_DocumentCarePlans_CarePlanAddendumInfo");
            $CarePlanAddendumInfo.hide();
        }
    }
}


function RefreshAssessmentlevel() {
    try {
        PopupProcessing();
        var Effectivedate = $('#TextBox_DocumentInformation_EffectiveDate').val();
        $.ajax({
            type: "POST",
            url: "../Modules/CarePlan/CarePlan.aspx?functionName=refreshassessmentlevel",
            data: 'EffectiveDate=' + Effectivedate,
            success: function (result) {
                onSuccessRefreshAssessmentlevel(result);
                HidePopupProcessing();
            },
            error: function (request, status, err) {
                HidePopupProcessing();
                LogClientSideException(err, 'Careplan - RefreshAssessmentlevel');
            }
        });
        return false;
    }
    catch (ex) { return false }
}

function onSuccessRefreshAssessmentlevel(result) {
    if (result != "") {
        if (result == "No ANSA Document") {
            ShowMsgBox("ANSA document is not available.", 'Information', MessageBoxButton.OK, MessageBoxIcon.Information);
        }
        else {
            var mhassessmentlevelofcare = GetFielValueFromXMLDom(AutoSaveXMLDom, "DocumentCarePlans", "MHAssessmentLevelOfCare");
            var ASAMLevelOfCare = GetFielValueFromXMLDom(AutoSaveXMLDom, "DocumentCarePlans", "ASAMLevelOfCare");

            var TreatmentPlanValue = $('DocumentCarePlans > MHAssessmentLevelOfCare', AutoSaveXMLDom).text();
            var TreatmentPlanASAMLevelOfCareValue = $('DocumentCarePlans > ASAMLevelOfCare', AutoSaveXMLDom).text();

            var resultset = result.split("@$$@");

            var DocumentVersionId = AutoSaveXMLDom.find("DocumentCarePlans:first DocumentVersionId").text();

            if (resultset[0] != "") {
                if (mhassessmentlevelofcare != "") {

                    SetColumnValueInXMLNodeByKeyValue("DocumentCarePlans", "DocumentVersionId", DocumentVersionId, "MHAssessmentLevelOfCare", resultset[0], AutoSaveXMLDom[0]);
                }
                else {
                    CreateAutoSaveXml('DocumentCarePlans', 'MHAssessmentLevelOfCare', resultset[0]);
                }

                $('[id=Span_DocumentCarePlans_MHAssessmentLevelOfCare]')[0].innerHTML = resultset[0];
            }

            if (resultset[1] != "") {
                if (ASAMLevelOfCare != "") {
                    SetColumnValueInXMLNodeByKeyValue("DocumentCarePlans", "DocumentVersionId", DocumentVersionId, "ASAMLevelOfCare", resultset[1], AutoSaveXMLDom[0]);
                }
                else {
                    CreateAutoSaveXml('DocumentCarePlans', 'ASAMLevelOfCare', resultset[1]);
                }

                $('[id=Span_DocumentCarePlans_ASAMLevelOfCare]')[0].innerHTML = resultset[1];
            }

            if (resultset[0] != "" || resultset[1] != "") {
                CreateUnsavedInstanceOnDatasetChange();
            }
        }
    }
}

function addIntervention(dom) {
    var _PKCarePlanPrescribedServiceId = 0;
    AutoSaveXMLDom.find("CustomCarePlanPrescribedServices").each(function () {
        $(this).children().each(function () {
            if (this.tagName == "CarePlanPrescribedServiceId") {
                if (parseInt($(this).text()) < 0 && _PKCarePlanPrescribedServiceId <= 0 && _PKCarePlanPrescribedServiceId > parseInt($(this).text())) {
                    _PKCarePlanPrescribedServiceId = parseInt($(this).text());
                }
            }
        });
    });

    if (_PKCarePlanPrescribedServiceId == 0)
        _PKCarePlanPrescribedServiceId = -1
    else
        _PKCarePlanPrescribedServiceId = _PKCarePlanPrescribedServiceId + (-1);

    var _CarePlanPrescribedServiceId;
    var _createdby;
    var _createddate;
    var _modifiedby;
    var _modifieddate;
    var DocumentVersionId;

    var _xmltable = AutoSaveXMLDom[0].childNodes[0].appendChild(AutoSaveXMLDom[0].createElement('CustomCarePlanPrescribedServices')); //Add Table
    _CarePlanPrescribedServiceId = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CarePlanPrescribedServiceId')); //Add Column
    _CarePlanPrescribedServiceId.text = _PKCarePlanPrescribedServiceId;

    _createdby = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedBy')); //Add Column
    _createdby.text = objectPageResponse.LoggedInUserCode;

    _createddate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('CreatedDate')); //Add Column
    _createddate.text = MIDDateString(new Date());

    _modifiedby = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedBy')); //Add Column
    _modifiedby.text = objectPageResponse.LoggedInUserCode;

    _modifieddate = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('ModifiedDate')); //Add Column
    _modifieddate.text = MIDDateString(new Date());

    _DocumentVersionId = _xmltable.appendChild(AutoSaveXMLDom[0].createElement('DocumentVersionId')); //Add Column
    _DocumentVersionId.text = "2012651";

    

    var CarePlanPrescribedServiceNumber = ($('.THnumber').length + 1);

    var data = '[{"CarePlanPrescribedServiceId":' + _PKCarePlanPrescribedServiceId + ',"DocumentVersionId":' + 2012651 + ',"ProviderId":"","AuthorizationCodeId":"","FromDate":"","ToDate":"","Units":"","Frequency":"","PersonResponsible":"","CarePlanPrescribedServiceNumber":"' + CarePlanPrescribedServiceNumber + '"}]';
    if (data != "") {
        if (typeof checkjsonstring == 'function') {
            if (checkjsonstring(data) == true) {
                var objTreatmentHistory = $.parseJSON(data);
                if (objTreatmentHistory.length > 0) {
                    if ($('#divIntervention').length > 0) {
                        $('#divIntervention').append($.render.treatmentHistory(objTreatmentHistory));
                    }
                }
            }
        }
    }


    CreateUnsavedInstanceOnDatasetChange();
    AddToUnsavedTables("CustomCarePlanPrescribedServices");
}

function MIDDateString(dateIn) {
    var d;
    if ((typeof (dateIn) === 'date') ? true : (typeof (dateIn) === 'object') ? dateIn.constructor.toString().match(/date/i) !== null : false) {
        d = dateIn;
    } else {
        d = new Date(dateIn);
    }
    function pad(n) {
        n = parseInt(n, 10);
        return n < 10 ? '0' + n : n;
    }
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' +
        pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function checkjsonstring(str) {
    try {
        var json = JSON.parse(str);//(str);
        return true;
    }
    catch (err) {
        return false;
    }
}

function Renderdata() {
    $.templates({
        treatmentHistory: {
            markup: '#InterventionSection',
            helpers: {
                GetDropDownListHTML: function (selectedID, mode) {
                    var resultHTML = "";
                    if (mode == 'ProviderId') {
                        $('[id$=dropdownListinterVentionProvider]').val(selectedID);
                        resultHTML = $('[id$=dropdownListinterVentionProvider]').html();
                    }
                    if (mode == 'FrequencyType') {
                        $('[id$=DropDownList_TPProcedures_FrequencyType]').val(selectedID);
                        resultHTML = $('[id$=DropDownList_TPProcedures_FrequencyType]').html();
                    }
                    if (mode == 'PersonResponsible') {
                        $('[id$=DropDownList_CarePlanPrescribedServices_PersonResponsible]').val(selectedID);
                        resultHTML = $('[id$=DropDownList_CarePlanPrescribedServices_PersonResponsible]').html();
                    }
                    if (mode == 'AuthorizationCodeId') {
                        $('[id$=DropDownList_CarePlanPrescribedServices_ServiceProvider]').val(selectedID);
                        resultHTML = $('[id$=DropDownList_CarePlanPrescribedServices_ServiceProvider]').html();
                       

                    }

                    return resultHTML;
                }
            }
        }
    });

    var data = $('[id$=divJsonInterventionSection]').html();
    if (data && data != "") {
        if (typeof checkjsonstring == 'function') {
            if (checkjsonstring(data) == true) {
                var objTreatmentHistory = $.parseJSON(data);
                if (objTreatmentHistory.length > 0) {
                    if ($('#divIntervention').length > 0) {
                        $('#divIntervention').append($.render.treatmentHistory(objTreatmentHistory));
                    }
                }
            }
        }
    }
}

function AddEventHandlers()
{
    Renderdata();
}