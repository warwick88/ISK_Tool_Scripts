﻿function BindDynamicCanvasJsGraph(ControlId, CarePlanDomainObjectiveId) {
    if (CarePlanDomainObjectiveId != '') {
        $("#div_MaingraphPlaceholder_" + CarePlanDomainObjectiveId).show();
    }
    else {
        $("#div_MaingraphPlaceholder_" + CarePlanDomainObjectiveId).hide();
    }

    var jsonObjOutcomeMeasure = [];

    var ProgressTowardsobjectListJSONData = $.parseJSON($('[id$=HiddenField_ProgressTowardsobjectListJSONData]').val());
    var yax = ['0', 'Deterioration', 'No Change', 'Some Improvement', 'Moderate Improvement', 'Achieved', ''];
    jQuery.each(ProgressTowardsobjectListJSONData, function (i, val) {
        jQuery.each(val, function (i, oval) {
            if (oval.CarePlanDomainObjectiveId == CarePlanDomainObjectiveId) {
                var OutcomeResult = oval.ProgressTowardsObjective.split(':');
                var OutcomeMeasureitem = { "label": OutcomeResult[0], "y": parseInt(OutcomeResult[1]) };
                jsonObjOutcomeMeasure.push(OutcomeMeasureitem);
            }
        });
    });

    if (jsonObjOutcomeMeasure.length <= 0) {
        $("#div_MaingraphPlaceholder_" + CarePlanDomainObjectiveId).hide();
    }
    var chart = new CanvasJS.Chart(ControlId, {
        title: {
            text: "Objective Progress"
        },
        axisY: {
            labelFormatter: function (e) {


                i = yax[e.value];

                return i;
            },
            maximum: 6,
            interval: 1,
            labelFontSize: 12,
            includeZero: false
        },
        axisX: {
            labelFontSize: 10
        },
        toolTip: {
            contentFormatter: function (e) {
                return e.entries[0].dataPoint.label + " : " + yax[e.entries[0].dataPoint.y];
            }
        },
        data: [{
            type: "line",
            axisXIndex: 0, //defaults to 0
            //showInLegend: true,
            //toolTipContent: "{label}",
            name: "CarePlanObjectiveId : " + (CarePlanDomainObjectiveId),
            dataPoints: jsonObjOutcomeMeasure
        }],
        legend: {
            cursor: "pointer",
            itemclick: function (e) {
                if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                    e.dataSeries.visible = false;
                }
                else {
                    e.dataSeries.visible = true;
                }
                chart.render();
            }
        }
    });
    chart.render();

}

function BindDynamicCanvasJsGraphMeasure(ControlId, CarePlanDomainObjectiveId, Measure) {
    if (CarePlanDomainObjectiveId != '') {
        $("#div_MaingraphPlaceholder_" + CarePlanDomainObjectiveId).show();
    }
    else {
        $("#div_MaingraphPlaceholder_" + CarePlanDomainObjectiveId).hide();
    }

    var jsonObjOutcomeMeasure = [];

    var ProgressTowardsobjectListJSONData = $.parseJSON($('[id$=HiddenField_ProgressTowardsobjectListJSONData]').val());
    var yax = ['0', 'Deterioration', 'No Change', 'Some Improvement', 'Moderate Improvement', 'Achieved', ''];

    jQuery.each(ProgressTowardsobjectListJSONData, function (i, val) {
        jQuery.each(val, function (i, oval) {
            if (oval.CarePlanDomainObjectiveId == Measure) {
                var OutcomeResult = oval.ProgressTowardsObjective.split(':');
                var OutcomeMeasureitem = { "label": OutcomeResult[0], "y": parseInt(OutcomeResult[1]) };
                jsonObjOutcomeMeasure.push(OutcomeMeasureitem);
            }
        });
    });

    if (jsonObjOutcomeMeasure.length <= 0) {
        $("#div_MaingraphPlaceholder_" + CarePlanDomainObjectiveId).hide();
    }
    var chart = new CanvasJS.Chart(ControlId, {
        title: {
            text: "Mastery Progression"
        },
        axisY: {
            //labelFormatter: function (e) {


            //    i = yax[e.value];

            //    return i;
            //},
            maximum: 8,
            interval: 1,
            labelFontSize: 12,
            includeZero: false
        },
        axisX: {
            labelFontSize: 10
        },
        toolTip: {
            contentFormatter: function (e) {
                return e.entries[0].dataPoint.label + " : " + e.entries[0].dataPoint.y;
            }
        },
        data: [{
            type: "line",
            axisXIndex: 0, //defaults to 0
            //showInLegend: true,
            //toolTipContent: "{label}",
            name: "CarePlanObjectiveId : " + (CarePlanDomainObjectiveId),
            dataPoints: jsonObjOutcomeMeasure
        }],
        legend: {
            cursor: "pointer",
            itemclick: function (e) {
                if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                    e.dataSeries.visible = false;
                }
                else {
                    e.dataSeries.visible = true;
                }
                chart.render();
            }
        }
    });
    chart.render();
}