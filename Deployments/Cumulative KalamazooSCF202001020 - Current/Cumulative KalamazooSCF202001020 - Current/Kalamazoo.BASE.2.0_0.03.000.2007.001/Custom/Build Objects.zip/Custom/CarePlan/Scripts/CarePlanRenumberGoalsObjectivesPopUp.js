﻿
//Purpose : Clear Goals/Objectives Tab HTML on tab click
function UpdateRenumberControl() {
    var controlCollection = "";
    var tableName = "";
    var keyFieldName = "";
    var strHTML = "";
    var myDate = new Date();
    tableName = $("input[id$=HiddenFieldTableName]").val();
    keyFieldName = $("input[id$=HiddenFieldKeyFieldName]").val();
    controlCollection = $("input[type='text'][@renumberText=renumberText]");
    if (controlCollection.length > 0) 
    {
        for (textBoxCount = 0; textBoxCount < controlCollection.length; textBoxCount++) {
            if (strHTML == "") {
                strHTML = $(controlCollection[textBoxCount]).attr("GoalId") + "$$" + controlCollection[textBoxCount].value;
            }
            else {
                strHTML = strHTML + "||" + $(controlCollection[textBoxCount]).attr("GoalId") + "$$" + controlCollection[textBoxCount].value;
            }
            if (tableName.toLowerCase() == "careplanobjectives") {
                parent.GetXMLParentNodeByColumnValue("CarePlanObjectives", "CarePlanObjectiveId", $(controlCollection[textBoxCount]).attr("GoalId"), parent.AutoSaveXMLDom).each(function () {
                    parent.SetColumnValueInXMLNodeByKeyValue("CarePlanObjectives", "CarePlanObjectiveId", $(this).find("CarePlanObjectiveId").text(), "ObjectiveNumber", controlCollection[textBoxCount].value, parent.AutoSaveXMLDom[0]);
                });
                parent.GetXMLParentNodeByColumnValue("CarePlanPrescribedServiceObjectives", "CarePlanObjectiveId", $(controlCollection[textBoxCount]).attr("GoalId"), parent.AutoSaveXMLDom).each(function () {
                    parent.SetColumnValueInXMLNodeByKeyValue("CarePlanObjectives", "CarePlanPrescribedServiceObjectiveId", $(this).find("CarePlanPrescribedServiceObjectiveId").text(), "ObjectiveNumber", controlCollection[textBoxCount].value, parent.AutoSaveXMLDom[0]);
                });
            }
            else if (tableName.toLowerCase() == "careplangoals") {
                parent.SetColumnValueInXMLNodeByKeyValue("CarePlanGoals", "CarePlanGoalId", $(controlCollection[textBoxCount]).attr("GoalId"), "GoalNumber", controlCollection[textBoxCount].value, parent.AutoSaveXMLDom[0]);
            }
        }
    }
    var data = 'CustomAction=RenumberCarePlanGoalObjectives^strHTML=' + strHTML + '^tableName=' + tableName + '^keyFieldName=' + keyFieldName + '^time=' + myDate.getMinutes() + myDate.getSeconds() + "^AutoSaveXML=" + encodeText(convert_accented_characters(parent.AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    parent.OpenPage(5763, 1077, data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
}


var CarePlanAlertCaption = 'Message';
//Purpose : Update Renumber Goal On "Save" button click
function RenumberGoal(control) {
    var tableName = "";
    if (control.value == "" || isNaN(control.value)) {
        ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        document.getElementById(control.id).value = $(control).attr('oldValue');
        return false;
    }
    else {
        var goalMaxValue = $("input[id$=HiddenFieldMaxNumber]");
        tableName = $("input[id$=HiddenFieldTableName]");
        if (tableName[0].value == "CarePlanGoals") {
            if (control.value <= 0) {
                ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                document.getElementById(control.id).value = $(control).attr('oldValue');
                return false;
            }
            else if ((parseInt(control.value) > 0) && (parseInt(control.value) > goalMaxValue.val())) {
                ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                document.getElementById(control.id).value = $(control).attr('oldValue');
                return false;
            }

        }
        else {
            if (control.value.indexOf(".") == -1) {
                if ((control.value.length) - (control.value.indexOf(".") + 1) > 2) {
                    ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    document.getElementById(control.id).value = $(control).attr('oldValue');
                    return false;
                }
                else if (control.value <= 0) {
                    ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    document.getElementById(control.id).value = $(control).attr('oldValue');
                    return false;
                }
            }
            else {
                if ((control.value.length) - (control.value.indexOf(".") + 1) > 2) {
                    ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    document.getElementById(control.id).value = $(control).attr('oldValue');
                    return false;
                }
                else if (control.value <= 0) {
                    ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    document.getElementById(control.id).value = $(control).attr('oldValue');
                    return false;
                }
                else if ((control.value > 0) && (control.value > goalMaxValue.val())) {
                    ShowMsgBox('Please enter a valid value.', CarePlanAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    document.getElementById(control.id).value = $(control).attr('oldValue');
                    return false;
                }
            }
        }
    }
    var controlCollection = "";
    if (tableName[0].value == "TPNeeds") {
        controlCollection = $("input[type='text'][@renumberText=renumberText][@oldvalue=" + parseInt(control.value) + "]");
    }
    else {
        controlCollection = $("input[renumberText=renumberText][value=" + control.value + "]");
    }
    if (controlCollection.length > 1) {
        var firstOldValue = $("#" + controlCollection[0].id + "").attr('oldValue');
        var firstControlValue = $("#" + controlCollection[0].id + "").val();

        $("#" + controlCollection[0].id + "").attr('oldValue', $("#" + controlCollection[1].id + "").attr('oldValue'));
        $("#" + controlCollection[0].id + "").val($("#" + controlCollection[1].id + "").attr('oldValue'));

        $("#" + controlCollection[1].id + "").attr('oldValue', firstOldValue);
        $("#" + controlCollection[1].id + "").val(firstOldValue);
    }
    if (controlCollection.length == 1) {
        $("#" + controlCollection[0].id + "").val($("#" + controlCollection[0].id + "").attr('oldValue'));
    }
}