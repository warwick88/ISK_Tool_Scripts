﻿//Purpose: Bind Prescribed Services Template by Json

//function HideShowInterventionsDuration() {
//    var InterventionsDurationData = "";
//    InterventionsDurationData = $('[id$=HiddenInterventionsDuration]').val();
//    if (InterventionsDurationData == "Y") {
//        $('[id*=Table_ServiceGroupNumber_]').show();
//        $('[id*=Table_ServiceGroupDuration_]').show();
//        $('[id*=Table_Tr_td_TimeAndDuration_]').width(25 + "%");
//        $("#InterventionsText").text('Time');

//    }
//    else {

//        $('[id*=InterventionsText_]').text('Duration');
//        $('[id*=Table_ServiceGroupNumber_]').hide();
//        $('[id*=Table_Tr_td_TimeAndDuration_]').width(1 + "%");
//        $('[id*=Table_ServiceGroupDuration_]').hide();
//    }
//}
function FillPrescribedServicesTabTemplate() {
    var PrescribedServicesData = "";
    var PrescribedServicesDataString = "";

    PrescribedServicesData = $('[id$=HiddenFieldPrescribedServices]').val();
    PrescribedServicesDataString = eval('(' + PrescribedServicesData + ')');
    if (PrescribedServicesData.length > 0) {
        $("#divIntervention").html('');
        $("#InterventionSection").tmpl(PrescribedServicesDataString.objectListPrescribedServices).appendTo("divIntervention");
    }
    AttachPrescribedServicesOnBlurEvents(true);    
}

//Purpose: Bind DropDownList in Prescribed Services Template
function GetDropDownHtmlPlanPrescribedServices(DropDownType, PrescribedServiceId, DropDownValue) {

    if (DropDownType == "ProviderId") {
        if (DropDownValue == "" || DropDownValue == undefined) {
            $("select[id$=DropDownList_CarePlanPrescribedServices_ProviderId]").val("");
        }
        else {
            $("select[id$=DropDownList_CarePlanPrescribedServices_ProviderId]").val(DropDownValue);
        }
        return $('select[id$=DropDownList_CarePlanPrescribedServices_ProviderId]').html();
    }

    if (DropDownType == "FrequencyType") {
        if (DropDownValue == "" || DropDownValue == undefined) {
            $("select[id$=DropDownList_TPProcedures_FrequencyType]").val("");
        }
        else {
            $("select[id$=DropDownList_TPProcedures_FrequencyType]").val(DropDownValue);
        }
        return $('select[id$=DropDownList_TPProcedures_FrequencyType]').html();
    }
    else if (DropDownType == "PersonResponsible") {
        if (DropDownValue == "" || DropDownValue == undefined) {
            $("select[id$=DropDownList_CarePlanPrescribedServices_PersonResponsible]").val("");
        }
        else {
            $("select[id$=DropDownList_CarePlanPrescribedServices_PersonResponsible]").val(DropDownValue);
        }
        return $('select[id$=DropDownList_CarePlanPrescribedServices_PersonResponsible]').html();
    }
    else if (DropDownType == "ServiceProvider") {
        $("select[id$=DropDownList_CarePlanPrescribedServices_ServiceProvider]").val(DropDownValue);
        return $('select[id$=DropDownList_CarePlanPrescribedServices_ServiceProvider]').html();
    }
}

//Purpose: ShowHide Condition For Service Group Details
function HideServiceGroupInnerTable(CheckBoxId, PrescribedServiceId, IsChecked, DocumentCodeId) { 
    if ($(CheckBoxId).length > 0) {
        if ($(CheckBoxId).attr("checked") == true) {
            AttachPrescribedServicesOnBlurEvents(true);
            $("#Table_ServiceGroupDetail_" + PrescribedServiceId + "").show();
            $("#Table_ServiceGroupDetail_" + PrescribedServiceId + "").find('select').val("");
            $("#Table_ServiceGroupDetail_" + PrescribedServiceId + "").find('select').change();
            $("#Table_ServiceGroupDetail_" + PrescribedServiceId + "").find('textarea').val("");
            $("#Table_ServiceGroupDetail_" + PrescribedServiceId + "").find('textarea').change();
            if (DocumentCodeId != "10001") {
                $("#TableTR_ServiceGroupDetail1_" + PrescribedServiceId + "").show();
                $("#TableTR_ServiceGroupDetail2_" + PrescribedServiceId + "").show();
                $("#TableTR_ServiceGroupDetail3_" + PrescribedServiceId + "").show();
                $("#TableTR_ServiceGroupDetail4_" + PrescribedServiceId + "").show();
            }
        }
        else {
            DeleteServiceGroupValuesCheckBoxUnChecked(PrescribedServiceId, IsChecked);
            AttachPrescribedServicesOnBlurEvents(false);
            $("#Table_ServiceGroupDetail_" + PrescribedServiceId + "").hide();
            $("#TableTR_ServiceGroupDetail1_" + PrescribedServiceId + "").hide();
            $("#TableTR_ServiceGroupDetail2_" + PrescribedServiceId + "").hide();
            $("#TableTR_ServiceGroupDetail3_" + PrescribedServiceId + "").hide();
            $("#TableTR_ServiceGroupDetail4_" + PrescribedServiceId + "").hide();
            showHideControls($("#Table_ServiceGroupDetail_" + PrescribedServiceId + ""), false, false);
            showHideControls($("#TableTR_ServiceGroupDetail2_" + PrescribedServiceId + ""), false, false);
            showHideControls($("#TableTR_ServiceGroupDetail3_" + PrescribedServiceId + ""), false, false);
            showHideControls($("#TableTR_ServiceGroupDetail4_" + PrescribedServiceId + ""), false, false);
        }
    }
}

//Purpose: This Function Deleted Service Group when CheckBox uncheck. Ajax Hit.
function DeleteServiceGroupValuesCheckBoxUnChecked(PrescribedServiceId, IsChecked) {
    GetXMLParentNodeByColumnValue("CarePlanPrescribedServices", "CarePlanPrescribedServiceId", PrescribedServiceId, AutoSaveXMLDom).each(function () {
        $(this).find("NumberOfSessions").remove(); $(this).find("Units").remove(); $(this).find("InterventionDetails").remove();
        $(this).find("UnitType").remove(); $(this).find("FrequencyType").remove(); $(this).find("PersonResponsible").remove();
        $(this).find("UnitType").text('N');
    });
    RemoveDeletedXMLNode("CarePlanPrescribedServiceObjectives", "CarePlanPrescribedServiceId", PrescribedServiceId);
    var data = 'CustomAction=DeleteServiceGroupValuesCheckBoxUnChecked^PrescribedServiceId=' + PrescribedServiceId + '^IsChecked=' + IsChecked + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    OpenPage(5763, 1077, data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
}

//Purpose: This Function Call inSide the HideServiceGroupInnerTable() Function
function showHideControls(obj, isShow, changeRequired) {
    if (isShow) {
        $(obj).show()
    }
    else {
        $(obj).hide();
        $(obj).find('textarea').val('');
        $(obj).find('textarea').change();
        $(obj).find('select').val("");
        $(obj).find('select').change();
        $(obj).find('input[type=text]').val('');
        $(obj).find('input[type=text]').change();
        $(obj).find('div').html('');
    }
}

//Purpose : Raise Prescribed Services tab click
function RaisePrescribedServicesTabClick() {
    CreateUnsavedInstanceOnDatasetChange();
    CarePlanTabPageInstance.GetTab(3).SetEnabled(true);
    CarePlanTabPageInstance.SetActiveTab(CarePlanTabPageInstance.tabs[3]);
    CarePlanTabPageInstance.RaiseTabClick(3, onTabSelected);
}

//Purpose: On Blur event attached with controls
function AttachPrescribedServicesOnBlurEvents(flag) {
    AttachValidationEventHandlers($("#divIntervention"));
    $('#divIntervention').find('input,select,textarea').unbind("change").bind("change", function () { UpdatePrescribedServicesFieldValue(this); });
}

//Purpose: On update of Prescribed Services Controls, say Units,NumberofSessions
function UpdatePrescribedServicesFieldValue(ctrl) {
    var nameArray = ctrl.id.split("_");
    var tablename = nameArray[1];
    var sourceField = nameArray[2];
    var prescribedServiceId = nameArray[nameArray.length - 1];
    var sourceFieldNewValue = GetControlValue(ctrl, undefined);

    if (sourceField == "NumberOfSessions" || sourceField == "Units" ) {
        if (isInteger(sourceFieldNewValue) == false) {
            $(ctrl).val("");
            sourceFieldNewValue = "";
        }
    }
    SetColumnValueInXMLNodeByKeyValue(tablename, "CarePlanPrescribedServiceId", prescribedServiceId, sourceField, sourceFieldNewValue, AutoSaveXMLDom[0])
    CreateUnsavedInstanceOnDatasetChange();
    CallAutoSaveProcess();
}



//Purpose : To refresh Prescribed Services tab data on Edit Need Discription
function RefreshPrescribedServicesTemplate(response, CustomAjaxRequest) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";
    if (response.indexOf("###StartDeletePrescribedServices###") >= 0) {
        startIndex = response.indexOf("###StartDeletePrescribedServices###") + 35;
        endIndex = response.indexOf("###EndDeletePrescribedServices###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        RaisePrescribedServicesTabClick();
    }
}

//Purpose : To Set Objective Info for a Prescribed Services on popup close.


//Description: Open CarePlan Edit View Objectives Pop Up
function OpenModelDialogueforEditViewObjectives(PrescribedServiceId, AuthorizationCodeName) {
    var PrescribedServiceId = PrescribedServiceId;
    var PrescribedServiceName = AuthorizationCodeName;
    var actionName = "editviewobjectives";
    OpenPage(5765, 1081, "PopUpAction=" + actionName + "^PrescribedServiceId=" + PrescribedServiceId + "^PrescribedServiceName=" + PrescribedServiceName, null, GetRelativePath(), 'T', "dialogHeight: 430px; dialogWidth: 600px;dialogTitle:Link/Unlink Objectives");
}