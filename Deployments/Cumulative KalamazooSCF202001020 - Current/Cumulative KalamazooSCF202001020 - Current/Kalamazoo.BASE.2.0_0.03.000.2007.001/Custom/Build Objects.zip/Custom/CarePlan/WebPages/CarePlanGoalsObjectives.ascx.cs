﻿using System;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using CarePlan;
using System.Linq;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using SHS.BaseLayer;
using SHS.DataServices;

namespace SHS.SmartCare
{
    public partial class CarePlanGoalsObjectives : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        private JavaScriptSerializer objectJavaScriptSerializer = null;
        DataSet dsMasterData = new DataSet();
        //public override string[] TablesUsedInTab
        //{
        //    get { return new string[] { "CarePlanObjectives", "CarePlanGoals" }; }
        //}

        public override void BindControls()
        {
            string goalId = base.GetRequestParameterValue("GoalId");
            if (!string.IsNullOrEmpty(goalId))
            {
                ParentDetailPageObject.SetParentScreenProperties("GoalId", goalId);
            }

            dsMasterData = CarePlan.CarePlan.GetMasterData();
            DropDownList_GoalsProviders.DataSource = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers;
            DropDownList_GoalsProviders.DataValueField = "ProviderId";
            DropDownList_GoalsProviders.DataTextField = "ProviderName";
            DropDownList_GoalsProviders.DataBind();

            DropDownList_GoalsStaff.DataSource = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff;
            DropDownList_GoalsStaff.DataValueField = "StaffId";
            DropDownList_GoalsStaff.DataTextField = "DisplayAs";
            DropDownList_GoalsStaff.DataBind();
            BindGoalObjectivesInfo();
            BindProgressTowardsObjective();
        }

        public override void Activate()
        {
            base.Activate();
            CarePlanMergeUnsavedXML();
        }

        public void CarePlanMergeUnsavedXML()
        {
            DataSet dataSetPageDataSet = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            try
            {
                if (Request.Form["myxmlstring"] != null)
                {
                    string unsavedXML = Convert.ToString(Request.Form["myxmlstring"]);
                    string strxml = unsavedXML.Replace("xmlns=\"\"", "");
                    SHS.BaseLayer.BaseCommonFunctions.MergeXMLInDataSet(ref dataSetPageDataSet, strxml);
                }
            }
            finally
            {
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void BindGoalObjectivesInfo()
        {
            List<ObjectivesListData> objectObjectivesListData = null;
            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            objectObjectivesListData = new List<ObjectivesListData>();
            ObjectivesListData objectObjectivesList = new ObjectivesListData();

            objectObjectivesList.objectListGoals = new List<Goals>();

            if (dataSetDocument.Tables.Contains("CarePlanGoals"))
            {
                if (SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dataSetDocument.Tables["CarePlanGoals"], 0))
                {
                    string MonitoredByType = string.Empty;
                    DataView dataViewCarePlanGoals = new DataView();
                    dataViewCarePlanGoals = dataSetDocument.Tables["CarePlanGoals"].DefaultView;
                    dataViewCarePlanGoals.RowFilter = "ISNULL(RecordDeleted,'N')<>'Y'";
                    dataViewCarePlanGoals.Sort = "GoalNumber Asc";


                    CarePlan.CarePlan objectCarePlan = new CarePlan.CarePlan();
                    for (int rowCount = 0; rowCount < dataViewCarePlanGoals.Count; rowCount++)
                    {
                        Goals objectGoals = new Goals();
                        objectGoals.objectListObjectives = new List<Objectives>();

                        objectGoals.CarePlanGoalId = Convert.ToString(dataViewCarePlanGoals[rowCount]["CarePlanGoalId"]);
                        objectGoals.CarePlanDomainGoalId = Convert.ToString(dataViewCarePlanGoals[rowCount]["CarePlanDomainGoalId"]);
                        objectGoals.GoalNumber = Convert.ToString(dataViewCarePlanGoals[rowCount]["GoalNumber"]);
                        objectGoals.ClientGoal = Convert.ToString(dataViewCarePlanGoals[rowCount]["ClientGoal"]);
                        if (SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("SetReviewInCarePlan").ToString().Trim() == "Y")
                            objectGoals.IsNewGoal = Convert.ToString(dataViewCarePlanGoals[rowCount]["IsNewGoal"]);
                        else
                            objectGoals.IsNewGoal = "N";
                        objectGoals.IsNewCarePlanGoal = Convert.ToString(dataViewCarePlanGoals[rowCount]["IsNewCarePlanGoal"]);
                        objectGoals.AssociatedNeeds = objectCarePlan.GetAssiciatedNeedsText(Convert.ToInt32(objectGoals.CarePlanGoalId), true);
                        objectGoals.AssociatedNeedswithoutDesc = objectCarePlan.GetAssiciatedNeedsText(Convert.ToInt32(objectGoals.CarePlanGoalId), false);

                        string goalObjText = GetGoalObjectiveDescriptionText(objectGoals.CarePlanDomainGoalId, dataSetDocument, "goals");
                        if (objectGoals.CarePlanDomainGoalId != "" && String.Equals(SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("UseBTATemplateForGoalsAndObjectivesInCarePlan").ToString(), "No"))
                        {
                            objectGoals.GoalDescription = goalObjText == "" ? (Convert.ToString(dataViewCarePlanGoals[rowCount]["AssociatedGoalDescription"]) == "" ? "" : Convert.ToString(dataViewCarePlanGoals[rowCount]["AssociatedGoalDescription"])) : goalObjText + " " + (Convert.ToString(dataViewCarePlanGoals[rowCount]["AssociatedGoalDescription"]) == "" ? " " : Convert.ToString(dataViewCarePlanGoals[rowCount]["AssociatedGoalDescription"]));
                        }
                        else
                            objectGoals.GoalDescription = Convert.ToString(dataViewCarePlanGoals[rowCount]["AssociatedGoalDescription"]);

                        objectGoals.GoalActive = Convert.ToString(dataViewCarePlanGoals[rowCount]["GoalActive"]);
                        objectGoals.ProgressTowardsGoal = Convert.ToString(dataViewCarePlanGoals[rowCount]["ProgressTowardsGoal"]);
                        objectGoals.GoalReviewUpdate = Convert.ToString(dataViewCarePlanGoals[rowCount]["GoalReviewUpdate"]);
                        objectGoals.ShowHideGoalActiveSection = Convert.ToString(dataViewCarePlanGoals[rowCount]["InitializedFromPreviousCarePlan"]) == "Y" ? "block" : "none";
                        objectGoals.ShowHideGoalDeleteIcon = Convert.ToString(dataViewCarePlanGoals[rowCount]["InitializedFromPreviousCarePlan"]) == "Y" ? "none" : "block";

                        MonitoredByType = Convert.ToString(dataViewCarePlanGoals[rowCount]["MonitoredByType"]) == "" ? "S" : Convert.ToString(dataViewCarePlanGoals[rowCount]["MonitoredByType"]);
                        objectGoals.MonitoredByType = MonitoredByType;
                        objectGoals.MonitoredBy = Convert.ToString(dataViewCarePlanGoals[rowCount]["MonitoredBy"]);
                        if (objectGoals.MonitoredBy == "" || objectGoals.MonitoredBy == "-1")
                        {
                            objectGoals.MonitoredBy = "-1";
                            objectGoals.MonitoredByText = "Select Monitored By";
                        }
                        else if (MonitoredByType == "S")
                        {
                            objectGoals.MonitoredByText = (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff.AsEnumerable()
                                                           .Where(p => p.Field<int>("StaffId") == Convert.ToInt32(objectGoals.MonitoredBy)).Select(p => p.Field<string>("DisplayAs"))).FirstOrDefault();

                        }
                        else if (MonitoredByType == "P")
                        {
                            objectGoals.MonitoredByText = (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers.AsEnumerable()
                                                           .Where(p => p.Field<int>("ProviderId") == Convert.ToInt32(objectGoals.MonitoredBy)).Select(p => p.Field<string>("ProviderName"))).FirstOrDefault();

                        }

                        objectGoals.GoalStartDate = dataViewCarePlanGoals[rowCount]["GoalStartDate"] == DBNull.Value ? DateTime.Now.ToString("MM/dd/yyyy") : Convert.ToDateTime(dataViewCarePlanGoals[rowCount]["GoalStartDate"]).ToString("MM/dd/yyyy");
                        objectGoals.GoalEndDate = dataViewCarePlanGoals[rowCount]["GoalEndDate"] == DBNull.Value ? "" : Convert.ToDateTime(dataViewCarePlanGoals[rowCount]["GoalEndDate"]).ToString("MM/dd/yyyy");
                        objectGoals.MonitoredByOtherDescription = Convert.ToString(dataViewCarePlanGoals[rowCount]["MonitoredByOtherDescription"]);

                        if (dataSetDocument.Tables.Contains("CarePlanObjectives"))
                        {
                            if (SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dataSetDocument.Tables["CarePlanObjectives"], 0))
                            {
                                DataView dataViewCarePlanObjectives = new DataView();
                                dataViewCarePlanObjectives = dataSetDocument.Tables["CarePlanObjectives"].DefaultView;
                                dataViewCarePlanObjectives.RowFilter = "CarePlanGoalId=" + objectGoals.CarePlanGoalId + " AND ISNULL(RecordDeleted,'N')<>'Y'";
                                dataViewCarePlanObjectives.Sort = "ObjectiveNumber Asc";

                                DataRow[] datarowCarePlanObjectivesArray = dataSetDocument.Tables["CarePlanObjectives"].Select("CarePlanGoalId=" + objectGoals.CarePlanGoalId + " AND ISNULL(RecordDeleted,'N')<>'Y'");
                                if (datarowCarePlanObjectivesArray.Length > 0)
                                {
                                    objectGoals.ObjectiveRecordCount = Convert.ToString(dataViewCarePlanObjectives.Count);
                                }
                                else
                                {
                                    objectGoals.ObjectiveRecordCount = "0";
                                }

                                for (int rowCountObjectives = 0; rowCountObjectives < dataViewCarePlanObjectives.Count; rowCountObjectives++)
                                {
                                    Objectives objectObjectives = new Objectives();
                                    objectObjectives.CarePlanObjectiveId = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["CarePlanObjectiveId"]);
                                    objectObjectives.CarePlanDomainObjectiveId = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["CarePlanDomainObjectiveId"]);
                                    objectObjectives.ObjectiveNumber = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["ObjectiveNumber"]);
                                    objectObjectives.StaffSupports = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["StaffSupports"]);
                                    objectObjectives.MemberActions = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["MemberActions"]);
                                    objectObjectives.UseOfNaturalSupports = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["UseOfNaturalSupports"]);
                                    objectObjectives.Status = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["Status"]);
                                    objectObjectives.ShowHideObjectiveDeleteIcon = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["InitializedFromPreviousCarePlan"]) == "Y" ? "none" : "block";

                                    //EI#677 - Analysis and Resolution to Fix - Exception: "There is no row at position 0" in SmartCare Application
                                    if (SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.IsDataTableFound("DocumentCarePlans"))
                                    {
                                        if (SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["DocumentCarePlans"].Rows[0]["CarePlanType"].ToString() == "RE" && SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("SetReviewInCarePlan").ToString().Trim() == "Y")
                                            objectObjectives.IsReview = "Y";
                                        else
                                            objectObjectives.IsReview = "N";
                                    }
                                    string objText = GetGoalObjectiveDescriptionText(objectObjectives.CarePlanDomainObjectiveId, dataSetDocument, "objective");
                                    if (objectObjectives.CarePlanDomainObjectiveId != "" && String.Equals(SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("UseBTATemplateForGoalsAndObjectivesInCarePlan").ToString(), "No"))
                                        objectObjectives.ObjectiveDescription = objText == "" ? (Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["AssociatedObjectiveDescription"]) == "" ? "" : Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["AssociatedObjectiveDescription"])) : objText + (Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["AssociatedObjectiveDescription"]) == "" ? "" : " " + Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["AssociatedObjectiveDescription"]));
                                    else
                                        objectObjectives.ObjectiveDescription = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["AssociatedObjectiveDescription"]);

                                    objectObjectives.CarePlanGoalId = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["CarePlanGoalId"]);
                                    objectObjectives.PrescribedServices = GetAssiciatedPrescribedServicesText(Convert.ToInt32(objectObjectives.CarePlanObjectiveId));
                                    objectObjectives.ObjectiveStartDate = dataViewCarePlanObjectives[rowCountObjectives]["ObjectiveStartDate"] == DBNull.Value ? DateTime.Now.ToString("MM/dd/yyyy") : Convert.ToDateTime(dataViewCarePlanObjectives[rowCountObjectives]["ObjectiveStartDate"]).ToString("MM/dd/yyyy");
                                    objectObjectives.ObjectiveEndDate = dataViewCarePlanObjectives[rowCountObjectives]["ObjectiveEndDate"] == DBNull.Value ? "" : Convert.ToDateTime(dataViewCarePlanObjectives[rowCountObjectives]["ObjectiveEndDate"]).ToString("MM/dd/yyyy");
                                    objectObjectives.ProgressTowardsObjective = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["ProgressTowardsObjective"]);
                                    objectObjectives.ObjectiveReview = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["ObjectiveReview"]);
                                    if (SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("SetReviewInCarePlan").ToString().Trim() == "Y")
                                        objectObjectives.IsNewObjective = Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["IsNewObjective"]);
                                    else
                                        objectObjectives.IsNewObjective = "N";

                                    objectGoals.objectListObjectives.Add(objectObjectives);
                                    if (Convert.ToString(dataViewCarePlanObjectives[rowCountObjectives]["Status"]) == "A")
                                    {
                                        objectGoals.CheckStatusActive = "A";
                                    }

                                }
                            }
                        }
                        objectObjectivesList.objectListGoals.Add(objectGoals);
                    }
                    if (string.IsNullOrEmpty(base.GetRequestParameterValue("GoalId")))
                    {
                        if (dataViewCarePlanGoals != null && dataViewCarePlanGoals.Count > 0)
                        {
                            ParentDetailPageObject.SetParentScreenProperties("GoalId", Convert.ToString(dataViewCarePlanGoals[dataViewCarePlanGoals.Count - 1]["CarePlanGoalId"]));
                        }
                    }
                }
            }


            objectJavaScriptSerializer = new JavaScriptSerializer();
            string objectStringGoalObjectivesJSON = objectJavaScriptSerializer.Serialize(objectObjectivesList);
            HiddenField_GoalObjectivesJSONData.Value = objectStringGoalObjectivesJSON;
        }

        /// <summary>
        /// <purpose>Get Assiciated Prescribed Services Text for Objective</purpose>
        /// </summary>
        /// <param name="objectiveId"></param>
        public string GetAssiciatedPrescribedServicesText(int objectiveId)
        {
            DataSet datasetCarePlans = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (datasetCarePlans.Tables.Contains("CustomCarePlanPrescribedServiceObjectives"))
            {
                DataRow[] datarowPrescribedServiceObjectives = datasetCarePlans.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanObjectiveId=" + Convert.ToString(objectiveId) + " and ISNULL(RecordDeleted,'N')<>'Y'");
                string associatedPrescribedService = string.Empty;
                if (datarowPrescribedServiceObjectives.Length > 0)
                {
                    foreach (DataRow datarowCurrent in datarowPrescribedServiceObjectives)
                    {
                        string prescribedServiceId = Convert.ToString(datarowCurrent["CarePlanPrescribedServiceId"]);
                        associatedPrescribedService += GetPrescribedServicesName(prescribedServiceId, datasetCarePlans) + ", ";
                    }
                    associatedPrescribedService = associatedPrescribedService.Trim();
                    if (associatedPrescribedService.EndsWith(","))
                    {
                        associatedPrescribedService = associatedPrescribedService.Substring(0, associatedPrescribedService.Length - 1);
                    }
                    if (associatedPrescribedService.StartsWith(","))
                    {
                        associatedPrescribedService = associatedPrescribedService.Substring(1, associatedPrescribedService.Length - 1);
                    }
                    return associatedPrescribedService;
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// <purpose>Get Prescribed Services Name form CustomCarePlanPrescribedServices tables</purpose>
        /// </summary>
        /// <param name="prescribedServiceId"></param>
        /// <param name="datasetCarePlans"></param>
        public string GetPrescribedServicesName(string prescribedServiceId, DataSet datasetCarePlans)
        {
            string prescribedServiceName = string.Empty;

            if (datasetCarePlans.Tables.Contains("CustomCarePlanPrescribedServices"))
            {
                DataRow[] datarowPrescribedServices = datasetCarePlans.Tables["CustomCarePlanPrescribedServices"].Select("CarePlanPrescribedServiceId=" + prescribedServiceId);
                if (datarowPrescribedServices.Length > 0)
                {
                    prescribedServiceName = Convert.ToString(Convert.ToString(datarowPrescribedServices[0]["AuthorizationCodeName"]));
                    return prescribedServiceName;

                }
            }
            return string.Empty;
        }

        public string GetGoalObjectiveDescriptionText(string domainGoalId, DataSet datasetDocument, string sourceOfDesc)
        {
            DataRow[] datarowDomains = null;
            string nameInGoalDescriptions = string.Empty;
            string description = string.Empty;
            if (datasetDocument.Tables.Contains("DocumentCarePlans") && SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(datasetDocument, "DocumentCarePlans"))
            {
                nameInGoalDescriptions = Convert.ToString(datasetDocument.Tables["DocumentCarePlans"].Rows[0]["NameInGoalDescriptions"]);
                if (domainGoalId != string.Empty)
                {
                    if (sourceOfDesc.ToLower() == "goals")
                    {
                        if (dsMasterData.Tables.Contains("CarePlanDomainGoals") && SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dsMasterData, "CarePlanDomainGoals"))
                        {
                            datarowDomains = dsMasterData.Tables["CarePlanDomainGoals"].Select("CarePlanDomainGoalId=" + domainGoalId);
                            if (datarowDomains.Length > 0)
                            {
                                description = Convert.ToString(datarowDomains[0]["GoalDescription"]);
                            }
                        }
                    }
                    else if (sourceOfDesc.ToLower() == "objective")
                    {
                        if (dsMasterData.Tables.Contains("CarePlanDomainObjectives") && SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dsMasterData, "CarePlanDomainObjectives"))
                        {
                            datarowDomains = dsMasterData.Tables["CarePlanDomainObjectives"].Select("CarePlanDomainObjectiveId=" + domainGoalId);
                            if (datarowDomains.Length > 0)
                            {
                                description = Convert.ToString(datarowDomains[0]["ObjectiveDescription"]);
                            }
                        }
                    }

                    if (domainGoalId == "-1")
                        return string.Empty;
                    return nameInGoalDescriptions + " " + description;
                }
            }
            return string.Empty;
        }

        private void BindProgressTowardsObjective()
        {
            DataSet ds = GetProgressTowardsObjective();

            ProgressTowardsObjectiveListData PTowardsObjectiveListData = new ProgressTowardsObjectiveListData();

            PTowardsObjectiveListData.ProgressTowardsobjectList = new List<PTowardsObjective>();

            foreach (DataRow dr in ds.Tables["ProgressTowardsObjective"].Rows)
            {
                PTowardsObjective ProgressTowardsObjective = new PTowardsObjective();

                ProgressTowardsObjective.CarePlanDomainObjectiveId = dr["CarePlanDomainObjectiveId"].ToString();
                ProgressTowardsObjective.ProgressTowardsObjective = dr["ProgressTowardsObjective"].ToString();

                PTowardsObjectiveListData.ProgressTowardsobjectList.Add(ProgressTowardsObjective);
            }

            objectJavaScriptSerializer = new JavaScriptSerializer();
            string objectStringProgressTowardsobjectListJSON = objectJavaScriptSerializer.Serialize(PTowardsObjectiveListData);
            HiddenField_ProgressTowardsobjectListJSONData.Value = objectStringProgressTowardsobjectListJSON;
        }

        private DataSet GetProgressTowardsObjective()
        {
            DataSet dataSetProgressTowardsObjective = null;
            SqlParameter[] _objectSqlParmeters = null;
            DateTime DocumentEffectiveDate = DateTime.Now;
            int ClientId = BaseCommonFunctions.ApplicationInfo.Client.ClientId;
            DataSet dataSetDocument = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (BaseCommonFunctions.CheckRowExists(dataSetDocument, "Documents") && !string.IsNullOrEmpty(dataSetDocument.Tables["Documents"].Rows[0]["EffectiveDate"].ToString()))
            {
                DocumentEffectiveDate = Convert.ToDateTime(dataSetDocument.Tables["Documents"].Rows[0]["EffectiveDate"].ToString());
            }

            try
            {
                dataSetProgressTowardsObjective = new DataSet();
                _objectSqlParmeters = new SqlParameter[2];

                _objectSqlParmeters[0] = new SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new SqlParameter("@DocumentEffectiveDate", DocumentEffectiveDate);
                SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "ssp_GetProgressTowardsObjective", dataSetProgressTowardsObjective, new string[] { "ProgressTowardsObjective" }, _objectSqlParmeters);
                return dataSetProgressTowardsObjective;
            }
            finally
            {
                if (dataSetProgressTowardsObjective != null) dataSetProgressTowardsObjective.Dispose();
                _objectSqlParmeters = null;
            }
        }

        private class PTowardsObjective
        {
            public string ProgressTowardsObjective = string.Empty;
            public string CarePlanDomainObjectiveId = string.Empty;
        }

        private class ProgressTowardsObjectiveListData
        {
            public List<PTowardsObjective> ProgressTowardsobjectList = null;
        }
    }
}
