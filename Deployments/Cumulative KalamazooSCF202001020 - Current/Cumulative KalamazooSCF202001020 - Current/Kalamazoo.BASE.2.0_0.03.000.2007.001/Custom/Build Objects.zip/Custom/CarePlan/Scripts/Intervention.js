﻿var CPConfirmCaption = 'Confirmation Message';
var CPAlertCaption = 'Message';

function ModifyInterventionValueInDataSet(keyValue, tableName, fieldName, controlId, actionName, keyFieldName) {
    try {
        PopupProcessing();
        //var controlId = control.id;
        var cObject = $('[id$=' + controlId + ']');
        var cValue = '';
        if (cObject.length > 0) {

            // Page defined function ValidateDate is changed with ValidateDateTreatmentPlan
            // Because same name clash with applicationCommon funciton /\/\ |<

            //Case of TextBox with Date
            //datatype
            if (cObject.attr("datatype") == 'Date') {
                ValidateDate(cObject[0]); //set the date if user enters . as date seprator. /\/\ |<
                var returnValue = ValidateDateValue(cObject);
                if (returnValue != '' && returnValue != 'Value is null') {
                    cObject.val('');
                    return false;
                }
                FromDateEndDateValidation(cObject[0], keyValue);

            }

            if (cObject[0].type == "radio") //Handle Case for  Radio Control 
            {
                cValue = cObject[0].value;
            }
            else if (cObject[0].type == "checkbox")  //Handle Case for CheckBox Control
            {
                if (cObject[0].checked == false) {
                    cValue = "N";
                }
                else {
                    cValue = "Y";
                }
            }
            else {
                //Below code added by Rakesh w.r.f to 398 in SC web phase II bugs/Features to support + sign saves in database Treatment Plan: Intervention text
                cValue = encodeText(cObject.val());
                //cValue = escape(cObject.val());
                //Changes end here
            }
        }

        var siteId = $('[id$=' + controlId + ']').attr("SiteId");
        if (!siteId) {
            siteId = "";
        }
        var selectedGoalNo = $('[id$=' + controlId + ']').attr("goalNo");
        if (!selectedGoalNo) {
            selectedGoalNo = "";
        }
        var authCodeId = $('[id$=' + controlId + '] option:selected').val();
        if (!authCodeId) {
            authCodeId = "";
        }
        var tpProcedureId = $('[id$=' + controlId + ']').attr("TPProcedureId");
        if (!tpProcedureId) {
            tpProcedureId = "";
        }
        //var textValue =  $('[id$=' + controlId + '] option:selected').text();

        var args = arguments;

        var myDate = new Date();
        // $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx?keyValue=" + keyValue, 'action=' + actionName + '&tableName=' + tableName + '&fieldName=' + fieldName + '&controlValue=' + cValue + '&keyFieldName=' + keyFieldName + '&GoalNo=' + selectedGoalNo + '&AuthCodeId=' + authCodeId + '&TPProcedureId=' + tpProcedureId + '&TextValue=' + textValue + '&time=' + myDate.getMinutes() + myDate.getSeconds(), function(result) { onSuccess(result, controlId, keyValue, keyFieldName); });
        $.post(GetRelativePath() + "Custom/CarePlan/WebPages/CarePlanAjaxScript.aspx?keyValue=" + keyValue, 'action=' + actionName + '&tableName=' + tableName + '&fieldName=' + fieldName + '&controlValue=' + cValue + '&keyFieldName=' + keyFieldName + '&SiteId=' + siteId + '&AuthCodeId=' + authCodeId + '&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) { onSuccessModifyInterventionValueInDataSet(result, controlId, keyValue, keyFieldName, args); });

    }
    catch (err) {
        LogClientSideException(err, 'CarePlan Intervention'); //Code added by Devinder 
    }
}

function onSuccessModifyInterventionValueInDataSet(result, controlId, keyValue, keyFieldName, args) {
    HidePopupProcessing();
    CreateUnsavedInstanceOnDatasetChange();
    if (controlId.indexOf("DropDownList_CustomCarePlanPrescribedServices_ProviderId_") == 0) {
        //if (args.length > 6) {
        SelectedIndexChanged($('[Id$=DropDownList_CustomCarePlanPrescribedServices_ProviderId_' + keyValue + ']')[0], "DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + keyValue, "Span_CustomCarePlanPrescribedServices_AuthorizationCodeId_" + keyValue, keyValue, "", "", false);
        //}
    }
    if (controlId.indexOf("DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_") == 0) {
        var authorizationcodeid = $('[Id$=DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_' + keyValue + ']').val();
        if (authorizationcodeid != "") {
            PopupProcessing();
            var myDate = new Date();
            $.post(GetRelativePath() + "Custom/CarePlan/WebPages/CarePlanAjaxScript.aspx", 'action=fillrequestlcmccmlabels&time=' + myDate.getMinutes() + myDate.getSeconds()
                + '&careplanprescribedserviceid=' + keyValue + '&authorizationcodeid=' + authorizationcodeid
                + '&providerid=' + $('[Id$=DropDownList_CustomCarePlanPrescribedServices_ProviderId_' + keyValue + ']').val()
                + '&totalunits=' + $('[Id$=Text_CustomCarePlanPrescribedServices_TotalUnits_' + keyValue + ']').val(), function (result) { FillRequestLcmCcmLabels(result, keyValue) });
            return false;
        }
    }
    if ((controlId.indexOf("Text_CustomCarePlanPrescribedServices_Units_") == 0) || (controlId.indexOf("DropDownList_CustomCarePlanPrescribedServices_Frequency_") == 0)
        || (controlId.indexOf("Text_CustomCarePlanPrescribedServices_TotalUnits_") == 0))
    {
        askForBillingCode($('[id$=' + controlId + ']')[0], keyValue);
    }


}

function SelectedIndexChanged(objeDropdown, dropdownAuthorizationID, spanID, carePlanPrescribedServicesId, tpProcedureId, authorizationCodeId, disableProcedureProvider) {
    var siteID = -1;

    //var goalNo = $('[id$=' + objeDropdown.id + ']').attr('goalNo')
    if (objeDropdown.selectedIndex >= 0) {
        siteID = objeDropdown.options[objeDropdown.selectedIndex].value;
    }
    parent.PopupProcessing();
    var myDate = new Date();
    $.post(GetRelativePath() + "Custom/CarePlan/WebPages/CarePlanAjaxScript.aspx", 'action=fillauthorizationdropdown&time=' + myDate.getMinutes() + myDate.getSeconds() + '&siteID=' + siteID + '&tpInterventionProcedureId=' + carePlanPrescribedServicesId + '&tpProcedureId=' + tpProcedureId + '&authorizationCodeId=' + authorizationCodeId + '&disableProcedureProvider=' + disableProcedureProvider, function (result) { FillAuthorizationDropdownOnSuccess(result, carePlanPrescribedServicesId) });

}

function FillAuthorizationDropdownOnSuccess(result, carePlanPrescribedServicesId) {
    if (result != null && result != "") {
        $('[id$=Span_CustomCarePlanPrescribedServices_AuthorizationCodeId_' + carePlanPrescribedServicesId + ']').html(result);
        $('[id$=DropDownList_CustomCarePlanPrescribedServices_AuthorizationCodeId_' + carePlanPrescribedServicesId + ']').val('');
        //$('[id$=Text_CustomCarePlanPrescribedServices_FromDate_' + carePlanPrescribedServicesId + ']').val($('[id$=TextBox_DocumentInformation_EffectiveDate]').val());
        //CreateAutoSaveXml("CustomCarePlanPrescribedServices", "FromDate", $('[id$=Text_CustomCarePlanPrescribedServices_FromDate_' + carePlanPrescribedServicesId + ']').val());
    }
    parent.HidePopupProcessing();
}

function FillRequestLcmCcmLabels(result, carePlanPrescribedServicesId) {
    parent.HidePopupProcessing();
    if (result != null && result != "" && result != undefined) {
        var lcmCcmLabelsdata = JSON.parse(result);
        $("[Id$='Span_UMCode_" + carePlanPrescribedServicesId + "']").html(lcmCcmLabelsdata.UMCode);
        $("[Id$='Span_ServiceCategory_" + carePlanPrescribedServicesId + "']").html(lcmCcmLabelsdata.ServiceCategory);
        $("[id$='Label_LCM_" + carePlanPrescribedServicesId + "']").text(lcmCcmLabelsdata.LCMLabel);
        $("[id$='Label_CCM_" + carePlanPrescribedServicesId + "']").text(lcmCcmLabelsdata.CCMLabel);
        $("[id$='Label_CustomCarePlanPrescribedServices_TotalUnits_" + carePlanPrescribedServicesId + "']").text(lcmCcmLabelsdata.TotalUnits);
        $("[id$='Label_CustomCarePlanPrescribedServices_PreviouslyRequested_" + carePlanPrescribedServicesId + "']").text(lcmCcmLabelsdata.PreviouslyRequested);
        $("[id$='Label_CustomCarePlanPrescribedServices_TotalRequestedYTD_" + carePlanPrescribedServicesId + "']").text(lcmCcmLabelsdata.TotalRequestedYTD);
        $("[id$='Label_UnitValue_" + carePlanPrescribedServicesId + "']").html("&nbsp;" + lcmCcmLabelsdata.UnitValue);
        $("[id$='Label_UnitType_" + carePlanPrescribedServicesId + "']").html("&nbsp;" + lcmCcmLabelsdata.UnitType);
    }
}

function OpenModelDialogueforEditViewObjectives(PrescribedServiceId, AuthorizationCodeName) {
    var PrescribedServiceId = PrescribedServiceId;
    var PrescribedServiceName = AuthorizationCodeName;
    var actionName = "editviewobjectives";
    OpenPage(5765, $('[id$=HiddenField_CarePlanPopUpScreenId]').val(), "PopUpAction=" + actionName + "^PrescribedServiceId=" + PrescribedServiceId + "^PrescribedServiceName=" + PrescribedServiceName, null, GetRelativePath(), 'T', "dialogHeight: 430px; dialogWidth: 600px;dialogTitle:Link/Unlink Objectives");
}

function AddNewCarePlanIntervention(carePlanPrescribedServiceId) {
    try {
        var myDate = new Date();
        var totalInterventionCount = '';
        //Changes made by Mamta- SCWebPhaseII Bugs/Features Ref Task 352 7/Dec/2011- To add author name in New goal GoalmoniteredStaffOther field
        //var GoalMonitoredStaffOther = $("select[id*=DropDownList_DocumentInformation_AuthorList]").find(":selected").text();
        //var GoalMonitoredStaffOtherCheckbox = 'N';
        //if (GoalMonitoredStaffOther != '') {
        //    GoalMonitoredStaffOtherCheckbox = 'Y';
        //}
        if ($("[id*=tr_MainIntervention]").length > 0)
            totalInterventionCount = $("[id*=tr_MainIntervention]").length + 1;
        else
            totalInterventionCount = 1;

        PopupProcessing();
        $.post(GetRelativePath() + "Custom/CarePlan/WebPages/CarePlanAjaxScript.aspx?needId=" + carePlanPrescribedServiceId, 'action=addintervention&time=' + myDate.getMinutes() + myDate.getSeconds() + '&InterventionCount=' + totalInterventionCount, function (result) { onSuccessAddIntervention(result, carePlanPrescribedServiceId) });
        //+ '&GoalMonitoredStaffOther=' + GoalMonitoredStaffOther + '&GoalMonitoredStaffOtherCheckbox=' + GoalMonitoredStaffOtherCheckbox
    }
    catch (err) {
        HidePopupProcessing();
        LogClientSideException(err, 'HRMTreatmetPlan');
    }
}

function onSuccessAddIntervention(result, needId) {
    HidePopupProcessing();
    CreateUnsavedInstanceOnDatasetChange();
    var pageResponse = result;
    var start = pageResponse.indexOf("###STARTPAGERESPONSESINGLEGOAL###") + 33;
    var end = pageResponse.indexOf("###ENDPAGERESPONSESINGLEGOAL###");
    pageResponse = pageResponse.substr(start, end - start);
    if (pageResponse != undefined) {

        var trMainIntervention = $('tr#MainInterventionEnd_' + needId);
        //TPInterventionProcedures.prev().after(pageResponse);
        var nextTR = trMainIntervention.next();
        nextTR.remove();
        trMainIntervention.after(pageResponse);
        //TPObjective.prev().after(pageResponse);

    }
}

function SetPrescribedServiceObjectivesInfo(response) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";
    var splitResponse = "";
    var primaryKey = "";
    var objectiveTemplate = "";

    if (response.indexOf("###StartEditViewObjectiveDescription###") >= 0) {
        startIndex = response.indexOf("###StartEditViewObjectiveDescription###") + 39;
        endIndex = response.indexOf("###EndEditViewObjectiveDescription###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        splitResponse = outputHTML.substr(outputHTML.indexOf("PrescribedServiceId=") + 20).split("$$$");
        primaryKey = splitResponse[0]
        objectiveTemplate = splitResponse[1];

        var PrescribedJsonData = "";
        var PrescribedJsonSerializedData = "";
        var ObjectiveNumString = '';
        PrescribedJsonData = objectiveTemplate;
        PrescribedJsonSerializedData = eval('(' + PrescribedJsonData + ')');
        if (PrescribedJsonData.length > 0) {
            $("#Div_EditViewObjectives_" + primaryKey).html("");
            $.each(PrescribedJsonSerializedData, function (key, val) {
                ObjectiveNumString += this.ObjectiveNumber;
            });
            $("#Div_EditViewObjectives_" + primaryKey).html(ObjectiveNumString);
            //$("#EditViewObjectivesListScript").tmpl(PrescribedJsonSerializedData).appendTo("#Div_EditViewObjectives_" + primaryKey);
        }
        RemoveDeletedXMLNode("CustomCarePlanPrescribedServiceObjectives", "CarePlanPrescribedServiceId", primaryKey);
        for (var i = 0; i < PrescribedJsonSerializedData.length; i++) {
            AppendNewRowTOAutoSaveXML(decodeText(PrescribedJsonSerializedData[i].RowXML));
        }
        CreateUnsavedInstanceOnDatasetChange();
        AttachPrescribedServicesOnBlurEvents(true);
    }
}

function DeleteIntervention(carePlanPrescribedServiceId, status) {
    try {
        if (status == "true") {
            //Modified by sourabh with ref to task#521, to resolve popup processing issue.
            ShowMsgBox('Are you sure you want to remove this Intervention Procedure?', CPConfirmCaption, MessageBoxButton.OKCancel, MessageBoxIcon.Question, 'DeleteInterventionOnOkOption(\'' + carePlanPrescribedServiceId + '\');', null, null, null, null, true);
            //end here
        }
        else {
            ShowMsgBox('Intervention Procedure can not be deleted.', CPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
            return false;
        }
    }
    catch (err) {
        LogClientSideException(err, 'carePlan'); 
    }
}

function DeleteInterventionOnOkOption(carePlanPrescribedServiceId) {
    try {
        var myDate = new Date();
        PopupProcessing();
        $.post(GetRelativePath() + "Custom/CarePlan/WebPages/CarePlanAjaxScript.aspx?carePlanPrescribedServiceId=" + carePlanPrescribedServiceId, 'action=deleteintervention&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) { onSuccessDeleteIntervention(result, carePlanPrescribedServiceId) });
    }
    catch (err) {
        HidePopupProcessing();
        LogClientSideException(err, 'CarePlan');
    }
}

function onSuccessDeleteIntervention(result, carePlanPrescribedServiceId) {
    HidePopupProcessing();
    var pageResponse = result;
    $("#tr_MainIntervention" + carePlanPrescribedServiceId).remove();

}

function ValidateDateValue(input) {

    try {
        var validformat = /^\d{2}\/\d{2}\/\d{4}$/ //Basic check for format validity
        var errorMessage = "";
        if (input.val() == '') {
            errorMessage = "Value is null";
        }
        else {
            var monthfield = input.val().split("/")[0]

            var dayfield = input.val().split("/")[1]
            var yearfield = input.val().split("/")[2]
            if (monthfield.length != 2) {
                errorMessage = "Value is null";
                return errorMessage;
            }
            if (dayfield.length != 2) {
                errorMessage = "Value is null";
                return errorMessage;
            }

            if (yearfield.length != 4) {
                errorMessage = "Value is null";
                return errorMessage;
            }

            var dayobj = new Date(yearfield, monthfield - 1, dayfield)
            if ((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield)) {
                errorMessage = "Invalid Day, Month, or Year range detected. Please correct";
            }
        }
        return errorMessage;
    }
    catch (err) {
        LogClientSideException(err, 'HRMTreatmetPlan'); //Code added by Devinder 
    }

}

function FromDateEndDateValidation(control, keyVal) {
    try {
        var textBoxTPProcedureStartDate = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_FromDate_" + keyVal + "]");
        var textBoxTPProcedureEndDate = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_ToDate_" + keyVal + "]");

        if (control.value == "") {
            return false;
        }

        if (control.id == textBoxTPProcedureStartDate[0].id) {
            if (control.attributes["datatype"].value == "Date") {
                var returnValue = ValidateDate(textBoxTPProcedureStartDate[0]); //set the date if user enters . as date seprator. /\/\ |<
                //  var returnValue = ValidateDateValue(textBoxTPInterventionProcedureStartDate);
                if (returnValue != true) {
                    textBoxTPProcedureStartDate.val('');
                    return false;
                }
            }
        }
        if (control.id == textBoxTPProcedureEndDate[0].id) {

            if (control.attributes["datatype"].value == "Date") {
                var returnValue = ValidateDate(textBoxTPProcedureEndDate[0]); //set the date if user enters . as date seprator. /\/\ |<
                //  var returnValue = ValidateDateValue(textBoxTPInterventionProcedureStartDate);
                if (returnValue != true) {
                    textBoxTPProcedureEndDate.val('');
                    return false;
                }
            }
        }
        if (textBoxTPProcedureStartDate[0].value != "" && textBoxTPProcedureEndDate[0].value != "") {
            //Now Perform check from date is less than start date or not

            var date1 = new Date(textBoxTPProcedureStartDate[0].value);
            var date2 = new Date(textBoxTPProcedureEndDate[0].value);
            var date3 = new Date($('[id$=HiddenField_EndDate]').val());

            if (date1 > date2) {

                SetErrorMessageAlignment("Translate(TODATENOTLESSFROMDATE,To date can not be less than the from date.)");
                //ShowMsgBox('To-Date can not be less than the From-Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                return false;
            }
            else

                if (date2 > date3) {
                    SetErrorMessageAlignment("Translate(TODATENOTLESSTHANTXPLANEXPIRYDATE,To date cannot be later than the Tx Plan Expire date.)");
                    // ShowMsgBox('To-Date can not be more than the TxPlan Expiry Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    return false;
                }

            var unitReqested = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_Units_" + keyVal + "]").val();
            var frequecyType = $("select[id$=DropDownList_CustomCarePlanPrescribedServices_Frequency_" + keyVal + "]")[0].value;
            if (unitReqested != "" && frequecyType != "0")
                UnitCalculation(control, keyVal);
        }



    }
    catch (err) {

        LogClientSideException(err, 'CarePlan');
    }


}


function UnitCalculation(control, keyVal) {
    try {

        //In First Step we have to perform validation
        var textBoxTPInterventionProcedureTotalUnits = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]");
        var textBoxTPInterventionProcedureUnits = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_Units_" + keyVal + "]");
        var dropdownFrequencyType = $("select[id$=DropDownList_CustomCarePlanPrescribedServices_Frequency_" + keyVal + "]");
        var textBoxTPInterventionProcedureStartDate = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_FromDate_" + keyVal + "]");
        var textBoxTPInterventionProcedureEndDate = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_ToDate_" + keyVal + "]");
        //var dropdownFrequencyType = $("select[id$=DropDownList_TPProcedures_FrequencyType]");


        //Check for all values
        if (textBoxTPInterventionProcedureUnits[0].value == "" || dropdownFrequencyType[0].selectedIndex == 0 || textBoxTPInterventionProcedureStartDate[0].value == "" || textBoxTPInterventionProcedureEndDate[0].value == "") {
            clearFields(keyVal);
            return false;
        }

        //if (control.id == textBoxTPInterventionProcedureTotalUnits[0].id) {
        if (textBoxTPInterventionProcedureUnits[0].value == "") {

            SetErrorMessageAlignment("Translate(ENTERUNITSREQUESTED,Please enter Units Requested.)");
            //ShowMsgBox('Please enter Units Requested.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
            textBoxTPInterventionProcedureUnits[0].focus();
            return false;
        }

        else if (textBoxTPInterventionProcedureUnits[0].value != "") {

            if (isNaN(parseInt(textBoxTPInterventionProcedureUnits[0].value)) == true) {

                SetErrorMessageAlignment("Translate(ENTERVALIDUNIT,Please enter Valid Unit.)");
                clearFields();
                //ShowMsgBox('Please enter Valid Unit.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureUnits[0].focus();
                return false;
            }
            if (textBoxTPInterventionProcedureUnits[0].value <= 0) {
                SetErrorMessageAlignment("Translate(ENTERVALIDUNIT,Please enter Valid Unit.)");
                clearFields();
                //ShowMsgBox('Please enter Valid Unit.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureUnits[0].focus();
                return false;
            }

        }

        if (dropdownFrequencyType[0].selectedIndex == 0) {

            SetErrorMessageAlignment("Translate(SELECTFREQUENCYTYPE,Please select Frequency Type.)");
            // ShowMsgBox('Please select Frequency Type.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
            document.getElementById(dropdownFrequencyType[0].id).focus();
            clearFields();
            return false;
        }


        if (control.id != textBoxTPInterventionProcedureStartDate[0].id && control.id != textBoxTPInterventionProcedureEndDate[0].id) {
            if (textBoxTPInterventionProcedureStartDate[0].value == '') {

                SetErrorMessageAlignment("Translate(ENTERSTARTDATE,Please enter Start Date.)");
                //ShowMsgBox('Please enter Start Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureStartDate[0].focus();
                return false;
            }
            else if (textBoxTPInterventionProcedureStartDate[0].value != '') {
                if (ValidateDateTreatmentPlan(textBoxTPInterventionProcedureStartDate[0]) == false) {
                    SetErrorMessageAlignment("Translate(ENTERVALIDSTARTDATE,Please enter valid Start Date.)");
                    // ShowMsgBox('Please enter valid Start Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    textBoxTPInterventionProcedureEndDate[0].focus();
                    return false;
                }
            }
            if (textBoxTPInterventionProcedureEndDate[0].value == '') {

                SetErrorMessageAlignment("Translate(ENTERENDDATE,Please enter End Date.)");
                //ShowMsgBox('Please enter End Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureEndDate[0].focus();
                return false;
            }
            else if (textBoxTPInterventionProcedureEndDate[0].value != '') {
                if (ValidateDateTreatmentPlan(textBoxTPInterventionProcedureEndDate[0]) == false) {
                    SetErrorMessageAlignment("Translate(ENTERVALIDENDDATE,Please enter valid End Date.)");
                    // ShowMsgBox('Please enter valid End Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    textBoxTPInterventionProcedureEndDate[0].focus();
                    return false;
                }

            }
            //Now Perform check from date is less than start date or not
            var date1 = new Date(textBoxTPInterventionProcedureStartDate[0].value);
            var date2 = new Date(textBoxTPInterventionProcedureEndDate[0].value);
            var date3 = new Date($('[id$=HiddenField_EndDate]').val());

            if (date1 > date2) {

                SetErrorMessageAlignment("Translate(TODATENOTLESSFROMDATE,To date can not be less than the from date.)");
                //ShowMsgBox('To-Date can not be less than the From-Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                return false;
            }
            else

                if (date2 > date3) {
                    SetErrorMessageAlignment("Translate(TODATENOTLESSTHANTXPLANEXPIRYDATE,To date cannot be later than the Tx Plan Expire date.)");
                    //ShowMsgBox('To-Date can not be more than the TxPlan Expiry Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    return false;
                }
        }



        if (control.id.indexOf('Text_CustomCarePlanPrescribedServices_TotalUnits_') >= 0 && textBoxTPInterventionProcedureTotalUnits[0].value != '' && parseInt(textBoxTPInterventionProcedureTotalUnits[0].value) > 0) {
            var result = textBoxTPInterventionProcedureTotalUnits[0].value;
            onSuccessUnitCalculation(result, keyVal)
        }
        else {
            var myDate = new Date();
            ShowHideErrorMessage("", 'false');
            $.post(GetRelativePath() + "Custom/CarePlan/WebPages/CarePlanAjaxScript.aspx", 'action=unitcalculation&procedureUnits=' + textBoxTPInterventionProcedureUnits[0].value + '&frequencyType=' + dropdownFrequencyType[0].value + '&startDate=' + textBoxTPInterventionProcedureStartDate[0].value + '&endDate=' + textBoxTPInterventionProcedureEndDate[0].value + '&careplanprescribedserviceid=' + keyVal, function (result) { onSuccessUnitCalculation(result, keyVal) });
        }

    }
    catch (err) {
        LogClientSideException(err, 'CarePlan');
    }

}


function onSuccessUnitCalculation(result, keyVal) {

    try {
        //var pageResponse = result;
        //var start = pageResponse.indexOf("##STARTPAGERESPONSEVALUE##") + 26;
        //var end = pageResponse.indexOf("##ENDPAGERESPONSEVALUE##");
        //pageResponse = pageResponse.substr(start, end - start);
        if (result != undefined) {

            $("[id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]").val(result);

            var Label_CustomCarePlanPrescribedServices_TotalUnits = $("[id$=Label_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]");

            Label_CustomCarePlanPrescribedServices_TotalUnits.text($("[id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]").val());

            var Label_TableName_PreviouslyRequested = $("[id$=Label_CustomCarePlanPrescribedServices_PreviouslyRequested_" + keyVal + "]");
            var Label_TableName_TotalRequestedYTD = $("[id$=Label_CustomCarePlanPrescribedServices_TotalRequestedYTD_" + keyVal + "]");



            if (!isNaN(parseInt(Label_TableName_PreviouslyRequested.text())) && !isNaN(parseInt($("[id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]")[0].value))) {
                Label_TableName_TotalRequestedYTD.text(parseInt(Label_TableName_PreviouslyRequested.text()) + parseInt($("[id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]").val()));
            }
            else if (!isNaN(parseInt($("[id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]").val()))) {

                Label_TableName_TotalRequestedYTD.text($("[id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]").val());
            }
            else {
                Label_TableName_TotalRequestedYTD.text('');
            }

            if (!isNaN(parseInt(Label_TableName_TotalRequestedYTD.text()))) {
                var LCM = $("[id$=Label_LCM_" + keyVal + "]");
                var CCM = $("[id$=Label_CCM_" + keyVal + "]");


                var valTotalReqYTD = 0;

                var valLCM = 0;
                var valCCM = 0;

                if (!isNaN(parseInt(LCM.text()))) {
                    valLCM = parseInt(LCM.text());
                }
                if (!isNaN(parseInt(CCM.text()))) {
                    valCCM = parseInt(CCM.text());
                }

                if (!isNaN(parseInt(Label_TableName_TotalRequestedYTD.text()))) {
                    valTotalReqYTD = parseInt(Label_TableName_TotalRequestedYTD.text());
                }

                var LCMAndCCMOver = 0;
                if ($("[id$=Label_LCM_" + keyVal + "]").text() != "" && valTotalReqYTD > valLCM) {
                    $("[id$=UnitOverLCM_" + keyVal + "]").css('display', 'block');
                    $("[id$=Label_LCM_Over_" + keyVal + "]").text((valTotalReqYTD - valLCM));

                    $("[id$=Label_LCM_Over_" + keyVal + "]").css('visibility', 'visible');
                    LCMAndCCMOver = LCMAndCCMOver + 1;
                }
                else {
                    $("[id$=UnitOverLCM_" + keyVal + "]").css('display', 'none');
                    $("[id$=Label_LCM_Over_" + keyVal + "]").css('visibility', 'hidden');
                    $("[id$=Label_LCM_Over_" + keyVal + "]").text('');
                }


                if ($("[id$=Label_CCM_" + keyVal + "]").text() != "" && valTotalReqYTD > valCCM) {
                    $("[id$=UnitOverCCM_" + keyVal + "]").css('display', 'block');
                    $("[id$=Label_CCM_Over_" + keyVal + "]").text((valTotalReqYTD - valCCM));

                    $("[id$=Label_CCM_Over_" + keyVal + "]").css('visibility', 'visible');
                    LCMAndCCMOver = LCMAndCCMOver + 1;
                }
                else {
                    $("[id$=UnitOverCCM_" + keyVal + "]").css('display', 'none');
                    $("[id$=Label_CCM_Over_" + keyVal + "]").css('visibility', 'hidden');
                    $("[id$=Label_CCM_Over_" + keyVal + "]").text('');
                }

                if (LCMAndCCMOver > 0)
                    $("[id$=spnLCMAndCCMOver_" + keyVal + "]").show();
                else
                    $("[id$=spnLCMAndCCMOver_" + keyVal + "]").hide();

            }
            ShowTotalUnitRequested(keyVal); //Added by Saurav Pande on 09th Feb 2012 to display total unit value
            //$('[id$=UnitOverLCM]').show();
            //$('[id$=UnitOverLCM]').hide();

        }

    }
    catch (err) {

        LogClientSideException(err, 'TPPopup');
    }


}

function ShowTotalUnitRequested(keyVal) {
    if ($("input[type=text][id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]").length > 0) {
        var totalUnits = $("input[type=text][id$=Text_CustomCarePlanPrescribedServices_TotalUnits_" + keyVal + "]");
        var UnitValues = $("[id$=Label_UnitValue_" + keyVal + "]");
        var UnitType = $("[id$=Label_UnitType_" + keyVal + "]").html();
        var requested = parseInt(UnitValues.text()) * parseInt(totalUnits[0].value);
        var msg = "";
        if (parseInt(requested) >= 0)
            msg = parseInt(totalUnits[0].value) + " Units = " + requested + " " + UnitType;
        $("[id$=Label_TotalRequestedUnits]").html('');
        $("[id$=Label_TotalRequestedUnits]").html(msg);
    }
}


function askForBillingCode(obj, keyVal) {

    if ($("[id$=TblBtnBillingCode]").length > 0) {
        var askForBillCode = $('[id$=HiddenFieldAskForBillingCode]').val();
        //BillingCodeInfoEntered = false;
        $('[id$=BillingCodeInfoEntered]').val('false');
        if (askForBillCode != "") {
            var authCodeId = $('[id$=HiddenFieldAuthorizationCodeId]').val();
            var tpProcedureId = $('[id$=HiddenFieldTPProcedureId]').val();



            var myDate = new Date();
            $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=askforbillingcode&TPProcedureId=' + tpProcedureId + '&AuthorizationCodeId=' + authCodeId + '&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) {

                if (obj.id.toString().indexOf("TextBox_TPProcedures_Units") >= 0) {
                    onSuccessAskForBillingCode_UnitCalculation(result, obj);
                }
                else
                    if (obj.id.toString().indexOf("DropDownList_TPProcedures_FrequencyType") >= 0) {
                        onSuccessAskForBillingCode_DropDownChange(result, obj);
                    }
                    else
                        if (obj.id.toString().indexOf("TextBox_TPProcedures_TotalUnits") >= 0) {
                            onSuccessAskForBillingCode_TotalUnits(result, obj);
                        }

            });
        }
        else {
            //BillingCodeInfoEntered = true;
            $('[id$=BillingCodeInfoEntered]').val('true');
            UnitCalculation(obj, keyVal);
        }
    }
    else {
        //BillingCodeInfoEntered = true;
        //$('[id$=BillingCodeInfoEntered]').val('true');
        UnitCalculation(obj, keyVal);
    }
}

function ValidateDateTreatmentPlan(input) {
    try {
        var validformat = /^\d{2}\/\d{2}\/\d{4}$/ //Basic check for format validity
        var returnval = false
        var errorMessage = "";
        if (input.value == '') {
            return;
        }
        else {
            var monthfield = input.value.split("/")[0]
            var dayfield = input.value.split("/")[1]
            var yearfield = input.value.split("/")[2]
            var dayobj = new Date(yearfield, monthfield - 1, dayfield)
            if ((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield)) {
                errorMessage = "Translate(INVALIDDAYMONTHYEAR,Invalid Day&#44; Month&#44; or Year range detected. Please correct)";
            }
            else {
                returnval = true
            }
        }
        if (returnval == false) {
            input.value = '';
            return false;
        }
        else {

            return true;
        }
    }
    catch (err) {
        LogClientSideException(err, 'HRMTreatmetPlan');
    }

}

function SetErrorMessageAlignment(message) {
    ShowHideErrorMessage(message, 'true');
    $($('[id$=SpanErrorMessage]')[0].parentNode.parentNode.parentNode.parentNode).attr('align', 'left');
    $($('[id$=SpanErrorMessage]')[0].parentNode.parentNode.parentNode.parentNode).attr('style', 'padding:5px 0 5px 0');
}

function clearFields(keyVal) {
    $("[id$=UnitOverCCM_" + keyVal + "]").css('display', 'none');
    $("[id$=Label_CCM_Over_" + keyVal + "]").css('visibility', 'hidden');
    $("[id$=Label_CCM_Over_" + keyVal + "]").text('');

    $("[id$=UnitOverLCM_" + keyVal + "]").css('display', 'none');
    $("[id$=Label_LCM_Over_" + keyVal + "]").css('visibility', 'hidden');
    $("[id$=Label_LCM_Over_" + keyVal + "]").text('');

    $("[id$=Label_TPProcedures_TotalUnits_" + keyVal + "]").text('0');
    $("[id$=TextBox_TPProcedures_TotalUnits_" + keyVal + "]").val('');
    $("[id$=Label_TableName_TotalRequestedYTD_" + keyVal + "]").text('');
}
