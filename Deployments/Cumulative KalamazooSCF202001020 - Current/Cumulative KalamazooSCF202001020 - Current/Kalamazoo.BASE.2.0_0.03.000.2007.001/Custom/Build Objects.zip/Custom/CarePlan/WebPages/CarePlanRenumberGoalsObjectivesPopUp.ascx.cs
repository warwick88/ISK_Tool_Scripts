﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using SHS.BaseLayer;

namespace SHS.SmartCare
{
    public partial class CarePlanRenumberGoalsObjectives : SHS.BaseLayer.ActivityPages.CustomActivityPage
    {

        #region Private Variable
        string _TableName = string.Empty;
        string _KeyFieldName = string.Empty;
        string _MaxNumberText = string.Empty;
        string _FieldText = string.Empty;
        string _SortFieldName = string.Empty;
        string PopupCaption = string.Empty;
        string _associatedDescription = string.Empty;
        string _domainId = string.Empty;
        #endregion
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            PanelRenumberGoal.Controls.Clear();
            HiddenFieldRelativePath.Value = Page.ResolveUrl("~/");
            SetControlValue();
            CreateControl();
        }
        /// <summary>
        /// <Description>This method is used to set title as well as for field name as per tableName</Description>
        /// </summary>
        private void SetControlValue()
        {
            string GoalNumber = GetRequestParameterValue("GoalNumber").Trim();
            _TableName = GetRequestParameterValue("tableName").Trim();
            _KeyFieldName = GetRequestParameterValue("keyFieldName").Trim();
            switch (_TableName.ToLower())
            {
                case "careplangoals":
                    _SortFieldName = "GoalNumber";
                    _MaxNumberText = "GoalNumber";
                    _FieldText = "GoalDescription";
                    PopupCaption = "Renumber Goals";
                    LitralRenumberText.Text = "Renumber Goals for Plan";
                    Literal_ReNumber.Text = "Renumber Goals";
                    HiddenFieldTableName.Value = "CarePlanGoals";
                    HiddenFieldKeyFieldName.Value = _KeyFieldName;
                    _associatedDescription = "AssociatedGoalDescription";
                    _domainId = "CarePlanDomainGoalId";
                    break;
                case "careplanobjectives":
                    _SortFieldName = "ObjectiveNumber";
                    _MaxNumberText = "ObjectiveNumber";
                    _FieldText = "ObjectiveDescription";
                    PopupCaption = "Renumber Objectives";
                    HiddenFieldTableName.Value = "CarePlanObjectives";
                    HiddenFieldKeyFieldName.Value = _KeyFieldName;
                    LitralRenumberText.Text = "Renumber Objectives for Goal #" + GoalNumber;
                    Literal_ReNumber.Text = "Renumber Objectives";
                    _associatedDescription = "AssociatedObjectiveDescription";
                    _domainId = "CarePlanDomainObjectiveId";
                    break;
            }
            ScriptManager.RegisterStartupScript(this.Page, GetType(), "SetModalTitleFunction", "parent.SetModalTitle('" + PopupCaption + "');", true);
        }

        /// <summary>
        /// <Description>Create Renumber Control</Description>
        /// </summary>
        private void CreateControl()
        {
            StringBuilder stringBuilderHTML = null;
            DataView dataViewCarePlan = null;

            using (DataSet dataSetDocumentCarePlan = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                if (dataSetDocumentCarePlan != null && dataSetDocumentCarePlan.Tables.Count > 0)
                {

                    if (dataSetDocumentCarePlan.Tables.Contains(_TableName) && dataSetDocumentCarePlan.Tables[_TableName].Rows.Count > 0)
                    {
                        dataViewCarePlan = new DataView(dataSetDocumentCarePlan.Tables[_TableName]);
                        #region through which filed we have to apply sort
                        dataViewCarePlan.Sort = _SortFieldName;
                        #endregion
                        if (_TableName.ToLower() == "careplanobjectives") { dataViewCarePlan.RowFilter = "Isnull(RecordDeleted,'N')<>'Y' and CarePlanGoalId=" + GetRequestParameterValue("GoalId").Trim(); }
                        else
                        {
                            dataViewCarePlan.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'";
                        }


                        HiddenFieldMaxNumber.Value = Convert.ToString(dataSetDocumentCarePlan.Tables[_TableName].Compute("Max(" + _MaxNumberText + ")", "Isnull(RecordDeleted,'N')<>'Y'"));
                        stringBuilderHTML = new StringBuilder();
                        for (int goalCount = 0; goalCount < dataViewCarePlan.Count; goalCount++)
                        {

                            stringBuilderHTML.Append("<table id=table_" + dataViewCarePlan[goalCount][_KeyFieldName].ToString() + "  width='96%' border='0' cellpadding='1' cellspacing='2'>"); //Create  table for UseGoal
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td style='width:10%' valign='top'>");
                            //CheckBox UseGoal 
                            string tempInterventionNumberOldValue = dataViewCarePlan[goalCount][_MaxNumberText].ToString();
                            stringBuilderHTML.Append("<input type='text' value=" + dataViewCarePlan[goalCount][_MaxNumberText].ToString() + " style='width:60%' id=TextBox_CarePlanGoals_GoalDescription_" + dataViewCarePlan[goalCount][_KeyFieldName].ToString() + " GoalId=" + dataViewCarePlan[goalCount][_KeyFieldName].ToString() + "  name=TextBox_CarePlanGoals_GoalNumber_" + dataViewCarePlan[goalCount][_KeyFieldName].ToString() + " oldValue=" + dataViewCarePlan[goalCount][_MaxNumberText].ToString() + " onblur='RenumberGoal(this);' class='form_textbox'  maxlength='10'  renumberText='renumberText' />");
                            stringBuilderHTML.Append("</td>");
                            //TextBox UseGoal
                            stringBuilderHTML.Append("<td style='width:70%'>");

                            stringBuilderHTML.Append("<textarea id=TextArea_CarePlanGoals_GoalDescription" + dataViewCarePlan[goalCount][_KeyFieldName].ToString() + " name=TextArea_CarePlanGoals_GoalDescription" + dataViewCarePlan[goalCount][_KeyFieldName].ToString() + " rows='5' cols='68' class='form_textareaWithoutWidth' disabled='disabled'>");
                            if (dataViewCarePlan[goalCount][_FieldText] != DBNull.Value || dataViewCarePlan[goalCount][_associatedDescription] != DBNull.Value)
                            {
                                if (dataViewCarePlan[goalCount][_domainId].ToString() == "" || dataViewCarePlan[goalCount][_domainId].ToString() == "-1")
                                    stringBuilderHTML.Append(dataViewCarePlan[goalCount][_associatedDescription].ToString());
                                else
                                    stringBuilderHTML.Append(dataViewCarePlan[goalCount][_FieldText].ToString() + " " + dataViewCarePlan[goalCount][_associatedDescription].ToString());
                            }
                            stringBuilderHTML.Append("</textarea>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td colspan='2' style=font-size: 11.25pt;font-weight: bold; font-family: Verdana;>");
                            stringBuilderHTML.Append("<hr style=color: #000000; height: 1px; />");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td colspan=2>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                        }
                        PanelRenumberGoal.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                    }
                }
            }

        }
    }
}
