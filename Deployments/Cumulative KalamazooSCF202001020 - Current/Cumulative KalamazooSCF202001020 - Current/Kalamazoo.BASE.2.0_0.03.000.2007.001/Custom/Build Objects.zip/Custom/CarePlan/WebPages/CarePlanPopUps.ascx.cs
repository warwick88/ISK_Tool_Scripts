﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using SHS.BaseLayer;
using DevExpress.Web.ASPxGridView;
namespace SHS.SmartCare
{
    public partial class CarePlanPopUps : SHS.BaseLayer.ActivityPages.CustomActivityPage
    {
        string PopUpcaption = string.Empty;
        string clinetName = string.Empty;
        string NeedText = string.Empty;
        string Screenname = string.Empty;
        DataSet dsMasterData = new DataSet();

        int GoalId = 0;
        protected override void OnLoad(EventArgs e)
        {
            HiddenField_CarePlanGoalId.Value = base.GetRequestParameterValue("GoalId");
            HiddenField_CarePlanDomainId.Value = base.GetRequestParameterValue("CarePlanDomainId");
            HiddenField_CarePlanObjectiveId.Value = base.GetRequestParameterValue("ObjectiveId");
            HiddenField_CarePlanPrescribedServiceId.Value = base.GetRequestParameterValue("PrescribedServiceId");
            HiddenField_CarePlanTeamId.Value = base.GetRequestParameterValue("CarePlanTeamId");
            base.OnLoad(e);
            HiddenFieldRelativePath.Value = Page.ResolveUrl("~/");
            Screenname = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.FindByScreenId(SHS.BaseLayer.BaseCommonFunctions.ScreenId).ScreenName.ToString();

            dsMasterData = CarePlan.CarePlan.GetMasterData();
            BindGridOfPopUp();

            if (SHS.BaseLayer.SharedTables.ApplicationSharedTables != null && SHS.BaseLayer.SharedTables.ApplicationSharedTables.IsDataTableFound("SystemConfigurationKeys"))
            {
                hiddenconfigurationkeyvalue.Value = SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("UseBTATemplateForGoalsAndObjectivesInCarePlan").ToString();
            }
            if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens != null)
            {
                HiddenField_CarePlanMainScreenId.Value = Convert.ToString(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens
                              .Where(x => (x.Field<string>("Code") == "8AF7837B-05A7-4DF8-B2ED-6B852A5BA50A"))
                              .Select(y => y.ScreenId).FirstOrDefault());
            }

        }

        /// <summary>
        /// <Description>This function is used to  set the form title and Label title</Description>
        /// </summary>
        private void BindGridOfPopUp()
        {
            DataSet dataSetCustomCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();
            switch (GetRequestParameterValue("PopUpAction").Trim().ToLower())
            {
                case "associatedneedswithgoals":
                    Panel_AssociatedNeeds.Visible = true;
                    Panel_GoalDescription.Visible = false;
                    Panel_AddNeeds.Visible = false;
                    Panel_EditViewObjectives.Visible = false;
                    Panel_TreatmentTeam.Visible = false;
                    Panel_AddProgramInTreatmenteam.Visible = false;
                    PopUpcaption = "Associated Needs";
                    CarePlanPopUpHeader.Text = "Associated Needs";
                    AssociatedNeedPopUp();
                    break;
                case "addneedsindomain":
                    Panel_AddNeeds.Visible = true;
                    Panel_AssociatedNeeds.Visible = false;
                    Panel_GoalDescription.Visible = false;
                    Panel_EditViewObjectives.Visible = false;
                    Panel_TreatmentTeam.Visible = false;
                    Panel_AddProgramInTreatmenteam.Visible = false;
                    PopUpcaption = "Add Needs";
                    Span_DomainName.InnerHtml = "Select the needs to be addressed for the " + base.GetRequestParameterValue("DomainName").ToHtmlDecoded();
                    CarePlanPopUpHeader.Text = "Add Needs";
                    AddNeedsPopUp();
                    break;

                case "goaldescription":
                    Panel_AssociatedNeeds.Visible = false;
                    Panel_AddNeeds.Visible = false;
                    Panel_GoalDescription.Visible = true;
                    Panel_EditViewObjectives.Visible = false;
                    Panel_TreatmentTeam.Visible = false;
                    Panel_AddProgramInTreatmenteam.Visible = false;
                    PopUpcaption = "Goal Description";
                    Span_AssocitedNeedName.InnerHtml = "Select the goal description based on the following needs: " + base.GetRequestParameterValue("AssociatedNeedNames").ToHtmlDecoded().Replace('\n', ',');
                    GoalDesciptionPopUp();
                    break;

                case "objectivedescription":
                    Panel_AssociatedNeeds.Visible = false;
                    Panel_AddNeeds.Visible = false;
                    Panel_GoalDescription.Visible = false;
                    Panel_ObjectiveDescription.Visible = true;
                    Panel_EditViewObjectives.Visible = false;
                    Panel_TreatmentTeam.Visible = false;
                    Panel_AddProgramInTreatmenteam.Visible = false;
                    PopUpcaption = "Objective Description";
                    Span_GoalDescription.InnerHtml = "  " + base.GetRequestParameterValue("GoalDescription").ToHtmlDecoded();//---------------Goal Description-------------
                    ObjectiveDesciptionPopUp();

                    break;
                case "editviewobjectives":
                    Panel_AssociatedNeeds.Visible = false;
                    Panel_AddNeeds.Visible = false;
                    Panel_GoalDescription.Visible = false;
                    Panel_ObjectiveDescription.Visible = false;
                    Panel_EditViewObjectives.Visible = true;
                    Panel_TreatmentTeam.Visible = false;
                    Panel_AddProgramInTreatmenteam.Visible = false;
                    PopUpcaption = "Link/Unlink Objectives";
                    Span_ServiceGroup.InnerHtml = "Specify active objectives to be addressed by " + base.GetRequestParameterValue("PrescribedServiceName").ToHtmlDecoded() + " services";//---------------Goal Description-------------
                    CarePlanPopUpHeader.Text = "Link/Unlink Objectives";
                    EditViewObjectivesPopUp();

                    break;

                case "treatmentteam":
                    Panel_AssociatedNeeds.Visible = false;
                    Panel_AddNeeds.Visible = false;
                    Panel_GoalDescription.Visible = false;
                    Panel_ObjectiveDescription.Visible = false;
                    Panel_EditViewObjectives.Visible = false;
                    Panel_TreatmentTeam.Visible = true;
                    Panel_AddProgramInTreatmenteam.Visible = false;
                    PopUpcaption = "Treatment Program";
                    CarePlanPopUpHeader.Text = "Treatment Program";
                    TreatmentTeamPopUp();

                    break;
                case "addtreatmenteammember":
                    Panel_AssociatedNeeds.Visible = false;
                    Panel_AddNeeds.Visible = false;
                    Panel_GoalDescription.Visible = false;
                    Panel_ObjectiveDescription.Visible = false;
                    Panel_EditViewObjectives.Visible = false;
                    Panel_TreatmentTeam.Visible = false;
                    Panel_AddProgramInTreatmenteam.Visible = true;
                    PopUpcaption = "Add Treatment Team Member";
                    CarePlanPopUpHeader.Text = "Add Treatment Team Member";
                    AddNewTreatmenTeamMember();

                    break;
            }

            if (PopUpcaption.Length > 0)
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "SetModalTitleFunction", "parent.SetModalTitle('" + PopUpcaption + "');", true);
        }

        /// <summary>
        /// <purpose>Get Checkbox HTML for AssociatedNeeds PopUp</purpose>
        /// </summary>
        /// <param name="NeedId"></param>
        public string GetCheckboxHTML(string NeedId)
        {
            string result = "";
            DataSet dataSetCustomCarePlan = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
            string needId = string.Empty;
            string needDescription = string.Empty;
            string domainGoalId = string.Empty;
            string goalNeedId = string.Empty;
            string associatedGoalNeedId = string.Empty;
            DataRow[] datarowDocumentGoals = dataSetCustomCarePlan.Tables["CarePlanGoals"].Select("CarePlanGoalId=" + HiddenField_CarePlanGoalId.Value.ToString() + " and ISNULL(RecordDeleted,'N')='N' ");
            if (datarowDocumentGoals.Length > 0)
            {
                domainGoalId = datarowDocumentGoals[0]["CarePlanDomainGoalId"].ToString();
            }

            DataRow[] datarowNeeds = dataSetCustomCarePlan.Tables["CarePlanGoalNeeds"].Select("CarePlanGoalId=" + HiddenField_CarePlanGoalId.Value.ToString() + " AND CarePlanNeedId=" + NeedId + " and ISNULL(RecordDeleted,'N')='N' ");
            if (datarowNeeds.Length > 0)
            {
                goalNeedId = Convert.ToString(datarowNeeds[0]["CarePlanGoalNeedId"]);
                needId = Convert.ToString(datarowNeeds[0]["CarePlanNeedId"]);
                needDescription = Convert.ToString(datarowNeeds[0]["AssociatedNeedDescription"]);

                if (dataSetCustomCarePlan.Tables.Contains("CarePlanNeeds") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanNeeds"], 0))
                {
                    DataRow[] datarowDomainNeeds = dataSetCustomCarePlan.Tables["CarePlanNeeds"].Select("CarePlanNeedId=" + needId);
                    if (datarowDomainNeeds.Length > 0)
                    {

                        foreach (DataRow drDomainNeeds in datarowDomainNeeds)
                        {
                            if (dsMasterData.Tables.Contains("CarePlanDomainGoals") && BaseCommonFunctions.CheckRowExists(dsMasterData.Tables["CarePlanDomainGoals"], 0))
                            {
                                DataTable datatableDomainGoals = dsMasterData.Tables["CarePlanDomainGoals"];
                                if (domainGoalId != "")
                                {
                                    DataRow[] datarowDomainGoalsToAssociate = datatableDomainGoals.Select("CarePlanDomainNeedId=" + drDomainNeeds["CarePlanDomainNeedId"].ToString() + " and CarePlanDomainGoalId=" + domainGoalId);
                                    if (datarowDomainGoalsToAssociate.Length > 0)
                                    {
                                        associatedGoalNeedId = datarowDomainGoalsToAssociate[0]["CarePlanDomainGoalId"].ToString();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (goalNeedId != "")
            {
                if (associatedGoalNeedId == domainGoalId && associatedGoalNeedId != "" && domainGoalId != "")
                {
                    result = "<input type=\"checkbox\" class=\"checkbox_AssociatedNeeds\" tobeassociated=\"1\" checked=\"checked\"  id=\"checkbox_" + NeedId + "\" name=\"checkbox_" + NeedId + "\" primarykey=\"" + NeedId + "\" desc=\"" + needDescription + "\" />";
                }
                else
                {
                    result = "<input type=\"checkbox\" class=\"checkbox_AssociatedNeeds\" tobeassociated=\"0\" checked=\"checked\"  id=\"checkbox_" + NeedId + "\" name=\"checkbox_" + NeedId + "\" primarykey=\"" + NeedId + "\" desc=\"" + needDescription + "\"/>";
                }
            }
            else
            {
                result = "<input type=\"checkbox\"  class=\"checkbox_AssociatedNeeds\" tobeassociated=\"0\" id=\"checkbox_" + NeedId + "\" name=\"checkbox_" + NeedId + "\" primarykey=\"" + NeedId + "\" desc=\"" + needDescription + "\"/>";
            }

            return result;
        }

        /// <summary>
        /// <purpose>Get Radio button  HTML forGoalDescription PopUp</purpose>
        /// </summary>
        /// <param name="DomainGoalId"></param>
        public string GetGoalDescriptionRadioButtonHTML(string DomainGoalId)
        {
            string result = "";
            DataSet dataSetCustomCarePlan = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
            int goalId = 0;
            string goalDescription = string.Empty;
            int _domainGoalId = 0;
            DataRow[] datarowGoals = dataSetCustomCarePlan.Tables["CarePlanGoals"].Select("CarePlanGoalId=" + HiddenField_CarePlanGoalId.Value.ToString() + " AND ISNULL(RecordDeleted,'N')='N' ");

            if (datarowGoals.Length > 0)
            {
                goalId = Convert.ToInt32(datarowGoals[0]["CarePlanGoalId"]);
                goalDescription = Convert.ToString(datarowGoals[0]["AssociatedGoalDescription"]);

                if (goalId != 0 && (DomainGoalId == Convert.ToString(datarowGoals[0]["CarePlanDomainGoalId"]) || DomainGoalId == "-1"))
                {
                    result = "<input type=\"radio\" class=\"radio_Description\"  checked=\"checked\"  id=\"radio_" + DomainGoalId + "\" name=\"radio_Goaldescription\" primarykey=\"" + DomainGoalId + "\" desc=\"" + goalDescription + "\" />";
                }
                else
                {
                    result = "<input type=\"radio\" class=\"radio_Description\"  id=\"radio_" + DomainGoalId + "\" name=\"radio_Goaldescription\" primarykey=\"" + DomainGoalId + "\" desc=\"" + goalDescription + "\"/>";
                }
            }
            else
            {
                result = "<input type=\"radio\" class=\"radio_Description\" checked=\"checked\"  id=\"radio_" + DomainGoalId + "\" name=\"radio_Goaldescription\" primarykey=\"" + DomainGoalId + "\" desc=\"" + goalDescription + "\"/>";
            }

            return result;
        }

        /// <summary>
        /// <purpose>Get Radio button  HTML for ObjectiveDescription PopUp</purpose>
        /// </summary>
        /// <param name="DomainObjectiveId"></param>
        public string GetObjectiveDescriptionRadioButtonHTML(string DomainObjectiveId)
        {
            string result = "";
            DataSet dataSetCustomCarePlan = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
            string goalId = string.Empty; ;
            string objectiveId = base.GetRequestParameterValue("ObjectiveId");
            DataRow[] datarowObjectives = dataSetCustomCarePlan.Tables["CarePlanObjectives"].Select("CarePlanDomainObjectiveId=" + DomainObjectiveId + " and  CarePlanObjectiveId=" + objectiveId + "  and ISNULL(RecordDeleted,'N')='N' ");
            string objectiveDescription = string.Empty;

            if (datarowObjectives.Length > 0)
            {
                goalId = datarowObjectives[0]["CarePlanGoalId"].ToString();
                objectiveDescription = datarowObjectives[0]["AssociatedObjectiveDescription"].ToString();
            }
            else
            {
                DataRow[] drOtherRow = dataSetCustomCarePlan.Tables["CarePlanObjectives"].Select("CarePlanObjectiveId=" + objectiveId + "  and ISNULL(RecordDeleted,'N')='N' ");
                if (drOtherRow.Length > 0)
                {
                    objectiveDescription = drOtherRow[0]["AssociatedObjectiveDescription"].ToString();
                }
            }
            if (objectiveDescription.Length > 0)
            {
                objectiveDescription = objectiveDescription.EncodeDoubleQuoteDyanmicHTMLControlValues();
            }
            if (goalId != "" || DomainObjectiveId == "-1")
            {
                result = "<input type=\"radio\" class=\"radio_Description\" checked=\"checked\"  id=\"radio_" + DomainObjectiveId + "\" name=\"radio_ObjectiveDescription\" primarykey=\"" + DomainObjectiveId + "\" desc=\"" + objectiveDescription + "\"/>";
            }
            else
            {
                result = "<input type=\"radio\" class=\"radio_Description\" id=\"radio_" + DomainObjectiveId + "\" name=\"radio_ObjectiveDescription\" primarykey=\"" + DomainObjectiveId + "\" desc=\"" + objectiveDescription + "\"/>";
            }

            return result;
        }

        /// <summary>
        /// <purpose>Get Checkbox HTML for Edit/View Objective PopUp</purpose>
        /// </summary>
        /// <param name="NeedId"></param>
        public string GetEditViewObjectiveCheckboxHTML(string ObjectiveId)
        {
            string result = "";
            DataSet dataSetCustomCarePlan = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
            int prescribedServiceObjectiveId = 0;
            DataRow[] datarowObjectives = dataSetCustomCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanPrescribedServiceId=" + HiddenField_CarePlanPrescribedServiceId.Value.ToString() + " AND CarePlanObjectiveId=" + ObjectiveId + "  and ISNULL(RecordDeleted,'N')='N' ");
            if (datarowObjectives.Length > 0)
            {
                prescribedServiceObjectiveId = Convert.ToInt32(datarowObjectives[0]["CarePlanPrescribedServiceObjectiveId"]);
            }
            if (prescribedServiceObjectiveId != 0)
            {
                result = "<input type=\"checkbox\" class=\"checkbox_AssociatedObjectives\" tobeassociated=\"1\" checked=\"checked\"  id=\"checkbox_" + ObjectiveId + "\" name=\"checkbox_" + ObjectiveId + "\"/>";
            }
            else
            {
                result = "<input type=\"checkbox\"  class=\"checkbox_AssociatedObjectives\" tobeassociated=\"0\" id=\"checkbox_" + ObjectiveId + "\" name=\"checkbox_" + ObjectiveId + "\"/>";
            }

            return result;
        }

        /// <summary>
        /// <purpose>Bind Grid  for AddNeedsPopUp </purpose>
        /// </summary>
        public void AddNeedsPopUp()
        {
            string domainNeedId = string.Empty;
            string domainId = string.Empty;
            domainId = base.GetRequestParameterValue("CarePlanDomainId");
            DataSet dataSetCustomCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();

            DataTable datatableDomainNeeds = dataSetCustomCarePlan.Tables["CarePlanNeeds"];
            DataRow[] datarowDomainNeeds = datatableDomainNeeds.Select(" ISNULL(RecordDeleted,'N')='N' ");
            if (dataSetCustomCarePlan.Tables.Contains("CarePlanNeeds") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanNeeds"], 0))
            {
                if (datarowDomainNeeds.Length > 0)
                {
                    int lengthflag = 1;
                    foreach (DataRow drDomainNeeds in datarowDomainNeeds)
                    {
                        if (lengthflag != datarowDomainNeeds.Length)
                        {
                            domainNeedId = domainNeedId + drDomainNeeds["CarePlanDomainNeedId"].ToString() + ",";
                        }
                        else
                        {
                            domainNeedId = domainNeedId + drDomainNeeds["CarePlanDomainNeedId"].ToString();
                        }
                        lengthflag++;
                    }
                }
            }
            if (dsMasterData.Tables.Contains("CarePlanDomainNeeds") && BaseCommonFunctions.CheckRowExists(dsMasterData.Tables["CarePlanDomainNeeds"], 0))
            {
                DataRow[] datarowNeeds = null;
                if (!string.IsNullOrEmpty(domainNeedId))
                {
                    datarowNeeds = dsMasterData.Tables["CarePlanDomainNeeds"].Select("CarePlanDomainId=" + domainId + " and CarePlanDomainNeedId not in(" + domainNeedId + ")");
                }
                else
                {
                    datarowNeeds = dsMasterData.Tables["CarePlanDomainNeeds"].Select("CarePlanDomainId=" + domainId);
                }
                if (datarowNeeds.Length > 0)
                {
                    DataTable dataTableToBindAddNeedsGrid = new DataTable();
                    dataTableToBindAddNeedsGrid.Columns.Add("DomainNeedId");
                    dataTableToBindAddNeedsGrid.Columns.Add("NeedName");
                    foreach (DataRow datarowCurrent in datarowNeeds)
                    {
                        DataRow datarowNewRow = dataTableToBindAddNeedsGrid.NewRow();
                        datarowNewRow["DomainNeedId"] = datarowCurrent["CarePlanDomainNeedId"];
                        datarowNewRow["NeedName"] = datarowCurrent["NeedName"];
                        dataTableToBindAddNeedsGrid.Rows.Add(datarowNewRow);
                    }
                    DataView dvNeeds = new DataView(dataTableToBindAddNeedsGrid);
                    dvNeeds.Sort = "NeedName";
                    GridViewCarePlanAddNeeds.DataSource = dvNeeds;
                    GridViewCarePlanAddNeeds.DataBind();
                }
            }
        }

        /// <summary>
        /// <purpose>Bind Grid  for AssociatedNeed Pop Up</purpose>
        /// </summary>
        public void AssociatedNeedPopUp()
        {
            GoalId = Convert.ToInt32(base.GetRequestParameterValue("GoalId"));
            DataSet dataSetCustomCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();
            if (dataSetCustomCarePlan.Tables.Contains("CarePlanGoals"))
            {
                DataTable datatableGoals = dataSetCustomCarePlan.Tables["CarePlanGoals"];
                DataRow[] datarowGoals = datatableGoals.Select("CarePlanGoalId=" + GoalId);
                if (datarowGoals.Length > 0)
                {
                    string goalNumber = Convert.ToString(datarowGoals[0]["GoalNumber"]);
                    Span_GoalNumber.InnerHtml = "Needs to be addressed on the " + Screenname + " associated with Goal " + goalNumber.ToHtmlDecoded() + ":";
                }
            }

            if (dataSetCustomCarePlan.Tables.Contains("CarePlanNeeds") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanNeeds"], 0))
            {
                DataTable datatableDocumentNeeds = dataSetCustomCarePlan.Tables["CarePlanNeeds"];
                DataRow[] datarowNeedsToAssociate = datatableDocumentNeeds.Select("AddressOnCarePlan='Y' AND ISNULL(RecordDeleted,'N')='N'");
                DataTable dataTableToBindAssociatedNeedsGrid = new DataTable();
                dataTableToBindAssociatedNeedsGrid.Columns.Add("NeedId");
                dataTableToBindAssociatedNeedsGrid.Columns.Add("NeedName");
                foreach (DataRow datarowCurrent in datarowNeedsToAssociate)
                {
                    DataRow datarowNewRow = dataTableToBindAssociatedNeedsGrid.NewRow();
                    datarowNewRow["NeedId"] = datarowCurrent["CarePlanNeedId"];
                    datarowNewRow["NeedName"] = datarowCurrent["NeedName"];
                    dataTableToBindAssociatedNeedsGrid.Rows.Add(datarowNewRow);
                }
                DataView dvSortedNeeds = new DataView(dataTableToBindAssociatedNeedsGrid);
                dvSortedNeeds.Sort = "NeedName";
                GridViewCarePlanAssociatedNeeds.DataSource = dvSortedNeeds;
                GridViewCarePlanAssociatedNeeds.DataBind();
            }
        }

        /// <summary>
        /// <purpose>Bind Grid  for GoalDescription Pop Up</purpose>
        /// </summary>
        /// <param name="adultType"></param>
        public void GoalDesciptionPopUp()
        {
            GoalId = Convert.ToInt32(base.GetRequestParameterValue("GoalId"));
            DataSet dataSetCustomCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();
            string adultType = string.Empty;

            if (dataSetCustomCarePlan.Tables.Contains("CarePlanGoals") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanGoals"], 0))
            {
                DataTable datatableGoals = dataSetCustomCarePlan.Tables["CarePlanGoals"];
                DataRow[] datarowGoals = datatableGoals.Select("CarePlanGoalId=" + GoalId);
                if (datarowGoals.Length > 0)
                {
                    string goalNumber = Convert.ToString(datarowGoals[0]["GoalNumber"]);
                    CarePlanPopUpHeader.Text = " Goal " + goalNumber + " Description";
                }
            }

            if (dataSetCustomCarePlan.Tables.Contains("DocumentCarePlans") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["DocumentCarePlans"], 0))
            {
                DataTable datatableCarePlans = dataSetCustomCarePlan.Tables["DocumentCarePlans"];
                clinetName = datatableCarePlans.Rows[0]["NameInGoalDescriptions"].ToString();

            }
            if (dataSetCustomCarePlan.Tables.Contains("CarePlanGoalNeeds") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanGoalNeeds"], 0))
            {
                DataTable datatableGoalNeeds = dataSetCustomCarePlan.Tables["CarePlanGoalNeeds"];
                DataRow[] datarowNeeds = datatableGoalNeeds.Select("CarePlanGoalId=" + GoalId + " and ISNULL(RecordDeleted,'N')='N'");
                if (datarowNeeds.Length > 0)
                {
                    DataTable datatableDomainGoalsBindGridAdult = new DataTable();
                    datatableDomainGoalsBindGridAdult.Columns.Add("DomainGoalId");
                    datatableDomainGoalsBindGridAdult.Columns.Add("GoalDescription");
                    DataTable datatableDomainGoalsAdult = new DataTable();

                    foreach (DataRow drNeeds in datarowNeeds)
                    {
                        if (dataSetCustomCarePlan.Tables.Contains("CarePlanNeeds") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanNeeds"], 0))
                        {
                            DataRow[] datarowDomainNeeds = dataSetCustomCarePlan.Tables["CarePlanNeeds"].Select("CarePlanNeedId=" + drNeeds["CarePlanNeedId"].ToString() + " and  ISNULL(RecordDeleted,'N')='N'");
                            if (datarowDomainNeeds.Length > 0)
                            {

                                foreach (DataRow drDomainNeeds in datarowDomainNeeds)
                                {
                                    int domainNeedId = Convert.ToInt32(drDomainNeeds["CarePlanDomainNeedId"]);
                                    if (dsMasterData.Tables.Contains("CarePlanDomainGoals") && BaseCommonFunctions.CheckRowExists(dsMasterData.Tables["CarePlanDomainGoals"], 0))
                                    {
                                        datatableDomainGoalsAdult = dsMasterData.Tables["CarePlanDomainGoals"];

                                        DataRow[] datarowDomainGoalsToAssociateAdullt = datatableDomainGoalsAdult.Select("CarePlanDomainNeedId=ISNULL(" + drDomainNeeds["CarePlanDomainNeedId"].ToString() + ",-1)");
                                        if (datarowDomainGoalsToAssociateAdullt.Length > 0)
                                        {
                                            foreach (DataRow datarowCurrent in datarowDomainGoalsToAssociateAdullt)
                                            {
                                                DataRow datarowNewRow = datatableDomainGoalsBindGridAdult.NewRow();
                                                datarowNewRow["DomainGoalId"] = datarowCurrent["CarePlanDomainGoalId"];

                                                if (SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("UseBTATemplateForGoalsAndObjectivesInCarePlan").ToString() == "Yes")
                                                {
                                                    datarowNewRow["GoalDescription"] = datarowCurrent["GoalDescription"];
                                                }
                                                else
                                                {
                                                    datarowNewRow["GoalDescription"] = clinetName + " " + datarowCurrent["GoalDescription"];
                                                }
                                              
                                               
                                                datatableDomainGoalsBindGridAdult.Rows.Add(datarowNewRow);
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }
                    DataRow datarowNewRowNoneOption = datatableDomainGoalsBindGridAdult.NewRow();
                    datarowNewRowNoneOption["DomainGoalId"] = -1;
                    datarowNewRowNoneOption["GoalDescription"] = "Other";
                    datatableDomainGoalsBindGridAdult.Rows.InsertAt(datarowNewRowNoneOption, 0);


                    GridViewCarePlanGoalDescription.DataSource = datatableDomainGoalsBindGridAdult;
                    GridViewCarePlanGoalDescription.DataBind();
                }
            }
        }

        /// <summary>
        /// <purpose>Bind Grid  for ObjectiveDesciption  Pop Up</purpose>
        /// </summary>
        /// <param name="adultType"></param>
        public void ObjectiveDesciptionPopUp()
        {
            string strObjectiveId = Convert.ToString(base.GetRequestParameterValue("ObjectiveId"));
            int ObjectiveId = 0;
            int.TryParse(strObjectiveId, out ObjectiveId);

            GoalId = Convert.ToInt32(base.GetRequestParameterValue("GoalId"));
            DataSet dataSetCustomCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();

            string adultType = string.Empty;


            if (dataSetCustomCarePlan.Tables.Contains("CarePlanObjectives") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanObjectives"], 0))
            {
                DataTable datatableObjectives = dataSetCustomCarePlan.Tables["CarePlanObjectives"];
                DataRow[] datarowObjectives = datatableObjectives.Select("CarePlanGoalId=" + GoalId + " AND CarePlanObjectiveId=" + ObjectiveId);
                if (datarowObjectives.Length > 0)
                {
                    string objectiveNumber = Convert.ToString(datarowObjectives[0]["ObjectiveNumber"]);
                    CarePlanPopUpHeader.Text = "Objective " + objectiveNumber + " Description";
                }
            }
            if (dataSetCustomCarePlan.Tables.Contains("DocumentCarePlans") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["DocumentCarePlans"], 0))
            {
                DataTable datatableCarePlans = dataSetCustomCarePlan.Tables["DocumentCarePlans"];
                clinetName = datatableCarePlans.Rows[0]["NameInGoalDescriptions"].ToString();

            }
            if (dataSetCustomCarePlan.Tables.Contains("CarePlanGoals") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanGoals"], 0))
            {
                DataTable datatableGoals = dataSetCustomCarePlan.Tables["CarePlanGoals"];
                DataRow[] datarowGoals = datatableGoals.Select("CarePlanGoalId=" + GoalId + " and  ISNULL(RecordDeleted,'N')='N' ");
                if (datarowGoals.Length > 0)
                {
                    string domainGoalId = datarowGoals[0]["CarePlanDomainGoalId"].ToString();
                    if (domainGoalId == "")
                        domainGoalId = "-1";
                    if (domainGoalId != "")
                    {
                        DataTable datatableDomainObjectivesBindGrid = new DataTable();
                        datatableDomainObjectivesBindGrid.Columns.Add("DomainObjectiveId");
                        datatableDomainObjectivesBindGrid.Columns.Add("ObjectiveDescription");

                        if (dsMasterData.Tables.Contains("CarePlanDomainObjectives") && BaseCommonFunctions.CheckRowExists(dsMasterData.Tables["CarePlanDomainObjectives"], 0))
                        {
                            DataTable datatableDomainObjectives = new DataTable();
                            datatableDomainObjectives = dsMasterData.Tables["CarePlanDomainObjectives"];

                            DataRow[] datarowDomainObjectiveToAssociate = datatableDomainObjectives.Select("CarePlanDomainGoalId=" + domainGoalId);
                            if (datarowDomainObjectiveToAssociate.Length > 0)
                            {
                                foreach (DataRow datarowCurrent in datarowDomainObjectiveToAssociate)
                                {
                                    DataRow datarowNewRow = datatableDomainObjectivesBindGrid.NewRow();
                                    datarowNewRow["DomainObjectiveId"] = datarowCurrent["CarePlanDomainObjectiveId"];

                                    if (SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("UseBTATemplateForGoalsAndObjectivesInCarePlan").ToString() == "Yes")
                                    {
                                        datarowNewRow["ObjectiveDescription"] = datarowCurrent["ObjectiveDescription"];
                                    }
                                    else
                                    {
                                        datarowNewRow["ObjectiveDescription"] = clinetName + " " + datarowCurrent["ObjectiveDescription"];
                                    }
                                   
                                   
                                    datatableDomainObjectivesBindGrid.Rows.Add(datarowNewRow);
                                }
                            }
                        }

                        DataRow datarowNewRowNoneOption = datatableDomainObjectivesBindGrid.NewRow();
                        datarowNewRowNoneOption["DomainObjectiveId"] = -1;
                        datarowNewRowNoneOption["ObjectiveDescription"] = "Other";
                        datatableDomainObjectivesBindGrid.Rows.InsertAt(datarowNewRowNoneOption, 0);

                        GridViewCarePlanObjectiveDescription.DataSource = datatableDomainObjectivesBindGrid;
                        GridViewCarePlanObjectiveDescription.DataBind();
                    }
                }
            }
        }

        /// <summary>
        /// <purpose>Bind Grid  for EditViewObjectives Pop Up</purpose>
        /// </summary>
        public void EditViewObjectivesPopUp()
        {
            DataSet dataSetCustomCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();
            if (dataSetCustomCarePlan.Tables.Contains("DocumentCarePlans") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["DocumentCarePlans"], 0))
            {
                DataTable datatableCarePlans = dataSetCustomCarePlan.Tables["DocumentCarePlans"];
                clinetName = datatableCarePlans.Rows[0]["NameInGoalDescriptions"].ToString();
            }
            if (dataSetCustomCarePlan.Tables.Contains("CarePlanObjectives") && BaseCommonFunctions.CheckRowExists(dataSetCustomCarePlan.Tables["CarePlanObjectives"], 0))
            {
                DataTable datatableDocumentObjective = dataSetCustomCarePlan.Tables["CarePlanObjectives"];
                DataRow[] datarowObjectiveToAssociate = datatableDocumentObjective.Select("Status='A' AND ISNULL(RecordDeleted,'N')='N'", "ObjectiveNumber Asc");
                DataTable dataTableToBindAssociatedObjectiveGrid = new DataTable();
                dataTableToBindAssociatedObjectiveGrid.Columns.Add("ObjectiveId");
                dataTableToBindAssociatedObjectiveGrid.Columns.Add("ObjectiveDescription");
                foreach (DataRow datarowCurrent in datarowObjectiveToAssociate)
                {
                    DataRow datarowNewRow = dataTableToBindAssociatedObjectiveGrid.NewRow();
                    datarowNewRow["ObjectiveId"] = datarowCurrent["CarePlanObjectiveId"];
                    if (datarowCurrent["CarePlanDomainObjectiveId"] == DBNull.Value || Convert.ToString(datarowCurrent["CarePlanDomainObjectiveId"].ToString()) == "-1")
                        datarowNewRow["ObjectiveDescription"] = datarowCurrent["AssociatedObjectiveDescription"] + " (" + datarowCurrent["ObjectiveNumber"] + ")";
                    else
                        datarowNewRow["ObjectiveDescription"] = clinetName + " " + datarowCurrent["ObjectiveDescription"] + " (" + datarowCurrent["ObjectiveNumber"] + ")";
                    dataTableToBindAssociatedObjectiveGrid.Rows.Add(datarowNewRow);
                }

                DivGridContainerEditViewObjectives.DataSource = dataTableToBindAssociatedObjectiveGrid;
                DivGridContainerEditViewObjectives.DataBind();
            }
        }

        /// <summary>
        /// <Description>This function is used to  Supports/Treatment Team Tab,Pop Up</Description>
        /// </summary>
        public void TreatmentTeamPopUp()
        {
            int ClientId = 0;
            ClientId = Convert.ToInt32(SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId);
            DataView dataViewStaff = null;
            string carePlanTeamIdVal = Convert.ToString(base.GetRequestParameterValue("CarePlanTeamId")).Trim();
            string programIdVal = Convert.ToString(base.GetRequestParameterValue("ProgramId")).Trim();
            string staffIdVal = Convert.ToString(base.GetRequestParameterValue("StaffId")).Trim();

            int CarePlanTeamId = string.IsNullOrEmpty(carePlanTeamIdVal) ? 0 : Convert.ToInt32(carePlanTeamIdVal);

            string AssignForContribution = base.GetRequestParameterValue("AssignForContribution");
            string flagValueForEdit = base.GetRequestParameterValue("flagValueForEdit"); ;

            using (SHS.UserBusinessServices.CoreCarePlan objectiveClientPrograms = new SHS.UserBusinessServices.CoreCarePlan())
            {
                DataSet datasetClientPrograms = new DataSet();
                datasetClientPrograms = objectiveClientPrograms.GetClientPrograms(ClientId, -1);
                if (datasetClientPrograms.Tables.Contains("TableClientPrograms"))
                {
                    if (BaseCommonFunctions.CheckRowExists(datasetClientPrograms, "TableClientPrograms", 0))
                    {
                        DropDownList_CarePlanPrograms_ProgramId.DataSource = datasetClientPrograms.Tables["TableClientPrograms"];
                        DropDownList_CarePlanPrograms_ProgramId.DataTextField = "ProgramName";
                        DropDownList_CarePlanPrograms_ProgramId.DataValueField = "ProgramId";
                        DropDownList_CarePlanPrograms_ProgramId.DataBind();
                        DropDownList_CarePlanPrograms_ProgramId.SelectedValue = programIdVal;
                    }
                }
            }

            if (programIdVal.Trim() != "")
            {
                using (SHS.UserBusinessServices.CoreCarePlan objectiveStaffListByPrograms = new SHS.UserBusinessServices.CoreCarePlan())
                {
                    DataSet datasetStaffListByPrograms = new DataSet();
                    datasetStaffListByPrograms = objectiveStaffListByPrograms.GetStaffListByProgramsId(Convert.ToInt32(programIdVal));
                    if (datasetStaffListByPrograms.Tables.Contains("TableStaffList"))
                    {
                        if (BaseCommonFunctions.CheckRowExists(datasetStaffListByPrograms, "TableStaffList", 0))
                        {
                            dataViewStaff = new DataView(datasetStaffListByPrograms.Tables["TableStaffList"]);
                            DropDownList_CarePlanPrograms_StaffId.DataTextField = "StaffName";
                            DropDownList_CarePlanPrograms_StaffId.DataValueField = "StaffId";
                            DropDownList_CarePlanPrograms_StaffId.DataSource = dataViewStaff;
                            DropDownList_CarePlanPrograms_StaffId.DataBind();
                            DropDownList_CarePlanPrograms_StaffId.SelectedValue = staffIdVal;
                        }
                    }
                }
            }
            if (AssignForContribution == "Y")
                Radio_Y_CarePlanPrograms_AssignForContribution.Checked = true;
            else
                if (AssignForContribution == "N")
                    Radio_N_CarePlanPrograms_AssignForContribution.Checked = true;
        }

        /// <summary>
        /// <Description>This function is used to  Supports/Treatment Team Tab,Pop Up When Save Document</Description>
        /// </summary>
        public void AddNewTreatmenTeamMember()
        {
            int clientId = 0, staffId = 0;
            clientId = Convert.ToInt32(SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId);
            staffId = Convert.ToInt32(SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.LoggedInUser.LoggedinUserId);

            using (SHS.UserBusinessServices.CarePlan objectiveClientPrograms = new SHS.UserBusinessServices.CarePlan())
            {
                DataSet datasetClientPrograms = new DataSet();
                datasetClientPrograms = objectiveClientPrograms.GetClientPrograms(clientId, staffId);
                if (datasetClientPrograms.Tables.Contains("TableClientPrograms"))
                {
                    if (BaseCommonFunctions.CheckRowExists(datasetClientPrograms, "TableClientPrograms", 0))
                    {
                        DropDownList_DocumentCarePlans_Program.DataSource = datasetClientPrograms.Tables["TableClientPrograms"];
                        DropDownList_DocumentCarePlans_Program.DataTextField = "ProgramName";
                        DropDownList_DocumentCarePlans_Program.DataValueField = "ProgramId";
                        DropDownList_DocumentCarePlans_Program.DataBind();
                    }
                }
            }
        }


    }
}