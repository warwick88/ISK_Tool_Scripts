﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using SHS.BaseLayer;
using System.Reflection;
using System.IO;
using System.Xml;
using SHS.BaseLayer.ActivityPages;
using CarePlan;
using System.Web.Script.Serialization;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Data.SqlClient;

namespace SHS.SmartCare
{
    public partial class CarePlanMain : DocumentDataActivityMultiTabPage
    {
        private JavaScriptSerializer objectJavaScriptSerializer = null;
        DataSet dsMasterData = new DataSet();
        public string Screenname = string.Empty;
        public int ScreenIdOfManinPage=0;
        public int ScreenIdOfPopUpPage = 0; 
        public override string DefaultTab
        {
            get { return "/Custom/CarePlan/WebPages/CarePlanGeneral.ascx"; }
        }

        public override string MultiTabControlName
        {
            get { return CarePlanTabPageInstance.ID; }
        }

        public override void setTabIndex(int TabIndex, out ControlCollection ctlcollection, out string UcPath)
        {
            CarePlanTabPageInstance.ActiveTabIndex = (short)TabIndex;
            ctlcollection = CarePlanTabPageInstance.TabPages[TabIndex].Controls;
            UcPath = CarePlanTabPageInstance.TabPages[TabIndex].Name;
        }
      
        public override void BindControls()
            {
                GetScreenIdByCode();
                
            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            Screenname = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.FindByScreenId(SHS.BaseLayer.BaseCommonFunctions.ScreenId).ScreenName.ToString();
            dsMasterData = CarePlan.CarePlan.GetMasterData();
            HiddenField_ReviewSettngs.Value = SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("SetReviewInCarePlan").ToString().Trim();
        }
        public void GetScreenIdByCode()
        {
            DataRow[] drScreensForMain = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.Select("Code = '8AF7837B-05A7-4DF8-B2ED-6B852A5BA50A'");
            if (drScreensForMain.Length > 0)
            {
                int.TryParse(drScreensForMain[0]["ScreenId"].ToString(), out ScreenIdOfManinPage);
            }
            DataRow[] drScreensForPopUp = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.Select("Code = '823BF8A6-80AF-4473-8AB8-DE179672944D'");
            if (drScreensForPopUp.Length > 0)
            {
                int.TryParse(drScreensForPopUp[0]["ScreenId"].ToString(), out ScreenIdOfPopUpPage);
            }
        }
        public override string PageDataSetName
        {
            get { return "DataSetISPCustomCarePlans"; }
        }

        public override string[] TablesToBeInitialized
        {
            get { return new string[] { "DocumentCarePlans,CarePlanDomains,CarePlanDomainNeeds,CarePlanDomainGoals,CarePlanNeeds,CarePlanGoals,CarePlanGoalNeeds,CarePlanObjectives,CarePlanPrograms,CarePlanDomainObjectives,ClientProgramsAuthorizationCodes,DocumentDiagnosisCodes,DocumentDiagnosis,DocumentDiagnosisFactors,CustomDocumentCarePlans,PreviouslyRequested" }; }
        }

        public override void ChangeInitializedDataSet(ref DataSet dataSetObject)
        {
            if (dataSetObject.Tables["DocumentCarePlans"].IsRowExists())
            {
                if (!string.IsNullOrEmpty(dataSetObject.Tables["DocumentCarePlans"].Rows[0]["ReviewEntireCareType"].ToString()))
                {
                    HiddenField_ReviewEntireCareType.Value = dataSetObject.Tables["DocumentCarePlans"].Rows[0]["ReviewEntireCareType"].ToString();
                }

                if (HiddenField_ReviewEntireCareType.Value == "S")
                {
                    if (!string.IsNullOrEmpty(dataSetObject.Tables["DocumentCarePlans"].Rows[0]["ReviewEntireCarePlan"].ToString()))
                    {
                        HiddenField_ReviewEntireCarePlan.Value = dataSetObject.Tables["DocumentCarePlans"].Rows[0]["ReviewEntireCarePlan"].ToString();
                    }
                }
                else
                {
                    HiddenField_ReviewEntireCarePlan.Value = "";
                }
                if (HiddenField_ReviewEntireCareType.Value == "D")
                {
                    if (!string.IsNullOrEmpty(dataSetObject.Tables["DocumentCarePlans"].Rows[0]["ReviewEntireCarePlanDate"].ToString()))
                    {
                        HiddenField_ReviewEntireCarePlanDate.Value = dataSetObject.Tables["DocumentCarePlans"].Rows[0]["ReviewEntireCarePlanDate"].ToString();
                    }

                }
                else
                {
                    HiddenField_ReviewEntireCarePlanDate.Value = "";
                }
            }
        }
        public override void ChangeDataSetBeforeUpdate(ref DataSet dataSetObject)
        {
            #region Remove Tables

            if (dataSetObject.Tables.Contains("CarePlanDomains"))
            {
                dataSetObject.Tables.Remove("CarePlanDomains");
            }
            if (dataSetObject.Tables.Contains("CarePlanDomainNeeds"))
            {
                dataSetObject.Tables.Remove("CarePlanDomainNeeds");
            }
            if (dataSetObject.Tables.Contains("CarePlanDomainGoals"))
            {
                dataSetObject.Tables.Remove("CarePlanDomainGoals");
            }
            if (dataSetObject.Tables.Contains("CarePlanDomainObjectives"))
            {
                dataSetObject.Tables.Remove("CarePlanDomainObjectives");
            }
            if (dataSetObject.Tables.Contains("DiagnosesIANDIIMaxOrder"))
            {
                dataSetObject.Tables.Remove("DiagnosesIANDIIMaxOrder");
            }
            if (dataSetObject.Tables.Contains("PreviouslyRequested"))
            {
                dataSetObject.Tables["PreviouslyRequested"].Clear();
            }


            #region DataSet Update For Prescribed Services & Prescribed Services Objective

            string PresribedServiceId = string.Empty;
            if (dataSetObject.Tables.Contains("CarePlanPrescribedServices"))
            {
                if (SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dataSetObject.Tables["CarePlanPrescribedServices"], 0))
                {
                    DataView dataViewCarePlanPrescribedServices = new DataView();
                    dataViewCarePlanPrescribedServices = dataSetObject.Tables["CarePlanPrescribedServices"].DefaultView;

                    for (int rowCount = 0; rowCount < (dataViewCarePlanPrescribedServices.Count); rowCount++)
                    {
                        string isChecked = Convert.ToString(dataViewCarePlanPrescribedServices[rowCount]["IsChecked"]);
                        PresribedServiceId = Convert.ToString(dataViewCarePlanPrescribedServices[rowCount]["CarePlanPrescribedServiceId"]);

                        if ((dataViewCarePlanPrescribedServices[rowCount].Row.RowState == DataRowState.Added) && (Convert.ToString(dataViewCarePlanPrescribedServices[rowCount]["IsChecked"]) == "N"))
                        {
                            dataViewCarePlanPrescribedServices[rowCount].Row.Delete();
                            rowCount--;
                        }
                        else if ((dataViewCarePlanPrescribedServices[rowCount].Row.RowState != DataRowState.Added) && (Convert.ToString(dataViewCarePlanPrescribedServices[rowCount]["IsChecked"]) == "N"))
                        {
                            dataViewCarePlanPrescribedServices[rowCount]["RecordDeleted"] = "Y";
                        }
                    }
                }
            }

            #endregion

            if (dataSetObject.Tables.Contains("ClientProgramsAuthorizationCodes"))
            {
                dataSetObject.Tables.Remove("ClientProgramsAuthorizationCodes");
            }

            #endregion

            DataRow[] drOtherGoals = dataSetObject.Tables["CarePlanGoals"].Select("CarePlanDomainGoalId= -1 or CarePlanDomainGoalId is null");

            foreach (DataRow row in drOtherGoals)
            {
                row["CarePlanDomainGoalId"] = DBNull.Value;
            }

            DataRow[] drOtherObjectives = dataSetObject.Tables["CarePlanObjectives"].Select("CarePlanDomainObjectiveId= -1 or CarePlanDomainObjectiveId is null");

            foreach (DataRow row in drOtherObjectives)
            {
                row["CarePlanDomainObjectiveId"] = DBNull.Value;
            }
            //code added by Veena to copy the end date to objectives if goal is ended.

            DataRow[] drEndGoals = dataSetObject.Tables["CarePlanGoals"].Select("GoalEndDate IS NOT NULL and IsNewGoal = 'N'");
            string GoalId = string.Empty;
            foreach (DataRow row in drEndGoals)
            {
                GoalId = row["CarePlanGoalId"].ToString();
                DataRow[] drtobeEndObjectives = dataSetObject.Tables["CarePlanObjectives"].Select("ObjectiveEndDate IS NOT NULL and CarePlanGoalId=" + GoalId);
                foreach (DataRow dorow in drtobeEndObjectives)
                {
                    if (string.IsNullOrEmpty(dorow["ObjectiveEndDate"].ToString()))
                        dorow["ObjectiveEndDate"] = row["GoalEndDate"];
                }
            }



        }
        public override System.Collections.Generic.List<CustomParameters> customInitializationStoreProcedureParameters
        {
            get
            {
                SHS.BaseLayer.DocumentInformation obj = new SHS.BaseLayer.DocumentInformation();

                System.Collections.Generic.List<CustomParameters> t = new List<CustomParameters>();
                t.Add(new CustomParameters("DocumentCodeID", Convert.ToString(ParentDetailPageObject.dataRowScreenRow["DocumentCodeId"])));
                return t;
            }
        }

        /// <summary>
        /// <purpose>Custom Ajax Hit</purpose>
        /// </summary>
        public override void CustomAjaxRequest()
        {
            base.CustomAjaxRequest();
            string customAction = string.Empty;
            customAction = base.GetRequestParameterValue("CustomAction");
            dsMasterData = CarePlan.CarePlan.GetMasterData();

            DataSet datasetDocumentCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            MergeUnsavedXMLInCarePlanDataSet(ref datasetDocumentCarePlan);

            switch (customAction)
            {
                case "AddNewCarePlanGoal":   //Tab Goal/Objective
                    AddNewCarePlanGoal();
                    break;
                case "AddNewCarePlanObjective":
                    AddNewCarePlanObjective();
                    break;
                case "EditNeedsDiscription": //Tab Needs
                    EditNeedsDiscription(base.GetRequestParameterValue("NeedId"), base.GetRequestParameterValue("NeedDiscription"));
                    break;
                case "AddNeedsPopUp":
                    AddNeeds(GetRequestParameterValue("CarePlanDomainNeedId"), Convert.ToInt32(GetRequestParameterValue("CarePlanDomainId")));
                    break;
                case "AssociateNeedPopUp":
                    AddAssociateNeed(GetRequestParameterValue("NeedId"), Convert.ToInt32(GetRequestParameterValue("GoalId")));
                    break;
                case "GoalDescriptionPopUp":
                    EditGoalDescription(GetRequestParameterValue("DomainGoalid"), Convert.ToInt32(GetRequestParameterValue("GoalId")));
                    break;
                case "ObjectiveDescriptionPopUp":
                    EditObjectiveDescription(GetRequestParameterValue("DomainObjectiveId"), Convert.ToInt32(GetRequestParameterValue("GoalId")), Convert.ToInt32(GetRequestParameterValue("ObjectiveId")));
                    break;
                case "EditViewObjectivesPopUp":
                    EditAssociatedPrescribedServiecs(GetRequestParameterValue("ObjectiveId"), Convert.ToInt32(GetRequestParameterValue("PrescribedServiceId")));
                    break;
                case "UpdateGoalObjectiveFieldValue":
                    UpdateGoalObjectiveFieldValue();
                    break;
                case "RenumberCarePlanGoalObjectives":
                    RenumberCarePlanGoalObjectives();
                    break;
                case "DeleteNeedsDiscription": //Delete Needs in Needs Tab
                    DeleteNeedsDiscription(base.GetRequestParameterValue("NeedId"));
                    break;
                case "DeleteCarePlanGoalObjective":
                    DeleteCarePlanGoalObjective();
                    break;
                case "GetPreviousProgressTowardGoal":
                    GetPreviousProgressTowardGoal();
                    break;
                case "UpdatePrescribedServicesFieldValue":
                    UpdatePrescribedServicesFieldValue();
                    break;
                case "UpdateNeedsFieldValue":
                    UpdateNeedsFieldValue();
                    break;
                case "DeleteServiceGroupValuesCheckBoxUnChecked":
                    DeleteServiceGroupValuesCheckBoxUnChecked();
                    break;
                case "UpdateNameInGoalDescInSessionDataset":
                    UpdateNameInGoalDescInSessionDataset();
                    break;
                case "AddUpdateTreatmentTeamFieldValue":
                    AddUpdateTreatmentTeamFieldValue();
                    break;
                case "DeleteTreatmentTeam": //Supports/Treatment Team Tab
                    DeleteTreatmentTeam();
                    break;
                case "UpdateTreatmentTeamFieldValue":
                    UpdateTreatmentTeamFieldValue();
                    break;
                case "CheckNonAuthorStaffPrograms":
                    CheckNonAuthorStaffPrograms();
                    break;
                case "AddNewTreatmentTeamMember":
                    AddNewTreatmentTeamMember();
                    break;
                case "GetPreviousProgressTowardGoalProgressReview":
                    GetPreviousProgressTowardGoalProgressReview();
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// <Purpose>TO Add a New Goal</Purpose>
        /// </summary>
        public void AddNewCarePlanGoal()
        {
            MergeLocalUnsavedXml();
            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            int documentversionId = 0;
            bool goalAddedFromNeedsTab = false;

            DataTable datatableCustomCarePlans = dataSetDocument.Tables["DocumentCarePlans"];
            if (BaseCommonFunctions.CheckRowExists(datatableCustomCarePlans, 0))
            {
                documentversionId = Convert.ToInt32(datatableCustomCarePlans.Rows[0]["DocumentVersionId"]);
            }
            DataTable datatableGoals = dataSetDocument.Tables["CarePlanGoals"];
            DataRow datarowNewGoal = datatableGoals.NewRow();
            int minGoalId = -1;
            DataRow[] datarowGoalWithMinId = datatableGoals.Select("CarePlanGoalId<0");
            if (datarowGoalWithMinId.Length > 0)
            {
                minGoalId = Convert.ToInt32(datatableGoals.Compute("Min(CarePlanGoalId)", "CarePlanGoalId<0")) - 1;
            }
            datarowNewGoal["CarePlanGoalId"] = minGoalId;
            if (datatableGoals.Select("ISNULL(RecordDeleted,'N')<>'Y'").Length > 0)
            {
                datarowNewGoal["GoalNumber"] = Convert.ToInt32(datatableGoals.Compute("Max(GoalNumber)", "ISNULL(RecordDeleted,'N')<>'Y'")) + 1;
            }
            else
            {
                datarowNewGoal["GoalNumber"] = "1";
            }
            datarowNewGoal["DocumentVersionId"] = documentversionId;
            datarowNewGoal["CarePlanDomainGoalId"] = -1;
            datarowNewGoal["InitializedFromPreviousCarePlan"] = "N";
            //Set Goal Active to 'N' when New Goal is added.
            datarowNewGoal["GoalActive"] = "Y";
            if (SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("SetReviewInCarePlan").ToString().Trim() == "Y")
                datarowNewGoal["IsNewGoal"] = "Y";
            else
                datarowNewGoal["IsNewGoal"] = "N";
            datarowNewGoal["MonitoredByType"] = "S";
            datarowNewGoal["GoalStartDate"] = DateTime.Now.ToString("MM/dd/yyyy");
            datarowNewGoal["IsNewCarePlanGoal"] = "Y";

            BaseCommonFunctions.InitRowCredentials(datarowNewGoal);
            AddGoalCustomInit(datarowNewGoal);
            
            datatableGoals.Rows.Add(datarowNewGoal);

            if ((!string.IsNullOrEmpty(base.GetRequestParameterValue("NewGoalSource")) && base.GetRequestParameterValue("NewGoalSource") == "NeedTab"))
            {
                int NeedId = 0;
                if (dataSetDocument.Tables.Contains("CarePlanGoalNeeds"))
                {
                    int.TryParse(base.GetRequestParameterValue("NeedId"), out NeedId);
                    DataTable datatableCarePlanGoalNeeds = dataSetDocument.Tables["CarePlanGoalNeeds"];

                    DataRow datarowNewGoalNeeds = datatableCarePlanGoalNeeds.NewRow();
                    datarowNewGoalNeeds["CarePlanGoalId"] = minGoalId;
                    datarowNewGoalNeeds["CarePlanNeedId"] = NeedId;
                    BaseCommonFunctions.InitRowCredentials(datarowNewGoalNeeds);
                    datatableCarePlanGoalNeeds.Rows.Add(datarowNewGoalNeeds);
                }
                goalAddedFromNeedsTab = true;
            }
            SetResponseOnAddGoal(datatableGoals, minGoalId, goalAddedFromNeedsTab);
        }

        void AddGoalCustomInit(DataRow goalRow)
        {
            if (string.Equals(BaseCommonFunctions.GetSystemConfigurationValue("CarePlanUseCustomGoalInitialization"),"Y",StringComparison.InvariantCultureIgnoreCase))
            {
                using(DataSet dsCustomInit = new DataSet())
                {
                    DateTime effectiveDate = DateTime.Now;
                    if(!BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.IsRowExists("Documents",0) || !DateTime.TryParse(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["Documents"].Rows[0]["EffectiveDate"].ToString(),out effectiveDate))
                    {
                        throw new CustomExceptionWithMessage("Unable to determine documents effective date");
                    }

                    SqlParameter[] parameters = new SqlParameter[4];
                    parameters[0] = new SqlParameter("@UserId",BaseCommonFunctions.ApplicationInfo.LoggedInUser.LoggedinUserId);
                    parameters[1] = new SqlParameter("@ClientId",BaseCommonFunctions.ApplicationInfo.Client.ClientId);
                    parameters[2] = new SqlParameter("@DocumentVersionId", BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentVersionId);
                    parameters[3] = new SqlParameter("@EffectiveDate", effectiveDate);


                    using(var con = new SqlConnection(SHS.DataServices.Connection.ConnectionString))
                    {
                        DBManager.FillDataset(con, "ssp_SCCarePlanInitNewGoal", dsCustomInit, new string[] {"Goals"}, parameters);
                    }

                    if (dsCustomInit.IsRowExists("Goals", 0) && dsCustomInit.Tables["Goals"].Columns.Contains("ClientGoal"))
                    {
                        DataRow initRow = dsCustomInit.Tables["Goals"].Rows[0];
                        goalRow["ClientGoal"] = initRow["ClientGoal"];
                    }
                }
            }
        }
        /// <summary>
        /// <purpose>Mouse Over ToolTip For Previous Progress Toward Goal Message</purpose>
        /// </summary>
        /// <param name="GoalId"></param>
        /// <param name="DomainGoalId"></param>
        public void GetPreviousProgressTowardGoal()
        {
            MergeLocalUnsavedXml();
            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            int GoalId = (string.IsNullOrEmpty(base.GetRequestParameterValue("GoalId"))) ? 0 : Convert.ToInt32(base.GetRequestParameterValue("GoalId"));
            int DomainGoalId = (string.IsNullOrEmpty(base.GetRequestParameterValue("DomainGoalId"))) ? 0 : Convert.ToInt32(base.GetRequestParameterValue("DomainGoalId"));
            int ClientId = Convert.ToInt32(BaseCommonFunctions.ApplicationInfo.Client.ClientId);
            int DocumentCodeId = Convert.ToInt32(dataSetDocument.Tables["Documents"].Rows[0]["DocumentCodeId"]);
            DateTime DocumentEffectiveDate = (string.IsNullOrEmpty(Convert.ToString(dataSetDocument.Tables["Documents"].Rows[0]["EffectiveDate"])) ? DateTime.Now : Convert.ToDateTime(dataSetDocument.Tables["Documents"].Rows[0]["EffectiveDate"]));
            string ProgressTowardsGoal = string.Empty;
            DataSet dataSetPreviousProgressTowardGoal = null;
            DataTable dataTablePreviousProgressTowardGoal = null;
            using (SHS.UserBusinessServices.CarePlan objectCarePlan = new SHS.UserBusinessServices.CarePlan())
            {
                dataSetPreviousProgressTowardGoal = objectCarePlan.GetProgressTowardsGoalObjective(ClientId, DocumentEffectiveDate, DocumentCodeId, DomainGoalId, 0, 'G');
                dataTablePreviousProgressTowardGoal = dataSetPreviousProgressTowardGoal.Tables["TableProgressTowardsGoal"];
                if (BaseCommonFunctions.CheckRowExists(dataTablePreviousProgressTowardGoal, 0))
                {
                    ProgressTowardsGoal = dataTablePreviousProgressTowardGoal.Rows[0]["ProgressTowardsGoal"].ToString();
                }
            }
            SetShowHidePanels("###StartPreviousProgressTowardGoal###", GoalId + "$$$" + ProgressTowardsGoal, "###EndPreviousProgressTowardGoal###",false);
        }


        /// <summary>
        /// <Purpose>To Add a New Objective for a Goal</Purpose>
        /// </summary>
        public void AddNewCarePlanObjective()
        {
            MergeLocalUnsavedXml();
            double objectiveNumber = 0.0;
            int goalId = Convert.ToInt32(base.GetRequestParameterValue("GoalId"));
           // DateTime? goalenddate = null;
            int goalNumber = 0;
            //if (!string.IsNullOrEmpty(base.GetRequestParameterValue("EndDate").ToString()))
            //{
            //    goalenddate = Convert.ToDateTime(base.GetRequestParameterValue("EndDate").ToString());
            //}
            
            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;

            if (BaseCommonFunctions.CheckRowExists(dataSetDocument, "CarePlanGoals"))
            {
                DataRow[] datarowGoal = dataSetDocument.Tables["CarePlanGoals"].Select("CarePlanGoalId=" + goalId);
                if (datarowGoal.Length > 0)
                {
                    goalNumber = Convert.ToInt32(datarowGoal[0]["GoalNumber"]);
                }
            }
            DataTable datatableObjectives = dataSetDocument.Tables["CarePlanObjectives"];
            DataRow datarowNewObjective = datatableObjectives.NewRow();

            int minCarePlanObjectiveId = -1;
            DataRow[] datarowObjectiveWithMinId = datatableObjectives.Select("CarePlanObjectiveId<0");
            if (datarowObjectiveWithMinId.Length > 0)
            {
                minCarePlanObjectiveId = Convert.ToInt32(datatableObjectives.Compute("Min(CarePlanObjectiveId)", "CarePlanObjectiveId<0")) - 1;
            }
            datarowNewObjective["CarePlanObjectiveId"] = minCarePlanObjectiveId;

            datarowNewObjective["CarePlanGoalId"] = goalId;
            if (datatableObjectives.Select("ISNULL(RecordDeleted,'N')<>'Y' and CarePlanGoalId=" + goalId).Length > 0)
            {
                objectiveNumber = Convert.ToDouble(datatableObjectives.Compute("Max(ObjectiveNumber)", "ISNULL(RecordDeleted,'N')<>'Y' and CarePlanGoalId=" + goalId));
                objectiveNumber = Math.Round((objectiveNumber + .01), 2);
            }
            else
            {
                objectiveNumber = Math.Round(Convert.ToDouble(goalNumber) + .01, 2);
            }
            datarowNewObjective["ObjectiveNumber"] = Convert.ToDouble(objectiveNumber.ToString("0.00"));
            datarowNewObjective["Status"] = "A";
            datarowNewObjective["ObjectiveStartDate"] = DateTime.Now.ToString("MM/dd/yyyy");
            //if (!string.IsNullOrEmpty(goalenddate.ToString()))
            //    datarowNewObjective["ObjectiveEndDate"] = goalenddate;
            datarowNewObjective["IsNewObjective"] = "Y";
            datarowNewObjective["InitializedFromPreviousCarePlan"] = "N";
            BaseCommonFunctions.InitRowCredentials(datarowNewObjective);
            datatableObjectives.Rows.Add(datarowNewObjective);
            SetResponseOnAddObjective(datatableObjectives, minCarePlanObjectiveId, goalId);
        }

        /// <summary>
        /// <Purpose>To Set Show/Hide Panels for Custom Ajax Request</Purpose>
        /// </summary>
        /// <param name="valueToSetAtStart"></param>
        /// <param name="valueToSet"></param>
        /// <param name="valueToSetAtEnd"></param>
        public void SetShowHidePanels(string valueToSetAtStart, string valueToSet, string valueToSetAtEnd)
        {
            SetShowHidePanels(valueToSetAtStart, valueToSet, valueToSetAtEnd, true);
        }
        public void SetShowHidePanels(string valueToSetAtStart, string valueToSet, string valueToSetAtEnd, bool IncludePageDataSet)
        {
            DataSet documentDataset = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            DataSet DatasetScreenTemp = new DataSet();
            DatasetScreenTemp.EnforceConstraints = false;
            DatasetScreenTemp = documentDataset.Copy();

            string TableList = "CarePlanDomains,CarePlanDomainNeeds,CarePlanDomainGoals,CarePlanDomainObjectives,DiagnosesIANDIIMaxOrder,ClientProgramsAuthorizationCodes";
            string[] ArrTableList = TableList.Split(',');
            for (int i = 0; i <= ArrTableList.Length - 1; i++)
            {
                if (DatasetScreenTemp.Tables.Contains(ArrTableList[i]))
                {
                    DatasetScreenTemp.Tables.Remove(ArrTableList[i].ToString());
                }
            }
            string pageDataSetXml = DatasetScreenTemp.GetXml();

            PanelMain.Visible = false;
            Literal literalStart = new Literal();
            Literal literalHtmlText = new Literal();
            Literal literalEnd = new Literal();
            literalStart.Text = valueToSetAtStart;
            literalHtmlText.Text += valueToSet;
            if (IncludePageDataSet == true)
            {
                literalEnd.Text = valueToSetAtEnd + "^pageDataSetXML=" + pageDataSetXml;
            }
            else
            {
                literalEnd.Text = valueToSetAtEnd + "^pageDataSetXML=";
            }

            PanelCustomAjax.Controls.Add(literalStart);
            PanelCustomAjax.Controls.Add(literalHtmlText);
            PanelCustomAjax.Controls.Add(literalEnd);


        }

        /// <summary>
        /// <purpose>Delete Needs in Care Plan</purpose>
        /// </summary>
        /// <param name="NeedId"></param>
        /// <param name="DomainId"></param>
        public void DeleteNeedsDiscription(string NeedId)
        {
            MergeLocalUnsavedXml();
            int domainId = Convert.ToInt32(base.GetRequestParameterValue("DomainId"));

            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            DataTable datatableNeeds = dataSetDocument.Tables["CarePlanNeeds"];

            DataRow datarowDeleteNeedDiscription = null;
            if (BaseCommonFunctions.CheckRowExists(dataSetDocument.Tables["CarePlanNeeds"], 0))
            {
                datarowDeleteNeedDiscription = datatableNeeds.Select("CarePlanNeedId=" + NeedId)[0];
                datarowDeleteNeedDiscription["RecordDeleted"] = "Y";
                BaseCommonFunctions.UpdateRecordDeletedInformation(datarowDeleteNeedDiscription);
                SetShowHidePanels("###StartDeleteNeedDiscription###", "DomainId=" + domainId + "$$$" + NeedId, "###EndDeleteNeedDiscription###",false);
            }
        }

        /// <summary>
        /// <purpose>Edit Needs Discription</purpose>
        /// </summary>
        /// <param name="NeedId"></param>
        /// <param name="NeedDiscription"></param>
        public void EditNeedsDiscription(string NeedId, string NeedDiscription)
        {

            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            DataTable datatableNeeds = dataSetDocument.Tables["CarePlanNeeds"];
            if (BaseCommonFunctions.CheckRowExists(dataSetDocument.Tables["CarePlanNeeds"], 0))
            {
                DataRow datarowEditNeedDiscription = null;
                datarowEditNeedDiscription = datatableNeeds.Select("NeedId=" + NeedId)[0];
                datarowEditNeedDiscription["NeedDescription"] = NeedDiscription;
            }
            SetShowHidePanels("###StartEditNeedDiscription###", "EditNeedsDiscription", "###EndEditNeedDiscription###",false);
        }

        /// <summary>
        ///<purpose>Open AddNeeds Pop Up</purpose>
        /// </summary>
        /// <param name="NeedText"></param>
        /// <param name="DomainId"></param>
        private void AddNeeds(string needId, int domainId)
        {
            MergeLocalUnsavedXml();
            DataSet dataSetCarePlan = null;
            DataTable datatableTemp = new DataTable();

            DataRow drCustomCarePlanNeeds = null;
            int documentVersionId = 0;
            string needName = string.Empty;
            ArrayList DomainNeedId = BaseCommonFunctions.StringSplit(needId, "###");
            Screenname = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.FindByScreenId(SHS.BaseLayer.BaseCommonFunctions.ScreenId).ScreenName.ToString();

            #region Define Temporary Table Structure
            datatableTemp.Columns.Add("NeedId", System.Type.GetType("System.Int32"));
            datatableTemp.Columns.Add("DomainNeedId", System.Type.GetType("System.Int32"));
            datatableTemp.Columns.Add("DocumentVersionId", System.Type.GetType("System.Int32"));
            datatableTemp.Columns.Add("AddressOnCarePlan", System.Type.GetType("System.String"));

            datatableTemp.Columns.Add("NeedName", System.Type.GetType("System.String"));
            datatableTemp.Columns.Add("DomainId", System.Type.GetType("System.Int32"));
            datatableTemp.Columns.Add("Source", System.Type.GetType("System.String"));
            datatableTemp.Columns.Add("SourceName", System.Type.GetType("System.String"));



            #endregion

            using (dataSetCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                //EI#677 - Analysis and Resolution to Fix - Exception: "There is no row at position 0" in SmartCare Application
                if (dataSetCarePlan.IsDataTableFound("DocumentCarePlans"))               
                    documentVersionId = Convert.ToInt32(dataSetCarePlan.Tables["DocumentCarePlans"].Rows[0]["DocumentVersionId"].ToString());

                if (DomainNeedId.Count > 0)
                {
                    foreach (string domainNeedId in DomainNeedId)
                    {
                        if (domainNeedId != "")
                        {
                            if (dsMasterData.Tables.Contains("CarePlanDomainNeeds"))
                            {
                                DataRow[] datarowDomainNeed = dsMasterData.Tables["CarePlanDomainNeeds"].Select(string.Format("CarePlanDomainNeedId={0}", domainNeedId));
                                if (datarowDomainNeed.Length > 0)
                                {
                                    needName = datarowDomainNeed[0]["NeedName"].ToString();
                                }
                            }

                            drCustomCarePlanNeeds = dataSetCarePlan.Tables["CarePlanNeeds"].NewRow();
                            drCustomCarePlanNeeds.BeginEdit();
                            drCustomCarePlanNeeds["CarePlanDomainNeedId"] = Convert.ToInt32(domainNeedId);
                            drCustomCarePlanNeeds["DocumentVersionId"] = documentVersionId;
                            drCustomCarePlanNeeds["AddressOnCarePlan"] = 'Y';
                            drCustomCarePlanNeeds["NeedName"] = needName;
                            drCustomCarePlanNeeds["CarePlanDomainId"] = domainId;
                            drCustomCarePlanNeeds["Source"] = "C";
                            drCustomCarePlanNeeds["SourceName"] = Screenname;
                            BaseCommonFunctions.InitRowCredentials(drCustomCarePlanNeeds);
                            drCustomCarePlanNeeds.EndEdit();
                            dataSetCarePlan.Tables["CarePlanNeeds"].Rows.Add(drCustomCarePlanNeeds);

                            #region Set New Need Column values
                            DataRow datarowNewNeed = datatableTemp.NewRow();
                            datarowNewNeed["NeedId"] = drCustomCarePlanNeeds["CarePlanNeedId"];
                            datarowNewNeed["DomainNeedId"] = drCustomCarePlanNeeds["CarePlanDomainNeedId"];
                            datarowNewNeed["DocumentVersionId"] = drCustomCarePlanNeeds["DocumentVersionId"];
                            datarowNewNeed["AddressOnCarePlan"] = drCustomCarePlanNeeds["AddressOnCarePlan"];
                            datarowNewNeed["NeedName"] = drCustomCarePlanNeeds["NeedName"];
                            datarowNewNeed["DomainId"] = drCustomCarePlanNeeds["CarePlanDomainId"];
                            datarowNewNeed["Source"] = drCustomCarePlanNeeds["Source"];
                            datarowNewNeed["SourceName"] = drCustomCarePlanNeeds["SourceName"];
                            #endregion
                            datatableTemp.Rows.Add(datarowNewNeed);
                        }

                    }
                    SetResponseOnAddNeed(datatableTemp, domainId);
                }
            }
        }
        /// <summary>
        /// <purpose>Open AssociateNeed Pop Up</purpose>
        /// </summary>
        /// <param name="NeedText"></param>
        /// <param name="GoalID"></param>
        private void AddAssociateNeed(string needId, int goalID)
        {
            JavaScriptSerializer jss = new JavaScriptSerializer();

            //object objs = jss.Deserialize<ObjectArray>(needId);

            StringWriter myWriter = new StringWriter();
            // Decode the encoded string.
            HttpUtility.HtmlDecode(needId, myWriter);

            //List<ObjectArray> objs = Deserialise<List<ObjectArray>>(myWriter.ToString());

            DataSet dataSetCarePlan = null;
            DataRow[] datarowNeeds = null;
            DataRow datarowCustomCarePlanNeeds = null;
            ArrayList NeedID = BaseCommonFunctions.StringSplit(needId, "###");
            using (dataSetCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetCarePlan != null && dataSetCarePlan.Tables.Contains("CarePlanGoalNeeds"))
                {
                    datarowNeeds = dataSetCarePlan.Tables["CarePlanGoalNeeds"].Select("CarePlanGoalId=" + Convert.ToString(goalID) + " and ISNULL(RecordDeleted,'N')='N' ");
                    if (datarowNeeds.Length > 0)
                    {
                        foreach (DataRow datarowCurrent in datarowNeeds)
                        {
                            datarowCurrent["RecordDeleted"] = 'Y';
                        }
                    }
                    if (NeedID.Count > 0)
                    {

                        foreach (string needid in NeedID)
                        {
                            if (needid != "")
                            {
                                ArrayList NeedDesc = BaseCommonFunctions.StringSplit(needid, "##");

                                DataRow[] datarowCurrentNeeds = dataSetCarePlan.Tables["CarePlanGoalNeeds"].Select("CarePlanGoalId=" + Convert.ToString(goalID) + " and CarePlanNeedId=" + NeedDesc[0]);

                                if (datarowCurrentNeeds.Length > 0)
                                {
                                    datarowCurrentNeeds[0]["RecordDeleted"] = 'N';
                                    if (NeedDesc.Count > 1)
                                        datarowCurrentNeeds[0]["AssociatedNeedDescription"] = NeedDesc[1];
                                    else
                                        datarowCurrentNeeds[0]["AssociatedNeedDescription"] = "";
                                }
                                else
                                {
                                    datarowCustomCarePlanNeeds = null;
                                    datarowCustomCarePlanNeeds = dataSetCarePlan.Tables["CarePlanGoalNeeds"].NewRow();
                                    datarowCustomCarePlanNeeds.BeginEdit();
                                    datarowCustomCarePlanNeeds["CarePlanNeedId"] = Convert.ToInt32(NeedDesc[0]);
                                    datarowCustomCarePlanNeeds["CarePlanGoalId"] = goalID;
                                    datarowCustomCarePlanNeeds["AssociatedNeedDescription"] = NeedDesc[1];
                                    BaseCommonFunctions.InitRowCredentials(datarowCustomCarePlanNeeds);
                                    datarowCustomCarePlanNeeds.EndEdit();
                                    dataSetCarePlan.Tables["CarePlanGoalNeeds"].Rows.Add(datarowCustomCarePlanNeeds);


                                }

                            }
                        }
                    }

                }
            }
            CarePlan.CarePlan objectCarePlan = new CarePlan.CarePlan();
            SetShowHidePanels("###StartAssociateNeedPopUp###", "GoalId=" + goalID + "$$$" + objectCarePlan.GetAssiciatedNeedsText(goalID,true), "###EndAssociateNeedPopUp###");
        }
        /// <summary>
        /// <purpose>Open GoalDescription Pop Up</purpose>
        /// </summary>
        /// <param name="ObjectiveText"></param>
        /// <param name="GoalId"></param>
        private void EditGoalDescription(string domainGoalID, int goalId)
        {
            DataSet dataSetCarePlan = null;
            DataRow[] datarowGoals = null;
            DataRow[] datarowDomainGoals = null;
            string goalDescription = string.Empty;
            string clinetName = string.Empty;
            int? _domainGoalID = null;

            ArrayList goaldesc = BaseCommonFunctions.StringSplit(domainGoalID, "##");

            using (dataSetCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetCarePlan != null && dataSetCarePlan.Tables.Contains("DocumentCarePlans"))
                {
                    DataTable datatableCarePlans = dataSetCarePlan.Tables["DocumentCarePlans"];
                    clinetName = datatableCarePlans.Rows[0]["NameInGoalDescriptions"].ToString();
                }

                if (dataSetCarePlan != null && dsMasterData.Tables.Contains("CarePlanDomainGoals"))
                {
                    if (!string.IsNullOrEmpty(goaldesc[0].ToString()))
                    {
                        datarowDomainGoals = dsMasterData.Tables["CarePlanDomainGoals"].Select(string.Format("CarePlanDomainGoalId={0}", goaldesc[0]));
                        datarowGoals = dataSetCarePlan.Tables["CarePlanGoals"].Select(string.Format("CarePlanGoalId={0}", goalId.ToString()));
                        if (datarowDomainGoals.Length > 0)
                        {
                            goalDescription = datarowDomainGoals[0]["GoalDescription"].ToString() + "\n\t" + datarowGoals[0]["AssociatedGoalDescription"];
                        }
                        _domainGoalID = Convert.ToInt32(goaldesc[0].ToString());
                    }
                    else
                    {
                        goalDescription = string.Empty;
                        clinetName = string.Empty;
                    }

                    int _goalId = 0;
                    if (dataSetCarePlan.Tables.Contains("CarePlanGoals"))
                    {
                        datarowGoals = dataSetCarePlan.Tables["CarePlanGoals"].Select(string.Format("CarePlanGoalId={0}", goalId.ToString()));
                        if (datarowGoals.Length > 0)
                        {
                            if (_domainGoalID == null)
                                datarowGoals[0]["CarePlanDomainGoalId"] = DBNull.Value;
                            else
                            {
                                datarowGoals[0]["CarePlanDomainGoalId"] = _domainGoalID;
                                if (goaldesc.Count > 1)
                                    datarowGoals[0]["AssociatedGoalDescription"] = goaldesc[1].ToString();
                                else
                                    datarowGoals[0]["AssociatedGoalDescription"] = "";
                            }

                            datarowGoals[0]["GoalDescription"] = goalDescription;

                            _goalId = Convert.ToInt32(datarowGoals[0]["CarePlanGoalId"]);
                            ChangeGoalDescription(_goalId, dataSetCarePlan);
                        }

                    }
                }
            }
            SetShowHidePanels("###StartGoalDescriptionPopUp###", "GoalId=" + goalId + "$$$" + clinetName + " " + goalDescription, "###EndGoalDescriptionPopUp###");
        }

        //Call Function When Goal Description Reset or Changed
        private void ChangeGoalDescription(int goalId, DataSet dataSetCarePlan)
        {
            DataRow[] datarowObjectives = null;
            DataRow[] datarowPrescribedObjectives = null;
            if (dataSetCarePlan != null && dataSetCarePlan.Tables.Contains("CarePlanObjectives"))
            {
                datarowObjectives = dataSetCarePlan.Tables["CarePlanObjectives"].Select(string.Format("CarePlanGoalId={0}", goalId.ToString()));
                if (datarowObjectives.Length > 0)
                {
                    for (int rowCount = 0; rowCount < datarowObjectives.Length; rowCount++)
                    {
                        if (dataSetCarePlan.Tables.Contains("CustomCarePlanPrescribedServiceObjectives"))
                        {
                            datarowPrescribedObjectives = dataSetCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Select(string.Format("CarePlanObjectiveId={0}", datarowObjectives[rowCount]["CarePlanObjectiveId"]));
                            if (datarowPrescribedObjectives.Length > 0)
                            {
                                for (int recCount = 0; recCount < datarowPrescribedObjectives.Length; recCount++)
                                {
                                    datarowPrescribedObjectives[recCount]["RecordDeleted"] = "Y";
                                }
                            }
                        }
                        if (goalId > 0)
                        {
                            datarowObjectives[rowCount]["RecordDeleted"] = "Y";
                        }
                        else if (goalId <= -1)
                        {
                            datarowObjectives[rowCount].Delete();
                        }
                    }
                }
            }
        }



        /// <summary>
        /// <purpose>Open ObjectiveDescription Pop Up</purpose>
        /// </summary>
        /// <param name="ObjectiveText"></param>
        /// <param name="GoalId"></param>
        private void EditObjectiveDescription(string domainObjectiveId, int goalId, int objectiveId)
        {
            DataSet dataSetCarePlan = null;
            DataRow[] datarowObjectives = null;
            DataRow[] datarowDomainObjectives = null;
            string objectiveDescription = string.Empty;
            string clinetName = string.Empty;
            int setErrorFlag = 0;
            using (dataSetCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (domainObjectiveId != "")
                {
                    if (dataSetCarePlan != null && dataSetCarePlan.Tables.Contains("DocumentCarePlans"))
                    {
                        DataTable datatableCarePlans = dataSetCarePlan.Tables["DocumentCarePlans"];
                        clinetName = datatableCarePlans.Rows[0]["NameInGoalDescriptions"].ToString();
                    }

                    if (dataSetCarePlan != null && dsMasterData.Tables.Contains("CarePlanDomainObjectives"))
                    {
                        if (!ValidateGoalObjective(domainObjectiveId, dataSetCarePlan, goalId))
                        {
                            datarowDomainObjectives = dsMasterData.Tables["CarePlanDomainObjectives"].Select(string.Format("CarePlanDomainObjectiveId={0}", domainObjectiveId));
                            if (datarowDomainObjectives.Length > 0)
                            {
                                objectiveDescription = datarowDomainObjectives[0]["ObjectiveDescription"].ToString();
                            }

                            if (dataSetCarePlan.Tables.Contains("CarePlanObjectives"))
                            {
                                datarowObjectives = dataSetCarePlan.Tables["CarePlanObjectives"].Select("CarePlanGoalId=" + goalId.ToString() + " and CarePlanObjectiveId=" + objectiveId.ToString());
                                if (datarowObjectives.Length > 0)
                                {
                                    datarowObjectives[0]["CarePlanDomainObjectiveId"] = Convert.ToInt32(domainObjectiveId);
                                    datarowObjectives[0]["ObjectiveDescription"] = objectiveDescription;
                                }
                            }
                        }
                        else
                        {
                            setErrorFlag = 1;
                        }
                    }
                }
            }
            SetShowHidePanels("###StartObjectiveDescriptionPopUp###", "ObjectiveId=" + objectiveId + "," + setErrorFlag + "$$$" + clinetName + " " + objectiveDescription, "###EndObjectiveDescriptionPopUp###");
        }


        private bool ValidateGoalObjective(string domainObjectiveId, DataSet dataSetCarePlan, int goalId)
        {
            bool returnValue = false;
            DataView dataViewCarePlanDomainObjectives = new DataView();

            if (dataSetCarePlan != null && dsMasterData.Tables.Contains("CarePlanDomainObjectives"))
            {
                dataViewCarePlanDomainObjectives = dataSetCarePlan.Tables["CarePlanObjectives"].DefaultView;
                dataViewCarePlanDomainObjectives.RowFilter = " CarePlanGoalId=" + goalId + " AND ISNULL(RecordDeleted,'N')<>'Y'";
                dataViewCarePlanDomainObjectives.Sort = "CarePlanObjectiveId Desc";

                for (int counterFlag = 0; counterFlag < dataViewCarePlanDomainObjectives.Count; counterFlag++)
                {
                    if (domainObjectiveId.Trim() == Convert.ToString(dataViewCarePlanDomainObjectives[counterFlag]["CarePlanDomainObjectiveId"]).Trim())
                    {
                        returnValue = true;
                        break;
                    }
                    else
                    { returnValue = false; }
                }
            }
            return returnValue;
        }




        /// <summary>
        /// <purpose>Open ObjectiveDescription Pop Up</purpose>
        /// </summary>
        /// <param name="ObjectiveText"></param>
        /// <param name="prescribedServiceId"></param>
        private void EditAssociatedPrescribedServiecs(string objectiveIdText, int prescribedServiceId)
        {
            MergeLocalUnsavedXml();
            DataSet dataSetCarePlan = null;
            DataRow[] datarowObjectives = null;
            DataRow datarowCustomObjectives = null;
            DataRow[] datarowDomainObjectives = null;
            ArrayList ObjectiveIdArrayList = BaseCommonFunctions.StringSplit(objectiveIdText, "###");
            string objectiveNumber = string.Empty;
            string objectiveDescription = string.Empty;
            string clinetName = string.Empty;
            using (dataSetCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
            {
                if (dataSetCarePlan != null && dataSetCarePlan.Tables.Contains("CustomCarePlanPrescribedServiceObjectives"))
                {
                    datarowObjectives = dataSetCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanPrescribedServiceId=" + Convert.ToString(prescribedServiceId) + " and ISNULL(RecordDeleted,'N')='N' ");
                    if (datarowObjectives.Length > 0)
                    {
                        foreach (DataRow datarowCurrent in datarowObjectives)
                        {
                            datarowCurrent["RecordDeleted"] = 'Y';
                        }
                    }
                    if (ObjectiveIdArrayList.Count > 0)
                    {
                        foreach (string objectiveId in ObjectiveIdArrayList)
                        {
                            if (objectiveId != "")
                            {

                                DataRow[] datarowCurrentNeeds = dataSetCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanPrescribedServiceId=" + Convert.ToString(prescribedServiceId) + " and CarePlanObjectiveId=" + objectiveId);
                                if (datarowCurrentNeeds.Length > 0)
                                {
                                    datarowCurrentNeeds[0]["RecordDeleted"] = 'N';
                                    DataRow[] drObj = dataSetCarePlan.Tables["CarePlanObjectives"].Select("CarePlanObjectiveId=" + objectiveId);
                                    if (drObj.Length > 0 && drObj[0]["AssociatedObjectiveDescription"] != DBNull.Value)
                                    {
                                        datarowCurrentNeeds[0]["ObjectiveDescription"] = drObj[0]["AssociatedObjectiveDescription"].ToString();
                                    }
                                }
                                else
                                {

                                    datarowDomainObjectives = dataSetCarePlan.Tables["CarePlanObjectives"].Select("CarePlanObjectiveId=" + objectiveId + " and ISNULL(RecordDeleted,'N')='N'");
                                    if (datarowDomainObjectives.Length > 0)
                                    {
                                        objectiveNumber = datarowDomainObjectives[0]["ObjectiveNumber"].ToString();
                                        objectiveDescription = datarowDomainObjectives[0]["ObjectiveDescription"].ToString();
                                        if (datarowDomainObjectives[0]["ObjectiveDescription"].ToString() == "")
                                        {
                                            objectiveDescription = datarowDomainObjectives[0]["AssociatedObjectiveDescription"].ToString();
                                        }
                                    }

                                    datarowCustomObjectives = null;
                                    datarowCustomObjectives = dataSetCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].NewRow();
                                    datarowCustomObjectives.BeginEdit();
                                    datarowCustomObjectives["CarePlanPrescribedServiceId"] = prescribedServiceId;
                                    datarowCustomObjectives["CarePlanObjectiveId"] = Convert.ToInt32(objectiveId);
                                    datarowCustomObjectives["ObjectiveNumber"] = objectiveNumber;
                                    datarowCustomObjectives["ObjectiveDescription"] = objectiveDescription;
                                    BaseCommonFunctions.InitRowCredentials(datarowCustomObjectives);
                                    datarowCustomObjectives.EndEdit();
                                    dataSetCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Rows.Add(datarowCustomObjectives);

                                }
                            }
                        }
                    }
                }
            }
            SetResponseOnPrescribedServiceObjective(dataSetCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"], prescribedServiceId);
        }
        /// <summary>
        /// <Purpose>TO Add a New Goal</Purpose>
        /// </summary>
        public void UpdateGoalObjectiveFieldValue()
        {
            string tableName = base.GetRequestParameterValue("tablename");
            string primaryKey = base.GetRequestParameterValue("primaryKey");
            string columnname = base.GetRequestParameterValue("columnname");
            string columnValue = base.GetRequestParameterValue("ctrlValue");

            if (tableName == "CarePlanGoals")
            {
                DataTable datatableGoals = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CarePlanGoals"];
                DataRow[] datarowGoals = datatableGoals.Select("CarePlanGoalId=" + primaryKey);
                if (datarowGoals.Length > 0)
                {
                    datarowGoals[0][columnname] = columnValue;
                }
            }
            else if (tableName == "CarePlanObjectives")
            {
                DataTable datatableObjectives = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CarePlanObjectives"];
                DataRow[] datarowObjectives = datatableObjectives.Select("CarePlanObjectiveId=" + primaryKey);
                if (datarowObjectives.Length > 0)
                {
                    datarowObjectives[0][columnname] = columnValue;

                    if (columnname.ToLower() == "status")
                    {
                        if (columnValue.ToUpper() == "D" || columnValue.ToUpper() == "C")
                        {
                            UpdatePrescribedServicesObjectives(primaryKey, SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet);
                        }
                    }
                }
            }
            SetShowHidePanels("###StartUpdateGoalObjectiveFieldValue###", "UpdateGoalObjectiveFieldValue", "###EndUpdateGoalObjectiveFieldValue###");
        }

        /// <summary>
        /// <Purpose>TO Renumber Care Plan Goal Objectives</Purpose>
        /// </summary>
        public void RenumberCarePlanGoalObjectives()
        {
            MergeLocalUnsavedXml();
            string[] rowSeparator = null;
            string[] separatorCol = null;
            DataRow[] dataRowCarePlan = null;
            string[] arrayColCollection = null;
            DataSet dataSetDocument = null;
            string tableName = string.Empty;
            string keyFieldName = string.Empty;
            string fieldText = string.Empty;

            rowSeparator = new string[] { "||" };
            separatorCol = new string[] { "$$" };
            dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;

            if (dataSetDocument != null && dataSetDocument.Tables.Count > 0)
            {
                tableName = base.GetRequestParameterValue("tableName");
                keyFieldName = base.GetRequestParameterValue("keyFieldName");
                switch (tableName.ToLower())
                {
                    case "careplangoals":
                        fieldText = "GoalNumber";
                        break;
                    case "careplanobjectives":
                        fieldText = "ObjectiveNumber";
                        break;

                }
                if (dataSetDocument.Tables.Contains(tableName) && dataSetDocument.Tables[tableName].Rows.Count > 0)
                {
                    string[] strSplitArr = base.GetRequestParameterValue("strHTML").Split(rowSeparator, StringSplitOptions.None);
                    if (strSplitArr.Length > 0)
                    {
                        for (int rowCount = 0; rowCount < strSplitArr.Length; rowCount++)
                        {
                            arrayColCollection = strSplitArr[rowCount].Split(separatorCol, StringSplitOptions.None);
                            dataRowCarePlan = dataSetDocument.Tables[tableName].Select("Isnull(RecordDeleted,'N')<>'Y' and " + keyFieldName + "=" + Convert.ToInt32(arrayColCollection[0]));
                            RenumberObjectivesSetInPrescribedServices(dataSetDocument, Convert.ToInt32(arrayColCollection[0]), arrayColCollection[1]);
                            if (dataRowCarePlan.Length > 0)
                            {
                                dataRowCarePlan[0].BeginEdit();
                                dataRowCarePlan[0][fieldText] = arrayColCollection[1];
                                dataRowCarePlan[0].EndEdit();
                                if (tableName.ToLower() == "careplangoals")
                                {
                                    ChangeObjectiveNumbers(Convert.ToInt32(dataRowCarePlan[0]["CarePlanGoalId"]), Convert.ToInt32(dataRowCarePlan[0]["GoalNumber"]), ref dataSetDocument);
                                }
                            }
                        }
                    }
                }
            }
            SetShowHidePanels("###StartRenumberCarePlanGoalObjectives###", "RenumberCarePlanGoalObjectives", "###EndRenumberCarePlanGoalObjectives###",false);
        }

        /// <summary>
        /// <Purpose>To Renumber Care Plan Goal Objectives Update in Prescribed Services Edit/View Objective</Purpose>
        /// </summary>
        private void RenumberObjectivesSetInPrescribedServices(DataSet dataSetDocument, int objectiveId, string objectiveValue)
        {
            DataRow[] dataRowCarePlan = null;
            string tableName = "CustomCarePlanPrescribedServiceObjectives";
            if (dataSetDocument.Tables.Contains(tableName) && dataSetDocument.Tables[tableName].Rows.Count > 0)
            {
                dataRowCarePlan = dataSetDocument.Tables[tableName].Select("Isnull(RecordDeleted,'N')<>'Y' and CarePlanObjectiveId =" + objectiveId);
                if (dataRowCarePlan.Length > 0)
                {
                    for (int rowCount = 0; rowCount <= (dataRowCarePlan.Length - 1); rowCount++)
                    {
                        dataRowCarePlan[rowCount].BeginEdit();
                        dataRowCarePlan[rowCount]["ObjectiveNumber"] = objectiveValue;
                        dataRowCarePlan[rowCount].EndEdit();
                    }
                }
            }
        }

        /// <summary>
        /// <Purpose>TO Change Objective Numbers</Purpose>
        /// </summary>
        private void ChangeObjectiveNumbers(int newGoalID, int newNumber, ref DataSet dataSetDocument)
        {
            DataRow[] dataRowsObjectives = null;
            string objectiveNumber = string.Empty;
            try
            {
                dataRowsObjectives = dataSetDocument.Tables["CarePlanObjectives"].Select("CarePlanGoalId=" + newGoalID);
                for (int objectiveCount = 0; objectiveCount < dataRowsObjectives.Length; objectiveCount++)
                {
                    dataRowsObjectives[objectiveCount].BeginEdit();
                    objectiveNumber = dataRowsObjectives[objectiveCount]["ObjectiveNumber"].ToString();
                    dataRowsObjectives[objectiveCount]["ObjectiveNumber"] = newNumber.ToString() + objectiveNumber.Substring(objectiveNumber.IndexOf("."));
                    dataRowsObjectives[objectiveCount].EndEdit();
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            finally
            {
                dataRowsObjectives = null;
            }
        }

        /// <summary>
        /// <Purpose>TO Delete a Care Plan Goal/Objective</Purpose>
        /// </summary>
        private void DeleteCarePlanGoalObjective()
        {
            MergeLocalUnsavedXml();
            string goalObjectiveId = base.GetRequestParameterValue("GoalObjectiveId");
            string sourceTableName = base.GetRequestParameterValue("SourceTableName");

            if (!(string.IsNullOrEmpty(goalObjectiveId) && (string.IsNullOrEmpty(sourceTableName))))
            {
                DataSet datasetDocumentCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;

                if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, sourceTableName))
                {
                    DataRow datarowCarePlanGoalObjective = datasetDocumentCarePlan.Tables[sourceTableName].NewRow();
                    if (sourceTableName.ToLower() == "careplangoals")
                    {
                        if (datasetDocumentCarePlan.Tables[sourceTableName].Rows.Count <= 1)
                        {
                            SetShowHidePanels("###StartDeleteCarePlanGoalObjective###", "Error Occurred", "###EndDeleteCarePlanGoalObjective###",false);
                            return;
                        }

                        if (datasetDocumentCarePlan.Tables[sourceTableName].Select("CarePlanGoalId=" + goalObjectiveId).Length > 0)
                            datarowCarePlanGoalObjective = datasetDocumentCarePlan.Tables[sourceTableName].Select("CarePlanGoalId=" + goalObjectiveId)[0];
                        BaseCommonFunctions.UpdateRecordDeletedInformation(datarowCarePlanGoalObjective);
                        //Call function to delete associated goals
                        DeleteGoalRelatedObjectiveOnGoalDelete(goalObjectiveId, datasetDocumentCarePlan);
                        //Call funtion to renuber goals when a single Goal is deleted
                        string concatenatedGoalIdGoalDesc = UpdateDataSetToRenumberGoalsAndObjectives(datasetDocumentCarePlan);
                        SetShowHidePanels("###StartDeleteCarePlanGoalObjective###", "CarePlanGoalId=" + goalObjectiveId + "$$$$" + concatenatedGoalIdGoalDesc, "###EndDeleteCarePlanGoalObjective###",false);
                    }

                    else if (sourceTableName.ToLower() == "careplanobjectives")
                    {
                        if (datasetDocumentCarePlan.Tables[sourceTableName].Select("CarePlanObjectiveId=" + goalObjectiveId).Length > 0)
                            datarowCarePlanGoalObjective = datasetDocumentCarePlan.Tables[sourceTableName].Select("CarePlanObjectiveId=" + goalObjectiveId)[0];
                        BaseCommonFunctions.UpdateRecordDeletedInformation(datarowCarePlanGoalObjective);
                        //Call funtion to renuber goals when a single Goal is deleted
                        string concatenatedObjIdObjNumber = UpdateDataSetToRenumberObjectives(datasetDocumentCarePlan, goalObjectiveId);

                        //Call function to delete objective's associated Prescribed services on objective's deletion
                        DeleteCarePlanObjectivesPrescribedServices(goalObjectiveId);

                        SetShowHidePanels("###StartDeleteCarePlanGoalObjective###", "CarePlanObjectiveId=" + goalObjectiveId + "$$$$" + concatenatedObjIdObjNumber, "###EndDeleteCarePlanGoalObjective###",false);

                    }
                    if (datarowCarePlanGoalObjective != null)
                    {
                        BaseCommonFunctions.UpdateRecordDeletedInformation(datarowCarePlanGoalObjective);
                    }
                }
            }
        }

        /// <summary>
        /// <Purpose>On update of Prescribed Services Field Value</Purpose>
        /// </summary>
        private void UpdatePrescribedServicesFieldValue()
        {
            string presribedServiceID = base.GetRequestParameterValue("PrimaryKeyValue");
            string sourceFieldName = base.GetRequestParameterValue("SourceFieldName");
            string sourceFieldNewValue = base.GetRequestParameterValue("SourceFieldNewValue");

            DataSet datasetCustomDocumentCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (datasetCustomDocumentCarePlan.Tables.Contains("CustomCarePlanPrescribedServices")
                && BaseCommonFunctions.CheckRowExists(datasetCustomDocumentCarePlan, "CustomCarePlanPrescribedServices")
                )
            {
                DataTable datatablePrescribedServices = datasetCustomDocumentCarePlan.Tables["CustomCarePlanPrescribedServices"];
                DataRow[] datarowPrescribedService = datatablePrescribedServices.Select("PrescribedServiceId=" + presribedServiceID);
                if (datarowPrescribedService.Length > 0)
                {
                    if (datatablePrescribedServices.Columns.Contains(sourceFieldName))
                    {
                        if (sourceFieldNewValue != DBNull.Value.ToString())
                        {
                            datarowPrescribedService[0][sourceFieldName] = sourceFieldNewValue;
                        }
                        else
                        {
                            datarowPrescribedService[0][sourceFieldName] = DBNull.Value;
                        }
                    }
                }
            }
            SetShowHidePanels("###StartUpdatePrescribedServicesFieldValue###", "UpdatePrescribedServicesFieldValue", "###EndUpdatePrescribedServicesFieldValue###");

        }

        /// <summary>
        /// <Purpose>On update of Needs Controls,Description,DeleteNeed,Action Taken</Purpose>
        /// </summary>
        private void UpdateNeedsFieldValue()
        {
            MergeLocalUnsavedXml();
            string needID = base.GetRequestParameterValue("PrimaryKeyValue");
            string sourceFieldName = base.GetRequestParameterValue("SourceFieldName");
            string sourceFieldNewValue = base.GetRequestParameterValue("SourceFieldNewValue");

            DataSet datasetCarePlanNeeds = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (datasetCarePlanNeeds.Tables.Contains("CarePlanNeeds")
                && BaseCommonFunctions.CheckRowExists(datasetCarePlanNeeds, "CarePlanNeeds")
                )
            {
                DataTable datatableNeeds = datasetCarePlanNeeds.Tables["CarePlanNeeds"];
                DataRow[] datarowNeeds = datatableNeeds.Select("NeedId=" + needID);
                if (datarowNeeds.Length > 0)
                {
                    if (datatableNeeds.Columns.Contains(sourceFieldName))
                    {
                        datarowNeeds[0][sourceFieldName] = sourceFieldNewValue;
                    }
                }
            }
            SetShowHidePanels("###StartEditAddressOnCarePlan###", "EditAddressOnCarePlan", "###EndEditAddressOnCarePlan###");

        }

        /// <summary>
        /// <Purpose>On update of Objectives Status,Disassociate the Prescribed Services Objectives</Purpose>
        /// </summary>
        private void UpdatePrescribedServicesObjectives(string objectiveId, DataSet datasetDocument)
        {
            if (datasetDocument.Tables.Contains("CustomCarePlanPrescribedServiceObjectives")
                && BaseCommonFunctions.CheckRowExists(datasetDocument, "CustomCarePlanPrescribedServiceObjectives"))
            {
                DataRow[] datarowPrescribedObjectives = datasetDocument.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanObjectiveId=" + objectiveId);
                foreach (DataRow datarowCurrent in datarowPrescribedObjectives)
                {
                    BaseCommonFunctions.UpdateRecordDeletedInformation(datarowCurrent);
                }
            }
        }

        /// <summary>
        /// Set Response of cutsom ajax call when new goal is added
        /// </summary>
        /// <param name="datatableGoals"></param>
        /// <param name="goalIdAdded"></param>
        private void SetResponseOnAddGoal(DataTable datatableGoals, int goalIdAdded, bool goalAddedFromNeedsTab)
        {
            string MonitoredByType = string.Empty;
            List<ObjectivesListData> objectObjectivesListData = null;
            objectObjectivesListData = new List<ObjectivesListData>();
            ObjectivesListData objectObjectivesList = new ObjectivesListData();
            objectObjectivesList.objectListGoals = new List<Goals>();

            DataRow datarowNewGoal = datatableGoals.Select("CarePlanGoalId=" + goalIdAdded)[0];

            Goals objectGoals = new Goals();
            objectGoals.objectListObjectives = new List<Objectives>();

            objectGoals.CarePlanGoalId = Convert.ToString(datarowNewGoal["CarePlanGoalId"]);
            objectGoals.CarePlanDomainGoalId = Convert.ToString(datarowNewGoal["CarePlanDomainGoalId"]);
            objectGoals.GoalNumber = Convert.ToString(datarowNewGoal["GoalNumber"]);
            //objectGoals.MemberGoalVision = Convert.ToString(datarowNewGoal["MemberGoalVision"]);
            objectGoals.AssociatedNeeds = "";
            objectGoals.ClientGoal = datarowNewGoal["ClientGoal"].ToString();
            objectGoals.GoalDescription = Convert.ToString(datarowNewGoal["GoalDescription"]);
            objectGoals.GoalActive = Convert.ToString(datarowNewGoal["GoalActive"]);
            objectGoals.ProgressTowardsGoal = Convert.ToString(datarowNewGoal["ProgressTowardsGoal"]);
            objectGoals.GoalReviewUpdate = Convert.ToString(datarowNewGoal["GoalReviewUpdate"]);
            objectGoals.ShowHideGoalActiveSection = Convert.ToString(datarowNewGoal["InitializedFromPreviousCarePlan"]) == "Y" ? "block" : "none";
            objectGoals.ShowHideGoalDeleteIcon = Convert.ToString(datarowNewGoal["InitializedFromPreviousCarePlan"]) == "Y" ? "none" : "block";

            MonitoredByType = Convert.ToString(datarowNewGoal["MonitoredByType"]) == "" ? "S" : Convert.ToString(datarowNewGoal["MonitoredByType"]);
            objectGoals.MonitoredByType = MonitoredByType;
            objectGoals.MonitoredBy = Convert.ToString(datarowNewGoal["MonitoredBy"]);
            objectGoals.MonitoredByOtherDescription = Convert.ToString(datarowNewGoal["MonitoredByOtherDescription"]);
            objectGoals.GoalStartDate = datarowNewGoal["GoalStartDate"] == DBNull.Value ? DateTime.Now.ToString("MM/dd/yyyy") : string.Format("{0:MM/dd/yyyy}", datarowNewGoal["GoalStartDate"]);
            objectGoals.GoalEndDate = datarowNewGoal["GoalEndDate"] == DBNull.Value ? "" : string.Format("{0:MM/dd/yyyy}", datarowNewGoal["GoalEndDate"]);
            objectGoals.IsNewGoal = "Y";
            objectGoals.IsNewCarePlanGoal = "Y";
            if (objectGoals.MonitoredBy == "" || objectGoals.MonitoredBy == "-1")
            {
                objectGoals.MonitoredBy = "-1";
                objectGoals.MonitoredByText = "Select Monitored By";
            }
            else if (MonitoredByType == "S")
            {
                objectGoals.MonitoredByText = (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff.AsEnumerable()
                                               .Where(p => p.Field<int>("StaffId") == Convert.ToInt32(objectGoals.MonitoredBy)).Select(p => p.Field<string>("DisplayAs"))).FirstOrDefault();

            }
            else if (MonitoredByType == "P")
            {
                objectGoals.MonitoredByText = (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers.AsEnumerable()
                                               .Where(p => p.Field<int>("ProviderId") == Convert.ToInt32(objectGoals.MonitoredBy)).Select(p => p.Field<string>("ProviderName"))).FirstOrDefault();

            }
            
            objectObjectivesList.objectListGoals.Add(objectGoals);
            objectGoals.RowXML = Server.HtmlEncode(ExtractARowToXML(datarowNewGoal));
            #region Get newly added row XML from both CarePlanGoals and CarePlanGoalNeeds Table
            if (goalAddedFromNeedsTab == true)
            {
                DataSet ds = new DataSet();
                ds.Tables.Add(datarowNewGoal.Table.Clone());
                ds.Tables["CarePlanGoals"].ImportRow(datarowNewGoal);
                DataRow datarowNewGoalNeeds = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["CarePlanGoalNeeds"].Select("CarePlanGoalId=" + goalIdAdded)[0];
                ds.Tables.Add(datarowNewGoalNeeds.Table.Clone());
                ds.Tables["CarePlanGoalNeeds"].ImportRow(datarowNewGoalNeeds);
                objectGoals.RowXML = Server.HtmlEncode(ExtractARowToXML(ds));
            }
            #endregion

            
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string objectStringGoalObjectivesJSON = objectJavaScriptSerializer.Serialize(objectObjectivesList);
            if (goalAddedFromNeedsTab == true)
            {
                SetShowHidePanels("###StartAddGoalFromNeedsTab###", objectStringGoalObjectivesJSON, "###EndAddGoalFromNeedsTab###",false);
                ParentDetailPageObject.SetParentScreenProperties("GoalId", Convert.ToString(goalIdAdded));
            }
            else
            {
                SetShowHidePanels("###StartAddGoal###", objectStringGoalObjectivesJSON, "###EndAddGoal###",false);
                ParentDetailPageObject.SetParentScreenProperties("GoalId", Convert.ToString(goalIdAdded));
            }
        }

        /// <summary>
        /// Set Response of cutsom ajax call when new objective is added
        /// </summary>
        /// <param name="datatableObjectives"></param>
        /// <param name="objectiveIdAdded"></param>
        /// <param name="goalId"></param>
        private void SetResponseOnAddObjective(DataTable datatableObjectives, int objectiveIdAdded, int goalId)
        {
            Objectives objectObjective = new Objectives();
            if (datatableObjectives.Rows.Count > 0)
            {
                DataRow datarowNewObjective = datatableObjectives.Select("CarePlanObjectiveId=" + objectiveIdAdded)[0];
                objectObjective.CarePlanDomainObjectiveId = Convert.ToString(datarowNewObjective["CarePlanDomainObjectiveId"]);
                objectObjective.CarePlanGoalId = Convert.ToString(goalId);
                objectObjective.MemberActions = Convert.ToString(datarowNewObjective["MemberActions"]);
                objectObjective.ObjectiveDescription = Convert.ToString(datarowNewObjective["ObjectiveDescription"]);
                objectObjective.CarePlanObjectiveId = Convert.ToString(objectiveIdAdded);
                objectObjective.ObjectiveNumber = Convert.ToString(datarowNewObjective["ObjectiveNumber"]);
                objectObjective.PrescribedServices = string.Empty;
                objectObjective.ShowHideObjectiveDeleteIcon = "Y";
                objectObjective.StaffSupports = Convert.ToString(datarowNewObjective["StaffSupports"]);
                objectObjective.Status = Convert.ToString(datarowNewObjective["Status"]);
                objectObjective.UseOfNaturalSupports = Convert.ToString(datarowNewObjective["UseOfNaturalSupports"]);
                objectObjective.ObjectiveStartDate = datarowNewObjective["ObjectiveStartDate"] == DBNull.Value ? DateTime.Now.ToString("MM/dd/yyyy") : Convert.ToDateTime(datarowNewObjective["ObjectiveStartDate"]).ToString("MM/dd/yyyy");
                //if (!string.IsNullOrEmpty(datarowNewObjective["ObjectiveEndDate"].ToString()))
                //    objectObjective.ObjectiveEndDate = Convert.ToDateTime(datarowNewObjective["ObjectiveEndDate"]).ToString("MM/dd/yyyy");

                //EI#677 - Analysis and Resolution to Fix - Exception: "There is no row at position 0" in SmartCare Application
                if (SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.IsDataTableFound("DocumentCarePlans"))                
                {
                    if (SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["DocumentCarePlans"].Rows[0]["CarePlanType"].ToString() == "RE" && SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("SetReviewInCarePlan").ToString().Trim() == "Y")
                        objectObjective.IsReview = "Y";
                    else
                        objectObjective.IsReview = "N";
                }
                if (SHS.BaseLayer.BaseCommonFunctions.GetSystemConfigurationValue("SetReviewInCarePlan").ToString().Trim() == "Y")
                objectObjective.IsNewObjective = "Y";
                else
                    objectObjective.IsNewObjective="N";
                objectObjective.RowXML = Server.HtmlEncode(ExtractARowToXML(datarowNewObjective));
            }
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string objectStringGoalObjectivesJSON = objectJavaScriptSerializer.Serialize(objectObjective);
            SetShowHidePanels("###StartAddObjective###", objectStringGoalObjectivesJSON, "###EndAddObjective###",false);
            ParentDetailPageObject.SetParentScreenProperties("ObjectiveId", Convert.ToString(objectiveIdAdded));

        }

        /// <summary>
        /// <purpose>Delete Service Group Values when CheckBox is UnChecked according to PrescribedServiceId </purpose>
        /// </summary>
        public void DeleteServiceGroupValuesCheckBoxUnChecked()
        {
            MergeLocalUnsavedXml();
            string PrescribedServiceId = base.GetRequestParameterValue("PrescribedServiceId");
            string IsChecked = base.GetRequestParameterValue("IsChecked");

            DataSet dataSetCarePlanDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            DataTable datatablePrescribedServices = dataSetCarePlanDocument.Tables["CustomCarePlanPrescribedServices"];
            DataTable datatablePrescribedServicesObjective = dataSetCarePlanDocument.Tables["CustomCarePlanPrescribedServiceObjectives"];

            DataRow[] datarowDeletePrescribedServices = null;
            DataRow[] datarowDeletePrescribedServicesObjectives = null;
            if (BaseCommonFunctions.CheckRowExists(dataSetCarePlanDocument.Tables["CustomCarePlanPrescribedServices"], 0))
            {
                datarowDeletePrescribedServices = datatablePrescribedServices.Select("CarePlanPrescribedServiceId=" + PrescribedServiceId);
                if (datarowDeletePrescribedServices.Length > 0)
                {
                    datarowDeletePrescribedServices[0]["NumberOfSessions"] = DBNull.Value;
                    datarowDeletePrescribedServices[0]["Units"] = DBNull.Value;
                    datarowDeletePrescribedServices[0]["UnitType"] = DBNull.Value;
                    datarowDeletePrescribedServices[0]["FrequencyType"] = DBNull.Value;
                    datarowDeletePrescribedServices[0]["PersonResponsible"] = DBNull.Value;
                   datarowDeletePrescribedServices[0]["InterventionDetails"] = DBNull.Value;
                    datarowDeletePrescribedServices[0]["IsChecked"] = "N";
                }
                if (BaseCommonFunctions.CheckRowExists(dataSetCarePlanDocument.Tables["CustomCarePlanPrescribedServiceObjectives"], 0))
                {
                    datarowDeletePrescribedServicesObjectives = datatablePrescribedServicesObjective.Select("CarePlanPrescribedServiceId=" + PrescribedServiceId);
                    if (datarowDeletePrescribedServicesObjectives.Length > 0)
                    {
                        datarowDeletePrescribedServicesObjectives[0]["RecordDeleted"] = "Y";
                        BaseCommonFunctions.UpdateRecordDeletedInformation(datarowDeletePrescribedServicesObjectives[0]);
                    }
                }
                SetShowHidePanels("###StartDeletePrescribedServices###", "DeletePrescribedServices", "###EndDeletePrescribedServices###",false);
            }
        }
        /// <summary>
        /// Set Response of cutsom ajax call when Add Needs
        /// </summary>
        /// <param name="datatableGoals"></param>
        /// <param name="goalIdAdded"></param>
        private void SetResponseOnAddNeed(DataTable datatableAddNeeds, int domainId)
        {
            DataSet dataSetScreenData = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            List<NeedsListData> objectListGridData = null;
            NeedsListData objectNeedListData = new NeedsListData();
            objectNeedListData.objectListDomain = new List<Domain>();
            Domain objectDomain = new Domain();
            objectDomain.objectListNeeds = new List<Needs>();
            objectDomain.CarePlanDomainId = Convert.ToString(domainId);
            string documentCodeId = "1501";
            foreach (DataRow datarowNeeds in datatableAddNeeds.Select("DomainId=" + objectDomain.CarePlanDomainId))
            {
                Needs objectNeed = new Needs();
                objectNeed.objectListNeedGoals = new List<NeedGoals>();
                objectNeed.CarePlanNeedId = Convert.ToString(datarowNeeds["NeedId"]);
                objectNeed.CarePlanDomainNeedId = Convert.ToString(datarowNeeds["DomainNeedId"]);
                objectNeed.AddressOnCarePlan = Convert.ToString(datarowNeeds["AddressOnCarePlan"]);
                objectNeed.NeedDescription = string.Empty;
                objectNeed.CarePlanDomainId = Convert.ToString(datarowNeeds["DomainId"]);
                objectNeed.NeedName = Convert.ToString(datarowNeeds["NeedName"]);
                objectNeed.Source = "C";
                objectNeed.SourceName = Screenname;
                objectNeed.DocumentCodeId = documentCodeId;
                objectNeed.RowXML = Server.HtmlEncode(ExtractARowToXML(dataSetScreenData.Tables["CarePlanNeeds"].Select("CarePlanNeedId=" + datarowNeeds["NeedId"])[0]));
                objectNeed.ActionTakenIsGoalExist = "0";
                objectDomain.objectListNeeds.Add(objectNeed);
            }
            if (objectDomain.objectListNeeds.Count == 1)
                objectDomain.NoIdenifiedNeedMsg = "No identified needs";
            objectDomain.NoIdenifiedNeedMsg = "";

            objectNeedListData.objectListDomain.Add(objectDomain);
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string strJSON = objectJavaScriptSerializer.Serialize(objectNeedListData);
            SetShowHidePanels("###StartAddNeedsPopUp###", strJSON + "$$$" + domainId, "###EndAddNeedsPopUp###",false);
        }

        /// <summary>
        /// Set Response of cutsom jaax call when new objective is added
        /// </summary>
        /// <param name="datatableObjectives"></param>
        /// <param name="objectiveIdAdded"></param>
        /// <param name="goalId"></param>
        private void SetResponseOnPrescribedServiceObjective(DataTable datatablePSO, int prescribedServiceId)
        {
            string ObjectiveNumberStringComma = string.Empty;
            string ObjectiveNumberString = string.Empty;
            string clinetName = string.Empty;
            DataSet dataSetCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (dataSetCarePlan != null && dataSetCarePlan.Tables.Contains("DocumentCarePlans"))
            {
                DataTable datatableCarePlans = dataSetCarePlan.Tables["DocumentCarePlans"];
                clinetName = datatableCarePlans.Rows[0]["NameInGoalDescriptions"].ToString();
            }
            List<EditViewObjectives> objectListEditViewObjectives = null;
            objectListEditViewObjectives = new List<EditViewObjectives>();

            DataRow[] dataRowPrescribedServiceObjectivesArray = datatablePSO.Select("CarePlanPrescribedServiceId=" + prescribedServiceId + "AND ISNULL(RecordDeleted,'N')<>'Y'", "ObjectiveNumber ASC");
            string htmlObjectiveSection = string.Empty;
            string objectiveDesc = string.Empty;
            string ObjectiveNum = string.Empty;

            for (int rowCounter = 0; rowCounter < dataRowPrescribedServiceObjectivesArray.Length; rowCounter++)
            {
                EditViewObjectives objectEditViewObjectives = new EditViewObjectives();
                objectiveDesc = Convert.ToString(dataRowPrescribedServiceObjectivesArray[rowCounter]["ObjectiveDescription"]);
                ObjectiveNum = Convert.ToString(dataRowPrescribedServiceObjectivesArray[rowCounter]["ObjectiveNumber"]);

                if (rowCounter == dataRowPrescribedServiceObjectivesArray.Length - 1)
                {
                    htmlObjectiveSection = ObjectiveNum;
                }
                else
                {
                    htmlObjectiveSection = ObjectiveNum + ", ";
                }

                htmlObjectiveSection = HttpUtility.HtmlDecode(htmlObjectiveSection);
                objectEditViewObjectives.ObjectiveNumber = htmlObjectiveSection;
                objectEditViewObjectives.ObjectiveDescription =  objectiveDesc;
                objectEditViewObjectives.RowXML = Server.HtmlEncode(ExtractARowToXML(dataRowPrescribedServiceObjectivesArray[rowCounter]));
                objectListEditViewObjectives.Add(objectEditViewObjectives);
            }
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string objectStringGoalObjectivesJSON = objectJavaScriptSerializer.Serialize(objectListEditViewObjectives);
            SetShowHidePanels("###StartEditViewObjectiveDescription###", "PrescribedServiceId=" + prescribedServiceId + "$$$" + objectStringGoalObjectivesJSON, "###EndEditViewObjectiveDescription###",false);
        }

        /// <summary>
        /// //Purpose : To update the name in goald esc on change of value in textfield NameInGoalDescriptions
        /// </summary>
        private void UpdateNameInGoalDescInSessionDataset()
        {
            MergeLocalUnsavedXml();
            string nameInGoalDescriptions = base.GetRequestParameterValue("NameInGoalDescriptions");

            DataSet datasetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (datasetDocument.Tables.Contains("DocumentCarePlans") && BaseCommonFunctions.CheckRowExists(datasetDocument, "DocumentCarePlans"))
            {
                datasetDocument.Tables["DocumentCarePlans"].Rows[0].BeginEdit();
                datasetDocument.Tables["DocumentCarePlans"].Rows[0]["NameInGoalDescriptions"] = nameInGoalDescriptions;
                datasetDocument.Tables["DocumentCarePlans"].Rows[0].EndEdit();
            }
            SetShowHidePanels("###StartUpdateNameInGoalDescInSessionDataset###", "UpdateNameInGoalDescInSessionDataset", "###EndUpdateNameInGoalDescInSessionDataset###",false);
        }

        /// <summary>
        /// <Purpose>On update of Prescribed Services Field Value</Purpose>
        /// </summary>
        private void AddUpdateTreatmentTeamFieldValue()
        {
            MergeLocalUnsavedXml();
            string ProgramId = Convert.ToString(base.GetRequestParameterValue("ProgramId"));
            string StaffId = Convert.ToString(base.GetRequestParameterValue("StaffId"));
            string AssignForContribution = Convert.ToString(base.GetRequestParameterValue("AssignForContribution"));
            string strCarePlanTeamId = Convert.ToString(base.GetRequestParameterValue("CarePlanTeamId"));
            int CarePlanTeamId = 0;
            int.TryParse(strCarePlanTeamId, out CarePlanTeamId);
            string ProgramName = Convert.ToString(base.GetRequestParameterValue("ProgramName"));
            string StaffName = Convert.ToString(base.GetRequestParameterValue("StaffName"));

            int documentVersionId = Convert.ToInt32(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["DocumentVersions"].Rows[0]["DocumentVersionId"]);
            DataTable datatableCarePlanTeams = null;
            DataSet datasetCustomCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            DataRow datarowCarePlanTeams = null;
            if (datasetCustomCarePlan.Tables.Contains("CarePlanPrograms"))
            {
                datatableCarePlanTeams = datasetCustomCarePlan.Tables["CarePlanPrograms"];

                if (datatableCarePlanTeams.Select("CarePlanProgramId=" + CarePlanTeamId.ToString()).Length > 0)
                {
                    datarowCarePlanTeams = datatableCarePlanTeams.Select("CarePlanProgramId=" + CarePlanTeamId.ToString())[0];
                    datarowCarePlanTeams["ProgramId"] = (string.IsNullOrEmpty(ProgramId)) ? "0" : ProgramId;
                    datarowCarePlanTeams["StaffId"] = (string.IsNullOrEmpty(StaffId)) ? "0" : StaffId;
                    datarowCarePlanTeams["AssignForContribution"] = AssignForContribution;
                    datarowCarePlanTeams["DocumentVersionId"] = documentVersionId;
                    datarowCarePlanTeams["ProgramName"] = ProgramName;
                    datarowCarePlanTeams["StaffName"] = StaffName;
                    BaseCommonFunctions.UpdateModifiedInformation(datarowCarePlanTeams);

                }
                else
                {
                    datarowCarePlanTeams = datatableCarePlanTeams.NewRow();
                    datarowCarePlanTeams["ProgramId"] = (string.IsNullOrEmpty(ProgramId)) ? "0" : ProgramId;
                    datarowCarePlanTeams["StaffId"] = (string.IsNullOrEmpty(StaffId)) ? "0" : StaffId;
                    datarowCarePlanTeams["AssignForContribution"] = AssignForContribution;
                    datarowCarePlanTeams["DocumentVersionId"] = documentVersionId;
                    datarowCarePlanTeams["ProgramName"] = ProgramName;
                    datarowCarePlanTeams["StaffName"] = StaffName;
                    BaseCommonFunctions.InitRowCredentials(datarowCarePlanTeams);

                    datatableCarePlanTeams.Rows.Add(datarowCarePlanTeams);
                }
            }
            SetResponseAddEditTreatmentTeam(datarowCarePlanTeams, ProgramName, StaffName);
        }

        /// <summary>
        /// Set Response of cutsom ajax call when Add Edit Treatment Team
        /// </summary>
        /// <param name="DataTable"></param>
        private void SetResponseAddEditTreatmentTeam(DataRow datarowCarePlanTeams, string ProgramName, string StaffName)
        {
            string CarePlanTeamId = string.Empty;
            List<TreatmentTeamListData> objectTreatmentTeamListData = null;
            objectTreatmentTeamListData = new List<TreatmentTeamListData>();

            TreatmentTeamListData objCPTreatmentTeam = new TreatmentTeamListData();
            objCPTreatmentTeam.objectListTreatmentTeamData = new List<TreatmentTeamData>();

            if (datarowCarePlanTeams != null)
            {
                DataRow datarowTreatmentTeam = datarowCarePlanTeams;
                TreatmentTeamData objectTreatmentTeam = new TreatmentTeamData();
                objectTreatmentTeam.CarePlanProgramId = Convert.ToString(datarowTreatmentTeam["CarePlanProgramId"]);
                objectTreatmentTeam.DocumentVersionId = Convert.ToString(datarowTreatmentTeam["DocumentVersionId"]);
                objectTreatmentTeam.ProgramId = Convert.ToString(datarowTreatmentTeam["ProgramId"]);
                objectTreatmentTeam.ProgramName = ProgramName;
                objectTreatmentTeam.StaffId = Convert.ToString(datarowTreatmentTeam["StaffId"]);
                objectTreatmentTeam.StaffName = StaffName;
                objectTreatmentTeam.AssignForContribution = Convert.ToString(datarowTreatmentTeam["AssignForContribution"]);
                objectTreatmentTeam.Completed = Convert.ToString(datarowTreatmentTeam["DocumentVersionId"]);
                objectTreatmentTeam.DocumentAssignedTaskId = Convert.ToString(datarowTreatmentTeam["DocumentAssignedTaskId"]);
                objectTreatmentTeam.RowXML = Server.HtmlEncode(ExtractARowToXML(datarowTreatmentTeam));
                objCPTreatmentTeam.objectListTreatmentTeamData.Add(objectTreatmentTeam);
            }
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string strTreatmentTeam = objectJavaScriptSerializer.Serialize(objCPTreatmentTeam);
            SetShowHidePanels("###StartAddEditTreatmentTeam###", strTreatmentTeam, "###EndAddEditTreatmentTeam###");
        }

        /// <summary>
        /// <purpose>Delete Treatment Team in Grid Selected Record</purpose>
        /// </summary>
        public void DeleteTreatmentTeam()
        {
            MergeLocalUnsavedXml();
            int CarePlanTeamId = Convert.ToInt32(base.GetRequestParameterValue("CarePlanTeamId"));

            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            DataTable datatableTreatmentTeam = dataSetDocument.Tables["CarePlanPrograms"];

            DataRow datarowDeleteTreatmentTeam = null;
            if (BaseCommonFunctions.CheckRowExists(dataSetDocument.Tables["CarePlanPrograms"], 0))
            {
                datarowDeleteTreatmentTeam = datatableTreatmentTeam.Select("CarePlanProgramId=" + CarePlanTeamId)[0];
                datarowDeleteTreatmentTeam["RecordDeleted"] = "Y";
                BaseCommonFunctions.UpdateRecordDeletedInformation(datarowDeleteTreatmentTeam);
                SetShowHidePanels("###StartDeleteTreatmentTeam###", "CarePlanTeamId=" + CarePlanTeamId, "###EndDeleteTreatmentTeam###",false);
            }
        }

        /// <summary>
        /// <purpose>Update Value in Treatment Team</purpose>
        /// </summary>
        private void UpdateTreatmentTeamFieldValue()
        {
            MergeLocalUnsavedXml();
            string columnName = base.GetRequestParameterValue("ColumnName").Trim();
            string primaryKeyValue = base.GetRequestParameterValue("PrimaryKeyValue").Trim();
            string sourceFieldNewValue = base.GetRequestParameterValue("SourceFieldNewValue").Trim();

            DataSet datasetCustomDocumentCarePlan = BaseCommonFunctions.GetScreenInfoDataSet();
            if (datasetCustomDocumentCarePlan.Tables.Contains("CarePlanPrograms")
                && BaseCommonFunctions.CheckRowExists(datasetCustomDocumentCarePlan, "CarePlanPrograms")
                )
            {
                DataTable datatableTreatmentTeam = datasetCustomDocumentCarePlan.Tables["CarePlanPrograms"];
                DataRow[] datarowTreatmentTeam = datatableTreatmentTeam.Select("CarePlanProgramId=" + primaryKeyValue);
                if (datarowTreatmentTeam.Length > 0)
                {
                    if (datatableTreatmentTeam.Columns.Contains(columnName))
                    {
                        if (sourceFieldNewValue != DBNull.Value.ToString())
                        {
                            datarowTreatmentTeam[0][columnName] = sourceFieldNewValue;
                        }
                        else
                        {
                            datarowTreatmentTeam[0][columnName] = DBNull.Value;
                        }
                    }
                }
            }
            SetShowHidePanels("###StartUpdateTreatmentTeamFieldValue###", "TreatmentTeamFieldValue", "###EndUpdateTreatmentTeamFieldValue###",false);

        }

        /// <summary>
        /// <purpose>Check for Non-Author Staff for Treatment Plan Program</purpose>
        /// </summary>
        public void CheckNonAuthorStaffPrograms()
        {
            int staffId = 0;
            staffId = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId;
            int clientId = -1;
            int.TryParse(Convert.ToString(BaseCommonFunctions.ApplicationInfo.Client.ClientId), out clientId);
            int staffProgramCount = 0;
            int documentversionId = 0;

            if (clientId != -1)
            {
                DataSet datasetDocumentCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;


                DataTable datatableCustomCarePlans = datasetDocumentCarePlan.Tables["DocumentCarePlans"];
                if (BaseCommonFunctions.CheckRowExists(datatableCustomCarePlans, 0))
                {
                    documentversionId = Convert.ToInt32(datatableCustomCarePlans.Rows[0]["DocumentVersionId"]);
                }

                #region Check if that non-author staff already exists, then we do not need to insert it again
                if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CarePlanPrograms"))
                {
                    DataTable datatableCarePlanTreatmentTeam = datasetDocumentCarePlan.Tables["CarePlanPrograms"];
                    DataRow[] datarowLogegdInUserTeam = datatableCarePlanTreatmentTeam.Select("StaffId=" + staffId + "AND ISNULL(RecordDeleted,'N')<>'Y'");
                    if (datarowLogegdInUserTeam.Length > 0)
                    {
                        //do nothing - neither insert nor we need to open popup for program choosing
                        SetShowHidePanels("###StartCheckNonAuthorStaffPrograms###", Convert.ToString(1), "###EndCheckNonAuthorStaffPrograms###",false);
                        return;
                    }
                }
                #endregion

                using (SHS.UserBusinessServices.CarePlan objectCarePlan = new SHS.UserBusinessServices.CarePlan())
                {
                    DataSet datasetClientPrograms = objectCarePlan.GetClientPrograms(clientId, staffId);
                    if (BaseCommonFunctions.CheckRowExists(datasetClientPrograms, "TableClientPrograms"))
                    {
                        DataTable datatableClientPrograms = datasetClientPrograms.Tables["TableClientPrograms"];
                        if (datatableClientPrograms.Rows.Count == 1)
                        {
                            DataRow datarowNew = datasetDocumentCarePlan.Tables["CarePlanPrograms"].NewRow();
                            datarowNew["ProgramId"] = datatableClientPrograms.Rows[0]["ProgramId"];
                            datarowNew["StaffId"] = staffId;
                            datarowNew["DocumentVersionId"] = documentversionId;
                            BaseCommonFunctions.InitRowCredentials(datarowNew);
                            datasetDocumentCarePlan.Tables["CarePlanPrograms"].Rows.Add(datarowNew);

                        }
                        staffProgramCount = datatableClientPrograms.Rows.Count;
                    }
                }
            }
            SetShowHidePanels("###StartCheckNonAuthorStaffPrograms###", Convert.ToString(staffProgramCount), "###EndCheckNonAuthorStaffPrograms###",false);
        }

        /// <summary>
        /// <purpose>Update Value in Treatment Team through POPup when Document Save</purpose>
        /// </summary>
        private void AddNewTreatmentTeamMember()
        {
            MergeLocalUnsavedXml();
            string strProgramId = Convert.ToString(base.GetRequestParameterValue("ProgramId"));
            int programId = 0;
            int.TryParse(strProgramId, out programId);
            string ProgramName = Convert.ToString(base.GetRequestParameterValue("ProgramName"));
            int documentVersionId = Convert.ToInt32(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["DocumentVersions"].Rows[0]["DocumentVersionId"]);
            int staffId = Convert.ToInt32(BaseCommonFunctions.ApplicationInfo.LoggedInUser.LoggedinUserId);
            string staffName = Convert.ToString(BaseCommonFunctions.ApplicationInfo.LoggedInUser.LoggedinUserName);

            DataTable datatableCarePlanTeams = null;
            DataSet datasetCustomCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            DataRow datarowCarePlanTeams = null;
            if (datasetCustomCarePlan.Tables.Contains("CarePlanPrograms"))
            {
                datatableCarePlanTeams = datasetCustomCarePlan.Tables["CarePlanPrograms"];

                datarowCarePlanTeams = datatableCarePlanTeams.NewRow();
                datarowCarePlanTeams["ProgramId"] = programId;
                datarowCarePlanTeams["DocumentVersionId"] = documentVersionId;
                datarowCarePlanTeams["ProgramName"] = ProgramName;
                datarowCarePlanTeams["StaffId"] = staffId;
                datarowCarePlanTeams["StaffName"] = staffName;
                BaseCommonFunctions.InitRowCredentials(datarowCarePlanTeams);
                datatableCarePlanTeams.Rows.Add(datarowCarePlanTeams);

            }
            SetShowHidePanels("###StartAddNewTreatmentTeamMember###", "AddNewTreatmentTeamMember", "###EndAddNewTreatmentTeamMember###");

        }

        /// <summary>
        /// //Purpose: To Update Goals&Objectives Number when a goal is deleted
        /// </summary>
        /// <param name="datasetDocumentCarePlan"></param>
        /// <returns></returns>
        private string UpdateDataSetToRenumberGoalsAndObjectives(DataSet datasetDocumentCarePlan)
        {
            string stringConcatGoalIdGoalNumber = string.Empty;
            DataTable datatableCarePlanObjective = null;
            double objectiveNumber = 0.0;
            string stringConcatObjIdObjNumber = string.Empty;
            int counter = 0;
            string goalId = string.Empty;
            string objectiveId = string.Empty;
            double previousObjectNumber = 0.0;

            if (datasetDocumentCarePlan != null)
            {

                if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CarePlanGoals", 0))
                {
                    if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CarePlanObjectives"))
                    {
                        datatableCarePlanObjective = datasetDocumentCarePlan.Tables["CarePlanObjectives"];
                    }

                    DataRow[] datarowCarePlanGoals = datasetDocumentCarePlan.Tables["CarePlanGoals"].Select("ISNULL(RecordDeleted,'N')<>'Y'", "GoalNumber");
                    int rowCounter = 0;
                    foreach (DataRow datarowCurrent in datarowCarePlanGoals)
                    {
                        counter = 0;
                        previousObjectNumber = 0.0;
                        rowCounter = rowCounter + 1;
                        goalId = Convert.ToString(datarowCurrent["CarePlanGoalId"]);
                        datarowCurrent["GoalNumber"] = Convert.ToString(rowCounter);
                        stringConcatGoalIdGoalNumber += goalId + "-->" + "Goal # " + rowCounter + "^^^";
                        if (datatableCarePlanObjective != null)
                        {
                            DataRow[] datarowObjectives = datatableCarePlanObjective.Select("CarePlanGoalId=" + datarowCurrent["CarePlanGoalId"] + "AND ISNULL(RecordDeleted,'N')<>'Y'", "ObjectiveNumber");

                            foreach (DataRow datarowCarePlanObj in datarowObjectives)
                            {
                                objectiveId = Convert.ToString(datarowCarePlanObj["CarePlanObjectiveId"]);
                                if (counter == 0)
                                {
                                    objectiveNumber = Math.Round(Convert.ToDouble(datarowCurrent["GoalNumber"]) + .01, 2);
                                }
                                else
                                {
                                    objectiveNumber = Math.Round((previousObjectNumber + .01), 2);
                                }
                                datarowCarePlanObj["ObjectiveNumber"] = objectiveNumber;
                                stringConcatObjIdObjNumber += objectiveId + "-->" + objectiveNumber + "^^^";
                                counter = counter + 1;
                                previousObjectNumber = objectiveNumber;
                            }
                        }
                    }
                }
            }
            return stringConcatGoalIdGoalNumber + "####" + stringConcatObjIdObjNumber;
        }

        /// <summary>
        /// //Purpose: To Update Objectives Number when an Objective is deleted 
        /// </summary>
        /// <param name="datasetDocumentCarePlan"></param>
        /// <param name="deletedObjId"></param>
        /// <returns></returns>
        private string UpdateDataSetToRenumberObjectives(DataSet datasetDocumentCarePlan, string deletedObjId)
        {
            string concatedNatedObjIdAndObjNo = string.Empty;
            DataTable datatableObjectives = datasetDocumentCarePlan.Tables["CarePlanObjectives"];
            double previousObjectNumber = 0.0;
            string goalNumber = string.Empty;

            if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CarePlanObjectives", 0))
            {
                DataTable datatableCarePlanObj = datasetDocumentCarePlan.Tables["CarePlanObjectives"];
                DataRow[] datarowDeletedObj = datatableCarePlanObj.Select("CarePlanObjectiveId=" + deletedObjId);
                string goalId = Convert.ToString(datarowDeletedObj[0]["CarePlanGoalId"]);
                if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CarePlanGoals"))
                {
                    DataRow[] datarowGoal = datasetDocumentCarePlan.Tables["CarePlanGoals"].Select("CarePlanGoalId=" + goalId);
                    if (datarowGoal.Length > 0)
                    {
                        goalNumber = Convert.ToString(datarowGoal[0]["GoalNumber"]);
                    }
                }

                DataView dataviewObj = datatableCarePlanObj.DefaultView;
                dataviewObj.RowFilter = "CarePlanGoalId=" + goalId + "AND ISNULL(RecordDeleted,'N')<>'Y'";
                string objectiveId = string.Empty;
                double objectiveNumber = 0.0;
                int counter = 0;
                if (dataviewObj != null)
                {
                    for (int rowCount = 0; rowCount < dataviewObj.Count; rowCount++)
                    {
                        objectiveId = Convert.ToString(dataviewObj[rowCount]["CarePlanObjectiveId"]);
                        if (counter == 0)
                        {
                            objectiveNumber = Math.Round(Convert.ToDouble(goalNumber) + .01, 2);
                        }
                        else
                        {
                            objectiveNumber = Math.Round((previousObjectNumber + .01), 2);
                        }
                        dataviewObj[rowCount]["ObjectiveNumber"] = objectiveNumber;
                        concatedNatedObjIdAndObjNo += objectiveId + "-->" + objectiveNumber + "^^^";
                        counter = counter + 1;
                        previousObjectNumber = objectiveNumber;
                        UpdatePriscribedObjectIdRenumber(datasetDocumentCarePlan, objectiveId, objectiveNumber);
                    }
                }
            }
            return concatedNatedObjIdAndObjNo;
        }

        /// <summary>
        /// //Purpose: Objective Renumber in Prescribed Services
        /// </summary>
        /// <param name="deletedGoalId"></param>
        /// <param name="datasetDocumentCarePlan"></param>
        private void UpdatePriscribedObjectIdRenumber(DataSet datasetDocumentCarePlan, string objectiveId, double objectivNumber)
        {
            if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CustomCarePlanPrescribedServiceObjectives"))
            {
                DataRow[] datarowPrescribedServiceObj = datasetDocumentCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanObjectiveId=" + objectiveId + " AND ISNULL(RecordDeleted,'N')<>'Y'");
                if (datarowPrescribedServiceObj != null && datarowPrescribedServiceObj.Length > 0)
                {
                    foreach (DataRow datarowCurrent in datarowPrescribedServiceObj)
                    {
                        if (datarowCurrent.Table.Columns.Contains("ObjectiveNumber"))
                        { datarowCurrent["ObjectiveNumber"] = objectivNumber; }
                    }
                }
            }
        }


        /// <summary>
        /// //Purpose: To Delete Goal's Associated Objectives when a goal is deleted
        /// </summary>
        /// <Discription>
        /// What: Associated Objectives Deleted From Priscribed Services When Goal is deleted, Added New Function DeleteCarePlanObjectivesPrescribedServices() with in DeleteGoalRelatedObjectiveOnGoalDelete() function
        /// Why: Made changes as per task#2799 ,Care Plan; Objectives-prescribed services, Thresholds - Bugs/Features (Offshore)
        /// </Discription>
        /// <param name="deletedGoalId"></param>
        /// <param name="datasetDocumentCarePlan"></param>
        private void DeleteGoalRelatedObjectiveOnGoalDelete(string deletedGoalId, DataSet datasetDocumentCarePlan)
        {
            if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CarePlanObjectives"))
            {
                DataRow[] datarowGoalRelatedObjs = datasetDocumentCarePlan.Tables["CarePlanObjectives"].Select("CarePlanGoalId=" + deletedGoalId + " AND ISNULL(RecordDeleted,'N')<>'Y'");
                if (datarowGoalRelatedObjs.Length > 0)
                {
                    foreach (DataRow datarowCurrent in datarowGoalRelatedObjs)
                    {
                        BaseCommonFunctions.UpdateRecordDeletedInformation(datarowCurrent);

                        //Call function to delete objective's associated Prescribed services on objective's deletion
                        DeleteCarePlanObjectivesPrescribedServices(Convert.ToString(datarowCurrent["CarePlanObjectiveId"]));
                    }
                }
            }
        }

        /// <summary>
        /// <purpose>To Delete the associated Prescribed Service Objective when an objective is deleted</purpose>
        /// </summary>
        /// <param name="datasetDocumentCarePlan"></param>
        /// <param name="deletedObjId"></param>
        /// <Discription>What:UpdateRecordDeletedInformation Pass Current DataRow, Why: Deleted Objects not deleted in Priscribed Services</Discription>
        private void DeleteCarePlanObjectivesPrescribedServices(string deletedObjId)
        {
            DataSet datasetDocumentCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (BaseCommonFunctions.CheckRowExists(datasetDocumentCarePlan, "CustomCarePlanPrescribedServiceObjectives"))
            {
                DataRow[] datarowPrescribedServiceObj = datasetDocumentCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanObjectiveId=" + deletedObjId);
                if (datarowPrescribedServiceObj != null && datarowPrescribedServiceObj.Length > 0)
                {
                    foreach (DataRow datarowCurrent in datasetDocumentCarePlan.Tables["CustomCarePlanPrescribedServiceObjectives"].Select("CarePlanObjectiveId=" + deletedObjId))
                    {
                        BaseCommonFunctions.UpdateRecordDeletedInformation(datarowCurrent);
                    }
                }
            }
        }

        //public override DataSet GetData()
        //{
        //    DataSet datasetDocumentCarePlan = base.GetData();

        //    if (datasetDocumentCarePlan == null)
        //        return null;

        //    if (datasetDocumentCarePlan.Tables.Contains("CustomCarePlanPrescribedServices"))
        //    {
        //        if (datasetDocumentCarePlan.Tables.Contains("ClientProgramsAuthorizationCodes"))
        //        {
        //            DataRow[] datarowAuthCode = null;
        //            DataRow[] datarowPrescService = null;
        //            string authCodeId = string.Empty;
        //            DataTable datatablePrescribedServices = datasetDocumentCarePlan.Tables["CustomCarePlanPrescribedServices"];
        //            DataTable datatableAuthCode = datasetDocumentCarePlan.Tables["ClientProgramsAuthorizationCodes"];


        //            int documentversionId = 0;
        //            DataTable datatableCustomCarePlans = datasetDocumentCarePlan.Tables["DocumentCarePlans"];
        //            if (BaseCommonFunctions.CheckRowExists(datatableCustomCarePlans, 0))
        //            {
        //                documentversionId = Convert.ToInt32(datatableCustomCarePlans.Rows[0]["DocumentVersionId"]);
        //            }
        //            if (documentversionId > 0)
        //            {
        //                foreach (DataRow datarowCurrentPrescribedService in datatablePrescribedServices.Rows)
        //                {
        //                    datarowAuthCode = null;
        //                    authCodeId = Convert.ToString(datarowCurrentPrescribedService["AuthorizationCodeId"]);
        //                    datarowAuthCode = datatableAuthCode.Select("AuthorizationCodeId=" + authCodeId);
        //                    if (datarowAuthCode != null && datarowAuthCode.Length > 0)
        //                    {
        //                        //do nothing
        //                        //Do not do anything if AuthorizationCode still exists
        //                    }
        //                    else
        //                    {
        //                        BaseCommonFunctions.UpdateRecordDeletedInformation(datarowCurrentPrescribedService);
        //                    }
        //                }


        //                foreach (DataRow datarowCurrentAuthCode in datatableAuthCode.Rows)
        //                {
        //                    datarowPrescService = null;
        //                    authCodeId = Convert.ToString(datarowCurrentAuthCode["AuthorizationCodeId"]);
        //                    datarowPrescService = datatablePrescribedServices.Select("AuthorizationCodeId=" + authCodeId);
        //                    if (datarowPrescService != null && datarowPrescService.Length > 0)
        //                    {
        //                        //do nothing
        //                        //Do not do anything if AuthorizationCode still exists
        //                    }
        //                    else
        //                    {
        //                        //Add row in dataset for PrescribedServices
        //                        DataRow datarowNewPrescribedService = datatablePrescribedServices.NewRow();
        //                        datarowNewPrescribedService["AuthorizationCodeId"] = authCodeId;
        //                        datarowNewPrescribedService["AuthorizationCodeName"] = datarowCurrentAuthCode["AuthorizationCodeName"].ToString();
        //                        datarowNewPrescribedService["DocumentVersionId"] = documentversionId;
        //                        datarowNewPrescribedService["IsChecked"] = "N";
        //                        BaseCommonFunctions.InitRowCredentials(datarowNewPrescribedService);
        //                        datatablePrescribedServices.Rows.Add(datarowNewPrescribedService);
        //                    }
        //                }
        //            }
        //        }
        //    }

        //    return datasetDocumentCarePlan;

        //}

        public void MergeUnsavedXMLInCarePlanDataSet(ref DataSet dataSetPageDataSet)
        {
            TextReader stringReader = null;
            DataSet datasetXMLReader = null;

            try
            {
                DataSet dataSetMain = new DataSet();
                //To remove xmlnx from xml string for dynamic pages
                string strxml = base.GetRequestParameterValue("xmlstring").Replace("xmlns=\"\"", "");
                if (strxml.IndexOf("xmlns:xsi=") == -1)
                {
                    int index = strxml.IndexOf("xmlns");
                    if (index != -1)
                    {
                        strxml = strxml.Insert(index - 1, " " + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" + " ");
                    }
                }
                if (!string.IsNullOrEmpty(strxml))
                {
                    stringReader = new StringReader(strxml);
                    datasetXMLReader = new DataSet();
                    datasetXMLReader.ReadXml(stringReader);
                    datasetXMLReader.EnforceConstraints = false;
                    try
                    {
                        dataSetPageDataSet.Merge(datasetXMLReader, false, MissingSchemaAction.Ignore);
                    }
                    catch (Exception)
                    {
                        dataSetPageDataSet.Merge(datasetXMLReader, false, MissingSchemaAction.Ignore);
                    }
                }
            }
            finally
            {
                stringReader = null;
            }

        }
        /// <summary>
        /// This property is overrided if there is diagnosis page is there in tab
        /// </summary>
        public override bool HaveDiagnosisControl
        {
            get
            {
                return true;
            }
        }


        /// <summary>
        ///<What>Change Get Progress Review Rating based on Goal or Objective </What>
        ///<Why>Need Changes As per Task#2616 Thresholds Bugs/Features</Why>
        /// </summary>
        public void GetPreviousProgressTowardGoalProgressReview()
        {
            MergeLocalUnsavedXml();
            int DomainGoalId = 0;
            int DomainObjectiveId = 0;

            DataSet dataSetDocument = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            int CarePlanObjectiveId = (string.IsNullOrEmpty(base.GetRequestParameterValue("CarePlanObjectiveId"))) ? 0 : Convert.ToInt32(base.GetRequestParameterValue("CarePlanObjectiveId"));
                      
            
            int ClientId = Convert.ToInt32(BaseCommonFunctions.ApplicationInfo.Client.ClientId);
            int DocumentCodeId = Convert.ToInt32(dataSetDocument.Tables["Documents"].Rows[0]["DocumentCodeId"]);
            DateTime DocumentEffectiveDate = (string.IsNullOrEmpty(Convert.ToString(dataSetDocument.Tables["Documents"].Rows[0]["EffectiveDate"])) ? DateTime.Now : Convert.ToDateTime(dataSetDocument.Tables["Documents"].Rows[0]["EffectiveDate"]));
            string ProgressTowardsGoal = string.Empty;
            DataSet dataSetPreviousProgressTowardGoal = null;
            DataTable dataTablePreviousProgressTowardGoal = null;
            using (SHS.UserBusinessServices.CoreCarePlan objectCarePlan = new SHS.UserBusinessServices.CoreCarePlan())
            {

                DataRow[] drObjectives = dataSetDocument.Tables["CarePlanObjectives"].Select("CarePlanObjectiveId=" + CarePlanObjectiveId + " AND ISNULL(RecordDeleted,'N')<>'Y'");

                if (drObjectives.Length > 0 && drObjectives[0]["CarePlanDomainObjectiveId"] != DBNull.Value)
                {
                    DomainObjectiveId = Convert.ToInt32(drObjectives[0]["CarePlanDomainObjectiveId"]);
                    if (DomainGoalId == 0 && DomainObjectiveId > 0)
                    {
                        DomainGoalId = (int)(from a in dsMasterData.Tables["CarePlanDomainObjectives"].AsEnumerable()
                                             where a.Field<int>("CarePlanDomainObjectiveId") == DomainObjectiveId
                                             select a.Field<int>("CarePlanDomainGoalId")).FirstOrDefault();

                        dataSetPreviousProgressTowardGoal = objectCarePlan.GetProgressTowardsGoalObjective(ClientId, DocumentEffectiveDate, DocumentCodeId, DomainGoalId, DomainObjectiveId, 'O');
                        dataTablePreviousProgressTowardGoal = dataSetPreviousProgressTowardGoal.Tables["TableProgressTowardsObjective"];
                        if (BaseCommonFunctions.CheckRowExists(dataTablePreviousProgressTowardGoal, 0))
                        {
                            ProgressTowardsGoal = dataTablePreviousProgressTowardGoal.Rows[0]["ProgressTowardsGoal"].ToString();
                        }
                        else
                        {
                            ProgressTowardsGoal = "No Previous ratings available";
                        }
                    }
                }
                else
                {
                    ProgressTowardsGoal = "No Previous ratings available";
                }
            }
            SetShowHidePanels("###StartPreviousProgressTowardObjective###", CarePlanObjectiveId + "$$$" + ProgressTowardsGoal, "###EndPreviousProgressTowardObjective###",false);
        }

        public static T Deserialise<T>(string json)
        {
            T obj = Activator.CreateInstance<T>();
            using (MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(json)))
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
                obj = (T)serializer.ReadObject(ms);
                return obj;
            }
        }

        public void MergeLocalUnsavedXml()
        {
            if (!string.IsNullOrEmpty(base.GetRequestParameterValue("AutoSaveXML")))
            {
                DataSet dsCurrent = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
               // BaseCommonFunctions.MergeXMLInDataSet(ref dsCurrent, base.GetRequestParameterValue("AutoSaveXML").Replace("xmlns=\"\"", ""));
            }
        }
        public string ExtractARowToXML(DataRow dataRow)
        {
            string XmlString = string.Empty;
            try
            {
                DataSet ds = new DataSet();
                ds.Tables.Add(dataRow.Table.Clone());
                ds.Tables[0].ImportRow(dataRow);
                XmlString = ds.GetXml();
                using (StringWriter sw = new StringWriter())
                {
                    ds.Tables[0].WriteXml(sw);
                    XmlString = sw.ToString().Replace("<NewDataSet>", "").Replace("</NewDataSet>", "");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return XmlString;
        }
        public string ExtractARowToXML(DataSet dataSet)
        {
            string XmlString = string.Empty;
            try
            {
                dataSet.DataSetName = "NewDataSet";
                XmlString = dataSet.GetXml().Replace("<NewDataSet>", "").Replace("</NewDataSet>", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return XmlString;
        }
    }
}