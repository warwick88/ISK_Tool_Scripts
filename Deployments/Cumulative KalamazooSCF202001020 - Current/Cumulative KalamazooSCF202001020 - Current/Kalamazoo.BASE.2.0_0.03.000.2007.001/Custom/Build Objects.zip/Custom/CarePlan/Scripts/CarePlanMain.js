﻿var nonAuthorLogInProcessDone = false;
var templateFilled = false;

//Purpose : SetScreenSpecificValues function ovveridden in ref to populate goals/needs tab after save if tabindex = 1/2
function SetScreenSpecificValues(dom, action) {
    var carePlanSelectedTabIndex = CarePlanTabPageInstance.activeTabIndex;
    //Show/Hide textArea on clicking the checkbox
    if (carePlanSelectedTabIndex == 0) {
        ShowHideTextArea(dom, CarePlanTabPageInstance);
        var SystemKeyValue = $('[id$=HiddenField_ReviewSettngs]').val();
        if (SystemKeyValue == "Y") {
            // $('input[id=RadioButton_DocumentCarePlans_CarePlanType_R]')[0].style.display = 'block';
            //  $("#label_Review")[0].style.display = 'block';
        }
        else {
            $('input[id=RadioButton_DocumentCarePlans_CarePlanType_R]')[0].style.display = 'none';
            $("#label_Review")[0].style.display = 'none';
        }
    }
        //to fill Needs template data on tab click
    else if (carePlanSelectedTabIndex == 1) {
        FillNeedsTabTemplate();
        templateFilled = true;
    }
        //to fill Goal/Objectives template data on tab click
    else if (carePlanSelectedTabIndex == 2) {
        FillGoalObjectivesTabTemplate(action);
        templateFilled = true;
    }
        //to fill Prescribed Services template data on tab click
    else if (carePlanSelectedTabIndex == 3) {
        //FillPrescribedServicesTabTemplate();
        //RenderInterventiondata();
        templateFilled = true;
        //HideShowInterventionsDuration();
    }
        //Set Diagnosis order 
    else if (carePlanSelectedTabIndex == 4) {
        SetDiagnosisIAndIIHiddenOrderField(dom);
    }
        //to fill Prescribed Services template data on tab click
    else if (carePlanSelectedTabIndex == 5) {
        FillTreatmentTeamTemplate();
        templateFilled = true;
        var SystemKeyValue = $('[id$=HiddenField_ReviewSettngs]').val();
        if (SystemKeyValue == "Y") {
            SetReviewDateSection();
            SetReviewBasedonType(dom);
        }
    }
}

function RefreshTabPageContents(tabClickSender, tabText, tabUserControlName, TabIndex, action) {
    if (TabIndex == 1) {
        if (templateFilled == false)
            FillNeedsTabTemplate();
    }
    if (TabIndex == 2) {
        if (templateFilled == false)
            FillGoalObjectivesTabTemplate();
    }
    if (TabIndex == 3) {
        //if (templateFilled == false)
        //    debugger;
        //    FillPrescribedServicesTabTemplate();
    }
        //Set Diagnosis order 
        //Modified By SuryaBalan on 24-Aug-2016 for Bear River - Support Go Live #32 since its making issue when trying to change the label (the variable is not declared in this function)
    else if (TabIndex == 4) {
        SetDiagnosisIAndIIHiddenOrderField(AutoSaveXMLDom);
    }
    if (TabIndex == 5) {
        if (templateFilled == false)
            FillTreatmentTeamTemplate();
    }
}

function CustomAjaxRequestCallback(response, CustomAjaxRequest) {
    var outputHTML = '';
    var pageDataSetXml = '';
    stringVerboseEvent = "";
    if (response != null && response != undefined && response != "") {
        if (response.indexOf("^pageDataSetXML=") > 0) {
            var splitPageResponse = response.split("^pageDataSetXML=");
            if (splitPageResponse.length > 0) {
                outputHTML = splitPageResponse[0];
                pageDataSetXml = splitPageResponse[1];
                if (outputHTML.indexOf("###StartAddObjective###") < 0 && outputHTML.indexOf("###StartDeleteCarePlanGoalObjective###") < 0
                    && outputHTML.indexOf("###StartAddGoal###") < 0 && outputHTML.indexOf("###StartAddGoalFromNeedsTab###") < 0
                    && outputHTML.indexOf("###StartAddNeedsPopUp###") < 0 && outputHTML.indexOf("###StartDeleteNeedDiscription###") < 0
                    && outputHTML.indexOf("###StartEditViewObjectiveDescription###") < 0 && outputHTML.indexOf("###StartPreviousProgressTowardObjective###") < 0
                    && outputHTML.indexOf("###StartRenumberCarePlanGoalObjectives###") < 0 && outputHTML.indexOf("###StartAddEditTreatmentTeam###") < 0
                    && outputHTML.indexOf("###StartUpdateTreatmentTeamFieldValue###") < 0 && outputHTML.indexOf("###StartDeleteTreatmentTeam###") < 0) {
                    //update pagedataset xml after custom ajax
                    if (pageDataSetXml != "" && pageDataSetXml.indexOf("</DataSetDocumentMaster>") > 0) {

                        pageDataSetXml = pageDataSetXml.substr(0, pageDataSetXml.indexOf("</DataSetDocumentMaster>") + 24);

                        AutoSaveXMLDom = $.xmlDOM(pageDataSetXml);
                        if (AutoSaveXMLDom[0].childNodes[0].getAttribute("xmlns:xsi") == null) {
                            AutoSaveXMLDom[0].childNodes[0].setAttribute("xmlns:xsi", 'http://www.w3.org/2001/XMLSchema-instance')
                        }
                        // trigger the xml update event
                        $(document).triggerHandler('xmlchange');
                    }
                }
            }
        }
    }
    if (outputHTML.indexOf("###StartAddGoal###") >= 0 || outputHTML.indexOf("###StartAddGoalFromNeedsTab###") >= 0) {
        RefreshGoalObjectivesTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartEditNeedDiscription###") >= 0) {
        RefreshNeedsTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartAddObjective###") >= 0) {
        RefreshGoalObjectivesTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartDeleteNeedDiscription###") >= 0) {
        RefreshNeedsTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartAddNeedsPopUp###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
    else if (outputHTML.indexOf("###StartAssociateNeedPopUp###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
    else if (outputHTML.indexOf("###StartGoalDescriptionPopUp###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
    else if (outputHTML.indexOf("###StartEditViewObjectiveDescription###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
    else if (outputHTML.indexOf("###StartRenumberCarePlanGoalObjectives###") >= 0) {
        CloaseModalPopupWindow('RenumberCarePlanGoalObjectives');
    }

    else if (outputHTML.indexOf("###StartDeleteCarePlanGoalObjective###") >= 0) {
        RefreshGoalObjectivesTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartPreviousProgressTowardObjective###") >= 0) {
        RefreshGoalObjectivesTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartUpdatePrescribedServicesFieldValue###") >= 0) {
    }
    else if (outputHTML.indexOf("###StartEditAddressOnCarePlan###") >= 0) {
        RefreshNeedsTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###StartUpdateNameInGoalDescInSessionDataset###") >= 0) {
        CreateAutoSaveXml("DocumentCarePlans", "NameInGoalDescriptions", $('#TextBox_DocumentCarePlans_NameInGoalDescriptions').val());
    }
    else if (outputHTML.indexOf("###StartAddEditTreatmentTeam###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
    else if (outputHTML.indexOf("###StartDeleteTreatmentTeam###") >= 0) {
        //To Delete Treatment Team
        RefreshTreatmentTeamTemplate(outputHTML, CustomAjaxRequest);
    }
    else if (outputHTML.indexOf("###TreatmentTeamFieldValue###") >= 0) {
    }
    else if (outputHTML.indexOf("###StartCheckNonAuthorStaffPrograms###") >= 0) {
        ProcessResponseOfTreatmentTeamForNonAuthorStaff(outputHTML);
    }
    else if (outputHTML.indexOf("###StartAddNewTreatmentTeamMember###") >= 0) {
        CloaseModalPopupWindow(outputHTML);
    }
    else if (outputHTML.indexOf("###StartPreviousProgressTowardGoalProgressTab###") >= 0) {
        RatingProgressTowardGoalProgressReviewTab(outputHTML, CustomAjaxRequest);
    }
}


//Purpose : Clear Goals/Objectives Tab HTML on tab click
function SetParameterValueOnTabClick(sender, args) {
    var tabIndex = args.tab.index;
    var paramsToReturn = '';
    if (tabIndex == 3 || tabIndex == 2 || tabIndex == 1 || tabIndex == 5) {
        paramsToReturn = 'myxmlstring=' + encodeText(AutoSaveXMLDom[0].xml);

    }
    if (args.tab.index == 2) {
        var tabUcName = sender.tabs[args.tab.index].tabControl.name + "_C" + args.tab.index;
        var userControl = $("div[id$='" + tabUcName + "']");
        if (userControl.length > 0) {
            userControl.html('');
        }
        return "goalid=" + $("input[id$=HiddenField_GoalIdNumber_Needs]").val() + '&' + paramsToReturn;
    }
    else if (args.tab.index == 3) {
        var tabUcName = sender.tabs[args.tab.index].tabControl.name + "_C" + args.tab.index;
        var userControl = $("div[id$='" + tabUcName + "']");
        if (userControl.length > 0) {
            userControl.html('');
        }
    }
    else if (args.tab.index == 1) {
        var tabUcName = sender.tabs[args.tab.index].tabControl.name + "_C" + args.tab.index;
        var userControl = $("div[id$='" + tabUcName + "']");
        if (userControl.length > 0) {
            userControl.html('');
        }
    }
    else if (args.tab.index == 5) {
        var tabUcName = sender.tabs[args.tab.index].tabControl.name + "_C" + args.tab.index;
        var userControl = $("div[id$='" + tabUcName + "']");
        if (userControl.length > 0) {
            userControl.html('');
        }
    }

    if (tabIndex == 3 || tabIndex == 2 || tabIndex == 1 || tabIndex == 5) {
        return '&' + paramsToReturn;
    }
}

//Purpose : On close of model popups
function ModalPopupWindowClosed(ModelPopUpName) {

    if (ModelPopUpName.indexOf('###StartAssociateNeedPopUp###') >= 0) {
        SetFieldValueInCtrl(ModelPopUpName);
    }
    else if (ModelPopUpName.indexOf("###StartAddNeedsPopUp###") >= 0) {
        RefreshNeedsTemplate(ModelPopUpName);

    }
    else if (ModelPopUpName.indexOf("###StartGoalDescriptionPopUp###") >= 0) {
        SetFieldValueInCtrl(ModelPopUpName);
    }
    else if (ModelPopUpName.indexOf("###StartObjectiveDescriptionPopUp###") >= 0) {
        SetFieldValueInCtrl(ModelPopUpName);
    }
    else if (ModelPopUpName == 'RenumberCarePlanGoalObjectives') {
        RaiseGoalsObjectivesTabClick();
    }
    else if (ModelPopUpName.indexOf("###StartEditViewObjectiveDescription###") >= 0) {
        SetPrescribedServiceObjectivesInfo(ModelPopUpName);
    }
    else if (ModelPopUpName.indexOf("###StartAddEditTreatmentTeam###") >= 0) {
        RefreshTreatmentTeamTemplate(ModelPopUpName);
    }
    else if (ModelPopUpName.indexOf("###StartAddNewTreatmentTeamMember###") >= 0) {
        ProcessResponseOfTreatmentTeamForNonAuthorStaff(ModelPopUpName);
    }
    else if (ModelPopUpName.indexOf('AssociatedNeedPopUp') >= 0 || ModelPopUpName.indexOf('GoalDescription') >= 0 || ModelPopUpName.indexOf('ObjectiveDescription') >= 0) {
        if (GetAutoSaveEnabled() == "y") {
            CreateUnsavedChangesInstance();
        }
    }
}

//Purpose : Add event handler with textfield NameInGoalDesc under "General" Tab
function AddEventHandlers() {
    if (objectPageResponse.SelectedTabId == 0) {
        $('#TextBox_DocumentCarePlans_NameInGoalDescriptions').unbind("change").bind("change", function () { UpdateNameInGoalDescInSessionDataset(this) });
    }
}

//Purpose : change event handler of textfield NameInGoalDesc under "General" Tab
function UpdateNameInGoalDescInSessionDataset(ctrl) {
    var ctrlValue = ctrl.value;
    var data = "CustomAction=UpdateNameInGoalDescInSessionDataset^NameInGoalDescriptions=" + ctrlValue + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    OpenPage(5763, 1077, data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    return false;
}


function AppendNewRowTOAutoSaveXML(XMLNode, AppendRoot) {
    try {
        AppendRoot = AppendRoot == undefined ? true : false;
        if (AppendRoot) {
            XMLNode = "<Root>" + decodeText(XMLNode) + "</Root>";
        }
        var rootindex = 6;// XMLNode.indexOf("</Root>");
        var flindex = XMLNode.indexOf("<", rootindex + 1);
        var frindex = XMLNode.indexOf(">", rootindex + 1);
        var slindex = XMLNode.indexOf("<", frindex + 1);
        var srindex = XMLNode.indexOf(">", frindex + 1);
        var tablename = XMLNode.substr(flindex + 1, frindex - (flindex + 1));
        var primarykey = XMLNode.substr(slindex + 1, srindex - (slindex + 1));

        var lindex = XMLNode.indexOf("</" + tablename + ">");
        var n = XMLNode.replace("</Root>", "").replace("</root>", "");
        var ntableindex = n.indexOf("<", lindex + 1);
        var jsonData = GetAutoSaveXMLDomNode(tablename, $.xmlDOM(decodeText(XMLNode))).XMLExtract();
        CreateAutoSaveXMLObjArray(tablename, primarykey, jsonData[0], 'N', 'Y');
        if (ntableindex > 0) {
            var $str = $(XMLNode)
            $str.find(tablename).remove();
            AppendNewRowTOAutoSaveXML($str[0].outerHTML, false);
        }
    } catch (err) {
        LogClientSideException(err, 'CarePlanMain.js');
    }


    //$(AutoSaveXMLDom).find("DataSetDocumentMaster").append(encodeText(XMLNode));
    //var XMLDom = decodeText($(AutoSaveXMLDom).find("DataSetDocumentMaster")[0].xml);
    //AutoSaveXMLDom = $.xmlDOM(XMLDom);
    //if (AutoSaveXMLDom[0].childNodes[0].getAttribute("xmlns:xsi") == null) {
    //    AutoSaveXMLDom[0].childNodes[0].setAttribute("xmlns:xsi", 'http://www.w3.org/2001/XMLSchema-instance')
    //}
    //// trigger the xml update event
    //$(document).triggerHandler('xmlchange');
}
function RemoveDeletedXMLNode(tableName, primaryKeyColumnName, primaryKeyValue) {
    var xml = GetXMLParentNodeByColumnValue(tableName, primaryKeyColumnName, primaryKeyValue, AutoSaveXMLDom);
    $(xml).each(function () {
        $(this).remove();
    });
}
//Added by Lakshmi, As part of Spring River-Support Go Live #82 on 13.04.2018
function ConfirmMessageForInterventionCancel() {
}
//Added by Lakshmi, As part of Spring River-Support Go Live #82 on 13.04.2018
function ConfirmMessageForInterventionOK(effectiveDate) {
    if (DocumentStatus === "In Progress") {
        AutoSaveXMLDom.find("CarePlanPrescribedServices>IsChecked[text='Y']").each(function () {
            var PrescribedServiceId = $(this).parent().find("CarePlanPrescribedServiceId").text();
            SetColumnValueInXMLNodeByKeyValue("CarePlanPrescribedServices", "CarePlanPrescribedServiceId", PrescribedServiceId, "IsChecked", "N", AutoSaveXMLDom[0]);
        });
        SavePageData();
    }
}
//Added by Lakshmi, As part of Spring River-Support Go Live #82 on 13.04.2018
function CustomEffectiveDateOnChangeEventHandler(effectiveDate) {
    if (DocumentStatus === "In Progress")
        ShowMsgBox('The system will refresh the intervention data and any changes made will be lost. Do you wish to proceed ?', ConfirmationMessageCaption, MessageBoxButton.YesNo, MessageBoxIcon.Information, 'ConfirmMessageForInterventionOK(\'' + effectiveDate + '\')', 'ConfirmMessageForInterventionCancel()');
}
//Added by Lakshmi, As part of Spring River-Support Go Live #82 on 13.04.2018
function AllowTabChange() {
    if (TabIndex == 3 && DocumentStatus === "") {
        ShowHideErrorMessage("Please save the care plan before moving to intervention tab", 'true');
        return false;
    }
    else {
        return true;
    }
}
