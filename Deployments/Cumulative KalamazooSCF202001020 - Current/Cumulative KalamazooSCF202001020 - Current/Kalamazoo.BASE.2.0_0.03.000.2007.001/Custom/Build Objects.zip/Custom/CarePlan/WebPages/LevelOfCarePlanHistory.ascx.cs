﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SHS.BaseLayer;
using SHS.DataServices;
using SHS.UserBusinessServices;
using SHS.BaseLayer.ActivityPages;
using DevExpress.Web.ASPxEditors;
using System.Web.UI.WebControls.WebParts;
public partial class Modules_CarePlan_ActivityPages_Client_ListPages_LevelOfCarePlanHistory : SHS.BaseLayer.ActivityPages.ListActivityPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public override void BindFilters()
    {
        BindStaff();
        DropDownList_CodeName.Items.Add(new ListItem("All Level Of Care Types","-1"));
        DropDownList_CodeName.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        DropDownList_CodeName.FillDropDownDropGlobalCodes();
    }
    public override DataTable GetExportDataSet()
    {
        using (SHS.UserBusinessServices.CoreCarePlan carePlanObj = new SHS.UserBusinessServices.CoreCarePlan())
        {
            //string locationName = string.Empty;//added by atul pandey
            DataSet dataSet = null;
            // Begin custom code
            int clientId = -1;
            string effectiveDate = null;
            int levelOfCareType = -1;
            int createdBy = -1;
            int otherFilter = -1;
            clientId = BaseCommonFunctions.ApplicationInfo.Client.ClientId; 
            //string dt=GetSelectedValueFromXML<DateTime>("PlanStatus");
            createdBy =BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "StaffName", ParentPageObject.PageFiltersXML);
            levelOfCareType = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "CodeName", ParentPageObject.PageFiltersXML);
            otherFilter = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "OtherFilter", ParentPageObject.PageFiltersXML);
            effectiveDate = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "EffectiveDate", ParentPageObject.PageFiltersXML);
            dataSet = GetGridData(carePlanObj, clientId, effectiveDate, levelOfCareType, createdBy, otherFilter);
            //dataSet.Tables["Locations"].Columns.Remove("LocationId");
            //return dataSet.Tables["Locations"];
            return dataSet.Tables["DocumentCarePlans"];
        }
    
    
    
    }
    private void BindAllStatuses()
    {
        string[] arr = new string[2];

    }
    public override string DefaultSortExpression
    {
        get
        {
            return "EffectiveDate";
        }
    }
    private void BindStaff()
    {
        DropDownList_StaffName.DataSource = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff;
        DropDownList_StaffName.DataTextField = "StaffName";
        DropDownList_StaffName.DataValueField = "StaffId";
        DropDownList_StaffName.DataBind();
        DropDownList_StaffName.SelectedValue = "All Created By";
    }
    //private void Bind_Control_TaxonomyCode()
    //{
    //    if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes != null)
    //    {
    //        DataView dataViewLevelOfCarePlan = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes);
    //        dataViewLevelOfCarePlan.RowFilter = "Category = 'LEVELOFCARETYPES' and Active='Y' and ISNULL(RecordDeleted,'N')<>'Y'";
    //        //dataViewLevelOfCarePlan.Sort = "CodeName ASC ";
    //        DropDownList_Status.DataTextField = "CodeName";
    //        DropDownList_Status.DataValueField = "GlobalCodeId";
    //        DropDownList_Status.DataSource = dataViewLevelOfCarePlan;
    //        DropDownList_Status.DataBind();
    //        //DropDownList_Status.Items.Insert(0, new ListItem("", ""));
    //        DropDownList_Status.SelectedIndex = 0;
    //    }
    //}
    private void Bind_Filter_Others()
    {
        if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalSubCodes != null)
        {
            int Count = 0;
            DataView dataViewOthers = new DataView(SHS.BaseLayer.SharedTables.StaffSharedTables.Staff);
            dataViewOthers.RowFilter = "GlobalCodeId='6003' and Active='Y' and ISNULL(RecordDeleted,'N')<>'Y'";
            dataViewOthers.Sort = "SortOrder,SubCodeName";
            DropDownList_OtherFilter.DataTextField = "SubCodeName";
            DropDownList_OtherFilter.DataValueField = "GlobalSubCodeId";
            DropDownList_OtherFilter.DataSource = dataViewOthers;
            DropDownList_OtherFilter.DataBind();
            ListItem item = new ListItem(" ", "-1");
            DropDownList_OtherFilter.Items.Insert(0, item);
            Count = DropDownList_OtherFilter.Items.Count;
            if (Count == 2)
            {
                DropDownList_OtherFilter.SelectedIndex = 1;
                if (DropDownList_OtherFilter.SelectedItem.ToString() == "Other")
                    DropDownList_OtherFilter.Visible = false;
                else
                    DropDownList_OtherFilter.Visible = true;
                DropDownList_OtherFilter.SelectedIndex = -1;
            }
            else if (Count == 1)
            {
                DropDownList_OtherFilter.SelectedIndex = -1;
                DropDownList_OtherFilter.Visible = false;
            }
            else
            {
                DropDownList_OtherFilter.SelectedIndex = -1;
                DropDownList_OtherFilter.Visible = true;
            }
        }
    }
    public override System.Data.DataTable BindGrid()
    {
        //DataSet ds = new DataSet();
        //DataTable dt = new DataTable();
        ////DataTable table = new DataTable();
        //ds.Tables.Add(dt);
        //DataColumn col = new DataColumn("LevelOfCareType", typeof(string));
        //dt.Columns.Add(col);
        //col = new DataColumn("EffectiveDate", typeof(string));
        //dt.Columns.Add(col);
        //col = new DataColumn("LevelOfCare", typeof(string));
        //dt.Columns.Add(col);
        //col = new DataColumn("CreatedBy", typeof(string));
        //dt.Columns.Add(col);
        //DataRow row = dt.NewRow();
        //row["LevelOfCareType"] = null;
        //row["EffectiveDate"] = null;
        //row["LevelOfCare"] = null;
        //row["CreatedBy"] = null;
        //dt.Rows.Add(row);

        //row = dt.NewRow();
        //row["LevelOfCareType"] = "Good";
        //row["EffectiveDate"] = "10/01/2014";
        //row["LevelOfCare"] = "Test";
        //row["CreatedBy"] = "System";
        //dt.Rows.Add(row);
        //lvLevelOfCarePlanHistory.DataSource = ds.Tables["Table1"];
        //lvLevelOfCarePlanHistory.DataBind();

        //DataTable dt1 = new DataTable();
        //ds.Tables.Add(dt1);
        //DataColumn col1 = new DataColumn("PageNumber", typeof(int));
        //dt1.Columns.Add(col1);
        //col1 = new DataColumn("NumberOfPages", typeof(int));
        //dt1.Columns.Add(col1);
        //col1 = new DataColumn("NumberOfRows", typeof(int));
        //dt1.Columns.Add(col1);
        //// this.BindGrid = ds.Tables[0].DefaultView; 

        //DataRow row1 = dt1.NewRow();
        //row1["PageNumber"] = 0;
        //row1["NumberOfPages"] = 0;
        //row1["NumberOfRows"] = 0;

        //dt1.Rows.Add(row1);
        //return dt1;
        using (SHS.UserBusinessServices.CoreCarePlan carePlanObj = new SHS.UserBusinessServices.CoreCarePlan())
        {
            DataSet dataSet = null;
            int clientId = -1;
            string effectiveDate = null;
            int levelOfCareType = -1;
            int createdBy = -1;
            int otherFilter = -1;
            clientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

            //string locationName = string.Empty;//added by atul pandey
            //// Begin custom code
            //int location = -1;
            //int locationType = -1;
            //int otherFilter = -1;
            //GetInputDateFromTextBox(TextBox_LevelOfCarePlanHistoryEffectiveDate, "LevelOfCarePlanHistoryEffectiveDate", out  effectiveDate);
            GetSelectedValueFromDropdown(DropDownList_StaffName, "StaffName", out createdBy);
            GetSelectedValueFromDropdown(DropDownList_CodeName, "CodeName", out levelOfCareType);
            if (GetFilterValue("EffectiveDate") == "")
            {
                effectiveDate = null;
            }
            else
            {
                effectiveDate = GetFilterValue("EffectiveDate");
            } 
           // effectiveDate= GetFilterValue("EffectiveDate");
           //if (effectiveDate == "")
           //    effectiveDate = null;
            ////added by atul pandey on 4/23/2012
            //if (GetFilterValue("LocationName") != "")
            //{
            //    locationName = GetFilterValue("LocationName").Trim();
            //}
            //till here

            dataSet = GetGridData(carePlanObj, clientId, effectiveDate, levelOfCareType, createdBy, otherFilter);

            // End custom code
            if (dataSet != null)
            {
                if (dataSet.Tables.Count > 0)
                {
                    if (dataSet.Tables.Contains("DocumentCarePlans") == true)
                    {
                        lvLevelOfCarePlanHistory.DataSource = dataSet.Tables["DocumentCarePlans"];
                        lvLevelOfCarePlanHistory.DataBind();
                    }
                }
            }

            return dataSet.Tables["TablePagingInformation"];
        }
    }
    private void GetSelectedValueFromDropdown(DropDownList dropDown, string key, out int value)
    {
        if (dropDown.Items.Count > 0)
        {
            int.TryParse(GetFilterValue(key, dropDown.SelectedItem.Value.ToString()), out value);
        }
        else
        {
            int.TryParse(GetFilterValue(key), out value);
        }
    }

    private DataSet GetGridData(SHS.UserBusinessServices.CoreCarePlan carePlanObj,
       int clientId, string effectiveDate, int levelOfCareType, int createdBy, int otherFilter)
    {
        DataSet dataSet = null;

        //string sessionId = Session.SessionID;
        //int instanceId = 0;
        int pageNumber = ParentPageListObject.CurrentPage;
        int pageSize = ParentPageListObject.PageSize == 0 ? 1 : ParentPageListObject.PageSize;
        string sortExpression = ParentPageListObject.SortExpression;
        //int clientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;
        //int staffId = 0;  

        //int.TryParse(ParentPageListObject.CurrentHistoryId, out instanceId);
        //if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId != 0)
        //    staffId = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId;

        dataSet = carePlanObj.GetLevelOfCarePlanHistory(pageNumber, pageSize, sortExpression,
                                                                 clientId, effectiveDate, levelOfCareType, createdBy, otherFilter);


        return dataSet;


    }
    protected void LayoutCreated(object sender, EventArgs e)
    {
        var SortExpression = ParentPageListObject.SortExpression;
        string[] Sort = SortExpression.Split(' ');

        Panel divHeader = (Panel)lvLevelOfCarePlanHistory.FindControl("divHeader");
        foreach (Control ctrl in divHeader.Controls)
        {
            if (ctrl.GetType() == typeof(Panel))
            {
                string SortId = ((Panel)ctrl).Attributes["SortId"];
                if (SortId != null)
                {
                    ((Panel)ctrl).Attributes.Add("onclick", "SortListPage(" + ParentPageListObject.ScreenId.ToString() + ",'" + SortId + "');");
                    if (Sort.Count() > 0)
                    {
                        if (Sort[0] == SortId)
                        {
                            if (Sort.Count() == 1)
                            {
                                ((Panel)ctrl).CssClass = "SortUp";
                            }
                            else
                            {
                                ((Panel)ctrl).CssClass = "SortDown";
                            }
                        }
                    }

                }
            }
        }
        Panel divContent = (Panel)lvLevelOfCarePlanHistory.FindControl("divListPageContent");
        //CheckboxController1.ListPageControllerDivID = divContent.ClientID.Trim();
        divContent.Attributes.Add("onscroll", "fnScroll('#" + divHeader.ClientID + "','#" + divContent.ClientID + "');");
    }
}

