var DomainIdForAddNeeed = "";

//Purpose: Bind Needs Template by Json
function FillNeedsTabTemplate() {
    var domainNeedsData = "";
    var domainNeedsDataString = "";
    var DivNeedLists = $("#DivNeedLists");
    domainNeedsData = $('input[id$=HiddenFieldNeeds]', DivNeedLists).val();
    domainNeedsDataString = eval('(' + domainNeedsData + ')');
    if (domainNeedsData.length > 0) {
        $("#tblid").html('');
        $("#tableTemplate").tmpl(domainNeedsDataString.objectListDomain).appendTo("#tblid");
        BindTextAreaKeyPhrase();
    }
}

//Purpose   : Set Needs Description Value OnChange Event
//Purpose   : Delete Needs in Needs Tab According to NeedId Action Update/Delete.
function SetNeedDiscription(sender, DomainId, NeedId, action) {
    if (isInteger($(sender).val()) == false) {
        var needDiscription = $(sender).val();
        var nameArray = sender.id.split("_");
        var tablename = nameArray[1];
        var sourceField = nameArray[2];

        if (action == 'Update') {
            SetColumnValueInXMLNodeByKeyValue(tablename, "CarePlanNeedId", NeedId, sourceField, needDiscription, AutoSaveXMLDom[0])
            CreateUnsavedInstanceOnDatasetChange();
            CallAutoSaveProcess();
        }
        else if (action == 'Delete') {
            var data = 'CustomAction=DeleteNeedsDiscription^DomainId=' + DomainId + '^NeedId=' + NeedId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
            OpenPage(5763, GetCurrentScreenID(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
        }
    }
}


function SetDeferralReason(sender, DomainId, NeedId, action) {
    if (isInteger($(sender).val()) == false) {
        var needDiscription = $(sender).val();
        var nameArray = sender.id.split("_");
        var tablename = nameArray[1];
        var sourceField = nameArray[2];

        if (action == 'Update') {
            SetColumnValueInXMLNodeByKeyValue(tablename, "CarePlanNeedId", NeedId, sourceField, needDiscription, AutoSaveXMLDom[0])
            CreateUnsavedInstanceOnDatasetChange();
            CallAutoSaveProcess();
        }
        else if (action == 'Delete') {
            var data = 'CustomAction=DeleteNeedsDiscription^DomainId=' + DomainId + '^NeedId=' + NeedId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
            OpenPage(5763, GetCurrentScreenID(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
        }
    }
}

//Purpose : To refresh Needs tab data on Edit Need Discription
function RefreshNeedsTemplate(response) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";
    var splitResponse = "";
    var primaryKey = "";
    var fieldValue = "";

    if (response.indexOf("###StartEditNeedDiscription###") >= 0) {
        startIndex = response.indexOf("###StartEditNeedDiscription###") + 30;
        endIndex = response.indexOf("###EndEditNeedDiscription###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        CreateUnsavedInstanceOnDatasetChange();
    }
    else if (response.indexOf("###StartEditAddressOnCarePlan###") >= 0) {
        startIndex = response.indexOf("###StartEditAddressOnCarePlan###") + 32;
        endIndex = response.indexOf("###EndEditAddressOnCarePlan###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        CreateUnsavedInstanceOnDatasetChange();
    }
    else if (response.indexOf("###StartDeleteNeedDiscription###") >= 0) {
        startIndex = response.indexOf("###StartDeleteNeedDiscription###") + 32;
        endIndex = response.indexOf("###EndDeleteNeedDiscription###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        if (outputHTML.indexOf("DomainId=") >= 0) {
            var domainId = "";
            var needId = "";
            splitResponse = outputHTML.substr(outputHTML.indexOf("DomainId=") + 9).split("$$$");
            domainId = splitResponse[0]
            needId = splitResponse[1];
            $("table#NeedsDomain_" + domainId + "_" + needId).remove();
            RemoveDeletedXMLNode("CarePlanNeeds", "CarePlanNeedId", needId);
            CreateUnsavedInstanceOnDatasetChange();
            DomainNoIdenifiedNeedMsg(domainId);
        }
    }
    else if (response.indexOf("###StartAddNeedsPopUp###") >= 0) {
        startIndex = response.indexOf("###StartAddNeedsPopUp###") + 24;
        endIndex = response.indexOf("###EndAddNeedsPopUp###");
        splitResponse = response.substr(startIndex, endIndex - startIndex).split("$$$");
        outputHTML = splitResponse[0]
        fieldValue = splitResponse[1];
        AppendNewNeed(outputHTML);
        DomainNoIdenifiedNeedMsg(fieldValue);
        CreateUnsavedInstanceOnDatasetChange();
    }
}

//Purpose : Set "No Idenified Need Msg"  
function DomainNoIdenifiedNeedMsg(domainId) {
    var findNeedTableId = $("div#DivNeedsContainer_" + domainId + " table[id*=NeedsDomain_" + domainId + "]");
    if (findNeedTableId.length > 0) {
        $("#Span_NoIdenifiedNeedMsg_" + domainId).html("");
    }
    else {
        $("#Span_NoIdenifiedNeedMsg_" + domainId).html("No identified needs");
    }
}

//Description: Open CarePlan Add Needs Pop Up
function OpenModelDialogueforAddNeeds(DomainId, DomainName) {
    var actionName = "addneedsindomain";

    OpenPage(5765, 1081, "PopUpAction=" + actionName + "^CarePlanDomainId=" + DomainId + "^DomainName=" + DomainName, null, GetRelativePath(), 'T', "dialogHeight: 430px; dialogWidth: 600px;dialogTitle:Add Needs");
    DomainIdForAddNeeed = DomainId;
}

//Purpose :Append Needs In Domain Section
function AppendNewNeed(outputHTML) {
    var NeedsJsonData = "";
    var NeedsJsonSerializedData = "";
    var domainId = "";
    var needId = "";
    NeedsJsonData = outputHTML;
    NeedsJsonSerializedData = eval('(' + NeedsJsonData + ')');
    if (NeedsJsonData.length > 0) {
        $("#NestedScript").tmpl(NeedsJsonSerializedData.objectListDomain[0].objectListNeeds).appendTo("#DivNeedsContainer_" + DomainIdForAddNeeed);
        $.each(NeedsJsonSerializedData.objectListDomain[0].objectListNeeds, function (key, value) {
            AppendNewRowTOAutoSaveXML(decodeText(value.RowXML));
        });
        domainId = NeedsJsonSerializedData.objectListDomain[0].objectListNeeds[0].CarePlanDomainId;
        needId = NeedsJsonSerializedData.objectListDomain[0].objectListNeeds[0].CarePlanNeedId;
        BindTextAreaKeyPhrase();
    }
}

//Purpose : Set Cursor, Move Cursor to Desired Domain Needs
function SetFocusToNeed(domainId, needId) {
    var textareaNeedDescriptionId = "textarea#TextArea_CarePlanNeeds_NeedDescription_" + domainId + "_" + needId;
    if ($(textareaNeedDescriptionId).length > 0) {
        $(textareaNeedDescriptionId).focus();
    }
}

//Purpose : Raise Needs tab click
function RaiseNeedsTabClick() {
    
    CreateUnsavedInstanceOnDatasetChange();
    CarePlanTabPageInstance.GetTab(2).SetEnabled(true);
    CarePlanTabPageInstance.SetActiveTab(CarePlanTabPageInstance.tabs[2]);
    CarePlanTabPageInstance.RaiseTabClick(2, onTabSelected);
}

//Purpose : Mouse Over ToolTip For Goal Number
function GetGoalVisionDescriptionInfo(sender, MemberGoalVision, GoalDescription) {
  //  debugger;
    if (('#' + sender).length > 0) {
        var toottip = '';
        toottip = "Client Goal (in client's own words): " + MemberGoalVision + '\n';
        toottip += '\n';
        toottip += 'Goal Description: ' + GoalDescription + '\n';
        $('#' + sender)[0].title = toottip;
    }
}

//Purpose: On update of Needs Controls,Description,DeleteNeed,Action Taken
function UpdateNeedsFieldValue(domainId,needId, sourceField, ctrl, redioType) {
    var sourceFieldNewValue = $(ctrl).val();
    if ($(ctrl).length > 0) {
        if ($(ctrl).attr('checked') && redioType == 'A') {
            $('#Span_CarePlanNeeds_' + needId).removeAttr('disabled');
            $('#TextArea_CarePlanNeeds_DeferralReason_' + domainId + "_" + needId).attr('disabled', true);
            $('#TextArea_CarePlanNeeds_DeferralReason_' + domainId + "_" + needId).val("");
        }
        else if ($(ctrl).attr('checked') && redioType == 'D') {
            $('#Span_CarePlanNeeds_' + needId).attr('disabled', 'disabled');
            $('#TextArea_CarePlanNeeds_DeferralReason_' + domainId + "_" + needId).attr('disabled',false)
           
           
        }
        SetColumnValueInXMLNodeByKeyValue("CarePlanNeeds", "CarePlanNeedId", needId, sourceField, sourceFieldNewValue, AutoSaveXMLDom[0]);
        CreateUnsavedInstanceOnDatasetChange();
    }
}

//Purpose: On update of Needs Controls,Description,DeleteNeed,Action Taken
function GoalDisableActionTakenRedios(needId, ctrl) {
    var sourceFieldNewValue = $(ctrl).val();
    if ($(ctrl).length > 0) {
        var data = 'CustomAction=UpdateNeedsFieldValue^PrimaryKeyValue=' + needId + "^SourceFieldName=" + sourceField + "^SourceFieldNewValue=" + sourceFieldNewValue + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
        OpenPage(5763, 1077, data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
        CreateUnsavedInstanceOnDatasetChange();
    }
}

//Purpose: Set Value In hidden Filed Placed on Main Tab
function RedirectToGoalsObjectivesTab(GoalId) {
    RaiseGoalsObjectivesTabClick(GoalId);
}

//Purpose: If checked will only show Domains/Needs where Action Take = Defer and Source = MHA.
function GetOnlyAddressOnCarePlan(ctrl) {
    debugger;
    if ($(ctrl).is(':checked')) {
        $('table[id$=tblid] input[id*=RadioButton_AddressOnCarePlan]').each(function() {
            ShowHideAddressOnCarePlan(this, 'show');
        });
    }
    else {
        $('table[id$=tblid] input[id*=RadioButton_AddressOnCarePlan]').each(function() {
            ShowHideAddressOnCarePlan(this, 'hide');
        });
    }
}

//Purpose: This Function inside GetOnlyAddressOnCarePlan();
function ShowHideAddressOnCarePlan(ctrl, flag) {

    if ($(ctrl).length > 0) {
        var addressOnCarePlanValue = $(ctrl).val();
        var nameArray = $(ctrl).attr('id').split("_");
        var columnName = nameArray[1];
        var sourceFieldValue = nameArray[2];
        var needId = nameArray[3];
        var parentTableid = $(ctrl).closest('table');

        if ($(parentTableid).length > 0) {
            var domainid = parentTableid.attr('id');
            var NeedDomainTableId = $('table[id$=NeedsDomain_' + domainid + '_' + needId + ']');
            var NeedStatus = $(NeedDomainTableId).find('table:first').attr('id');

            if ($(ctrl).is(':checked')) {
                if ($(ctrl).val() == 'Y' && $(NeedDomainTableId).length > 0) {
                    if (flag == 'hide') {
                        $(NeedDomainTableId).show();
                    }
                    else if (flag == 'show') {
                        $(NeedDomainTableId).hide();
                    }
                }
                else if ($(ctrl).val() == 'N' && $(NeedDomainTableId).length > 0) {
                    if (flag == 'hide' && NeedStatus != 'M') {
                        $(NeedDomainTableId).show();
                    }
                    else if (flag == 'show' && NeedStatus != 'M') {
                        $(NeedDomainTableId).hide();
                    }
                }
            }
        }
    }
}
