﻿using System;
using System.Collections;
using System.Configuration;
using SHS.BaseLayer;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using SHS.UserBusinessServices;
using SHS.BaseLayer.ActivityPages;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using CarePlan;
using System.Web.UI.WebControls;

namespace SHS.SmartCare
{
    ///<summary>
    ///<Description>Create User Control For Supports/Treatment Team Tab</Description>
    ///</summary>
    public partial class CarePlanSupportsTreatmentTeam : DataActivityTab
    {
        private JavaScriptSerializer objectJavaScriptSerializer = null;
        public string Screenname { get; private set; }

        ///<summary>
        ///<Description>Override Bind Control Treatment Team Tab</Description>
        ///</summary>
        public override void BindControls()
        {
            if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes != null)
            {
                //DataView dataViewCILASupportLevel = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes);
                //dataViewCILASupportLevel.RowFilter = "Category='CAREPLANCILA' and Active='Y' and ISNULL(RecordDeleted,'N')='N'";
                //dataViewCILASupportLevel.Sort = "CodeName ASC";
                //DropDownList_DocumentCarePlans_CILASupportLevel.DataTextField = "CodeName";
                //DropDownList_DocumentCarePlans_CILASupportLevel.DataValueField = "GlobalCodeId";
                //DropDownList_DocumentCarePlans_CILASupportLevel.DataSource = dataViewCILASupportLevel;
                //DropDownList_DocumentCarePlans_CILASupportLevel.DataBind();
                //DropDownList_DocumentCarePlans_CILASupportLevel.Items.Insert(0, new ListItem("", ""));

                DataView dataViewSupportsInvolvement = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes);
                dataViewSupportsInvolvement.RowFilter = "Category='CAREPLANSUPPORTS' and Active='Y' and ISNULL(RecordDeleted,'N')='N'";
                dataViewSupportsInvolvement.Sort = "Sortorder ASC";
                DropDownList_DocumentCarePlans_SupportsInvolvement.DataTextField = "CodeName";
                DropDownList_DocumentCarePlans_SupportsInvolvement.DataValueField = "GlobalCodeId";
                DropDownList_DocumentCarePlans_SupportsInvolvement.DataSource = dataViewSupportsInvolvement;
                DropDownList_DocumentCarePlans_SupportsInvolvement.DataBind();
                DropDownList_DocumentCarePlans_SupportsInvolvement.Items.Insert(0, new ListItem("Select Supports Involvement", "0"));

                DropDownList_DocumentCarePlans_ReviewEntireCarePlan.Items.Add(new ListItem(string.Empty, "-1"));
                DropDownList_DocumentCarePlans_ReviewEntireCarePlan.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
                DropDownList_DocumentCarePlans_ReviewEntireCarePlan.FillDropDownDropGlobalCodes();

            }
            BIndTreatmentTeamTemplate();
            Screenname = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Screens.FindByScreenId(SHS.BaseLayer.BaseCommonFunctions.ScreenId).ScreenName.ToString();
        }

        //public override string[] TablesUsedInTab
        //{
        //    get { return new string[] { "DocumentCarePlans", "CarePlanPrograms" }; }
        //}

        public override void Activate()
        {
            base.Activate();
            CarePlanMergeUnsavedXML();
        }

        public void CarePlanMergeUnsavedXML()
        {
            DataSet dataSetPageDataSet = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            try
            {
                if (Request.Form["myxmlstring"] != null)
                {
                    string unsavedXML = Convert.ToString(Request.Form["myxmlstring"]);
                    string strxml = unsavedXML.Replace("xmlns=\"\"", "");
                    SHS.BaseLayer.BaseCommonFunctions.MergeXMLInDataSet(ref dataSetPageDataSet, strxml);
                }
            }
            finally
            {
            }
        }



        ///<summary>
        ///<Description>Bind Treatment Team Template For Add or Edit</Description>
        ///</summary>
        public void BIndTreatmentTeamTemplate()
        {
            List<TreatmentTeamListData> objectTreatmentTeamListData = null;
            objectTreatmentTeamListData = new List<TreatmentTeamListData>();

            TreatmentTeamListData objCPTreatmentTeam = new TreatmentTeamListData();
            objCPTreatmentTeam.objectListTreatmentTeamData = new List<TreatmentTeamData>();

            DataSet dataSetScreenData = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            if (BaseCommonFunctions.CheckRowExists(dataSetScreenData, "CarePlanPrograms"))
            {
                DataRow[] datarowCarePlanTeam = dataSetScreenData.Tables["CarePlanPrograms"].Select("ISNULL(RecordDeleted,'N')<>'Y'", "StaffName");
                if (datarowCarePlanTeam.Length > 0)
                {
                    foreach (DataRow datarowTreatmentTeam in datarowCarePlanTeam)
                    {
                        TreatmentTeamData objectTreatmentTeam = new TreatmentTeamData();
                        objectTreatmentTeam.CarePlanProgramId = Convert.ToString(datarowTreatmentTeam["CarePlanProgramId"]);
                        objectTreatmentTeam.DocumentVersionId = Convert.ToString(datarowTreatmentTeam["DocumentVersionId"]);
                        objectTreatmentTeam.ProgramId = Convert.ToString(datarowTreatmentTeam["ProgramId"]);
                        objectTreatmentTeam.ProgramName = Convert.ToString(datarowTreatmentTeam["ProgramName"]);
                        objectTreatmentTeam.StaffId = Convert.ToString(datarowTreatmentTeam["StaffId"]);
                        objectTreatmentTeam.StaffName = Convert.ToString(datarowTreatmentTeam["StaffName"]);
                        objectTreatmentTeam.AssignForContribution = Convert.ToString(datarowTreatmentTeam["AssignForContribution"]);
                        objectTreatmentTeam.Completed = Convert.ToString(datarowTreatmentTeam["Completed"]);
                        objectTreatmentTeam.DocumentAssignedTaskId = Convert.ToString(datarowTreatmentTeam["DocumentAssignedTaskId"]);

                        objCPTreatmentTeam.objectListTreatmentTeamData.Add(objectTreatmentTeam);
                    }
                }

            }
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string strTreatmentTeam = objectJavaScriptSerializer.Serialize(objCPTreatmentTeam);
            HiddenFieldTreatmentTeam.Value = strTreatmentTeam;
        }
    }
}
