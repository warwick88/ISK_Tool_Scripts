﻿
//Purpose : To fill goals/objectives tab data on tab clcik
var goalIdToWhichAdObjective = "";

//Created By:Vikas Kashyap
function FillProgressReviewGoalObjectivesTabTemplate(action) {
    var GoalsJsonData = "";
    var GoalsJsonSerializedData = "";
    //$("#Span_CustomDocumentCarePlanGoals_RenumberGoal").attr("disabled", "disabled");
    GoalsJsonData = $('[id$=HiddenField_GoalObjectivesProgressReviewJSONData]').val();
    GoalsJsonSerializedData = eval('(' + GoalsJsonData + ')');
    if (GoalsJsonData.length > 0) {
        $("#DivGoalProgressReviewContentMain").html('');
        $("#GoalProgressReviewTemplate").tmpl(GoalsJsonSerializedData.objectListProgressReviewData).appendTo("#DivGoalProgressReviewContentMain");

        //Disable Renumber Goals Link if No Goal is there in Care Plan
        //        if (GoalsJsonSerializedData.objectListProgressReviewData.length > 1) {
        //            $("#Span_CustomDocumentCarePlanGoals_RenumberGoal").removeAttr("disabled", "disabled");
        //        }
        //        else {
        //            $("#Span_CustomDocumentCarePlanGoals_RenumberGoal").attr("disabled", "disabled");
        //        }
    }

    //SetFocusToGoal(action);
    AttachOnBlurEventProgressReview();
}

//Created By:Vikas Kashyap
//Purpose : Handle onBlur event for controls on change of any value
function AttachOnBlurEventProgressReview() {
    BindTextAreaKeyPhrase();
    $("select,textarea", $('#DivGoalProgressReviewContentMain')).each(function() {
        this.onchange = function() { UpdateProgressReviewGoalsObjectiveXML(this) };
    });
    $("input[type=radio]", $('#DivGoalProgressReviewContentMain')).each(function() {
        this.onchange = function() { UpdateProgressReviewGoalsObjectiveXMLforRadioButtons(this) };
    });
}

//Created By:Vikas Kashyap
//Purpose : Update value in xml
function UpdateProgressReviewGoalsObjectiveXML(ctrl) {
    var nameArray = ctrl.id.split("_");
    var tablename = nameArray[1];
    var primaryKeyColumnName = '';
    if (tablename.toLowerCase().trim() == "customdocumentcareplanreviews") {
        primaryKeyColumnName = "CarePlanReviewId";
    }
    //    else if (tablename.toLowerCase().trim() == "CustomDocumentCarePlanReviews") {
    //        primaryKeyColumnName = "ObjectiveId";
    //    }
    var primaryKey = nameArray[2];
    var columnname = nameArray[nameArray.length - 1];
    var ctrlValue = GetControlValue(ctrl, undefined);
    //    OpenPage(5763, GetCurrentScreenID(), 'CustomAction=UpdateGoalObjectiveFieldValue^tablename=' + tablename + '^primaryKey=' + primaryKey + '^columnname=' + columnname + '^ctrlValue=' + ctrlValue, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);

    SetColumnValueInXMLNodeByKeyValue(tablename, primaryKeyColumnName, primaryKey, columnname, ctrlValue, AutoSaveXMLDom[0]);
    CreateUnsavedInstanceOnDatasetChange();
    DisableGoalIsNOTActive(ctrlValue, primaryKey);
}

//Created By:Vikas Kashyap
//Purpose : Update value in xml for radio button type controls
function UpdateProgressReviewGoalsObjectiveXMLforRadioButtons(ctrl) {
    var nameArray = ctrl.id.split("_");
    var tablename = nameArray[1];
    var radioValue = nameArray[3];
    var primaryKey = nameArray[2];
    var columnname = nameArray[nameArray.length - 1];
    var primaryKeyColumnName = '';
    if (tablename.toLowerCase().trim() == "customdocumentcareplanreviews") {
        primaryKeyColumnName = "CarePlanReviewId";
    }
    //    else if (tablename.toLowerCase().trim() == "CustomDocumentCarePlanReviews") {
    //        primaryKeyColumnName = "ObjectiveId";
    //    }
    //var ctrlValue = GetControlValue(ctrl, undefined);
    var control = $(ctrl);
    //var ctrlValue = control.val();
    var ctrlValue = radioValue;
    //OpenPage(5763, GetCurrentScreenID(), 'CustomAction=UpdateGoalObjectiveFieldValue^tablename=' + tablename + '^primaryKey=' + primaryKey + '^columnname=' + columnname + '^ctrlValue=' + ctrlValue, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    SetColumnValueInXMLNodeByKeyValue(tablename, primaryKeyColumnName, primaryKey, columnname, ctrlValue, AutoSaveXMLDom[0]);
    CreateUnsavedInstanceOnDatasetChange();
}


//Created By:Vikas Kashyap
//Created On: 29Nov2012
//Purpose : Mouse Over ToolTip For Previous Progress Toward Goal
function GetPreviousProgressTowardGoal(sender, DomainGoalId, DomainObjectiveId, CarePlanReviewId) {    
    var imagetooltip = $("img#" + sender).attr('title');
    if (imagetooltip == '') {
        var data = 'CustomAction=GetPreviousProgressTowardGoalProgressReview^DomainGoalId=' + DomainGoalId + "^DomainObjectiveId=" + DomainObjectiveId + "^CarePlanReviewId=" + CarePlanReviewId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
        OpenPage(5763, GetCurrentScreenID(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    }
}

function RatingProgressTowardGoalProgressReviewTab(response, CustomAjaxRequest) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";

    if (response.indexOf("###StartPreviousProgressTowardGoalProgressTab###") >= 0) {
        startIndex = response.indexOf("###StartPreviousProgressTowardGoalProgressTab###") + 48;
        endIndex = response.indexOf("###EndPreviousProgressTowardGoalProgressTab###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);

        if (outputHTML.indexOf("$$$") >= 0) {
            var outputArray = outputHTML.split("$$$");
            if (outputArray.length == 2) {
                var CarePlanReviewId = outputArray[0];
                var progressGoalText = outputArray[1];
                //Added by sunil  progressGoalText == null| for task 2616 (Thresholds bugs/Features)
                if (progressGoalText == null || progressGoalText == "") {
                    progressGoalText = "No previous ratings available";
                }
                if ($("img#imgGoal_" + CarePlanReviewId).length > 0) {
                    $("img#imgGoal_" + CarePlanReviewId).attr('title', progressGoalText);
                }
            }
        }
    }
}