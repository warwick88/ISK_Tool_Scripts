﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using SHS.BaseLayer;
using SHS.DataServices;
using SHS.UserBusinessServices;
using SHS.BaseLayer.ActivityPages;
using DevExpress.Web.ASPxEditors;
using System.Web.UI.WebControls.WebParts;

public partial class Modules_CarePlan_ActivityPages_Client_ListPages_GoalsAndObjectivesPlanHistory : SHS.BaseLayer.ActivityPages.ListActivityPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public override void BindFilters()
    {
        BindStaff();
        BindStatus();
        BindAllMoniteredBy();
        //DropDownList_GoalsAndObjectivesPlanHistory_AllErrorStatuses.Items.Add(new ListItem("All Error Status"));
        //DropDownList_GoalsAndObjectivesPlanHistory_AllErrorStatuses.DataTableGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes;
        //DropDownList_GoalsAndObjectivesPlanHistory_AllErrorStatuses.FillDropDownDropGlobalCodes(); 
        //throw new NotImplementedException();
        if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes != null)
        {
            DataView dataViewPrograms = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes);
            dataViewPrograms.RowFilter = "Active='Y' and Category = 'RADIOYN' and ISNULL(RecordDeleted,'N')<>'Y'";
            //dataViewPrograms.Sort = "SortOrder,CodeName";

            DropDownList_AllErrorStatuses.DataTextField = "CodeName";
            DropDownList_AllErrorStatuses.DataValueField = "GlobalCodeId";
            DropDownList_AllErrorStatuses.DataSource = dataViewPrograms;
            DropDownList_AllErrorStatuses.DataBind();
            ListItem item = new ListItem("All Error Statuses", "-1");
            DropDownList_AllErrorStatuses.Items.Insert(0, item);
            //DropDownList_AllErrorStatuses.SelectedValue = "-1";
            ////Added by vishant to implement message code functionality
            //ListItem item = new ListItem(SHS.BaseLayer.BaseCommonFunctions.GetApplicationMessageFromMessageCode("ALLSERVICEAREA_DD", SHS.BaseLayer.BaseCommonFunctions.ScreenId, "All Service Areas"), "-1");
            ////ListItem item = new ListItem("All Service Areas", "-1");
            //DropDownList_AllErrorStatuses.Items.Insert(0, item);
            //DropDownList_AllErrorStatuses.SelectedValue = "-1";
        }
    }

    private void BindStatus()
    {
        ListItem item = new ListItem();
        DropDownList_Status.Items.Add(new ListItem("All Statuses", "-1"));
        DropDownList_Status.Items.Add(new ListItem("Active", "0"));
        DropDownList_Status.Items.Add(new ListItem("Not Active", "1"));

        //ArrayList list = new ArrayList();
        //list.Add("All Statuses");
        //list.Add("Active");
        //list.Add("Not Active");
        //DropDownList_Status.DataSource = list;
        //DropDownList_Status.DataBind();
    }
    public override string DefaultSortExpression
    {
        get
        {
            return "Number";
        }
    }
    private void BindAllMoniteredBy()
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        dt.Columns.Add("MoniteredByName");
        dt.Columns.Add("MoniteredById");

        DataRow dr;
        foreach (DataRow drr in SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff.Rows)
        {
            dr = dt.NewRow();
            dr["MoniteredByName"] = drr["StaffName"];
            dr["MoniteredById"] = drr["StaffId"];

            dt.Rows.Add(dr);

        }
        DataRow dr1;
        foreach (DataRow drr1 in SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers.Rows)
        {
            dr1 = dt.NewRow();
            dr1["MoniteredByName"] = drr1["ProviderName"];
            dr1["MoniteredById"] = drr1["ProviderId"];
            dt.Rows.Add(dr1);
        }
        ds.Tables.Add(dt);
        DropDownList_MoniteredByName.DataTextField = "MoniteredByName";
        DropDownList_MoniteredByName.DataValueField = "MoniteredById";
        DropDownList_MoniteredByName.DataSource = ds;
        DropDownList_MoniteredByName.DataBind();

    }

    private void BindStaff()
    {
        DropDownList_StaffName.DataSource = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff;
        DropDownList_StaffName.DataTextField = "StaffName";
        DropDownList_StaffName.DataValueField = "StaffId";
        //DropDownList_StaffName.Items.Insert(0, new ListItem(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Staff.("PCALLEMCATEGORIES_DD", SHS.BaseLayer.BaseCommonFunctions.ScreenId, "All EM Categories"), "-1"));
        DropDownList_StaffName.DataBind();
        DropDownList_StaffName.Text = "All Created By";
    }

    public override System.Data.DataTable BindGrid()
    {
        using (SHS.UserBusinessServices.CoreCarePlan objectGoalsCarePlan = new SHS.UserBusinessServices.CoreCarePlan())
        {
            DataSet dataSet = null;
            int clientId = -1;
            string startDate = null;
            string endDate = null;
            int modifiedBy = -1;
            int status = -1;
            string search = String.Empty;
            int moniteredBy = -1;
            string moniteredByType = String.Empty;
            int isError = -1;

            //string isErrortest = "";
            int otherFilter = -1;
            clientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;
            GetSelectedValueFromDropdown(DropDownList_MoniteredByName, "MoniteredByName", out moniteredBy);
            GetSelectedValueFromDropdown(DropDownList_StaffName, "StaffName", out modifiedBy);
            GetSelectedValueFromDropdown(DropDownList_Status, "Status", out status);
            GetSelectedValueFromDropdown(DropDownList_AllErrorStatuses, "AllErrorStatuses", out isError);

            //if(DropDownList_AllErrorStatuses.SelectedValue)
            //if (DropDownList_AllErrorStatuses)

            //isError = (GetFilterValue("IsError", (DropDownList_GoalsAndObjectivesPlanHistory_AllErrorStatuses.SelectedValue) == "" ? null : DropDownList_GoalsAndObjectivesPlanHistory_AllErrorStatuses.SelectedValue));
            if (GetFilterValue("Search") != "")
            {
                search = GetFilterValue("Search").Trim();
            }
            if (GetFilterValue("StartDate") == "")
            {
                startDate = null;
            }
            else
            {
                startDate = GetFilterValue("StartDate");
            }
            if (GetFilterValue("EndDate") == "")
            {
                endDate = null;
            }
            else
            {
                endDate = GetFilterValue("EndDate");
            }

            dataSet = GetGridData(objectGoalsCarePlan, clientId, startDate, endDate, modifiedBy, status, search, moniteredBy, "S", isError, otherFilter);

            // End custom code
            if (dataSet != null)
            {
                if (dataSet.Tables.Count > 0)
                {
                    if (dataSet.Tables.Contains("CarePlanGoalHistory") == true)
                    {
                        lvGoalsAndObjectivePlanHistory.DataSource = dataSet.Tables["CarePlanGoalHistory"];
                        lvGoalsAndObjectivePlanHistory.DataBind();

                    }
                }
            }

            return dataSet.Tables["TablePagingInformation"];
        }
    }
    private void GetSelectedValueFromDropdown(DropDownList dropDown, string key, out int value)
    {
        if (dropDown.Items.Count > 0)
        {
            int.TryParse(GetFilterValue(key, dropDown.SelectedItem.Value.ToString()), out value);
        }
        else
        {
            int.TryParse(GetFilterValue(key), out value);
        }
    }
    private DataSet GetGridData(SHS.UserBusinessServices.CoreCarePlan objectGoalsCarePlan,
      int clientId, string startDate, string endDate, int modifiedBy, int status, string search, int moniteredBy, string moniteredByType, int isError, int otherFilter)
    {
        DataSet dataSet = null;

        //string sessionId = Session.SessionID;
        //int instanceId = 0;
        int pageNumber = ParentPageListObject.CurrentPage;
        int pageSize = ParentPageListObject.PageSize == 0 ? 1 : ParentPageListObject.PageSize;
        string sortExpression = ParentPageListObject.SortExpression;
        //int clientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;
        //int staffId = 0;  

        //int.TryParse(ParentPageListObject.CurrentHistoryId, out instanceId);
        //if (BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId != 0)
        //    staffId = BaseCommonFunctions.ApplicationInfo.LoggedInUser.UserId;

        dataSet = objectGoalsCarePlan.GetGOalsAndObjectivesPlanHistory(pageNumber, pageSize, sortExpression,
                                                                 clientId, startDate, endDate, modifiedBy, status, search, moniteredBy, "S", isError, otherFilter);

        ds = dataSet;
        return dataSet;


    }
    protected void LayoutCreated(object sender, EventArgs e)
    {
        var SortExpression = ParentPageListObject.SortExpression;
        string[] Sort = SortExpression.Split(' ');

        Panel divHeader = (Panel)lvGoalsAndObjectivePlanHistory.FindControl("divHeader");
        foreach (Control ctrl in divHeader.Controls)
        {
            if (ctrl.GetType() == typeof(Panel))
            {
                string SortId = ((Panel)ctrl).Attributes["SortId"];
                if (SortId != null)
                {
                    ((Panel)ctrl).Attributes.Add("onclick", "SortListPage(" + ParentPageListObject.ScreenId.ToString() + ",'" + SortId + "');");
                    if (Sort.Count() > 0)
                    {
                        if (Sort[0] == SortId)
                        {
                            if (Sort.Count() == 1)
                            {
                                ((Panel)ctrl).CssClass = "SortUp";
                            }
                            else
                            {
                                ((Panel)ctrl).CssClass = "SortDown";
                            }
                        }
                    }

                }
            }
        }
        Panel divContent = (Panel)lvGoalsAndObjectivePlanHistory.FindControl("divListPageContent");
        //CheckboxController1.ListPageControllerDivID = divContent.ClientID.Trim();
        divContent.Attributes.Add("onscroll", "fnScroll('#" + divHeader.ClientID + "','#" + divContent.ClientID + "');");

    }
    DataSet ds;
    protected void Test_DataBound(object sender, ListViewItemEventArgs e)
    {
        if (e.Item.ItemType == ListViewItemType.DataItem)
        {
            ListViewDataItem lvdi = (ListViewDataItem)e.Item;
            DataRowView dv = (DataRowView)lvdi.DataItem;
            String title = dv["Error"].ToString();
            DropDownList ddl = (DropDownList)lvdi.FindControl("DropDownList_IsError");
            ListItem item = ddl.Items.FindByValue(title);
            ddl.SelectedIndex = ddl.Items.IndexOf(item);
            string Id = dv["GoalsAndObjectivesHistoryId"].ToString();
            string Flag = dv["GoalsAndObjectivesHistoryType"].ToString();
            ddl.Attributes.Add("GoalsAndObjectivesHistoryId", Id);
            ddl.Attributes.Add("GoalsAndObjectivesHistoryType", Flag);
        }
    }
    public override DataTable GetExportDataSet()
    {
        using (SHS.UserBusinessServices.CoreCarePlan objectGoalsCarePlan = new SHS.UserBusinessServices.CoreCarePlan())
        {
            int clientId = -1;
            string startDate = null;
            string endDate = null;
            int modifiedBy = -1;
            int status = -1;
            string search = String.Empty;
            int moniteredBy = -1;
            string moniteredByType = String.Empty;
            int isError = -1;
            int otherFilter = -1; ;
            clientId = BaseCommonFunctions.ApplicationInfo.Client.ClientId;
            startDate = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "StartDate", ParentPageObject.PageFiltersXML);
            endDate = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "EndDate", ParentPageObject.PageFiltersXML);
            modifiedBy = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "StaffName", ParentPageObject.PageFiltersXML);
            status = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "Status", ParentPageObject.PageFiltersXML);
            search = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "Search", ParentPageObject.PageFiltersXML);
            moniteredBy = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "MoniteredByName", ParentPageObject.PageFiltersXML);
            moniteredByType = BaseCommonFunctions.GetSelectedValueFromXML<string>("/PageFilters/", "MonitoredByType", ParentPageObject.PageFiltersXML);
            isError = BaseCommonFunctions.GetSelectedValueFromXML<int>("/PageFilters/", "AllErrorStatuses", ParentPageObject.PageFiltersXML);
            if (GetFilterValue("Search") != "")
            {
                search = GetFilterValue("Search").Trim();
            }
            if (GetFilterValue("StartDate") == "")
            {
                startDate = null;
            }
            else
            {
                startDate = GetFilterValue("StartDate");
            }
            if (GetFilterValue("EndDate") == "")
            {
                endDate = null;
            }
            else
            {
                endDate = GetFilterValue("EndDate");
            }
            DataSet dataSet = null;
            dataSet = GetGridData(objectGoalsCarePlan, clientId, startDate, endDate, modifiedBy, status, search, moniteredBy, "S", isError, otherFilter);
            dataSet.Tables["CarePlanGoalHistory"].Columns.Remove("GoalsAndObjectivesHistoryId");
            dataSet.Tables["CarePlanGoalHistory"].Columns.Remove("GoalsAndObjectivesHistoryType");
            for (int i = 0; i < dataSet.Tables["CarePlanGoalHistory"].Rows.Count; i++)
            {
                if (Convert.ToString(dataSet.Tables["CarePlanGoalHistory"].Rows[i]["Error"]) == "5340")
                {
                    dataSet.Tables["CarePlanGoalHistory"].Rows[i]["Error"] = "Yes";
                }
                else
                {
                    dataSet.Tables["CarePlanGoalHistory"].Rows[i]["Error"] = "No";
                }
            }
            return dataSet.Tables["CarePlanGoalHistory"];
        }
    }
}
