﻿var ChangeCheck = false;
var cntCheck = 1;
//var BillingCodeInfoEntered = false;
var siteId = "";
var authId = "";
var unit = "";
var startDate = "";
var endDate = "";
var frequency = "";
var needId = "";
var tPInterventionProcedureId = "";
var authCodeName = "";
var siteName = "";
var TPProcedureIntervention
var TPConfirmCaption = "Translate(CONFIRMMESSAGE,Confirmation Message)";
var TPAlertCaption = "Translate(MESSAGE,Message)";
var TPProcedureId = 0;
var tpprocedureId;
var scrollPostion = 0;
var scrollFor = '';
//Added By Priya
var SortExpressionProcedure = '';

//Function to get the selected goal Value 
//CreatedOn:04 Sept 2009
//Author: Anuj Tomar
var CountSelectedGoal = 0;
var GoalTextAreaValue;

//Description:Function to open the popup 'FrequencyScopeAndDuration'
//CreatedOn:06-Oct-2010
//Author: Damanpreet Kaur 
//function openFrequencyScope(AuthorizationCodeId, SiteId, tpIterventionId, tPInterventionProcedureId, needId, frequencyType, units, fromDate, toDate)
//{
//    try
//    {
//        OpenPage(5765, 161, 'AuthorizationCodeId=' + AuthorizationCodeId + '^SiteId=' + SiteId + '^TPInterventionId=' + tpIterventionId, null, GetRelativePath(), 'T', "dialogHeight: 600px; dialogWidth: 800px;dialogTitle:FrequencyScopeAndDuration");
//    }
//    catch (err)
//    {
//        LogClientSideException(err, 'TPPopup');
//    }
//}

//Description:Function to open the popup 'SelectAuthorization'
//CreatedOn:11-Oct-2010
//Author: Damanpreet Kaur
function SetAuthorizationResult(AuthorizationCodeId, SiteId, tpIterventionId, tPInterventionProcedureId, needId, frequencyType, units, fromDate, toDate, TPProcedureId, totalUnits) {
    try {
        var myDate = new Date();
        //$.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx?tPInterventionProcedureId=" + tPInterventionProcedureId, 'action=addselectauthorization&tpIterventionId=' + tpIterventionId + '&NeedId=' + needId + '&Unit=' + units + '&From=' + fromDate + '&To=' + toDate + '&FrequencyType=' + frequencyType + '&TPProcedureId=' + TPProcedureId + '&TotalUnits=' + totalUnits + '&time=' + myDate.getMinutes() + myDate.getSeconds(), onSuccessSameAuthorization);
        $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx?tPInterventionProcedureId=" + tPInterventionProcedureId, 'action=addselectauthorization&tpIterventionId=' + tpIterventionId + '&NeedId=' + needId + '&Unit=' + units + '&From=' + fromDate + '&To=' + toDate + '&FrequencyType=' + frequencyType + '&TPProcedureId=' + TPProcedureId + '&TotalUnits=' + totalUnits + '&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) { onSuccessSameAuthorization(result, tPInterventionProcedureId) });
    }
    catch (err) {
        LogClientSideException(err, 'TPPopup');
    }
}

//Description:Function to get the result and transfer it to parent page
//CreatedOn:11-Oct-2010
//Author: Damanpreet Kaur
//function onSuccessSameAuthorization(result) {
function onSuccessSameAuthorization(result, tPInterventionProcedureId) {
    try {
        if (result != "") {
            var treatmentPlanInformation = eval("(" + result.replace(/&quot;/g, "\"") + ")");
            if (treatmentPlanInformation.ShowErrorMessage == false) {
                parent.RecreateInterventionCloseFrequencyAndScope(tPInterventionProcedureId);
                parent.CloaseModalPopupWindow();
                //parent.ProcessTxPlanMainInfo(parent.$("input[id$=HiddenFieldLocID]").val());

            }
        }
    }
    catch (err) {
        LogClientSideException(err, 'TPPopup');
    }
}

//Description:On Click of Save Button<Open popups according to the conditions>
//CreatedOn:08-Oct-2010
//Author: Damanpreet Kaur
function btnSave_Click() {
    try {


        var radiobuttons = $("input[type=radio]:checked");
        if (radiobuttons.length > 0) {
            if (radiobuttons.attr("IsAutho") == 'true') {
                siteId = $("[id$=HiddenFieldSiteId]").val();
                authId = $("[id$=HiddenFieldAuthorizationCodeId]").val();
                tPInterventionProcedureId = $("[id$=HiddenFieldTPInterventionProcedureId]").val();
                unit = $("[id$=HiddenFieldUnits]").val();
                needId = $("[id$=HiddenFieldNeedId]").val();
                startDate = $("[id$=HiddenFieldStartDate]").val();
                endDate = $("[id$=HiddenFieldEndDate]").val();
                frequency = $("[id$=HiddenFieldFrequency]").val();
                //tPInterventionProcedureId = $("[id$=HiddenFieldSelectedTPInterventionId]").val();
                var strObj = "var strObj={AuthorizationCodeId:'" + authId + "',SiteId:'" + siteId + "',TPInterventionProcedureId:'" + tPInterventionProcedureId + "'}";
                parent.CloaseModalPopupWindow(strObj);
                //Open Frequency Scope and Duration
                //openFrequencyScope(authId, siteId, tpIterventionId, tPInterventionProcedureId, needId, frequency, unit, startDate, endDate);
            }
            else {
                siteId = $("[id$=HiddenFieldSiteId]").val();
                authId = $("[id$=HiddenFieldAuthorizationCodeId]").val();
                tPInterventionProcedureId = $("[id$=HiddenFieldTPInterventionProcedureId]").val();
                unit = $("[id$=HiddenFieldUnits]").val();
                needId = $("[id$=HiddenFieldNeedId]").val();
                startDate = $("[id$=HiddenFieldStartDate]").val();
                endDate = $("[id$=HiddenFieldEndDate]").val();
                frequency = $("[id$=HiddenFieldFrequency]").val();
                tpIterventionId = $("[id$=HiddenFieldSelectedTPInterventionId]").val();
                var TPProcedureId = $("[id$=HiddenFieldTPProcedureId]").val();
                var totalUnits = $("[id$=LabelTotalUnits]").html();
                //Open Select Authorization
                SetAuthorizationResult(authId, siteId, tpIterventionId, tPInterventionProcedureId, needId, frequency, unit, startDate, endDate, TPProcedureId, totalUnits);
            }
            authCodeName = $("[id$=HiddenFieldAuthCodeName]").val();
            siteName = $("[id$=HiddenFieldSiteName]").val();
            //            CreateAutoSaveXml('TPInterventionProcedures', 'AuthorizationCodeName', authCodeName);
            //            CreateAutoSaveXml('TPInterventionProcedures', 'SiteName', siteName);
        }
        else {
            ShowMsgBox("Translate(SELECTAUTH,Please select authorization.)", "Translate(MESSAGE,Message)", MessageBoxButton.OK, MessageBoxIcon.Information);
        }

    }
    catch (err) {
        LogClientSideException(err, 'TPPopup');
    }
}

//function ModalPopupWindowClosed(ModelPopupName) {
//    //    if (ModelPopupName == 'SelectAuthorization') {
//    //        //Open Frequency Scope and Duration
//    //        openFrequencyScope(authId, siteId, tpIterventionId, tPInterventionProcedureId, needId, frequency, unit, startDate, endDate);
//    //        return false;
//    //    }

//    return false;
//}

function btnRadio_Click(tPInterventionProcedureId, needId, frequencyType, authCodeName, siteName, unit, from, to, TPProcedureId) {
    try {
        var radiobuttons = $("input[type=radio]:checked");
        if (radiobuttons.length > 0) {
            if (radiobuttons.attr("IsAutho") == 'true') {
                $("[id$=HiddenFieldUnits]").val(unit);
                $("[id$=HiddenFieldStartDate]").val(from);
                $("[id$=HiddenFieldEndDate]").val(to);
                $("[id$=HiddenFieldFrequency]").val(frequencyType);
                $("[id$=HiddenFieldNeedId]").val(needId);
                $("[id$=HiddenFieldAuthCodeName]").val(authCodeName);
                $("[id$=HiddenFieldSiteName]").val(siteName);
                $("[id$=HiddenFieldSelectedTPInterventionId]").val(tPInterventionProcedureId);
            }
            else {
                $("[id$=HiddenFieldUnits]").val(unit);
                $("[id$=HiddenFieldStartDate]").val(from);
                $("[id$=HiddenFieldEndDate]").val(to);
                $("[id$=HiddenFieldFrequency]").val(frequencyType);
                $("[id$=HiddenFieldNeedId]").val(needId);
                $("[id$=HiddenFieldAuthCodeName]").val(authCodeName);
                $("[id$=HiddenFieldSiteName]").val(siteName);
                $("[id$=HiddenFieldSelectedTPInterventionId]").val(tPInterventionProcedureId);
                $("[id$=HiddenFieldTPProcedureId").val(TPProcedureId);
            }
            $("[id$=buttonOk]").removeAttr("disabled");
        }

    }
    catch (err) {
        LogClientSideException(err, 'TPPopup');
    }
}

//Description:Function to open the popup 'BillingCodeAllocation'
//CreatedOn:13-Oct-2010
//Author: Damanpreet Kaur
function BillingCodeDetail() {
    try {
        window.showModalDialog("../BillingCodeAllocation.aspx", "test", "center:yes;resizable:no;dialogWidth:840px;dialogHeight:550px;");
        //OpenPage(5765, 10619, '', null, GetRelativePath(), 'T', "dialogHeight: 600px; dialogWidth: 800px;dialogTitle:Billing Code Allocation");
    }
    catch (err) {
        LogClientSideException(err, 'TPPopup');
    }
}

function FromDateEndDateValidation(control) {
    try {
        var textBoxTPProcedureStartDate = $('input[type=text][id$=TextBox_TPProcedures_StartDate]');
        var textBoxTPProcedureEndDate = $('input[type=text][id$=TextBox_TPProcedures_EndDate]');

        if (control.value == "") {
            return false;
        }

        if (control.id == textBoxTPProcedureStartDate[0].id) {
            if (control.attributes["datatype"].value == "Date") {
                var returnValue = ValidateDate(textBoxTPProcedureStartDate[0]); //set the date if user enters . as date seprator. /\/\ |<
                //  var returnValue = ValidateDateValue(textBoxTPInterventionProcedureStartDate);
                if (returnValue != true) {
                    textBoxTPProcedureStartDate.val('');
                    return false;
                }
            }
        }
        if (control.id == textBoxTPProcedureEndDate[0].id) {

            if (control.attributes["datatype"].value == "Date") {
                var returnValue = ValidateDate(textBoxTPProcedureEndDate[0]); //set the date if user enters . as date seprator. /\/\ |<
                //  var returnValue = ValidateDateValue(textBoxTPInterventionProcedureStartDate);
                if (returnValue != true) {
                    textBoxTPProcedureEndDate.val('');
                    return false;
                }
            }
        }
        if (textBoxTPProcedureStartDate[0].value != "" && textBoxTPProcedureEndDate[0].value != "") {
            //Now Perform check from date is less than start date or not

            var date1 = new Date(textBoxTPProcedureStartDate[0].value);
            var date2 = new Date(textBoxTPProcedureEndDate[0].value);
            var date3 = new Date($('[id$=Label_EndDate]').text());

            if (date1 > date2) {

                SetErrorMessageAlignment("Translate(TODATENOTLESSFROMDATE,To date can not be less than the from date.)");
                //ShowMsgBox('To-Date can not be less than the From-Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                return false;
            }
            else

                if (date2 > date3) {
                    SetErrorMessageAlignment("Translate(TODATENOTLESSTHANTXPLANEXPIRYDATE,To date cannot be later than the Tx Plan Expire date.)");
                    // ShowMsgBox('To-Date can not be more than the TxPlan Expiry Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    return false;
                }

            var unitReqested = $("input[type=text][id$=TextBox_TPProcedures_Units]").val();
            var frequecyType = $("select[id$=DropDownList_TPProcedures_FrequencyType]")[0].value;
            if (unitReqested != "" && frequecyType != "0")
                UnitCalculation(control);
        }



    }
    catch (err) {

        LogClientSideException(err, 'HRMTreatmetPlan');
    }


}

function checkForBlankValues() {
    try {
        if ($('input[type=text][id$=TextBox_TPProcedures_Units]')[0].value != '' &&
    $('input[type=text][id=TextBox_TPProcedures_StartDate]')[0].value != '' &&
    $('input[type=text][id=TextBox_TPProcedures_EndDate]')[0].value != '' &&
    $('select[id$=DropDownList_TPProcedures_FrequencyType]')[0].value > 0) {
            return true;
        }
        else {
            return false;
        }
    }
    catch (err) {
        LogClientSideException(err, 'HRMTreatmetPlan'); //Code added by Devinder 
    }
}
//Added By 
//This function is used to Calculate the Total Units Based on Requested value
function calculateTotalUnits() {
    try {

        var units = $('[id$=TextBox_TPProcedures_Units]')[0].value;

        if (isNaN(parseInt(units))) {
            $('[id$=TextBox_TPProcedures_Units]').val('');
            units = '';
        }

        if (checkForBlankValues()) {
            var fromDate = $('[id=TextBox_TPProcedures_StartDate]')[0].value;
            var toDate = $('[id=TextBox_TPProcedures_EndDate]')[0].value;
            units = $('[id$=TextBox_TPProcedures_Units]')[0].value;
            var frequencyType = $('[id$=DropDownList_TPProcedures_FrequencyType]')[0].value;

            $.ajax({
                type: "POST",
                url: "../AjaxScript.aspx?functionName=CalculateTotalUnitsForAuthorizationDocument",
                data: 'FromDate=' + fromDate + '&ToDate=' + toDate + '&Units=' + units + '&FrequencyRequested=' + frequencyType,
                success: fillTotalUnits
            });
        }
    }
    catch (err) {
        LogClientSideException(err, 'TPPopup');
    }
}
//Added By Mohit Madaan
//This function is used to Fill the Total Units in the Text box
function fillTotalUnits(result) {
    try {
        // $('[id=TextBox_TPProcedures_TotalUnits]')[0].value = result;

    }
    catch (err) {
        LogClientSideException(err, 'TPPopup');
    }
}

function UnitCalculation(control) {
    try {

        //In First Step we have to perform validation
        var textBoxTPInterventionProcedureTotalUnits = $("input[type=text][id$=TextBox_TPProcedures_TotalUnits]");
        var textBoxTPInterventionProcedureUnits = $("input[type=text][id$=TextBox_TPProcedures_Units]");
        var dropdownFrequencyType = $("select[id$=DropDownList_TPProcedures_FrequencyType]");
        var textBoxTPInterventionProcedureStartDate = $('input[type=text][id$=TextBox_TPProcedures_StartDate]');
        var textBoxTPInterventionProcedureEndDate = $('input[type=text][id$=TextBox_TPProcedures_EndDate]');
        var dropdownFrequencyType = $("select[id$=DropDownList_TPProcedures_FrequencyType]");


        //Check for all values
        if (textBoxTPInterventionProcedureUnits[0].value == "" || dropdownFrequencyType[0].selectedIndex == 0 || textBoxTPInterventionProcedureStartDate[0].value == "" || textBoxTPInterventionProcedureEndDate[0].value == "") {
            clearFields();
            return false;
        }

        //if (control.id == textBoxTPInterventionProcedureTotalUnits[0].id) {
        if (textBoxTPInterventionProcedureUnits[0].value == "") {

            SetErrorMessageAlignment("Translate(ENTERUNITSREQUESTED,Please enter Units Requested.)");
            //ShowMsgBox('Please enter Units Requested.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
            textBoxTPInterventionProcedureUnits[0].focus();
            return false;
        }

        else if (textBoxTPInterventionProcedureUnits[0].value != "") {

            if (isNaN(parseInt(textBoxTPInterventionProcedureUnits[0].value)) == true) {

                SetErrorMessageAlignment("Translate(ENTERVALIDUNIT,Please enter Valid Unit.)");
                clearFields();
                //ShowMsgBox('Please enter Valid Unit.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureUnits[0].focus();
                return false;
            }
            if (textBoxTPInterventionProcedureUnits[0].value <= 0) {
                SetErrorMessageAlignment("Translate(ENTERVALIDUNIT,Please enter Valid Unit.)");
                clearFields();
                //ShowMsgBox('Please enter Valid Unit.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureUnits[0].focus();
                return false;
            }

        }

        if (dropdownFrequencyType[0].selectedIndex == 0) {

            SetErrorMessageAlignment("Translate(SELECTFREQUENCYTYPE,Please select Frequency Type.)");
            // ShowMsgBox('Please select Frequency Type.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
            document.getElementById(dropdownFrequencyType[0].id).focus();
            clearFields();
            return false;
        }


        if (control.id != textBoxTPInterventionProcedureStartDate[0].id && control.id != textBoxTPInterventionProcedureEndDate[0].id) {
            if (textBoxTPInterventionProcedureStartDate[0].value == '') {

                SetErrorMessageAlignment("Translate(ENTERSTARTDATE,Please enter Start Date.)");
                //ShowMsgBox('Please enter Start Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureStartDate[0].focus();
                return false;
            }
            else if (textBoxTPInterventionProcedureStartDate[0].value != '') {
                if (ValidateDateTreatmentPlan(textBoxTPInterventionProcedureStartDate[0]) == false) {
                    SetErrorMessageAlignment("Translate(ENTERVALIDSTARTDATE,Please enter valid Start Date.)");
                    // ShowMsgBox('Please enter valid Start Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    textBoxTPInterventionProcedureEndDate[0].focus();
                    return false;
                }
            }
            if (textBoxTPInterventionProcedureEndDate[0].value == '') {

                SetErrorMessageAlignment("Translate(ENTERENDDATE,Please enter End Date.)");
                //ShowMsgBox('Please enter End Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                textBoxTPInterventionProcedureEndDate[0].focus();
                return false;
            }
            else if (textBoxTPInterventionProcedureEndDate[0].value != '') {
                if (ValidateDateTreatmentPlan(textBoxTPInterventionProcedureEndDate[0]) == false) {
                    SetErrorMessageAlignment("Translate(ENTERVALIDENDDATE,Please enter valid End Date.)");
                    // ShowMsgBox('Please enter valid End Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    textBoxTPInterventionProcedureEndDate[0].focus();
                    return false;
                }

            }
            //Now Perform check from date is less than start date or not
            var date1 = new Date(textBoxTPInterventionProcedureStartDate[0].value);
            var date2 = new Date(textBoxTPInterventionProcedureEndDate[0].value);
            var date3 = new Date($('[id$=Label_EndDate]').text());

            if (date1 > date2) {

                SetErrorMessageAlignment("Translate(TODATENOTLESSFROMDATE,To date can not be less than the from date.)");
                //ShowMsgBox('To-Date can not be less than the From-Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                return false;
            }
            else

                if (date2 > date3) {
                    SetErrorMessageAlignment("Translate(TODATENOTLESSTHANTXPLANEXPIRYDATE,To date cannot be later than the Tx Plan Expire date.)");
                    //ShowMsgBox('To-Date can not be more than the TxPlan Expiry Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
                    return false;
                }
        }



        // }


        //        else {
        ////            if (control.value == "") 
        ////            {
        ////                return false;
        ////            }
        //            else {
        //                //check validation for there associated control
        //                if (control.id == textBoxTPInterventionProcedureUnits[0].id) {
        //                    if (isNaN(parseInt(textBoxTPInterventionProcedureUnits[0].value)) == true) {
        //                        // alert("Please enter Valid Unit");
        //                        ShowMsgBox('Please enter Valid Unit.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        //                        textBoxTPInterventionProcedureUnits[0].focus();
        //                        return false;
        //                    }

        //                    if (textBoxTPInterventionProcedureUnits[0].value == 0 || textBoxTPInterventionProcedureUnits[0].value < 0) {
        //                        //alert("Please enter Valid Unit");
        //                        ShowMsgBox('Please enter Valid Unit.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        //                        textBoxTPInterventionProcedureUnits[0].focus();
        //                        return false;
        //                    }

        //                }
        //                else if (control.id == dropdownFrequencyType[0].id) {
        //                    if (dropdownFrequencyType[0].selectedIndex == 0) {

        //                        //alert("Please select Frequency Type");
        //                        ShowMsgBox('Please select Frequency Type.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        //                        document.getElementById(dropdownFrequencyType[0].id).focus();
        //                        clearFields();
        //                        return false;
        //                    }

        //                }

        //            }

        //        }

        if (control.id.indexOf('TextBox_TPProcedures_TotalUnits') >= 0 && textBoxTPInterventionProcedureTotalUnits[0].value != '' && parseInt(textBoxTPInterventionProcedureTotalUnits[0].value) > 0) {
            var result = "##STARTPAGERESPONSEVALUE##" + textBoxTPInterventionProcedureTotalUnits[0].value + "##ENDPAGERESPONSEVALUE##";
            onSuccessUnitCalculation(result)
        }
        else {
            var myDate = new Date();
            HideErrorMessage();
            $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=unitcalculation&procedureUnits=' + textBoxTPInterventionProcedureUnits[0].value + '&frequencyType=' + dropdownFrequencyType[0].value + '&startDate=' + textBoxTPInterventionProcedureStartDate[0].value + '&endDate=' + textBoxTPInterventionProcedureEndDate[0].value, onSuccessUnitCalculation);
        }

    }
    catch (err) {
        LogClientSideException(err, 'HRMTreatmetPlan');
    }

}

function onSuccessUnitCalculation(result) {

    try {
        var pageResponse = result;
        var start = pageResponse.indexOf("##STARTPAGERESPONSEVALUE##") + 26;
        var end = pageResponse.indexOf("##ENDPAGERESPONSEVALUE##");
        pageResponse = pageResponse.substr(start, end - start);
        if (pageResponse != undefined) {

            $('[id$=TextBox_TPProcedures_TotalUnits]').val(trim(pageResponse));

            var Label_TPProcedures_TotalUnits = $("[id$=Label_TPProcedures_TotalUnits]");

            Label_TPProcedures_TotalUnits.text($('[id$=TextBox_TPProcedures_TotalUnits]').val());

            var Label_TableName_PreviouslyRequested = $("[id$=Label_TableName_PreviouslyRequested]");
            var Label_TableName_TotalRequestedYTD = $("[id$=Label_TableName_TotalRequestedYTD]");



            if (!isNaN(parseInt(Label_TableName_PreviouslyRequested.text())) && !isNaN(parseInt($('[id$=TextBox_TPProcedures_TotalUnits]')[0].value))) {
                Label_TableName_TotalRequestedYTD.text(parseInt(Label_TableName_PreviouslyRequested.text()) + parseInt($('[id$=TextBox_TPProcedures_TotalUnits]').val()));
            }
            else if (!isNaN(parseInt($('[id$=TextBox_TPProcedures_TotalUnits]').val()))) {

                Label_TableName_TotalRequestedYTD.text($('[id$=TextBox_TPProcedures_TotalUnits]').val());
            }
            else {
                Label_TableName_TotalRequestedYTD.text('');
            }

            if (!isNaN(parseInt(Label_TableName_TotalRequestedYTD.text()))) {
                var LCM = $('[id$=Label_LCM]');
                var CCM = $('[id$=Label_CCM]');


                var valTotalReqYTD = 0;

                var valLCM = 0;
                var valCCM = 0;

                if (!isNaN(parseInt(LCM.text()))) {
                    valLCM = parseInt(LCM.text());
                }
                if (!isNaN(parseInt(CCM.text()))) {
                    valCCM = parseInt(CCM.text());
                }

                if (!isNaN(parseInt(Label_TableName_TotalRequestedYTD.text()))) {
                    valTotalReqYTD = parseInt(Label_TableName_TotalRequestedYTD.text());
                }

                var LCMAndCCMOver = 0;
                if ($('[id$=Label_LCM]').text() != "" && valTotalReqYTD > valLCM) {
                    $('[id$=UnitOverLCM]').css('display', 'block');
                    $('[id$=Label_LCM_Over]').text((valTotalReqYTD - valLCM));

                    $('[id$=Label_LCM_Over]').css('visibility', 'visible');
                    LCMAndCCMOver = LCMAndCCMOver + 1;
                }
                else {
                    $('[id$=UnitOverLCM]').css('display', 'none');
                    $('[id$=Label_LCM_Over]').css('visibility', 'hidden');
                    $('[id$=Label_LCM_Over]').text('');
                }


                if ($('[id$=Label_CCM]').text() != "" && valTotalReqYTD > valCCM) {
                    $('[id$=UnitOverCCM]').css('display', 'block');
                    $('[id$=Label_CCM_Over]').text((valTotalReqYTD - valCCM));

                    $('[id$=Label_CCM_Over]').css('visibility', 'visible');
                    LCMAndCCMOver = LCMAndCCMOver + 1;
                }
                else {
                    $('[id$=UnitOverCCM]').css('display', 'none');
                    $('[id$=Label_CCM_Over]').css('visibility', 'hidden');
                    $('[id$=Label_CCM_Over]').text('');
                }

                if (LCMAndCCMOver > 0)
                    $('[id$=spnLCMAndCCMOver]').show();
                else
                    $('[id$=spnLCMAndCCMOver]').hide();

            }
            ShowTotalUnitRequested(); //Added by Saurav Pande on 09th Feb 2012 to display total unit value
            //$('[id$=UnitOverLCM]').show();
            //$('[id$=UnitOverLCM]').hide();




        }

    }
    catch (err) {

        LogClientSideException(err, 'TPPopup');
    }


}

function clearFields() {
    $('[id$=UnitOverCCM]').css('display', 'none');
    $('[id$=Label_CCM_Over]').css('visibility', 'hidden');
    $('[id$=Label_CCM_Over]').text('');

    $('[id$=UnitOverLCM]').css('display', 'none');
    $('[id$=Label_LCM_Over]').css('visibility', 'hidden');
    $('[id$=Label_LCM_Over]').text('');

    $("[id$=Label_TPProcedures_TotalUnits]").text('0');
    $('[id$=TextBox_TPProcedures_TotalUnits]').val('');
    $("[id$=Label_TableName_TotalRequestedYTD]").text('');
}


function ValidateDateTreatmentPlan(input) {
    try {
        var validformat = /^\d{2}\/\d{2}\/\d{4}$/ //Basic check for format validity
        var returnval = false
        var errorMessage = "";
        if (input.value == '') {
            return;
        }
        else {
            var monthfield = input.value.split("/")[0]
            var dayfield = input.value.split("/")[1]
            var yearfield = input.value.split("/")[2]
            var dayobj = new Date(yearfield, monthfield - 1, dayfield)
            if ((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield)) {
                errorMessage = "Translate(INVALIDDAYMONTHYEAR,Invalid Day&#44; Month&#44; or Year range detected. Please correct)";
            }
            else {
                returnval = true
            }
        }
        if (returnval == false) {
            input.value = '';
            return false;
        }
        else {

            return true;
        }
    }
    catch (err) {
        LogClientSideException(err, 'HRMTreatmetPlan');
    }

}

//Description:update sc
//CreatedOn:18th-Nov-2009
//Author: Vikas Vyas
//This function is now used in HRMAssignProcedure popups 4 July,2010
function UpdateHRMTPAssignProcedure() {

    try {

        var myDate = new Date();

        $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=updatehrmtpassignprocedure', onSuccessUpdateHRMTPAssignProcedure);



    }
    catch (err) {
        LogClientSideException(err, 'HRMTreatmetPlan');

    }


}

//Description:get unit after calculation
//CreatedOn:18th-Nov-2009
//Author: Vikas Vyas

//Now this function is used on HRMAssignprodeudere popups 
function onSuccessUpdateHRMTPAssignProcedure(result) {


    var pageResponse = result;
    var start = pageResponse.indexOf("##STARTPAGERESPONSEVALUE##") + 26;
    var end = pageResponse.indexOf("##ENDPAGERESPONSEVALUE##");
    pageResponse = pageResponse.substr(start, end - start);
    if (pageResponse != undefined) {
        //commented on 06 July orignal code block :$("#PanelGridView")[0].outerHTML = pageResponse;
        $("div[id$=PanelGridView]")[0].outerHTML = pageResponse;
        //commented on 06 July orignal code block : $("input[type='button'][Id=ButtonUpdate]").attr("disabled", "disabled");
        $("input[type='button'][Id$=ButtonUpdate]").attr("disabled", "disabled");

        //$("input[type='button'][Id=ButtonInsert]").attr("value", "Insert");


    }

}
function OpenPopupBillingCode(calledFrom) {

    // added by Rakesh 27th Dec 2010
    //For Open Pop Billing Code Allocation User must specify 'From' 'to' # Units and Frequency and then  must click on 'Billing Code Details Required...' to specify billing code authorization information. 
    var errNo = 0;
    var fromDate = $("input[type=text][id$=TextBox_TPProcedures_StartDate]").val();
    var toDate = $("input[type=text][id$=TextBox_TPProcedures_EndDate]").val();
    var unitReqested = $("input[type=text][id$=TextBox_TPProcedures_Units]").val();
    var totalUnit = $("input[type=text][id$=TextBox_TPProcedures_TotalUnits]").val();
    var serviceType = $("[id$=Label_ServiceCategory]").text();

    var frequecyType = $("select[id$=DropDownList_TPProcedures_FrequencyType]")[0].value;
    if (fromDate == "") {
        errNo++;
        ShowHideErrorMessage("Please enter start date)", 'true');
        return false;
    }
    else if (toDate == "") {
        errNo++;
        ShowHideErrorMessage("Please enter end date)", 'true');
        return false;
    }
    else if (unitReqested == "") {
        errNo++;
        ShowHideErrorMessage("Please enter required units)", 'true');
        return false;
    }
    else if (frequecyType == "0") {
        errNo++;
        ShowHideErrorMessage("Please select frequency type)", 'true');
        return false;
    }
    else if (totalUnit == "") {
        errNo++;
        ShowHideErrorMessage("Please enter total units)", 'true');
        return false;
    }

    else if (fromDate != "" && toDate != "") {
        //Now Perform check from date is less than start date or not
        var date1 = new Date(fromDate);
        var date2 = new Date(toDate);
        var date3 = new Date($('[id$=Label_EndDate]').text());

        if (date1 > date2) {
            //alert("To-Date can not be less then the From-Date");
            errNo = 3;
        }
        else

            if (date2 > date3) {
                errNo = 4;
            }

    }
    if (unitReqested != "") {
        if (errNo == 0) {
            if (parseInt(unitReqested) <= 0) {
                errNo = 2;
            }
        }
    }

    if (errNo > 0) {

        if (errNo == 2)
            SetErrorMessageAlignment("Translate(ENTERVALIDUNIT,Please enter Valid Unit.)");

        else if (errNo == 3)
            SetErrorMessageAlignment("Translate(TODATENOTLESSFROMDATE,To date can not be less than the from date.)");

        else if (errNo == 4)
            SetErrorMessageAlignment("Translate(TODATENOTLESSTHANTXPLANEXPIRYDATE,To date cannot be later than the Tx Plan Expire date.)");

        //        else
        //            SetErrorMessageAlignment("Translate(REQUIREDFIELDS,Please enter required fields.)");
    }

    else {
        HideErrorMessage();
        var relatedPath = GetRelativePath();
        var filterData = '';

        OpenPage(5765, 10619, 'SiteAuthorization=' + $("[id$=HiddenFieldAuthorizationCodeId]").val() + '^TPProcedureId=' + $('[id$=HiddenFieldTPProcedureId]').val() + '^Label_AuthCode=' + $("[id$=Label_AuthorizationCode]").text() + '^Label_Type=' + $("[id$=Label_Type]").text() + '^Label_ReqYTD=' + $("[id$=TextBox_TPProcedures_TotalUnits]").val() + '^Label_LCM=' + $("[id$=Label_LCM]").text() + '^Label_CCM=' + $("[id$=Label_CCM]").text() + '^ServiceType=' + serviceType + '^Label_StartDate=' + $("[id$=Label_StartDate]").text() + '^Label_EndDate=' + $("[id$=Label_EndDate]").text() + '^TotalRequestedYTD=' + $("[id$=Label_TableName_TotalRequestedYTD").text(), null, GetRelativePath(), 'T', "dialogHeight: 540px; dialogWidth: 850px;dialogTitle:Billing Code Allocation;dialogcrossbutton:hide");
    }
    // parent.OpenClientSearchPopUp(relatedPath, calledFrom, filterData);
    // OpenPage(5765, 10619, "", null, $("[id$=HiddenFieldRelativePath]").val(), 'T', "dialogHeight: 520px; dialogWidth: 480px;dialogTitle:Billing Code Allocation");
}

function OpenProcedureBillingCodePopUp() {


    var _date = new Date();
    var AuthorizationCodeId = $('[id$=HiddenFieldAuthorizationCodeId]').val();
    OpenPage(5765, 143, "AuthorizationCodeId=" + AuthorizationCodeId + "^Time=" + _date.getMinutes() + _date.getSeconds(), 1, GetRelativePath(), 'T', "dialogHeight:345px; dialogWidth:454px; dialogtitle:Associated Procedure Code / Billing Code;dialogcrossbutton:hide");

}

// Still Testing
function SetHRMTPProcedureDataSet() {
    try {
        var providerName = $("[id$=Label_ProviderName]");
        var AuthorizationCodeName = $("[id$=Label_AuthorizationCode");

        var InterventionProceduerProvider = $("input[id$=HiddenFieldInterventionProceduerProvider]");
        var RequestFrequency = $("select[id$=DropDownList_TPProcedures_FrequencyType]");
        var RequestFrequencyName = $("select[id$=DropDownList_TPProcedures_FrequencyType]");
        var RequestStartDate = $("input[type=text][id$=TextBox_TPProcedures_StartDate]");
        var RequestEndDate = $("input[type=text][id$=TextBox_TPProcedures_EndDate]");
        var RequesUnits = $("input[type=text][id$=TextBox_TPProcedures_Units]");
        var RequesTotalUnit = $("input[type=text][id$=TextBox_TPProcedures_TotalUnits]");

        //var Status = $("[id$=TextBox_TPProcedure_Status]");

        var myDate = new Date();

        var TpprocedureId = $("input[id$=HiddenFieldTPProcedureId]");

        $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx?interventionProcedureId=", 'action=insertinterventionprocedure2&RequestFrequency=' + RequestFrequency[0].value + '&RequestFrequencyName=' + RequestFrequencyName[0][RequestFrequencyName[0].selectedIndex].text + '&RequestStartDate=' + RequestStartDate[0].value + '&RequestEndDate=' + RequestEndDate[0].value + '&RequestTotalUnit=' + RequesTotalUnit[0].value + '&RequesUnits=' + RequesUnits[0].value + '&InterventionProceduerProvider=' + InterventionProceduerProvider[0].value + '&Status=0&tpprocedureId=' + 0 + '&requestercomment=0 &time=' + myDate.getMinutes() + myDate.getSeconds() + '&providerName=' + providerName[0].outerText + '&authorizationName=' + AuthorizationCodeName[0].outerText, function CallBackFun(result) { alert("Success") });    //InterventionProceduerProvider   




    }
    catch (err) {
        LogClientSideException(err, 'HRMTreatmetPlan');
    }
}

function SaveAndClose() {
    try {
        //parent.CloaseModalPopupWindow();
        parent.CloseHRMTPAssignProcedure($("input[type='button'][Id$=ButtonUpdate]"), $("input[type='button'][Id$=ButtonInsert]"));
    } catch (err) {

    }
}


function CloseHRMTPAssignProcedure() {

    try {


        //Perform the check
        //commented on 06 July orignal code block : if ($("input[type='button'][Id=ButtonUpdate]")[0].disabled == false && $("input[type='button'][Id=ButtonInsert]")[0].value != "Modify") {
        //        if (ButtonUpdate[0].disabled == false && ButtonInsert[0].value != "Modify")
        //        {
        //            ShowMsgBox('Do you want to save this Treatment Plan Procedure?', TPConfirmCaption, MessageBoxButton.YesNoCancel, MessageBoxIcon.Question, 'CloseHRMTPAssignProcedureOKOption();', 'CloseHRMTPAssignProcedureCancelOption()');
        //        }
        //commented on 06 July orignal code block :else if ($("input[type='button'][Id=ButtonInsert]")[0].value != "Modify") {
        //        else if (ButtonInsert[0].value != "Modify")
        //        {

        var myDate = new Date();
        $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=closehrmtpassignprocedure', onSuccessCloseHRMTPAssignProcedure);
        //        }
        //        else
        //        {
        //            parent.CloaseModalPopupWindow();
        //        }

    }
    catch (err) {

        // LogClientSideException(err,'HRMTreatmetPlan');
    }


}


//-----------------------------------------------------------------------


function OpenViewContractPopup() {
    var _date = new Date();
    OpenPage(5765, 146, "Time=" + _date.getMinutes() + _date.getSeconds(), 1, GetRelativePath(), 'T', "dialogHeight:335px; dialogWidth:450px; dialogtitle:View Contract;");

}


function SaveFrequencyScopeAndDuration2() {

    var errorString = "";
    var errNo = 0;
    //Perform validation before proceeding further
    //Basic Validations
    //End

    //IF Provider is external and BillingCode specify is must then 
    //End
    //var IsBilllingCodeBtnExists = $('[id$=TblBtnBillingCode]').length;
    var TPInterventionProcedureId = $('[id$=HiddenFieldTPInterventionProcedureId]').val();
    var siteId = $("input[id$=HiddenFieldSiteId]").val();
    //if (tpprocedureId == "undefined") {
    tpprocedureId = $("input[id$=HiddenFieldTPProcedureId]").val();
    //}
    //else {
    //  tpprocedureId = TPProcedureId;
    // }
    var authorizationcodeId = $("input[id$=HiddenFieldAuthorizationCodeId]").val();
    var fromDate = $("input[type=text][id$=TextBox_TPProcedures_StartDate]").val();
    var toDate = $("input[type=text][id$=TextBox_TPProcedures_EndDate]").val();
    var unitReqested = $("input[type=text][id$=TextBox_TPProcedures_Units]").val();
    var totalUnit = $("input[type=text][id$=TextBox_TPProcedures_TotalUnits]").val();
    var frequecyType = $("select[id$=DropDownList_TPProcedures_FrequencyType]")[0].value;
    var requestorComment = $("textarea[id$=TextArea_TPGeneral_AuthorizationRequestorComment]").val();
    var IsRequestUrgent = $('[id$=CheckBox_TPProcedures_Urgent]').attr('checked');

    if (fromDate == "") {
        errNo++;
        ShowHideErrorMessage("Please enter start date)", 'true');
        return false;
        //errorString += " From Date,";
    }
    else if (toDate == "") {
        errNo++;
        ShowHideErrorMessage("Please enter end date)", 'true');
        return false;
        //errorString += " To Date,";
    }
    else if (unitReqested == "") {
        errNo++;
        ShowHideErrorMessage("Please enter required units)", 'true');
        return false;
        //errorString += " Requested Units,";
    }
    else if (frequecyType == "0") {
        errNo++;
        ShowHideErrorMessage("Please select frequency type)", 'true');
        return false;
        //errorString += " Frequency Type,";
    }
    else if (totalUnit == "") {
        errNo++;
        ShowHideErrorMessage("Please enter total units)", 'true');
        return false;
        //errorString += " Total Units,";
    }

    else if (fromDate != "" && toDate != "") {
        //Now Perform check from date is less than start date or not
        var date1 = new Date(fromDate);
        var date2 = new Date(toDate);
        var date3 = new Date($('[id$=Label_EndDate]').text());

        if (date1 > date2) {
            //alert("To-Date can not be less then the From-Date");
            errNo = 3;
        }
        else

            if (date2 > date3) {
                errNo = 4;
            }

    }
    if (unitReqested != "") {
        if (errNo == 0) {
            if (parseInt(unitReqested) <= 0) {
                errNo = 2;
            }
        }
    }
    if (errNo == 0 && $('[id$=BillingCodeInfoEntered]').val() == 'false') {
        errNo = 5;

    }
    //Changes made with ref to task 268 in SC web phaseII bugs /Features
    if (errNo == 0 && $.trim(requestorComment) == '' && IsRequestUrgent == true) {
        errNo = 6;
    }

    if (errNo > 0) {
        //errorString.substr(0, errorString.lastIndexOf(',') - 1);
        if (errNo == 2)
            SetErrorMessageAlignment("Translate(ENTERVALIDUNIT,Please enter Valid Unit.)");
            //ShowMsgBox('Please enter Valid Unit.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        else if (errNo == 3)
            SetErrorMessageAlignment("Translate(TODATENOTLESSFROMDATE,To date can not be less than the from date.)");
            //ShowMsgBox('To-Date can not be less than the From-Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        else if (errNo == 4)
            SetErrorMessageAlignment("Translate(TODATENOTLESSTHANTXPLANEXPIRYDATE,To date cannot be later than the Tx Plan Expire date.)");
            //ShowMsgBox('To-Date can not be more than the TxPlan Expiry Date.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        else if (errNo == 5)
            SetErrorMessageAlignment("Translate(ENTERBILLINGCODEINFO,Please enter Billing Code Information.)");
            //Changes made with ref to task 268 in SC web phaseII bugs /Features
        else if (errNo == 6)
            SetErrorMessageAlignment("Translate(FORURGENTUMMSGREQUIRED,For \'urgent\' requests&#44; UM Message Comments are required.)");
        //        else
        //            SetErrorMessageAlignment("Translate(REQUIREDFIELDS,Please enter required fields.)");
        // ShowMsgBox('Please enter required fields.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);


    }

    else {
        var CallClose = false;
        if (arguments.length > 0) {
            CallClose = true;
        }

        parent.PopupProcessing();
        var myDate = new Date();
        $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx?tpprocedureId=" + tpprocedureId, 'action=updatefrequencyscopeanddurations&authorizationcodeId=' + authorizationcodeId + '&siteId=' + siteId + '&TPInterventionProcedureId=' + TPInterventionProcedureId + '&fromDate=' + fromDate + '&toDate=' + toDate + '&unitReqested=' + unitReqested + '&totalUnit=' + totalUnit + '&frequecyType=' + frequecyType + '&requestorComment=' + requestorComment + '&IsBillingCodeBtnExists=' + IsBilllingCodeBtnExists + '&RequestUregent=' + IsRequestUrgent + '&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) { onSucc(result, CallClose, TPInterventionProcedureId) });
    }
}


function onSucc(result, CallClose, TPInterventionProcedureId) {
    parent.HidePopupProcessing();
    ChangeCheck = false;
    if (typeof result != undefined && result.toString() == "-1" && $("[id$=HiddenFieldSpecifyBillingCode]").val() == 'Y') {

        SetErrorMessageAlignment("Translate(SPECIFYBILLINGCODEFORTHISAUTH,You must specify billing codes for this authorization.)");
        //ShowMsgBox('You must specify billing codes for this authorization.', TPAlertCaption, MessageBoxButton.OK, MessageBoxIcon.Information);
        ChangeCheck = true;
        return;
    }
    else
        if (result.toString().indexOf("tpprocedureId") >= 0) {
            var tpProcedureId = result.toString().split(':');
            $('[id$=HiddenFieldTPProcedureId]').val(tpProcedureId[1]);
        }

    if (CallClose) {
        MsgBoxNo(TPInterventionProcedureId);
    }
}


// This function is used for setting alignment of Error Message
function SetErrorMessageAlignment(message) {
    ShowHideErrorMessage(message, 'true');
    $($('[id$=SpanErrorMessage]')[0].parentNode.parentNode.parentNode.parentNode).attr('align', 'left');
    $($('[id$=SpanErrorMessage]')[0].parentNode.parentNode.parentNode.parentNode).attr('style', 'padding:5px 0 5px 0');
}

function HideErrorMessage() {
    ShowHideErrorMessage("", 'false');
}


function CloseFrequencyScopeAndDuration() {
    var TPInterventionProcedureId = $('input[id$=HiddenFieldTPInterventionProcedureId]').val()
    if (ChangeCheck) {
        ShowMsgBox("Translate(SAVEFREQSCOPEDURATION,Do you want to save the changes made to Frequency and Scope Duration?)", "Translate(CONFIRMMESSAGE,Confirmation Message)", MessageBoxButton.YesNoCancel, MessageBoxIcon.Question, 'MsgBoxYes()', 'MsgBoxNo()', 'MsgBoxCancel()');
    }
    else {
        MsgBoxNo(TPInterventionProcedureId);
    }
    //    var myDate = new Date();
    //    $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=clearsessions&time=' + myDate.getMinutes() + myDate.getSeconds(), function(result) { });
    //    parent.CloaseModalPopupWindow();
    //    parent.CreateTxPlanOnCloseFrequencyAndScope();


}

function MsgBoxYes() {
    SaveFrequencyScopeAndDuration2('MsgBoxYes');
}

function MsgBoxNo(TPInterventionProcedureId) {
    if (typeof TPInterventionProcedureId == 'undefined')
        TPInterventionProcedureId = $("input[id$=HiddenFieldTPInterventionProcedureId]").val();
    var myDate = new Date();
    $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=clearsessions&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) { });
    parent.CloaseModalPopupWindow();
    //parent.CreateTxPlanOnCloseFrequencyAndScope();
    parent.RecreateInterventionCloseFrequencyAndScope(TPInterventionProcedureId);
    ChangeCheck = false;
    $('[id$=BillingCodeInfoEntered]').val('false');
}

function MsgBoxCancel() {

}
////////////////////////////////////////////////////////////////////////////////////////////////////

//returns true if billing code exists
function askForBillingCode(obj) {

    if ($("[id$=TblBtnBillingCode]").length > 0) {
        var askForBillCode = $('[id$=HiddenFieldAskForBillingCode]').val();
        //BillingCodeInfoEntered = false;
        $('[id$=BillingCodeInfoEntered]').val('false');
        if (askForBillCode != "") {
            var authCodeId = $('[id$=HiddenFieldAuthorizationCodeId]').val();
            var tpProcedureId = $('[id$=HiddenFieldTPProcedureId]').val();



            var myDate = new Date();
            $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=askforbillingcode&TPProcedureId=' + tpProcedureId + '&AuthorizationCodeId=' + authCodeId + '&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) {

                if (obj.id.toString().indexOf("TextBox_TPProcedures_Units") >= 0) {
                    onSuccessAskForBillingCode_UnitCalculation(result, obj);
                }
                else
                    if (obj.id.toString().indexOf("DropDownList_TPProcedures_FrequencyType") >= 0) {
                        onSuccessAskForBillingCode_DropDownChange(result, obj);
                    }
                    else
                        if (obj.id.toString().indexOf("TextBox_TPProcedures_TotalUnits") >= 0) {
                            onSuccessAskForBillingCode_TotalUnits(result, obj);
                        }

            });
        }
        else {
            //BillingCodeInfoEntered = true;
            $('[id$=BillingCodeInfoEntered]').val('true');
            UnitCalculation(obj); ChangeCheck = true;
        }
    }
    else {
        //BillingCodeInfoEntered = true;
        $('[id$=BillingCodeInfoEntered]').val('true');
        UnitCalculation(obj); ChangeCheck = true;
    }
}

function askForBillingCode_Date(obj) {

    if ($("[id$=TblBtnBillingCode]").length > 0) {
        var askForBillCode = $('[id$=HiddenFieldAskForBillingCode]').val();
        //BillingCodeInfoEntered = false;
        $('[id$=BillingCodeInfoEntered]').val('false');
        if (askForBillCode != "") {
            var authCodeId = $('[id$=HiddenFieldAuthorizationCodeId]').val();
            var tpProcedureId = $('[id$=HiddenFieldTPProcedureId]').val();



            var myDate = new Date();
            $.post(GetRelativePath() + "Custom/Treatment Plan/WebPages/TreatmentPlanHRMAjaxScript.aspx", 'action=askforbillingcode&TPProcedureId=' + tpProcedureId + '&AuthorizationCodeId=' + authCodeId + '&time=' + myDate.getMinutes() + myDate.getSeconds(), function (result) {




                onSuccessAskForBillingCode_Date(result, obj);


            });
        }
        else {
            //BillingCodeInfoEntered = true;
            $('[id$=BillingCodeInfoEntered]').val('true');
            return showCalendar(obj, '%m/%d/%Y');
        }
    }
    else {
        //BillingCodeInfoEntered = true;
        $('[id$=BillingCodeInfoEntered]').val('true');
        return showCalendar(obj, '%m/%d/%Y');
    }
}
function onSuccessAskForBillingCode_UnitCalculation(result, obj) {

    $('[id$=HiddenFieldAskForBillingCode]').val(result.toString());
    if (result.toString() == "BillingCodeChangeReq:YES") {
        if (cntCheck != 0)
            ShowMsgBox("Translate(REENTERBILLINGCODEONINFOCHANGE,You will need to re-enter Billing Code details if you change this information.  Do you want to continue?)", "Translate(HRMTREATMENTPLAN,HRM Treatment Plan)", MessageBoxButton.YesNo, MessageBoxIcon.Question, 'ClickYes(\'' + obj.id + '\')', 'ClickNo(\'' + obj.id + '\')');
        else {
            //BillingCodeInfoEntered = true;
            //$('[id$=BillingCodeInfoEntered]').val('true');
            UnitCalculation(obj); ChangeCheck = true;
        }
    }
    else {
        //BillingCodeInfoEntered = true;
        $('[id$=BillingCodeInfoEntered]').val('true');
        UnitCalculation(obj); ChangeCheck = true;
    }
}
function onSuccessAskForBillingCode_Date(result, obj) {

    $('[id$=HiddenFieldAskForBillingCode]').val(result.toString());
    if (result.toString() == "BillingCodeChangeReq:YES") {
        if (cntCheck != 0)
            ShowMsgBox("Translate(REENTERBILLINGCODEONINFOCHANGE,You will need to re-enter Billing Code details if you change this information.  Do you want to continue?)", "Translate(HRMTREATMENTPLAN,HRM Treatment Plan)", MessageBoxButton.YesNo, MessageBoxIcon.Question, 'ClickYesDate(\'' + obj + '\')', 'ClickNoDate(\'' + obj + '\')');
        else {
            //$('[id$=BillingCodeInfoEntered]').val('true');
            return showCalendar(obj, '%m/%d/%Y');
        }
    }
    else {
        //BillingCodeInfoEntered = true;
        $('[id$=BillingCodeInfoEntered]').val('true');
        return showCalendar(obj, '%m/%d/%Y');
    }
}
function onSuccessAskForBillingCode_DropDownChange(result, obj) {

    $('[id$=HiddenFieldAskForBillingCode]').val(result.toString());
    if (result.toString() == "BillingCodeChangeReq:YES") {
        if (cntCheck != 0)
            ShowMsgBox("Translate(REENTERBILLINGCODEONINFOCHANGE,You will need to re-enter Billing Code details if you change this information.  Do you want to continue?)", "Translate(HRMTREATMENTPLAN,HRM Treatment Plan)", MessageBoxButton.YesNo, MessageBoxIcon.Question, 'ClickYes(\'' + obj.id + '\')', 'ClickNoDropDown(\'' + obj.id + '\')');
        else {
            //$('[id$=BillingCodeInfoEntered]').val('true');
            UnitCalculation(obj); ChangeCheck = true;
        }
    }
    else {
        $('[id$=BillingCodeInfoEntered]').val('true');
        UnitCalculation(obj); ChangeCheck = true;
    }
}

function onSuccessAskForBillingCode_TotalUnits(result, obj) {

    $('[id$=HiddenFieldAskForBillingCode]').val(result.toString());
    if (result.toString() == "BillingCodeChangeReq:YES") {
        if (cntCheck != 0)
            ShowMsgBox("Translate(REENTERBILLINGCODEONINFOCHANGE,You will need to re-enter Billing Code details if you change this information.  Do you want to continue?)", "Translate(HRMTREATMENTPLAN,HRM Treatment Plan)", MessageBoxButton.YesNo, MessageBoxIcon.Question, 'ClickYes(\'' + obj.id + '\')', 'ClickNoDropDown(\'' + obj.id + '\')');
        else {
            //$('[id$=BillingCodeInfoEntered]').val('true');
            UnitCalculation(obj); ChangeCheck = true;
        }
    }
    else {
        $('[id$=BillingCodeInfoEntered]').val('true');
        UnitCalculation(obj); ChangeCheck = true;
    }
}
function ClickYes(obj) {
    //BillingCodeInfoEntered = false;
    $('[id$=BillingCodeInfoEntered]').val('false');
    obj = document.getElementById(obj);
    UnitCalculation(obj); ChangeCheck = true;
    cntCheck = 0;
}

function ClickNo(obj) {
    //BillingCodeInfoEntered = true;
    $('[id$=BillingCodeInfoEntered]').val('true');
    obj = document.getElementById(obj);
    obj.value = obj.oldvalue;
    cntCheck = 1;
}

function ClickNoDropDown(obj) {
    //BillingCodeInfoEntered = true;
    $('[id$=BillingCodeInfoEntered]').val('true');
    obj = document.getElementById(obj);
    obj.selectedIndex = obj.oldvalue;
    cntCheck = 1;
}

function ClickYesDate(obj) {
    //BillingCodeInfoEntered = false;
    $('[id$=BillingCodeInfoEntered]').val('false');
    //obj = document.getElementById(obj);
    cntCheck = 0;
    return showCalendar(obj, '%m/%d/%Y');
}

function ClickNoDate(obj) {
    //BillingCodeInfoEntered = true;
    $('[id$=BillingCodeInfoEntered]').val('true');
    obj = document.getElementById(obj);
    obj.value = obj.oldvalue;
    cntCheck = 1;
}

//function onChangeAuthReqComment(obj) {
//    //return onChangeAuthReqComment11(obj);
//    //var primaryKey=$('DocumentVersionId', $('TPGeneral', parent.AutoSaveXMLDom[0].xml)).text();
//   // SetColumnValueInXMLNodeByKeyValue('TPGeneral', 'DocumentVersionId', primaryKey, 'AuthorizationRequestorComment', obj.value, $(parent.AutoSaveXMLDom[0].xml);
//    
//}

//Added by Saurav Pande on 09th Feb 2012 to display total unit value w.rf. to Task# 8 KCMHSAS-Other changes
//Added checks by Varinder Verma on TotalUnits and requested as per task #373 of "Kalamazoo-Bugs" of Ace project
function ShowTotalUnitRequested() {
    if ($("input[type=text][id$=TextBox_TPProcedures_TotalUnits]").length > 0) {
        var totalUnits = $("input[type=text][id$=TextBox_TPProcedures_TotalUnits]");
        var UnitValues = $("[id$=Label_UnitValue]");
        var UnitType = $("[id$=Label_UnitType]").html();
        var requested = parseInt(UnitValues.text()) * parseInt(totalUnits[0].value);
        var msg = "";
        if (parseInt(requested) >= 0)
            msg = parseInt(totalUnits[0].value) + " Units = " + requested + " " + UnitType;
        $("[id$=Label_TotalRequestedUnits]").html('');
        $("[id$=Label_TotalRequestedUnits]").html(msg);
    }
}

//Added by Saurav Pande on 17th Feb 2012
// To Set value for 'Label_TotalRequestedUnits' if requested value is already saved in database.
//  w.rf. to Task# 8 KCMHSAS-Other changes
var IsBilllingCodeBtnExists;
$(document).ready(function () {
    ShowTotalUnitRequested();
    var SpecifyBillingCode = $("[id$=HiddenFieldSpecifyBillingCode]").val();
    if (SpecifyBillingCode == 'N') {
        $("[id$=TblBtnBillingCode]").hide();
        IsBilllingCodeBtnExists = 0;
    }
    else {
        $("[id$=TblBtnBillingCode]").show();
        IsBilllingCodeBtnExists = 1;
    }
})