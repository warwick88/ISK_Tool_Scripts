﻿function IncludeRequestParametersValues() {
    var filterString = "";
    filterString += GetFilterValues();
    //Remove # from the begning of the string
    filterString = filterString.substring(1, filterString.length);
    filterString = filterString.replace(/#/gi, "&") + "&ExportUsingPageDataSet=Y"
    return filterString;
}