﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using SHS.BaseLayer;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using CarePlan;
using System.Text;
using System.Data.SqlClient;
using SHS.DataServices;
using Microsoft.ApplicationBlocks.Data;
using System.Web.Script.Serialization;
using System.Linq;
namespace SHS.SmartCare
{
    public partial class CarePlanPrescribedServices : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        SHS.UserBusinessServices.Document _objectDocuments = null;
        string agencyName = string.Empty;
        DataSet dataSetTreatmentPlanHRM = null;
        int tpprocedureId = 0;
        private JavaScriptSerializer objectJavaScriptSerializer = null;

       public  StringBuilder strHtml = new StringBuilder();
        public string JsonCarePlanPrescribedServices = string.Empty;
        public string JsonPsychiatricMedications = string.Empty;
        public int THCount = 0;
        public int PMCount = 0;
        ///<summary>
        ///<Description>Class For Care Plan Prescribed Services</Description>
        ///</summary>

        //public override string[] TablesUsedInTab
        //{
        //    get { return new string[] { "CarePlanPrescribedServices" }; }
        //}
        ///<summary>
        ///<Description>This Function override and Bind Controls on PageLoad</Description>
        ///</summary>
        public override void BindControls()
        {

            if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes != null)
            {
                //DataView dataViewXduration = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes);
                //dataViewXduration.RowFilter = "Category='INTERVENTIONDURATION' and Active='Y' and ISNULL(RecordDeleted,'N')='N'";
                //dataViewXduration.Sort = "SortOrder ASC";
                //DropDownList_CarePlanPrescribedServices_Duration.DataTextField = "CodeName";
                //DropDownList_CarePlanPrescribedServices_Duration.DataValueField = "GlobalCodeId";
                //DropDownList_CarePlanPrescribedServices_Duration.DataSource = dataViewXduration;
                //DropDownList_CarePlanPrescribedServices_Duration.DataBind();
                //DropDownList_CarePlanPrescribedServices_Duration.Items.Insert(0, new ListItem("", ""));
                _objectDocuments = new SHS.UserBusinessServices.Document();
                agencyName = _objectDocuments.GetAgencyName();
                if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers != null)
                {
                    //objectDocuments = new SHS.UserBusinessServices.Document();
                    //agencyName = objectDocuments.GetAgencyName();
                    DataView dataViewProviders = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers);
                    dataViewProviders.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                    DropDownList_CarePlanPrescribedServices_ProviderId.DataTextField = "ProviderName";
                    DropDownList_CarePlanPrescribedServices_ProviderId.DataValueField = "SiteId";
                    DropDownList_CarePlanPrescribedServices_ProviderId.DataSource = dataViewProviders;
                    DropDownList_CarePlanPrescribedServices_ProviderId.DataBind();
                    DropDownList_CarePlanPrescribedServices_ProviderId.Items.Insert(0, new ListItem(agencyName, "-1"));
                    //Uncommented by Mamta Gupta - Ref Task No. 755 - SCWebPhaseII Bugs/Features - To add -2 siteid in InterventionProviders.
                    DropDownList_CarePlanPrescribedServices_ProviderId.Items.Insert(1, new ListItem("Community/Natural Support", "-2"));
                }
                

                BindServices();

                //DataView dataViewServiceProvider = new DataView(_dsAuthorizationCodes.Tables[0]);
                //DropDownListServiceProvider.DataTextField = "DisplayAs";
                //DropDownListServiceProvider.DataValueField = "AuthorizationCodeId";
                //DropDownListServiceProvider.DataSource = dataViewServiceProvider;
                //DropDownListServiceProvider.DataBind(); 


                DataView dataViewPersonResponsible = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes);
                dataViewPersonResponsible.RowFilter = "Category='PRESCRIBEDRESP' and Active='Y' and ISNULL(RecordDeleted,'N')='N'";
                dataViewPersonResponsible.Sort = "SortOrder ASC";
                DropDownList_CarePlanPrescribedServices_PersonResponsible.DataTextField = "CodeName";
                DropDownList_CarePlanPrescribedServices_PersonResponsible.DataValueField = "GlobalCodeId";
                DropDownList_CarePlanPrescribedServices_PersonResponsible.DataSource = dataViewPersonResponsible;
                DropDownList_CarePlanPrescribedServices_PersonResponsible.DataBind();
                DropDownList_CarePlanPrescribedServices_PersonResponsible.Items.Insert(0, new ListItem("", ""));

                //DataView dataViewFrequencyType = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes);
                //dataViewFrequencyType.RowFilter = "Category='TPFREQUENCYTYPE' and Active='Y' and ISNULL(RecordDeleted,'N')='N'";
                //dataViewFrequencyType.Sort = "SortOrder ASC";
                //DropDownList_CarePlanPrescribedServices_FrequencyType.DataTextField = "CodeName";
                //DropDownList_CarePlanPrescribedServices_FrequencyType.DataValueField = "GlobalCodeId";
                //DropDownList_CarePlanPrescribedServices_FrequencyType.DataSource = dataViewFrequencyType;
                //DropDownList_CarePlanPrescribedServices_FrequencyType.DataBind();
                //DropDownList_CarePlanPrescribedServices_FrequencyType.Items.Insert(0, new ListItem("", ""));

                using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPFREQUENCYTYPE", true, "", "", false))
                {
                    DropDownList_TPProcedures_FrequencyType.DataTextField = "CodeName";
                    DropDownList_TPProcedures_FrequencyType.DataValueField = "GlobalCodeId";
                    DropDownList_TPProcedures_FrequencyType.DataSource = DataViewGlobalCodes;
                    DropDownList_TPProcedures_FrequencyType.DataBind();
                    DropDownList_TPProcedures_FrequencyType.Items.Insert(0, new ListItem("", "0"));
                }

            }
            BindPrescribedServicesInfo();


            //BindInterventionProvider();
            FrequencyScopeAndDurationActivate();




                DataSet dsCurrent = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();
            var CarePlanPrescribedServicesList = (from p in dsCurrent.Tables["CustomCarePlanPrescribedServices"].AsEnumerable()
                                        where p.Field<string>("RecordDeleted") == (p.Field<string>("RecordDeleted") == null ? null : "N")
                                        select new
                                        {
                                            CarePlanPrescribedServiceId = p.Field<int?>("CarePlanPrescribedServiceId"),
                                            DocumentVersionId = p.Field<int?>("DocumentVersionId"),
                                            ProviderId = p.Field<int?>("ProviderId"),
                                            AuthorizationCodeId = p.Field<int?>("AuthorizationCodeId"),
                                            FromDate = p.Field<DateTime?>("FromDate") == null ? "" : (p.Field<DateTime>("FromDate")).ToString("MM/dd/yyyy"),
                                            ToDate = p.Field<DateTime?>("FromDate") == null ? "" : (p.Field<DateTime>("ToDate")).ToString("MM/dd/yyyy"),
                                            Units = p.Field<decimal?>("Units"),
                                            Frequency = p.Field<int?>("Frequency"),
                                            PersonResponsible = p.Field<int?>("PersonResponsible"),

                                            //ExternalProviderFacilityName = p.Field<string>("ExternalProviderFacilityName") == null ? "" : p.Field<string>("ExternalProviderFacilityName"),
                                           
                                            //TreatmentDischargeDate = p.Field<DateTime?>("TreatmentDischargeDate") == null ? "" : (p.Field<DateTime>("TreatmentDischargeDate")).ToString("MM/dd/yyyy"),
                                            CarePlanPrescribedServiceNumber = GetTHCount(),
                                        }).ToList();

            var pjsonSerialiser = new JavaScriptSerializer();
            var pjson = pjsonSerialiser.Serialize(CarePlanPrescribedServicesList);
            JsonCarePlanPrescribedServices = pjson.ToString().Trim();
        }

        public void BindServices()
        {

            DataSet _dsAuthorizationCodes = new DataSet();
            _dsAuthorizationCodes = GetAuthorizationCodeTxPlanMain(Convert.ToInt32(DropDownList_CarePlanPrescribedServices_ProviderId.SelectedValue));

            //DataRow[] drCoreServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Core Services'", "DisplayAs asc");

            if (_dsAuthorizationCodes.Tables.Count > 0 && _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Rows.Count > 0)
            {

                strHtml.Append("<select id=DropDownList_CarePlanPrescribedServices_ServiceProvider class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet();\"  style='height:20px;color: Black;width:180px;' >");

                //strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:20px;color: Black;font-size: 12px;width:180px;'>");


                //For Filling Core Services
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                DataRow[] drCoreServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Core Services'", "DisplayAs asc");
                for (int loopCounter = 0; loopCounter < drCoreServices.Length; loopCounter++)
                {


                    strHtml.Append("<option  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");


                }


                //For Filling Speciality Services
                strHtml.Append("</optgroup>");

                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");

                DataRow[] drSpecialityServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Speciality Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drSpecialityServices.Length; loopCounter++)
                {

                    strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");

                }

                //For Filling Other Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");

                DataRow[] drOtherServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Other Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drOtherServices.Length; loopCounter++)
                {

                    strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");


                }
                strHtml.Append("</optgroup>");

                strHtml.Append("</select>");

                //PanelTxPlanMain.Controls.Add(new LiteralControl(strHtml.ToString()));


            }


        }
        public override void Activate()
        {
            base.Activate();
            CarePlanMergeUnsavedXML();
        }
        public string GetTHCount()
        {
            THCount = THCount + 1;

            return THCount.ToString();
        }
        //public void BindInterventionProvider()
        //{
        
        
        
        //}
        public void CarePlanMergeUnsavedXML()
        {
            DataSet dataSetPageDataSet = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            try
            {
                if (Request.Form["myxmlstring"] != null)
                {
                    string unsavedXML = Convert.ToString(Request.Form["myxmlstring"]);
                    string strxml = unsavedXML.Replace("xmlns=\"\"", "");
                    SHS.BaseLayer.BaseCommonFunctions.MergeXMLInDataSet(ref dataSetPageDataSet, strxml);
                }
            }
            finally
            {
            }
        }

        /////<summary>
        /////<Description>This Function Bind Care Plan Prescribed Services Template with Json</Description>
        /////</summary>
        public void BindPrescribedServicesInfo()
        {
            string ObjectiveNumberStringComma = string.Empty;
            string ObjectiveNumberString = string.Empty;
            string clinetName = string.Empty;
            string documentCodeId = Convert.ToString(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["Documents"].Rows[0]["DocumentCodeId"].ToString());

            DataSet dataSetScreenData = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            List<PrescribedServicesListData> objectListPrescribedServicesListData = null;

            objectListPrescribedServicesListData = new List<PrescribedServicesListData>();
            PrescribedServicesListData objectPrescribedServicesData = new PrescribedServicesListData();

            objectPrescribedServicesData.objectListPrescribedServices = new List<PrescribedServices>();

            DataSet dataSetCarePlan = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
            //EI#677 - Analysis and Resolution to Fix - Exception: "There is no row at position 0" in SmartCare Application
            if (dataSetCarePlan.IsDataTableFound("DocumentCarePlans"))
                clinetName = dataSetCarePlan.Tables["DocumentCarePlans"].Rows[0]["NameInGoalDescriptions"].ToString();

            if (dataSetScreenData.Tables.Contains("CarePlanPrescribedServices"))
            {
                if (BaseCommonFunctions.CheckRowExists(dataSetScreenData.Tables["CarePlanPrescribedServices"], 0))
                {
                    DataRow[] dataRowPrescribedServicesArray = dataSetScreenData.Tables["CarePlanPrescribedServices"].Select("ISNULL(RecordDeleted,'N')<>'Y'", "AuthorizationCodeName");
                    foreach (DataRow dataRowPrescribedServices in dataRowPrescribedServicesArray)
                    {
                        ObjectiveNumberStringComma = string.Empty;
                        PrescribedServices objectPrescribedServices = new PrescribedServices();
                        objectPrescribedServices.objectListEditViewObjectives = new List<EditViewObjectives>();
                        objectPrescribedServices.AuthorizationCodeId = Convert.ToString(dataRowPrescribedServices["AuthorizationCodeId"]);
                        objectPrescribedServices.NumberOfSessions = Convert.ToString(dataRowPrescribedServices["NumberOfSessions"]);
                        objectPrescribedServices.Units = Convert.ToString(dataRowPrescribedServices["Units"]);
                        objectPrescribedServices.Number = Convert.ToString(dataRowPrescribedServices["Number"]);

                        objectPrescribedServices.Duration = (string.IsNullOrEmpty(Convert.ToString(dataRowPrescribedServices["Duration"]))) ? "" : Convert.ToString(dataRowPrescribedServices["Duration"]);

                        objectPrescribedServices.UnitType = (string.IsNullOrEmpty(Convert.ToString(dataRowPrescribedServices["UnitType"]))) ? "" : Convert.ToString(dataRowPrescribedServices["UnitType"]);
                        objectPrescribedServices.FrequencyType = (string.IsNullOrEmpty(Convert.ToString(dataRowPrescribedServices["FrequencyType"]))) ? "" : Convert.ToString(dataRowPrescribedServices["FrequencyType"]);
                        objectPrescribedServices.PersonResponsible = (string.IsNullOrEmpty(Convert.ToString(dataRowPrescribedServices["PersonResponsible"]))) ? "" : Convert.ToString(dataRowPrescribedServices["PersonResponsible"]);
                        objectPrescribedServices.AuthorizationCodeName = Convert.ToString(dataRowPrescribedServices["AuthorizationCodeName"]);
                        objectPrescribedServices.CarePlanPrescribedServiceId = Convert.ToString(dataRowPrescribedServices["CarePlanPrescribedServiceId"]);
                        objectPrescribedServices.IsChecked = Convert.ToString(dataRowPrescribedServices["IsChecked"]);
                        objectPrescribedServices.InterventionDetails = Convert.ToString(dataRowPrescribedServices["InterventionDetails"]);
                        objectPrescribedServices.DocumentCodeId = documentCodeId;

                        if (documentCodeId != "1469")// for MHA assessment
                        {
                            if (dataSetScreenData.Tables.Contains("CarePlanPrescribedServiceObjectives"))
                            {
                                if (SHS.BaseLayer.BaseCommonFunctions.CheckRowExists(dataSetScreenData.Tables["CarePlanPrescribedServiceObjectives"], 0))
                                {
                                    DataView dataRowPrescribedServiceObjectivesArray = new DataView(dataSetScreenData.Tables["CarePlanPrescribedServiceObjectives"]);
                                    dataRowPrescribedServiceObjectivesArray.RowFilter = "CarePlanPrescribedServiceId=" + objectPrescribedServices.CarePlanPrescribedServiceId + "AND ISNULL(RecordDeleted,'N')<>'Y'";
                                    dataRowPrescribedServiceObjectivesArray.Sort = "CarePlanPrescribedServiceId DESC";

                                    string htmlObjectiveSection = string.Empty;
                                    string objectiveDesc = string.Empty;
                                    string ObjectiveNum = string.Empty;

                                    for (int rowCounter = 0; rowCounter < dataRowPrescribedServiceObjectivesArray.Count; rowCounter++)
                                    {
                                        EditViewObjectives objectEditViewObjectives = new EditViewObjectives();

                                        objectiveDesc = Convert.ToString(dataRowPrescribedServiceObjectivesArray[rowCounter]["ObjectiveDescription"]);
                                        string objectiveId = Convert.ToString(dataRowPrescribedServiceObjectivesArray[rowCounter]["CarePlanObjectiveId"]);
                                        DataView dataViewCarePlanObjectives = new DataView(dataSetScreenData.Tables["CarePlanObjectives"]);
                                        dataViewCarePlanObjectives.RowFilter = "CarePlanObjectiveId=" + objectiveId + "AND ISNULL(RecordDeleted,'N')<>'Y'";
                                        if (dataViewCarePlanObjectives.Count > 0)
                                        {
                                            ObjectiveNum = Convert.ToString(dataViewCarePlanObjectives[0]["ObjectiveNumber"]);

                                            if (rowCounter == dataRowPrescribedServiceObjectivesArray.Count - 1)
                                            {
                                                htmlObjectiveSection = ObjectiveNum;
                                            }
                                            else
                                            {
                                                htmlObjectiveSection = ObjectiveNum + ",";
                                            }

                                            htmlObjectiveSection = HttpUtility.HtmlDecode(htmlObjectiveSection);

                                            objectEditViewObjectives.ObjectiveNumber = htmlObjectiveSection;
                                            if (dataViewCarePlanObjectives[0]["CarePlanDomainObjectiveId"] == DBNull.Value || Convert.ToInt32(dataViewCarePlanObjectives[0]["CarePlanDomainObjectiveId"]) == -1)
                                                objectEditViewObjectives.ObjectiveDescription = Convert.ToString(dataViewCarePlanObjectives[0]["AssociatedObjectiveDescription"]);
                                            else if (dataViewCarePlanObjectives[0]["AssociatedObjectiveDescription"] != DBNull.Value)
                                            {
                                                objectEditViewObjectives.ObjectiveDescription = Convert.ToString(dataViewCarePlanObjectives[0]["AssociatedObjectiveDescription"]);
                                            }
                                            else
                                                objectEditViewObjectives.ObjectiveDescription = objectiveDesc;

                                            objectPrescribedServices.objectListEditViewObjectives.Add(objectEditViewObjectives);
                                        }
                                    }

                                }
                            }
                        }
                        objectPrescribedServicesData.objectListPrescribedServices.Add(objectPrescribedServices);
                    }
                }
            }
            objectJavaScriptSerializer = new JavaScriptSerializer();
            string stringPrescribedServicesData = objectJavaScriptSerializer.Serialize(objectPrescribedServicesData);
            HiddenFieldPrescribedServices.Value = stringPrescribedServicesData;
        }


        public DataSet GetAuthorizationCodeTxPlanMain(int SiteID)
        {
            DataSet dataSetAuthorizationCodeTxPlanMain = null;
            try
            {
                DataSet dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                if (dsCurrentScreen == null)
                    dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

                int ClientId = 0;
                int DocumentVersionId = 0;
                if (dsCurrentScreen.IsDataTableFound("Documents"))
                {
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                }
                if (ClientId <= 0)
                    ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                dataSetAuthorizationCodeTxPlanMain = new DataSet();
                System.Data.SqlClient.SqlParameter[] _objectSqlParmeters = new System.Data.SqlClient.SqlParameter[3];
                _objectSqlParmeters[0] = new System.Data.SqlClient.SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new System.Data.SqlClient.SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[2] = new System.Data.SqlClient.SqlParameter("@SiteID", SiteID);
                Microsoft.ApplicationBlocks.Data.SqlHelper.FillDataset(SHS.DataServices.Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCGetTPServiceUMAuthorization", dataSetAuthorizationCodeTxPlanMain, new string[] { "TPServiceAuthorizationCodes" }, _objectSqlParmeters);

            }
            catch
            {

            }
            return dataSetAuthorizationCodeTxPlanMain;
        }





        private void FrequencyScopeAndDurationActivate()
        {

            int authorizationCodeId = 0;
            int siteId = -1;

            int TPInterventionProcedureId = 0;
            try
            {
                int.TryParse(base.GetRequestParameterValue("SiteId"), out siteId);
                int.TryParse(base.GetRequestParameterValue("AuthorizationCodeId"), out authorizationCodeId);
                int.TryParse(base.GetRequestParameterValue("TPProcedureId"), out tpprocedureId);
                int.TryParse(base.GetRequestParameterValue("TPInterventionProcedureId"), out TPInterventionProcedureId);

                #region If the Provider is from Agency Table We should not show the "Required BillingCode" button on the Screen
                if (siteId == -1)
                    HiddenFieldSpecifyBillingCode.Value = "N";
                #endregion

                if (HiddenFieldSpecifyBillingCode.Value != "N")
                {
                   // DataSet ds = GetClinicianMustSpecifyBillingCode(authorizationCodeId);
                    //if (ds != null && ds.Tables["HRMTreatmentPlanSpecifyBillingCode"].Rows.Count > 0)
                    //{
                    //    if (ds.Tables["HRMTreatmentPlanSpecifyBillingCode"].Rows[0]["ClinicianMustSpecifyBillingCode"] != DBNull.Value)
                    //    {
                    //     //   HiddenFieldSpecifyBillingCode.Value = ds.Tables["HRMTreatmentPlanSpecifyBillingCode"].Rows[0]["ClinicianMustSpecifyBillingCode"].ToString();
                    //    }
                    //    else
                    //    {
                    //      //  HiddenFieldSpecifyBillingCode.Value = "Y";
                    //    }
                    //}
                }



               // HiddenFieldTPInterventionProcedureId.Value = TPInterventionProcedureId.ToString();


                //HiddenFieldAuthorizationCodeId.Value = authorizationCodeId.ToString();
                FillDropDown();
                ShowValueInProviderSiteAuthorizationCodeSection(siteId);
                //ShowValueInMessageToUM();
                //ShowValueInAuthorizationSpan();
                ShowValueInAuthCodeSection(authorizationCodeId, siteId, TPInterventionProcedureId, tpprocedureId);
              //  ShowValueInInterventionSection(authorizationCodeId, siteId);
                if (siteId != -1 && siteId != 0)
                {
                 //   ShowBillingCodeDetailRequiredStatus(authorizationCodeId);
                }
                else
                {
                    //TblBtnBillingCode.Attributes.Add("style", "display:none");
                }


                HiddenFieldSiteId.Value = siteId.ToString();
                HiddenFieldAuthorizationCodeId.Value = authorizationCodeId.ToString();
                HiddenFieldTPProcedureId.Value = tpprocedureId.ToString();

                using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
                {
                    if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                    {
                        if (BaseCommonFunctions.CheckRowExists(dataSetTreatmentPlanHRM, "Documents", 0))
                        {
                            if (dataSetTreatmentPlanHRM.Tables["Documents"].Rows[0]["EffectiveDate"] != DBNull.Value)
                            {
                                HiddenField_EffectiveDate.Value = Convert.ToDateTime(dataSetTreatmentPlanHRM.Tables["Documents"].Rows[0]["EffectiveDate"].ToString()).ToString("MM/dd/yyyy");
                            }

                        }

                        /* New code to calculate Previously Requested Units */





                        /* Ends Previously Requested Units */

                    }

                }


                if (tpprocedureId > 0)
                {
                    //Edit Case
                    SetScreenFields(tpprocedureId, authorizationCodeId, siteId);
                    HiddenFieldBillingCodeInfoEntered.Value = "true";
                }
                else
                {

                   // TextBox_TPProcedures_StartDate.Value = HiddenField_EffectiveDate.Value;
                    HiddenFieldBillingCodeInfoEntered.Value = "false";
                }

                GetUnitTypeAndValue(authorizationCodeId);

            }
            finally
            {
                authorizationCodeId = 0;
                siteId = -1;
                tpprocedureId = 0;
            }

        }
        private void SetScreenFields(int tpprocedureId, int authorizationCodeId, int siteId)
        {
            DataRow[] drTPProcedure = null;
            int valLCM = 0;
            int valCCM = 0;
            int dblTotalUnitRequested = 0;
            int prevReq = 0;
            int unitsCalculated = 0;


            using (dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                drTPProcedure = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("TPProcedureId=" + tpprocedureId);

                if (drTPProcedure != null && drTPProcedure.Length > 0)
                {
               //     TextBox_TPProcedures_StartDate.Value = Convert.ToDateTime(drTPProcedure[0]["StartDate"].ToString()).ToString("MM/dd/yyyy");
                  //  TextBox_TPProcedures_EndDate.Value = Convert.ToDateTime(drTPProcedure[0]["EndDate"].ToString()).ToString("MM/dd/yyyy");

                    int unitsCheck = -1;
                    unitsCheck = Convert.ToInt32(drTPProcedure[0]["Units"]);
                    if (unitsCheck > -1)
                    {
                   //     TextBox_TPProcedures_Units.Value = unitsCheck.ToString();
                    }

                    int totalUnitsCheck = -1;
                    totalUnitsCheck = Convert.ToInt32(drTPProcedure[0]["TotalUnits"]);
                    if (totalUnitsCheck > -1)
                    {
                        Label_TPProcedures_TotalUnits.Text = TextBox_TPProcedures_TotalUnits.Value = totalUnitsCheck.ToString();
                    }
                    //TextBox_TPProcedures_Units.Value = drTPProcedure[0]["Units"].ToString();
                    DropDownList_TPProcedures_FrequencyType.SelectedValue = drTPProcedure[0]["FrequencyType"].ToString();
                    //Label_TPProcedures_TotalUnits.Text = TextBox_TPProcedures_TotalUnits.Value = drTPProcedure[0]["TotalUnits"].ToString();

                    //if (Convert.ToString(drTPProcedure[0]["Urgent"]) == "Y")
                    //    CheckBox_TPProcedures_Urgent.Checked = true;
                    //else
                    //    CheckBox_TPProcedures_Urgent.Checked = false;
                    /* Setting Label fields */



                    int.TryParse(Label_TPProcedures_TotalUnits.Text, out unitsCalculated);

                    int.TryParse(Label_TableName_PreviouslyRequested.Text, out prevReq);
                    Label_TableName_TotalRequestedYTD.Text = (unitsCalculated + prevReq).ToString();
                    int.TryParse(Label_TableName_TotalRequestedYTD.Text, out dblTotalUnitRequested);
                    if (Label_LCM.Text.Trim() != "")
                    {
                        int.TryParse(Label_LCM.Text, out valLCM);
                    }

                    if (Label_CCM.Text.Trim() != "")
                    {
                        int.TryParse(Label_CCM.Text, out valCCM);
                    }
                    if (Label_LCM.Text.Trim() != "")
                    {
                        if (dblTotalUnitRequested > valLCM)
                        {
                            Label_LCM_Over.Text = (dblTotalUnitRequested - valLCM).ToString();
                            Label_LCM_Over.Attributes.Add("style", "visibility:visible;");
                        }
                    }

                    if (Label_CCM.Text.Trim() != "")
                    {
                        if (dblTotalUnitRequested > valCCM)
                        {
                            Label_CCM_Over.Text = (dblTotalUnitRequested - valCCM).ToString();
                            Label_CCM_Over.Attributes.Add("style", "visibility:visible");

                        }
                    }



                    /*Setting Message Field */
                    //TextArea_TPGeneral_AuthorizationRequestorComment.Value = dataSetTreatmentPlanHRM.Tables["TPGeneral"].Select("DocumentVersionId=" + drTPProcedure[0]["DocumentVersionId"].ToString())[0]["AuthorizationRequestorComment"].ToString();


                }
            }

        }
        private string UnitCalculation(DateTime startDate, DateTime endDate, string procedureUnits, int frequencyType)
        {

            TimeSpan days;
            int unitDays = 0;
            double unitMonths = 0;
            double unitWeeks = 0;
            double unitQuarter = 0;
            double unitYear = 0;

            string totalUnitRequested = string.Empty;
            try
            {
                //frequencyType = Convert.ToInt32(Request.Form["frequencyType"]);
                //procedureUnits = Request.Form["procedureUnits"];
                //startDate = Convert.ToDateTime(Request.Form["startDate"]);
                //endDate = Convert.ToDateTime(Request.Form["endDate"]);
                days = (endDate - startDate);
                unitDays = Convert.ToInt32(days.TotalDays + 1);
                unitWeeks = Convert.ToInt32(Math.Round(Convert.ToDouble(unitDays) / 7, MidpointRounding.AwayFromZero));

                //unitDays = Convert.ToInt32(days.TotalDays) + 1;
                //unitWeeks = System.Math.Ceiling(Convert.ToDouble(unitDays) / 7);
                //unitYear = (endDate.Year - startDate.Year) + 1;
                unitYear = endDate.Year - startDate.Year;
                unitMonths = Convert.ToInt32(Math.Round(Convert.ToDouble(unitDays) / 30, MidpointRounding.AwayFromZero));
                unitQuarter = Convert.ToInt32(Math.Round(Convert.ToDouble(unitMonths) / 3, MidpointRounding.AwayFromZero));
                /*
                if (unitYear > 1)
                {
                    unitMonths = System.Math.Ceiling(((12 - startDate.Month) + endDate.Month + 1) * (unitYear - 1));
                }
                else
                {
                    unitMonths = (endDate.Month - startDate.Month) + 1;
                }
                 */
                //unitQuarter = System.Math.Ceiling(Convert.ToDouble(unitMonths) / 3);
                if (unitDays != 0)
                {
                    if (frequencyType == 160 && procedureUnits != string.Empty) //for daily
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitDays).ToString();
                    }
                    else if (frequencyType == 161 && procedureUnits != string.Empty) //for 2 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 2)).ToString();
                        // totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 162 && procedureUnits != string.Empty) //for 3 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 3)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 3.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 163 && procedureUnits != string.Empty) //for 4 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 4)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 4.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 164 && procedureUnits != string.Empty) //for 5 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 5)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 5.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 165 && procedureUnits != string.Empty) //for 5 days/week
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) * 6)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 6.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 166 && procedureUnits != string.Empty) //for weekly
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)))).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 167 && procedureUnits != string.Empty) //for every two weeks
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitWeeks * Convert.ToDouble(procedureUnits)) / 2)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 14.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 168 && procedureUnits != string.Empty) //for monthly
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitMonths * Convert.ToDouble(procedureUnits)))).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 30.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 169 && procedureUnits != string.Empty) //for twice a month
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitMonths * Convert.ToDouble(procedureUnits)) * 2)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 7.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 170 && procedureUnits != string.Empty) //for every four weeks
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitWeeks / 4).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 28.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 171 && procedureUnits != string.Empty) //for quarterly
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitQuarter).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 90.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 172 && procedureUnits != string.Empty) //for  twice a quarterly
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitQuarter * 2).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 2.0 / 90.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 173 && procedureUnits != string.Empty) //for  every two month
                    {
                        totalUnitRequested = System.Math.Ceiling(((unitMonths * Convert.ToDouble(procedureUnits)) / 2)).ToString();
                        //totalUnitRequested = Convert.ToInt32(Convert.ToDouble(procedureUnits) * 1.0 / 60.0 * unitDays).ToString();
                    }
                    else if (frequencyType == 174 && procedureUnits != string.Empty) //for  twice a year
                    {
                        //totalUnitRequested = System.Math.Ceiling(((unitYear * Convert.ToDouble(procedureUnits)) * 2)).ToString();
                        //----Modified By:Ashwani K. Angrish on 8 Dec ref#781 on StreamLine Testing
                        //totalUnitRequested = (System.Math.Ceiling(2 * Convert.ToDouble(procedureUnits)) * ((Convert.ToInt32(days.TotalDays) / 365) + 1)).ToString();
                        totalUnitRequested = (System.Math.Ceiling(2 * Convert.ToDouble(procedureUnits)) * unitYear).ToString();
                    }
                    else if (frequencyType == 175 && procedureUnits != string.Empty) //for  once a year
                    {
                        //totalUnitRequested = System.Math.Ceiling(((unitYear * Convert.ToDouble(procedureUnits)))).ToString();
                        //----Modified By:Ashwani K. Angrish on 8 Dec ref#781 on StreamLine Testing
                        //totalUnitRequested = (System.Math.Ceiling(1 * Convert.ToDouble(procedureUnits)) * ((Convert.ToInt32(days.TotalDays) / 365) + 1)).ToString();
                        totalUnitRequested = (System.Math.Ceiling(1 * Convert.ToDouble(procedureUnits)) * unitYear).ToString();
                    }
                    else if (frequencyType == 176 && procedureUnits != string.Empty) //for only  once
                    {
                        totalUnitRequested = procedureUnits;
                    }
                    else if (frequencyType == 177 && procedureUnits != string.Empty)// for Every 3 weeks
                    {
                        totalUnitRequested = System.Math.Ceiling(Convert.ToDouble(procedureUnits) * unitWeeks / 3).ToString();
                    }
                }



                return totalUnitRequested;
            }
            finally
            {

            }
        }
        /// <summary>
        /// <Description>Method is used to fill value in dropdown</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>11th-Nov-2010</CreatedOn>
        /// </summary>
        private void FillDropDown()
        {
            using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPFREQUENCYTYPE", true, "", "", false))
            {
                DropDownList_TPProcedures_FrequencyType.DataTextField = "CodeName";
                DropDownList_TPProcedures_FrequencyType.DataValueField = "GlobalCodeId";
                DropDownList_TPProcedures_FrequencyType.DataSource = DataViewGlobalCodes;
                DropDownList_TPProcedures_FrequencyType.DataBind();
                DropDownList_TPProcedures_FrequencyType.Items.Insert(0, new ListItem("", "0"));
            }
        }


        /// <summary>
        /// <Description>Method is used to Show value in the Provider/Site and AuthorizationCode section</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>11th-Nov-2010</CreatedOn>
        /// </summary>
        /// <param name="siteId"></param>
        private void ShowValueInProviderSiteAuthorizationCodeSection(int siteId)
        {

            SHS.UserBusinessServices.Document objectDocuments = null;
            DataRow[] drcollectionSite = null;
            DataRow[] drcollectionProvider = null;
            int providerId = 0;
            try
            {
                if (siteId == -1) //Case when internal provider is selected
                {
                    objectDocuments = new SHS.UserBusinessServices.Document();
                    //Label_ProviderName.Text = objectDocuments.GetAgencyName();
                    //Label_SiteName.Text = string.Empty;
                }
                else
                {
                    drcollectionSite = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Sites.Select("SiteId=" + siteId);
                    if (drcollectionSite.Length > 0)
                    {
                        int.TryParse(drcollectionSite[0]["ProviderId"].ToString(), out providerId);
                        drcollectionProvider = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers.Select("ProviderId=" + providerId);
                        if (drcollectionProvider.Length > 0)
                        {
                          //  Label_ProviderName.Text = BaseCommonFunctions.TrancateElementText(Convert.ToString(GetProviderName(providerId)), 50);
                        }
                        //Label_SiteName.Text = BaseCommonFunctions.TrancateElementText(Convert.ToString(drcollectionSite[0]["SiteName"]), 50);
                    }

                }
            }
            finally
            {
                objectDocuments = null;
            }



        }




        /// <summary>
        /// <Description>Method is used set the value in the UMMessageArea</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>11th-Nov-2010</CreatedOn>
        /// </summary>
   

        /// <summary>
        /// <Description>Method is used to calculate the value of TxExpire Date on the basis of DocumentEffective Date</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>27th-Nov-2010</CreatedOn>
        /// </summary>
  



        /// <summary>
        /// <Description>Method is used to Create the Intervention control</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>27th-Nov-2010</CreatedOn>
        /// </summary>
        private void ShowValueInInterventionSection(int authorizationCodeId, int siteId)
        {
            StringBuilder stringBuilderHTML = null;
            string filterStringCriteria = string.Empty;
            int tpprocedureId = 0;
            int.TryParse(base.GetRequestParameterValue("TPProcedureId"), out tpprocedureId);
            DataRow[] dataRowTPInterventionProcedures = null;
            try
            {
                using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
                {
                    if (siteId == -1)
                    {

                        if (tpprocedureId == 0)
                        {
                            filterStringCriteria = "AuthorizationCodeId=" + authorizationCodeId + " and  Isnull(RecordDeleted,'N')<>'Y' and TPInterventionProcedureId=" + HiddenFieldTPInterventionProcedureId.Value;
                        }
                        else
                        {
                            filterStringCriteria = "AuthorizationCodeId=" + authorizationCodeId + " and  Isnull(RecordDeleted,'N')<>'Y' and TPProcedureId=" + tpprocedureId;
                        }
                        //and TPInterventionProcedureId=" + HiddenFieldTPInterventionProcedureId.Value;
                    }
                    else
                    {
                        if (tpprocedureId == 0)
                        {
                            filterStringCriteria = "AuthorizationCodeId=" + authorizationCodeId + " and SiteId=" + siteId + " and  Isnull(RecordDeleted,'N')<>'Y' and TPInterventionProcedureId=" + HiddenFieldTPInterventionProcedureId.Value;
                        }
                        else
                        {
                            filterStringCriteria = "AuthorizationCodeId=" + authorizationCodeId + " and SiteId=" + siteId + " and  Isnull(RecordDeleted,'N')<>'Y' and TPProcedureId=" + tpprocedureId;
                        }
                        //and TPInterventionProcedureId=" + HiddenFieldTPInterventionProcedureId.Value;
                    }

                    dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select(filterStringCriteria);

                    stringBuilderHTML = new StringBuilder();
                    stringBuilderHTML.Append("<table id=TPAssociatedObjective width='99%' border='0' cellspacing='0' cellpadding='0'>");
                    stringBuilderHTML.Append("<tr><td colspan=2 class='height2'></td></tr>");

                    for (int interventionCount = 0; interventionCount < dataRowTPInterventionProcedures.Length; interventionCount++)
                    {
                        DataRow dataRowCurrent = dataRowTPInterventionProcedures[interventionCount];
                        stringBuilderHTML.Append("<tr>");
                        stringBuilderHTML.Append("<td valign='top'>");
                        stringBuilderHTML.Append("<td valign='top' width='3%' class='form_label'>" + dataRowCurrent["InterventionNumber"] + "</td>");
                        stringBuilderHTML.Append("<td valign='top' style='width:95%'>");
                        stringBuilderHTML.Append("<textarea name=TextArea_TPInterventionProcedures_InterventionText_" + dataRowCurrent["TPInterventionProcedureId"].ToString() + "  id=TextArea_TPInterventionProcedures_InterventionText_" + dataRowCurrent["TPInterventionProcedureId"].ToString() + " rows='4' cols='20' style='width:96%' readonly='readonly' class='form_textarea'>");
                        if (dataRowCurrent["InterventionText"] != DBNull.Value)
                        {
                            stringBuilderHTML.Append(dataRowCurrent["InterventionText"].ToString() + "</textarea>");
                        }
                        else
                        {
                            stringBuilderHTML.Append("&nbsp;</textarea>");
                        }


                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");
                        stringBuilderHTML.Append("<tr><td style='width:5px'>&nbsp;</td></tr>");
                        stringBuilderHTML.Append("<td colSpan=2>");
                        stringBuilderHTML.Append("<hr style='color:#FFFFFF;height:1px;'/>");
                        stringBuilderHTML.Append("</td>");
                        stringBuilderHTML.Append("</tr>");

                    }
                    //Add space between 2 rows
                    stringBuilderHTML.Append("<tr><td colspan=2 class='height2'></td></tr>");
                    stringBuilderHTML.Append("</table>");
                //    PanelAssociatedIntervention.ScrollBars = ScrollBars.Vertical;
                  //  PanelAssociatedIntervention.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                }
            }
            finally
            {
                stringBuilderHTML = null;
                filterStringCriteria = string.Empty;
                dataRowTPInterventionProcedures = null;
            }

        }


        /// <summary>
        /// <Description>Method is used to Set value the Intervention control</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>27th-Nov-2010</CreatedOn>
        /// </summary>
        private void ShowValueInAuthCodeSection(int authorizationCodeId, int siteId, int TPInterventionProcedureId, int tpprocedureId)
        {
            SHS.UserBusinessServices.TreatmentPlan objectTreatmentPlan = null;
            DataRow[] drAuthCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("ISNULL(RecordDeleted,'N')<>'Y' and AuthorizationCodeId=" + authorizationCodeId);
            int UMCodeId = 0;
            try
            {
                objectTreatmentPlan = new SHS.UserBusinessServices.TreatmentPlan();
                DataSet dataSetLCMAndCCM = GetLCMAndCCM(authorizationCodeId);
                if (dataSetLCMAndCCM != null)
                {
                    if (dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows.Count > 0)
                    {
                        Label_UMCode.Text = BaseCommonFunctions.TrancateElementText(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CodeName"].ToString(), 20);
                        Label_ServiceCategory.Text = BaseCommonFunctions.TrancateElementText(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["ServiceCategoryName"].ToString(), 20);
                        //Label_LCM.Text = Math.Abs(Convert.ToDouble(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["LCM12MonthMax"].ToString())).ToString();
                        Label_LCM.Text = Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["LCM12MonthMax"]);
                        //Label_CCM.Text = Math.Abs(Convert.ToDouble(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CCM12MonthMax"].ToString())).ToString();
                        Label_CCM.Text = Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["CCM12MonthMax"]);
                        //Below code added by Rakesh to get UMCodeID and passed UMCodeId in CalculatePreviousRequested  instead of passing dataSetLCMAndCCM
                        int.TryParse(Convert.ToString(dataSetLCMAndCCM.Tables["LCMAndCCM"].Rows[0]["UMCodeId"]), out UMCodeId);
                        CalculatePreviousRequested(siteId, authorizationCodeId, TPInterventionProcedureId, UMCodeId, tpprocedureId);
                    }
                    else
                    {
                        trHead_1.Attributes.Add("style", "display:none");
                        trHead_2.Attributes.Add("style", "display:none");
                        trHead_3.Attributes.Add("style", "display:none");
                        //trHead_2.Visible = false;
                        //trHead_3.Visible = false;
                     //   PanelAssociatedIntervention.Height = Unit.Pixel(200);
                    }
                }

                if (drAuthCode != null && drAuthCode.Length > 0)
                {
                   //  Label_AuthorizationCode.Text = BaseCommonFunctions.TrancateElementText(drAuthCode[0]["DisplayAs"].ToString(), 30);
                }
            }
            finally
            {
                objectTreatmentPlan = null;
            }

        }



        /// <summary>
        /// <Description>Method is used to Set Visible/Hide status of Button</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>29th-Nov-2010</CreatedOn>
        /// </summary>
        /// <param name="auhoirzationCodeId"></param>
        

        /// <summary>
        /// <Description>Method is used to Calculate Previous Requested Units</Description>
        /// <Author>Maninder</Author>
        /// <CreatedOn>21-April-2011</CreatedOn>
        /// </summary>
        /// <param name="siteId"></param>
        /// <param name="authorizationCodeId"></param>    
        /// <param name="TPInterventionProcedureId"></param>
        /// <param name="dsUMCode"></param>
        private void CalculatePreviousRequested(int siteId, int authorizationCodeId, int TPInterventionProcedureId, int UMCodeId, int tpprocedureId)
        {
            using (DataSet dataSetTreatmentPlanHRM = BaseCommonFunctions.GetScreenInfoDataSet())
            {
                int sumPrev = 0;
                //int UMCodeId = 0; --commented by Rakesh wrf to task 269 in Phase II bugs/Features

                DataRow[] drTPInterventions = null;
                if (siteId != -1)
                {
                    // Modified by Saurav Pande on 11th June 2012 with ref. to task# 55 in Summit Pointe/ARRA 3.0 in PhaseII, added Isnull(RecordDeleted,'N')
                    //drTPInterventions = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("SiteId=" + siteId + " and (Units is not null)  and Isnull(InitializedFromPreviousPlan,'N') <> 'Y' and TPInterventionProcedureId<>" + TPInterventionProcedureId + " and AuthorizationCodeId=" + authorizationCodeId + "and Isnull(RecordDeleted,'N') <> 'Y' and TPProcedureId <>" + tpprocedureId);

                    //Modified by Rohith on  05 Sep 2013 wrt task #192 in Summit 3.5 Implementation
                    drTPInterventions = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("AuthorizationCodeId=" + authorizationCodeId + " and  SiteId=" + siteId);
                }
                else
                {
                    // Modified by Saurav Pande on 11th June 2012 with ref. to task# 55 in Summit Pointe/ARRA 3.0 in PhaseII, added Isnull(RecordDeleted,'N')
                    //drTPInterventions = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("(Units is not null) and Isnull(InitializedFromPreviousPlan,'N') <> 'Y'  and TPInterventionProcedureId<>" + TPInterventionProcedureId + " and AuthorizationCodeId=" + authorizationCodeId + " and (SiteId is null or SiteId=-1)" + "and Isnull(RecordDeleted,'N') <> 'Y' and TPProcedureId <>" + tpprocedureId);

                    //Modified by Rohith on  05 Sep 2013 wrt task #192 in Summit 3.5 Implementation
                    drTPInterventions = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("AuthorizationCodeId=" + authorizationCodeId + " and  ((SiteId is null or SiteId = -1) or (SiteId=" + siteId + "))");
                }

                if (drTPInterventions.Length > 0)
                {


                    foreach (DataRow drTPInt in drTPInterventions)
                    {
                        int totalSumInterven = 0;

                        int.TryParse(drTPInt["TotalUnits"].ToString(), out totalSumInterven);

                        sumPrev += totalSumInterven;


                    }

                }

                //Below coded commented by Rakesh to show previously requested unites with ref to task 269 in SC web phase II bugs/Features requency Scope and Durtation: Calculate Previously Requested correctly
                //if (BaseCommonFunctions.CheckRowExists(dsUMCode, "UMCode",0))
                //{
                //  int.TryParse(Convert.ToString(dsUMCode.Tables["UMCode"].Rows[0]["UMCodeId"]),out UMCodeId);           
                //}
                //Changes end here

                if (BaseCommonFunctions.CheckRowExists(dataSetTreatmentPlanHRM, "PreviouslyRequested"))
                {
                    DataRow[] dr = dataSetTreatmentPlanHRM.Tables["PreviouslyRequested"].Select("UMCodeId=" + UMCodeId);
                    if (dr.Length > 0)
                    {
                        sumPrev += Convert.ToInt32(dr[0]["TotalRequested"]);
                    }

                }
                Label_TableName_PreviouslyRequested.Text = sumPrev.ToString();
                //Below coded added by Rakesh to show previously requested unites with ref to task 269 in SC web phase II bugs/Features requency Scope and Durtation: Calculate Previously Requested correctly
                if (sumPrev > 0)
                {
                    int unitsCalculated = 0;
                    trHead_1.Attributes.Add("style", "display:block");
                    trHead_2.Attributes.Add("style", "display:block");
                    int.TryParse(Label_TPProcedures_TotalUnits.Text, out unitsCalculated);
                    Label_TableName_TotalRequestedYTD.Text = (unitsCalculated + sumPrev).ToString();
                    if (string.IsNullOrEmpty(Label_UMCode.Text.Trim()) && string.IsNullOrEmpty(Label_ServiceCategory.Text.Trim()))
                    {
                        Label_UMCode.Text = "No Caps Informations exsits.";
                    }
                }
                //Changes end here
            }
        }

        /// <summary>
        /// <Description>Method is used to get the UnitType and Its numeric value.</Description>
        /// <Author>Saurav Pande</Author>
        /// <CreatedOn>9th-Feb-2012</CreatedOn>
        /// </summary>
        /// 
        public void GetUnitTypeAndValue(int AuthorizationCodeId)
        {
            //Changes Made by Saurav Pande on 16th June 2012 with ref to task 1592 in KalamazooBugs-Go Live

            //using (SHS.UserBusinessServices.TreatmentPlan objectGetUnitTypeAndValue = new SHS.UserBusinessServices.TreatmentPlan())
            //{
            //    DataSet dataSetUnitTypeAndValue = objectGetUnitTypeAndValue.GetUnitTypeAndValue(AuthorizationCodeId);
            //    //Added "UnitValue" DBNull check by Varinder on Feb 23,2012 as per task #373 of "Kalamazoo-Bugs' Ace project
            //    if (dataSetUnitTypeAndValue.Tables["Table"].Rows[0]["UnitType"] != DBNull.Value && dataSetUnitTypeAndValue.Tables["Table"].Rows[0]["UnitValue"] != DBNull.Value)
            //            {
            //                var unitVal = dataSetUnitTypeAndValue.Tables["Table"].Rows[0]["UnitValue"].ToString();
            //                Label_UnitValue.Text = Convert.ToString(Math.Floor(Convert.ToDecimal(unitVal)));
            //                Label_UnitType.Text = dataSetUnitTypeAndValue.Tables["Table"].Rows[0]["UnitType"].ToString();
            //            }

            //}

            decimal units = 0;
            int unitType = 0;

            if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes != null && SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Rows.Count > 0)
            {
                DataRow[] drAuthorizationCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("AuthorizationCodeId=" + AuthorizationCodeId);
                if (drAuthorizationCode.Length > 0)
                {
                    int.TryParse(Convert.ToString(drAuthorizationCode[0]["UnitType"]), out unitType);
                    decimal.TryParse(Convert.ToString(drAuthorizationCode[0]["Units"]), out units);

                    DataRow[] drGlobalCode = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitType);
                    Label_UnitValue.Text = Convert.ToString(Math.Floor(Convert.ToDecimal(units)));
                    if (drGlobalCode.Length > 0)
                        Label_UnitType.Text = Convert.ToString(drGlobalCode[0]["CodeName"]);
                }

            }

            //Changes End Here
        }

        #region ClinicianMustSpecifyBillingCode
        //public DataSet GetClinicianMustSpecifyBillingCode(int authorizationCodeId)
        //{
        //    SqlParameter[] _objectSqlParmeters = null;
        //    DataSet UpdateType = null;
        //    try
        //    {
        //        UpdateType = new DataSet();
        //        _objectSqlParmeters = new SqlParameter[1];
        //        _objectSqlParmeters[0] = new SqlParameter("@AuthorizationCodeId", authorizationCodeId);
        //        SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "csp_HRMTreatmentPlanSpecifyBillingCode", UpdateType, new string[] { "HRMTreatmentPlanSpecifyBillingCode" }, _objectSqlParmeters);
        //        return UpdateType;
        //    }
        //    finally
        //    {
        //        if (UpdateType != null)
        //        {
        //            UpdateType.Dispose();
        //        }
        //    }
        //}
        #endregion

        public string GetProviderName(int ProviderId)
        {
            DataSet dataSetProviderName = new DataSet();
            SqlParameter[] _objectSqlParmeters = null;
            try
            {
                _objectSqlParmeters = new SqlParameter[1];
                _objectSqlParmeters[0] = new SqlParameter("@ProviderId", ProviderId);
                SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCGetprovidername", dataSetProviderName, new string[] { "ProviderName" }, _objectSqlParmeters);
                if (dataSetProviderName != null && dataSetProviderName.Tables["ProviderName"].Rows.Count > 0)
                {
                    dataSetProviderName.Tables[0].TableName = "ProviderName";
                    if (dataSetProviderName.Tables["ProviderName"].Rows.Count > 0)
                    {
                        return dataSetProviderName.Tables["ProviderName"].Rows[0][0].ToString();
                    }
                    else { return string.Empty; }
                }
                else { return string.Empty; }
            }
            finally
            {
                dataSetProviderName = null;
            }

        }

        public DataSet GetLCMAndCCM(int AuthorizationCodeId)
        {
            DataSet DataSetLCMAndCCM = null;
            SqlParameter[] _objectSqlParmeters = new SqlParameter[2];
            try
            {
                DataSet dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                if (dsCurrentScreen == null)
                    dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

                int ClientId = 0;
                int DocumentVersionId = 0;
                if (dsCurrentScreen.IsDataTableFound("Documents"))
                {
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                }
                if (ClientId <= 0)
                    ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                DataSetLCMAndCCM = new DataSet();
                _objectSqlParmeters = new SqlParameter[3];
                _objectSqlParmeters[0] = new SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[2] = new SqlParameter("@AuthorizationCodeId", AuthorizationCodeId);
                SqlHelper.FillDataset(Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCWebGetLCMAndCCM", DataSetLCMAndCCM, new string[] { "LCMAndCCM" }, _objectSqlParmeters);
                return DataSetLCMAndCCM;
            }
            finally
            {
                if (DataSetLCMAndCCM != null)
                    DataSetLCMAndCCM.Dispose();
                _objectSqlParmeters = null;
            }

        }







    }
}
