﻿//Purpose : To fill goals/objectives tab data on tab clcik
var goalIdToWhichAdObjective = "";


function FillGoalObjectivesTabTemplate(action) {
    var GoalsJsonData = "";
    var GoalsJsonSerializedData = "";
    $("#Span_CarePlanGoals_RenumberGoal").attr("disabled", "disabled");
    GoalsJsonData = $('[id$=HiddenField_GoalObjectivesJSONData]').val();
    GoalsJsonSerializedData = eval('(' + GoalsJsonData + ')');
    if (GoalsJsonData.length > 0) {
        $("#DivGoalContentMain").html('');
        $("#GoalTemplate").tmpl(GoalsJsonSerializedData.objectListGoals).appendTo("#DivGoalContentMain");

        BindMonitoredBy(GoalsJsonSerializedData);

        jQuery.each(GoalsJsonSerializedData.objectListGoals, function (i, val) {
            jQuery.each(val.objectListObjectives, function (i, oval) {
                if (oval.CarePlanDomainObjectiveId != '') {
                    $("#OutcomesContainer_" + oval.CarePlanDomainObjectiveId).append($('#OutcomesHTML').render(oval))
                }
            });
        });

        //Disable Renumber Goals Link if No Goal is there in Care Plan
        if (GoalsJsonSerializedData.objectListGoals.length > 1) {
            $("#Span_CarePlanGoals_RenumberGoal").removeAttr("disabled", "disabled");
        }
        else {
            $("#Span_CarePlanGoals_RenumberGoal").attr("disabled", "disabled");
        }
    }
    
    SetFocusToGoal(action);
    AttachOnBlurEvents();
    BindScreenLabelsWithControls($("#DivGoalContentMain"));
}

//Purpose : To add a new Goal tab data on tab clcik
function AddNewCarePlanGoal(NewGoalSource, NeedId) {
    var data = 'CustomAction=AddNewCarePlanGoal^NewGoalSource=' + NewGoalSource + "^NeedId=" + NeedId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    OpenPage(5763, GetCurrentScreenID(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
}

function GoalEnddatechage(goal) {
    var SystemKeyValue = $('[id$=HiddenField_ReviewSettngs]').val();
    if (SystemKeyValue == "Y") {
        var enddate = $(goal).val();
        var goalenddate = $(goal)[0].id;
        var nameArray1 = $(goal)[0].id.split("_");
        var goalid = nameArray1[2]
        SetColumnValueInXMLNodeByKeyValue(nameArray1[1], 'CarePlanGoalId', goalid, 'GoalEndDate', enddate, AutoSaveXMLDom[0]);
    }
}

//Purpose : To refresh Goal/objectives tab data on adding a new goal
function RefreshGoalObjectivesTemplate(response, CustomAjaxRequest) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";

    if (response.indexOf("###StartAddGoal###") >= 0) {
        startIndex = response.indexOf("###StartAddGoal###") + 18;
        endIndex = response.indexOf("###EndAddGoal###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        AppendNewGoal(outputHTML);
        CreateUnsavedInstanceOnDatasetChange();
       
    }
    else if (response.indexOf("###StartAddGoalFromNeedsTab###") >= 0) {
        startIndex = response.indexOf("###StartAddGoalFromNeedsTab###") + 30;
        endIndex = response.indexOf("###EndAddGoalFromNeedsTab###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        var GoalsTempJsonData = "";
        var GoalsTempJsonSerializedData = "";
        GoalsTempJsonData = outputHTML;
        GoalsTempJsonSerializedData = eval('(' + GoalsTempJsonData + ')');
        if (GoalsTempJsonData.length > 0) {
            AppendNewRowTOAutoSaveXML(decodeText(GoalsTempJsonSerializedData.objectListGoals[0].RowXML.toString()));
        }
        CreateUnsavedInstanceOnDatasetChange();
        RaiseGoalsObjectivesTabClick(objectPageResponse.ScreenProperties.GoalId);
    }
    else if (response.indexOf("###StartAddObjective###") >= 0) {
        startIndex = response.indexOf("###StartAddObjective###") + 23;
        endIndex = response.indexOf("###EndAddObjective###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        CreateUnsavedInstanceOnDatasetChange();
        AppendNewObjective(outputHTML);
    }
    else if (response.indexOf("###StartDeleteCarePlanGoalObjective###") >= 0) {
        startIndex = response.indexOf("###StartDeleteCarePlanGoalObjective###") + 38;
        endIndex = response.indexOf("###EndDeleteCarePlanGoalObjective###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        if (outputHTML.indexOf("GoalId=") >= 0) {
            var goalIdToDelete = outputHTML.substr(outputHTML.indexOf("GoalId=") + 7, (outputHTML.indexOf("$$$$")) - (outputHTML.indexOf("GoalId=") + 7));
            //To Renumber Goals when a goal is deleted
            var concatenatedGoalIdGoalNumber = outputHTML.substr(outputHTML.indexOf("$$$$") + 4);
            RemoveDeletedXMLNode("CarePlanGoals", "CarePlanGoalId", goalIdToDelete);
            GetXMLParentNodeByColumnValue("CarePlanObjectives", "CarePlanGoalId", goalIdToDelete, AutoSaveXMLDom).each(function () {
                RemoveDeletedXMLNode("CustomCarePlanPrescribedServiceObjectives", "CarePlanObjectiveId", $(this).find("CarePlanObjectiveId").text());
            });
            RemoveDeletedXMLNode("CarePlanObjectives", "CarePlanGoalId", goalIdToDelete);
            CreateUnsavedInstanceOnDatasetChange();
            $("#TableGoalMain_" + goalIdToDelete).remove();
            if ($("table[id*=TableGoalMain_]", $("#DivGoalContentMain")).length > 1) {
                $("#Span_CarePlanGoals_RenumberGoal").removeAttr("disabled", "disabled");
            }
            else {
                $("#Span_CarePlanGoals_RenumberGoal").attr("disabled", "disabled");
            }
            UpdateGoalsNumberInHTML(concatenatedGoalIdGoalNumber);
        }
        else if (outputHTML.indexOf("ObjectiveId=") >= 0) {
            var goalId = "";

            var objectiveIdToDelete = outputHTML.substr(outputHTML.indexOf("ObjectiveId=") + 12, (outputHTML.indexOf("$$$$")) - (outputHTML.indexOf("ObjectiveId=") + 12));
            //To Renumber Goals when a goal is deleted
            var concatenatedObjIdObjNumber = outputHTML.substr(outputHTML.indexOf("$$$$") + 4);
            //method to remove the deleted node from AutoSaveXML
            RemoveDeletedXMLNode("CarePlanObjectives", "CarePlanObjectiveId", objectiveIdToDelete);
            RemoveDeletedXMLNode("CustomCarePlanPrescribedServiceObjectives", "CarePlanObjectiveId", objectiveIdToDelete);

            var objectDivId = $("table[id=TableObjectivesMain_" + objectiveIdToDelete + "]").closest("div")[0];
            if ($(objectDivId).length > 0) {
                var nameArray = objectDivId.id.split("_");
                goalId = nameArray[nameArray.length - 1];
            }
            //Remove Objective Table
            $("#TableObjectivesMain_" + objectiveIdToDelete).remove();
            if ($(objectDivId).length > 0) {
                if ($("table[id*=TableObjectivesMain_]", objectDivId).length > 1) {
                    $("#Span_CarePlanObjectives_RenumberObjective_" + goalId + "").removeAttr("disabled", "disabled");
                }
                else {
                    $("#Span_CarePlanObjectives_RenumberObjective_" + goalId + "").attr("disabled", "disabled");
                }
            }
            UpdateObjectiveNumbersInHTML(concatenatedObjIdObjNumber);
            CreateUnsavedInstanceOnDatasetChange();
        }
        //Show Error Message in case user can not delete the goal in case only one goal is there in Care Plan
        else if (outputHTML == "Error Occurred") {
            ShowMsgBox('This Goal can not be removed as there is one goal avaliable in Care Plan.', 'Care Plan Alert', MessageBoxButton.OK, MessageBoxIcon.Information);
            return false;
        }

    }
    else if (response.indexOf("###StartPreviousProgressTowardObjective###") >= 0) {
        startIndex = response.indexOf("###StartPreviousProgressTowardObjective###") + 42;
        endIndex = response.indexOf("###EndPreviousProgressTowardObjective###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        if (outputHTML.indexOf("$$$") >= 0) {
            var outputArray = outputHTML.split("$$$");
            if (outputArray.length == 2) {
                var objectiveId = outputArray[0];
                var progressGoalText = outputArray[1];
                SetProgressTowardsObjectiveMouseHoverText(objectiveId, progressGoalText);
            }
        }
    }
    BindScreenLabelsWithControls($("#DivGoalContentMain"));
}

//Purpose : To add new objective for a goal
function AddNewCarePlanObjective(goalId, goalNumber) {
    var data = 'CustomAction=AddNewCarePlanObjective^GoalId=' + goalId + "^GoalNumber=" + goalNumber + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    OpenPage(5763, GetCurrentScreenID(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    goalIdToWhichAdObjective = goalId;
}

//Purpose : Raise Goals/Objective tab click
function RaiseGoalsObjectivesTabClick(GoalIdNumber) {
    var objectGoalIdNumber = GoalIdNumber;
    $('input#HiddenField_GoalIdNumber_Needs').val(objectGoalIdNumber);

    CarePlanTabPageInstance.GetTab(2).SetEnabled(true);
    CarePlanTabPageInstance.SetActiveTab(CarePlanTabPageInstance.tabs[2]);
    CarePlanTabPageInstance.RaiseTabClick(2, onTabSelected);
}


//Description:Open CarePlan Associated Needs with Goals Pop Up
function OpenModelDialogueforAssociatedNeeds(GoalId) {
    var actionName = "associatedneedswithgoals";
    OpenPage(5765, 1081, "PopUpAction=" + actionName + "^GoalId=" + GoalId, null, GetRelativePath(), 'T', "dialogHeight: 430px; dialogWidth: 600px;dialogTitle:Associated Needs");
}
//Description:Open CarePlan  Goal Description with Goals Pop Up
function OpenModelDialogueforGoalDescription(GoalId, AssociatedNeedNames) {
    var actionName = "goalDescription";
    OpenPage(5765, 1081, "PopUpAction=" + actionName + "^GoalId=" + GoalId + "^AssociatedNeedNames=" + AssociatedNeedNames, null, GetRelativePath(), 'T', "dialogHeight: 430px; dialogWidth: 600px;dialogTitle:Goal Description");
}

//Description:Open CarePlan  Objective Description with Goals Pop Up
function OpenModelDialogueforObjectiveDescription(GoalId, ObjectiveId, GoalDescription) {
    var actionName = "objectivedescription";
    var description = GoalDescription.length > 500 ? GoalDescription.substring(0, 500) + '...' : GoalDescription;
    OpenPage(5765, 1081, "PopUpAction=" + actionName + "^GoalId=" + GoalId + "^ObjectiveId=" + ObjectiveId + "^GoalDescription=" + description, null, GetRelativePath(), 'T', "dialogHeight: 430px; dialogWidth: 600px;dialogTitle:Objective Description");
}

//Purpose : Handle onBlur event for controls on change of any value
function AttachOnBlurEvents() {
    $("select,textarea,input[type=text]", $('#DivGoalContentMain')).unbind('change').bind('change', function () { UpdateGoalsObjectiveXML(this) });

    $("input[type=radio]", $('#DivGoalContentMain')).unbind('change').bind('change', function () { UpdateGoalsObjectiveXMLforRadioButtons(this); });
    
}
//function to copy the end date of goal to objectives
function UpdateObjectiveEnddate(goal) {
    var SystemKeyValue = $('[id$=HiddenField_ReviewSettngs]').val();
    if (SystemKeyValue == "Y") {
        var enddate = $(goal).val();
        var goalenddate = $(goal)[0].id;
        var nameArray1 = $(goal)[0].id.split("_");
        var goalid = nameArray1[2]
        var $objEndDate = $('[id$=_ObjectiveEndDate][CarePlanGoalId=' + goalid + ']');
        if ($objEndDate.length > 0) {
            var objEndDateValue = enddate;
            SetColumnValueInXMLNodeByKeyValue(nameArray1[1], 'CarePlanGoalId', goalid, 'GoalEndDate', objEndDateValue, AutoSaveXMLDom[0]);
            $objEndDate.each(function (i, n) {
                $(this).val(objEndDateValue);
                var nameArray = $(this)[0].id.split("_");
                var Objtablename = nameArray[1];
                var objprimaryKeyColumnName = '';
                if (Objtablename.toLowerCase().trim() == "careplanobjectives") {
                    objprimaryKeyColumnName = "CarePlanObjectiveId";
                }
                var objprimaryKey = nameArray[2];
                var objcolumnname = nameArray[nameArray.length - 1];
                SetColumnValueInXMLNodeByKeyValue(Objtablename, objprimaryKeyColumnName, objprimaryKey, objcolumnname, objEndDateValue, AutoSaveXMLDom[0]);
            });
        }
    }
}
//Purpose : Update value in xml
function UpdateGoalsObjectiveXML(ctrl) {
    var nameArray = ctrl.id.split("_");
    var tablename = nameArray[1];
    var primaryKeyColumnName = '';
    if (tablename.toLowerCase().trim() == "careplangoals") {
        primaryKeyColumnName = "CarePlanGoalId";
    }
    else if (tablename.toLowerCase().trim() == "careplanobjectives") {
        primaryKeyColumnName = "CarePlanObjectiveId";
    }
    var primaryKey = nameArray[2];
    var columnname = nameArray[nameArray.length - 1];
    var ctrlValue = GetControlValue(ctrl, undefined);
    //Added by Lakshmi, Pathway - Support Go Live #334
    if (columnname.trim() == 'GoalStartDate' || columnname.trim() == 'GoalEndDate' || columnname.trim() == 'ObjectiveStartDate' || columnname.trim() == 'ObjectiveEndDate') {
        ValidateDate(ctrl);
        ctrlValue = ctrl.value;
    }
    SetColumnValueInXMLNodeByKeyValue(tablename, primaryKeyColumnName, primaryKey, columnname, ctrlValue, AutoSaveXMLDom[0]);
    if (GetAutoSaveEnabled() == "y") {
        CreateUnsavedChangesInstance();
    }
    showHideProgressTowardsObjectives(columnname, ctrlValue, primaryKey, tablename, primaryKeyColumnName, primaryKey);

}

//Purpose : Disable Goal Is NOT Active Radio according to status
function DisableGoalIsNOTActive(ctrlValue, primaryKey) {
    var statusDropdownId = $('select#DropDownList_CarePlanObjectives_' + primaryKey + '_Status').attr('id');
    var parantTRIdStatus = $('select[id$=' + statusDropdownId + ']').closest('tr').attr('id')

    if ($('select[id$=' + statusDropdownId + ']').length > 0) {
        var nameArray = parantTRIdStatus.split("_");
        var GoalId = nameArray[1];
        var GoalIsNOTActiveRadioId = $('input#Radio_CarePlanGoals_N_' + GoalId + '_GoalActive');
        if ($(GoalIsNOTActiveRadioId).length > 0) {

            var isExist = false;
            if ($('table[id$=CarePlanGoals_' + GoalId + ']').length > 0) {

                $('table[id$=CarePlanGoals_' + GoalId + '] select').each(function () {
                    if ($(this).length > 0) {
                        if ($(this).val() == 'A') {
                            isExist = true;
                        }
                    }
                })
            }
            if (isExist == true) {
                $(GoalIsNOTActiveRadioId).attr('disabled', 'disabled');
                $(GoalIsNOTActiveRadioId).removeAttr('checked');
            }
            else {
                $(GoalIsNOTActiveRadioId).removeAttr('disabled');
            }

        }
    }
}

//Purpose : Update value in xml for radio button type controls
function UpdateGoalsObjectiveXMLforRadioButtons(ctrl) {
    var nameArray = ctrl.id.split("_");
    var tablename = nameArray[1];
    var radioValue = nameArray[2];
    var primaryKey = nameArray[3];
    var columnname = nameArray[nameArray.length - 1];
    var primaryKeyColumnName = '';
    if (tablename.toLowerCase().trim() == "careplangoals") {
        primaryKeyColumnName = "CarePlanGoalId";
    }
    else if (tablename.toLowerCase().trim() == "careplanobjectives") {
        primaryKeyColumnName = "CarePlanObjectiveId";
    }
    
    UpdateMonitoredByTypeRadioButton(primaryKey, radioValue);
    var control = $(ctrl);
    var ctrlValue = radioValue;
    SetColumnValueInXMLNodeByKeyValue(tablename, primaryKeyColumnName, primaryKey, columnname, ctrlValue, AutoSaveXMLDom[0]);
    if (columnname == "ProgressTowardsObjective")
        UpdateScoreDetails(tablename, primaryKeyColumnName, primaryKey);
    if (GetAutoSaveEnabled() == "y") {
        CreateUnsavedChangesInstance();
    }
}

//Purpose : Open Renumber Goals popup
function OpenRenumberCarePlanGoalsPopUp(tableName, keyFieldName, goalNumber, goalId) {
    var myDate = new Date();
    OpenPage(5765, 1087, "tableName=" + tableName + "^keyFieldName= " + keyFieldName + "^goalNumber=" + goalNumber + "^GoalId=" + goalId + "^time=" + myDate.getMinutes() + myDate.getSeconds(), null, GetRelativePath(), 'T', "dialogHeight: 580px; dialogWidth: 480px;dialogTitle:");
}

//Purpose : Delete a Care Plan Goal/Objective
function DeleteCarePlanGoalObjective(sourceTable, goalObjectiveId) {
    var data = 'CustomAction=DeleteCarePlanGoalObjective^SourceTableName=' + sourceTable + "^GoalObjectiveId=" + goalObjectiveId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    OpenPage(5763, GetCurrentScreenID(),data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
}


//Purpose : Mouse Over ToolTip For Previous Progress Toward Goal
function GetPreviousProgressTowardGoal(sender, GoalId, DomainGoalId) {
    var data = 'CustomAction=GetPreviousProgressTowardGoal^GoalId=' + GoalId + "^DomainGoalId=" + DomainGoalId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    OpenPage(5763, GetCurrentScreenID(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
}

//Purpose : Fill Objective Status Dropdown Options html at runtime from a drodpown defined in html.
function GetObjectiveStatusDDLOptions(ObjectiveId, Status) {
    $("select[id$=DropDownList_CarePlanObjectives_Status]  option[value='" + Status + "']").attr("selected", "selected");
    return $('select[id$=DropDownList_CarePlanObjectives_Status]').html();
}

//Purpose : Set Cursor, Move Cursor to Desired Goal on Tab Load
function SetFocusToGoal(action) {
    if (action != "update") {
        var goalId = objectPageResponse.ScreenProperties.GoalId;
        var textareaMemberGoalVisionId = 'textarea#Textarea_CarePlanGoals_' + goalId + '_ClientGoal';
        if ($(textareaMemberGoalVisionId).length > 0) {
            scrollToElement(goalId);
            setTimeout(function () { $(textareaMemberGoalVisionId).focus(); }, 0);
        }
    }
    else {
        if ($("textarea[id*=_MemberGoalVision]").length > 0) {
            $("textarea[id*=_MemberGoalVision]")[0].focus();
        }
    }
}

//Purpose :Set Cursor, Fixed position.
function scrollToElement(goalId) {
    var SpanAddObjective = 'Span#Span_AddObjective_' + goalId;
    var scrollTo = $(SpanAddObjective, $('table#CarePlanGoals_' + goalId));
    if (SpanAddObjective.length > 0) {
        var container = $('div#CarePlanTabPageInstance_C2');
        if (container.length > 0) {
            container.scrollTop(
                         scrollTo.offset().top - container.offset().top + container.scrollTop() - 300
                    );
        }
    }
}

//Purpose : Append a new Goal in Jquery Template of Goals
function AppendNewGoal(outputHTML) {
    var GoalsJsonData = "";
    var GoalsJsonSerializedData = "";
    $("#Span_CarePlanGoals_RenumberGoal").attr("disabled", "disabled");
    GoalsJsonData = outputHTML;
    GoalsJsonSerializedData = eval('(' + GoalsJsonData + ')');
    if (GoalsJsonData.length > 0) {
        AppendNewRowTOAutoSaveXML(decodeText(GoalsJsonSerializedData.objectListGoals[0].RowXML));
        $("#GoalTemplate").tmpl(GoalsJsonSerializedData.objectListGoals).appendTo("#DivGoalContentMain");

        BindMonitoredBy(GoalsJsonSerializedData);

        if ($("table[id*=TableGoalMain_]", $("#DivGoalContentMain")).length > 1) {
            $("#Span_CarePlanGoals_RenumberGoal").removeAttr("disabled", "disabled");
        }
        else {
            $("#Span_CarePlanGoals_RenumberGoal").attr("disabled", "disabled");
        }
        ShowHideErrorMessage('', 'false');
    }
    SetFocusToGoal(undefined);
    AttachOnBlurEvents();
}

//Purpose : Append a new Objective in Jquery Template of Objectives
function AppendNewObjective(outputHTML) {
    var GoalsJsonData = "";
    var GoalsJsonSerializedData = "";
    GoalsJsonData = outputHTML;
    GoalsJsonSerializedData = eval('(' + GoalsJsonData + ')');
    var ObjectiveXMLNode = decodeText(GoalsJsonSerializedData.RowXML);
    AppendNewRowTOAutoSaveXML(ObjectiveXMLNode);
    if (GoalsJsonData.length > 0) {
        $("#ObjectiveTemplate").tmpl(GoalsJsonSerializedData).appendTo("#DivGoalObjectiveContainer_" + goalIdToWhichAdObjective);
        var goalId = GoalsJsonSerializedData.CarePlanGoalId;
        if ($("table[id*=TableObjectivesMain_]", $("#DivGoalObjectiveContainer_" + goalId + "")).length > 1) {
            $("#Span_CarePlanObjectives_RenumberObjective_" + goalId + "").removeAttr("disabled", "disabled");
        }
        else {
            $("#Span_CarePlanObjectives_RenumberObjective_" + goalId + "").attr("disabled", "disabled");
        }
    }
    SetFocusToNewObjective();
    AttachOnBlurEvents();
}

//Purpose : Set Field values for goaldescription/objectivedescription/associate needs on popup close
function SetFieldValueInCtrl(response) {
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";
    var splitResponse = "";
    var primaryKey = "";
    var fieldValue = "";
    if (response.indexOf("###StartAssociateNeedPopUp###") >= 0) {
        startIndex = response.indexOf("###StartAssociateNeedPopUp###") + 29;
        endIndex = response.indexOf("###EndAssociateNeedPopUp###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        splitResponse = outputHTML.substr(outputHTML.indexOf("GoalId=") + 7).split("$$$");
        primaryKey = splitResponse[0]
        fieldValue = splitResponse[1];
        var textareaAssociatedNeeds = 'textarea#Textarea_CarePlanGoalNeeds_' + primaryKey + '_AssociatedNeeds';
        $(textareaAssociatedNeeds).val(fieldValue);
    }
    else if (response.indexOf("###StartGoalDescriptionPopUp###") >= 0) {
        startIndex = response.indexOf("###StartGoalDescriptionPopUp###") + 31;
        endIndex = response.indexOf("###EndGoalDescriptionPopUp###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        splitResponse = outputHTML.substr(outputHTML.indexOf("GoalId=") + 7).split("$$$");
        primaryKey = splitResponse[0]
        fieldValue = splitResponse[1];
        var textareaGoalDescription = 'textarea#TextArea_CarePlanGoals_' + primaryKey + '_GoalDescription';
        $(textareaGoalDescription).val(fieldValue);

        if ($('div#DivGoalObjectiveContainer_' + primaryKey).length > 0) {
            $('div#DivGoalObjectiveContainer_' + primaryKey).html('');
        }
    }
    else if (response.indexOf("###StartObjectiveDescriptionPopUp###") >= 0) {
        startIndex = response.indexOf("###StartObjectiveDescriptionPopUp###") + 36;
        endIndex = response.indexOf("###EndObjectiveDescriptionPopUp###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        splitResponse = outputHTML.substr(outputHTML.indexOf("ObjectiveId=") + 12).split("$$$");
        primaryKey = splitResponse[0].split(",")[0];
        fieldValue = splitResponse[1];
        var textareaObjectiveDescription = 'textarea#TextArea_CarePlanObjectives_' + primaryKey + '_ObjectiveDescription';
        $(textareaObjectiveDescription).val(fieldValue);
    }
    CreateUnsavedInstanceOnDatasetChange();
}

//Purpose : Set focus to new added objective
function SetFocusToNewObjective() {
    var objectiveId = objectPageResponse.ScreenProperties.ObjectiveId;
    var textareaStaffSupports = 'textarea#Textarea_CarePlanObjectives_' + objectiveId + '_StaffSupports';
    if ($(textareaStaffSupports).length > 0) {
        $(textareaStaffSupports).focus();
    }
    var SpanAddObjective = 'Span#Span_AddObjective_' + goalIdToWhichAdObjective;
    var scrollTo = $(SpanAddObjective, $('table#CarePlanGoals_' + goalIdToWhichAdObjective));
    if (SpanAddObjective.length > 0) {
        var container = $('div#CarePlanTabPageInstance_C2');
        container.scrollTop(scrollTo.offset().top - container.offset().top + container.scrollTop() - 400);
    }
}

//Purpose : Update Goals/Objectives Renumbering when a goal is deleted
function UpdateGoalsNumberInHTML(concatenatedString) {
    var goalId = "";
    var goalNumber = "";
    var objId = "";
    var objNumber = "";

    if (concatenatedString != null && concatenatedString != undefined && concatenatedString != "") {
        var goalAndObjectiveDataArray = concatenatedString.split("####");
        if (goalAndObjectiveDataArray != null && goalAndObjectiveDataArray != undefined && goalAndObjectiveDataArray != "") {
            var goalDataArray = goalAndObjectiveDataArray[0];
            var objDataArray = goalAndObjectiveDataArray[1];
            if (goalDataArray != null && goalDataArray != undefined && goalDataArray != "") {
                var gaolIdGoalNumberArray = goalDataArray.split("^^^");
                if (gaolIdGoalNumberArray != null && gaolIdGoalNumberArray != undefined && gaolIdGoalNumberArray != "") {
                    for (var counter = 0; counter < gaolIdGoalNumberArray.length; counter++) {
                        var concatString = gaolIdGoalNumberArray[counter].split("-->");
                        if (concatString != null && concatString != undefined && concatString != "") {
                            var goalId = concatString[0];
                            var goalNumber = concatString[1];
                            SetGoalNumber(goalId, goalNumber);
                        }
                    }
                }
            }

            if (objDataArray != null && objDataArray != undefined && objDataArray != "") {
                var objIdObjNumberArray = objDataArray.split("^^^");
                if (objIdObjNumberArray != null && objIdObjNumberArray != undefined && objIdObjNumberArray != "") {
                    for (var counter = 0; counter < objIdObjNumberArray.length; counter++) {
                        var objConcatString = objIdObjNumberArray[counter].split("-->");
                        if (objConcatString != null && objConcatString != undefined && objConcatString != "") {
                            var objId = objConcatString[0];
                            var objNumber = objConcatString[1];
                            SetObjectiveNumber(objId, objNumber);
                        }
                    }
                }
            }

        }
    }
}

//Purpose : Update Goals/Objectives Renumbering when an Objective is deleted
function UpdateObjectiveNumbersInHTML(concatenatedObjIdObjNumber) {
    var objId = "";
    var objNumber = "";

    if (concatenatedObjIdObjNumber != null && concatenatedObjIdObjNumber != undefined && concatenatedObjIdObjNumber != "") {
        var objectiveDataArray = concatenatedObjIdObjNumber.split("^^^");

        if (objectiveDataArray != null && objectiveDataArray != undefined && objectiveDataArray != "") {
            for (var counter = 0; counter < objectiveDataArray.length; counter++) {
                var objConcatString = objectiveDataArray[counter].split("-->");
                if (objConcatString != null && objConcatString != undefined && objConcatString != "") {
                    var objId = objConcatString[0];
                    var objNumber = objConcatString[1];
                    SetObjectiveNumber(objId, objNumber);
                }
            }
        }
    }
}

//Purpose : Update Goal Number in Labels when a goal is deleted
function SetGoalNumber(goalId, goalNumber) {
    SetColumnValueInXMLNodeByKeyValue("CarePlanGoals", "CarePlanGoalId", goalId, "GoalNumber", goalNumber.split("#")[1].trim(), AutoSaveXMLDom);
    $("#Span_CarePlanGoals_" + goalId + "_GoalNumber").each(function () {
        this.innerHTML = goalNumber;
    });
    $("#Span_CarePlanGoals_" + goalId + "_GoalNumberWithDeleteIcon").each(function () {
        this.innerHTML = goalNumber;
    });
    $("#Span_CarePlanGoals_" + goalId + "_GoalNumberWithMonitoredBy").each(function () {
        this.innerHTML = goalNumber;
    });
}

//Purpose : Update Objective Number in Labels when Goal/Objective goal is deleted
function SetObjectiveNumber(objId, objNumber) {
    SetColumnValueInXMLNodeByKeyValue("CarePlanObjectives", "CarePlanObjectiveId", objId, "ObjectiveNumber", objNumber, AutoSaveXMLDom);
    $("#Span_CarePlanObjectives_" + objId).each(function () {
        this.innerHTML = objNumber + ":";
    });
}

//Purpose : Set Mouse Hover text for Progress towards Objective as last signed care plan
function SetProgressTowardsObjectiveMouseHoverText(objectiveId, progressGoalText) {
    $("#Img_CarePlanObjectives_" + objectiveId).attr("title", progressGoalText);
}

function BindMonitoredBy(GoalsJsonSerializedDataObj) {
    var GoalsJsonData = "";
    var GoalsJsonSerializedData = "";

    if (GoalsJsonSerializedDataObj == undefined) {
        GoalsJsonData = $('[id$=HiddenField_GoalObjectivesJSONData]').val();
        GoalsJsonSerializedData = eval('(' + GoalsJsonData + ')');
    }
    else {
        GoalsJsonSerializedData = GoalsJsonSerializedDataObj;
    }
    if ($("select[id$=DropDownList_GoalsProviders]")[0].length <= 1) {
        $('.ProvidorDropdown').hide();
    }
    else {
        $('.ProvidorDropdown').show();
    }
  
    for (var goal = 0; goal < GoalsJsonSerializedData.objectListGoals.length; goal++) {
        var goalObj = GoalsJsonSerializedData.objectListGoals[goal];
        var $drodown = $('#DropdownList_CarePlanGoals_' + goalObj.CarePlanGoalId + '_MonitoredBy');
        if ($drodown.length > 0) {
            $drodown.unbind('mouseover').bind('mouseover', function () {
                BindDropDownOnFocus(this);
            });
        }
    }
 
   
}

function BindDropDownOnFocus(ctrl) {
    if ($(ctrl)[0].options.length <= 1) {
        var nameArray = ctrl.id.split("_");
        var tablename = nameArray[1];
        var FocusedMonitoredBy = "-1";
        var FocusedMonitoredByType = "S";
        var primaryKey = nameArray[nameArray.length - 2];
        var CarePlanGoals = GetAutoSaveXMLDomNode('CarePlanGoals');
        var items = CarePlanGoals.length > 0 ? $(CarePlanGoals).XMLExtract() : [];
        var item = ArrayHelpers.GetItem(items, primaryKey, 'CarePlanGoalId');
        if (item !== null && item !== undefined) {
            FocusedMonitoredBy = item["MonitoredBy"];
            FocusedMonitoredByType = item["MonitoredByType"];
        }
        if (FocusedMonitoredByType == "S") {
            $("select[Id$=DropdownList_CarePlanGoals_" + primaryKey + "_MonitoredBy]").html($("select[id$=DropDownList_GoalsStaff]").html());
            $("select[Id$=DropdownList_CarePlanGoals_" + primaryKey + "_MonitoredBy]").val(FocusedMonitoredBy);
        }
        else if (FocusedMonitoredByType == "P") {
            $("select[Id$=DropdownList_CarePlanGoals_" + primaryKey + "_MonitoredBy]").html($("select[id$=DropDownList_GoalsProviders]").html());
            $("select[Id$=DropdownList_CarePlanGoals_" + primaryKey + "_MonitoredBy]").val(FocusedMonitoredBy);
        }
    }

}
function UpdateMonitoredByTypeRadioButton(primaryKey, radioValue) {
   
    var $ddMonitoredBy = $('#DropdownList_CarePlanGoals_' + primaryKey + '_MonitoredBy');
    if (radioValue == "O") {
        $("#TextBox_CarePlanGoals_" + primaryKey + "_MonitoredByOtherDescription").removeAttr("disabled");        
        if ($ddMonitoredBy.length > 0) {
            $ddMonitoredBy.attr("MonitoredByType", radioValue);
            $ddMonitoredBy.attr('disabled', 'disabled');
        }
    }
    else {
        if (radioValue == "S") {
            if ($ddMonitoredBy.length > 0)
                $ddMonitoredBy.attr("MonitoredByType", radioValue);

            $ddMonitoredBy.html($("select[id$=DropDownList_GoalsStaff]").html());
        }
        else if (radioValue == "P") {
            if ($ddMonitoredBy.length > 0)
                $ddMonitoredBy.attr("MonitoredByType", radioValue);

            $ddMonitoredBy.html($("select[id$=DropDownList_GoalsProviders]").html());
        }

        $ddMonitoredBy.removeAttr('disabled');
        var $otherTextbox = $("#TextBox_CarePlanGoals_" + primaryKey + "_MonitoredByOtherDescription");
        if ($otherTextbox.length > 0) {
            $otherTextbox.attr("disabled", "disabled");
            if ($otherTextbox.val() != "") {
                $otherTextbox.val("");
                UpdateGoalsObjectiveXML($otherTextbox[0]);
            }
        }
    }
}
function showHideProgressTowardsObjectives(columnname, ctrlValue, primaryKey, tablename, primaryKeyColumnName, primaryKey) {
    if (columnname == "ObjectiveEndDate") {
        if (ctrlValue == "") {
            $('input[name=Radio_CarePlanObjectives_' + primaryKey + '_ProgressTowardsObjective]:checked').removeAttr('checked');
            $('#objTableRow_' + primaryKey).hide();
            SetColumnValueInXMLNodeByKeyValue(tablename, primaryKeyColumnName, primaryKey, columnname, ctrlValue, AutoSaveXMLDom[0]);
        }
        else {
            $('#objTableRow_' + primaryKey).show();
        }
    }
    else if (columnname == "GoalEndDate") {
        if (ctrlValue != "") {
            var $objEndDate = $('[id$=_ObjectiveEndDate][CarePlanGoalId=' + primaryKey + ']');
            if ($objEndDate.length > 0) {
                var objEndDateValue = ctrlValue;
                $objEndDate.each(function (i, n) {
                    $(this).val(objEndDateValue);
                    var nameArray = $(this)[0].id.split("_");
                    var Objtablename = nameArray[1];
                    var objprimaryKeyColumnName = '';
                    if (Objtablename.toLowerCase().trim() == "careplanobjectives") {
                        objprimaryKeyColumnName = "CarePlanObjectiveId";
                    }
                    var objprimaryKey = nameArray[2];
                    var objcolumnname = nameArray[nameArray.length - 1];
                    SetColumnValueInXMLNodeByKeyValue(Objtablename, objprimaryKeyColumnName, objprimaryKey, objcolumnname, objEndDateValue, AutoSaveXMLDom[0]);
                    $('#objTableRow_' + objprimaryKey).show();
                });
                
            }
        }
    }
}
//Purpose : Mouse Over ToolTip For Previous Progress Toward Goal
function GetPreviousProgressTowardGoal(sender, CarePlanObjectiveId) {
    var imagetooltip = $("img#" + sender).attr('title');
    if (imagetooltip == '') {
        var data = "CustomAction=GetPreviousProgressTowardGoalProgressReview^CarePlanObjectiveId=" + CarePlanObjectiveId + "^AutoSaveXML=" + encodeText(convert_accented_characters(AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
        OpenPage(5763, GetCurrentScreenID(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    }
}

function UpdateScoreDetails(Objtablename, objprimaryKeyColumnName, objprimaryKey) {
    var objcolumnname = 'ScoreDate';
    var objColumnValue = formatDate(new Date(), 'MM/dd/yyyy');
    SetColumnValueInXMLNodeByKeyValue(Objtablename, objprimaryKeyColumnName, objprimaryKey, objcolumnname, objColumnValue, AutoSaveXMLDom[0]);
}