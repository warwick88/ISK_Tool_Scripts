﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SHS.BaseLayer;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using SHS.DataServices;

namespace SHS.SmartCare
{

    public partial class CarePlanPrescribedServices : SHS.BaseLayer.ActivityPages.DataActivityTab
    {
        SqlParameter[] _objectSqlParmeters = null;
        public void Dispose()
        {
            this.DisposeObject();
        }
        public void DisposeObject()
        {
            _objectSqlParmeters = null;
        }

        //  public string RelativePath;
        string goalNo = "";
        List<InteractionAuthorizationCodesHRMTxPlan> _InteractionAuthorizationCodesHRMTxPlan = new List<InteractionAuthorizationCodesHRMTxPlan>();
        SHS.UserBusinessServices.Document _objectDocuments = null;
        string agencyName = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {

            //    RelativePath = Page.ResolveUrl("~/");	  			
        }
        /// <summary>
        /// <Description></Description>
        /// <Author></Author>
        /// <CreatedOn></CreatedOn>
        /// </summary>
        public override void BindControls()
        {
            _objectDocuments = new SHS.UserBusinessServices.Document();
            agencyName = _objectDocuments.GetAgencyName();
            _objectDocuments = null;
            CreateGoal();
            //HiddenFieldRelativePath.Value = Page.ResolveUrl("~/");
        }

        /// <summary>
        /// <Description>This method is used to Read Data from TPNeeds and Create Goal Section </Description>
        /// <Author>Vikas Vyas</Author>       
        /// <CreatedOn></CreatedOn>
        /// <Modified By >Anuj Tomat</Author>
        /// <Modified On>12 oct,2009</CreatedOn>
        /// </summary>
        private void CreateGoal()
        {
            DataSet dataSetTreatmentPlanHRM = null;
            DataView dataViewTPNeeds = null;
            DataRowView dataRowViewTPNeeds = null;
            StringBuilder stringBuilderHTML = null;
          
            try
            {
                PanelTxPlanMain.Controls.Clear();

                using (dataSetTreatmentPlanHRM = BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet)
                {
                    if (dataSetTreatmentPlanHRM != null && dataSetTreatmentPlanHRM.Tables.Count > 0)
                    {
                        if (dataSetTreatmentPlanHRM.Tables.Contains("CarePlanPrescribedServices") && dataSetTreatmentPlanHRM.Tables["CarePlanPrescribedServices"].Rows.Count > 0)
                        {
                            dataViewTPNeeds = new DataView(dataSetTreatmentPlanHRM.Tables["CarePlanPrescribedServices"]);
                            //Sort On the basis of Need Number because we have show Goal on Number basis
                            dataViewTPNeeds.Sort = "CarePlanPrescribedServiceId";
                            dataViewTPNeeds.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'";
                            //Set Need Count in the hidden field
                            HiddenFiedNeedCount.Value = Convert.ToString(dataViewTPNeeds.Count);
                            //Loop how many rows exists in the TPNeeds table for creating Goal
                            stringBuilderHTML = new StringBuilder();

                            stringBuilderHTML.Append("<table Id='TableHRMTxPlainMain1'  style='width:98%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");

                            for (int needCount = 0; needCount < dataViewTPNeeds.Count; needCount++)
                            {
                                goalNo = dataViewTPNeeds[needCount]["CarePlanPrescribedServiceId"].ToString();
                                dataRowViewTPNeeds = dataViewTPNeeds[needCount]; //Create DataRowView 
                                // ---commented 0n 1 July 2010 by Ashwani
                                //stringBuilderHTML = new StringBuilder();
                                // ---Endcommented 0n 1 July 2010 by Ashwani
                                //Create  table for Goal
                                //NewLy Added on 2 JULY
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td style='width:99%'>");
                                //---END 2 JULY
                                #region Main Table
                                stringBuilderHTML.Append("<table Id=" + goalNo + "  style='width:100%;'  border='0' cellpadding='0' cellspacing='0'  BindAutoSaveEvents ='False'  BindSetFormData='False'>");


                                //Start -- New Code Added By Damanpreet For Create a Section
                                #region First TR of Main Table (start Section)
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table cellspacing='0'  cellpadding='0' border='0' width='100%'>");

                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td align='left' nowrap='nowrap' class='content_tab_left'>");
                                stringBuilderHTML.Append("<span name=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["CarePlanPrescribedServiceId"].ToString() + "  id=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["CarePlanPrescribedServiceId"].ToString() + " style='color:Black;font-size:11px;' BindAutoSaveEvents ='False'  BindSetFormData='False' > Goal # " + dataRowViewTPNeeds["NeedNumber"].ToString() + "</span>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td width='17'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='17' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_sep.gif />");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td width='100%' class='content_tab_top'>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("<td width='7'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='26' width='7' alt='' src=" + RelativePath + "App_Themes/Includes/Images/content_tab_right.gif />");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append(" </tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion First TR Main Table (start Section)
                                //Stop -- New Code Added By Damanpreet For Create a Section

                                //----------Code Added By Damanpreet
                                #region 2 TR for Main Table
                                //stringBuilderHTML.Append("<tr>");
                                //stringBuilderHTML.Append("<td colspan='3' style='height:1px;'>");
                                //stringBuilderHTML.Append("&nbsp;");
                                //stringBuilderHTML.Append("</td>");
                                //stringBuilderHTML.Append("</tr>");
                                #endregion 2 TR for Main Table

                                #region 3 TR for Main Table
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td class='right_contanier_bg'>");

                                #region TabContent Table

                                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%' id=" + goalNo + ">");

                                //--------------End Code Added By Damanpreet---------------



                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td colspan='3'>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");

                                #region 1 TR of TabContent Table
                                stringBuilderHTML.Append("<tr>"); //1st Row Open Tag
                                stringBuilderHTML.Append("<td style='width:3%' valign='top' align='center'>");//1st Row 1st Column Open Tag
                                if (dataRowViewTPNeeds["SourceNeedId"] == DBNull.Value)
                                {
                                    stringBuilderHTML.Append("<img id=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + "  name=Img_TPNeeds_NeedId_" + dataRowViewTPNeeds["NeedId"].ToString() + " src=" + RelativePath + "App_Themes/Includes/Images/deleteIcon.gif  tag=" + dataRowViewTPNeeds["NeedId"].ToString() + "   style='cursor:hand;' onclick = \"DaleteTxPlanGoal('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + dataViewTPNeeds.Count + "');\"/>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("&nbsp;");
                                }
                                stringBuilderHTML.Append("</td>"); //1st Row 1st Column  Close tag

                                stringBuilderHTML.Append("<td style='width:8%' valign='top' align='center' >");//1st Row 2nd Column Open Tag
                                //Assign Goal Text e.g (Goal#1)
                                stringBuilderHTML.Append("<span name=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_TPNeeds_NeedNumber_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='color:Black;font-size:11px;' ParentChildControls='True' > Goal # " + dataRowViewTPNeeds["NeedNumber"].ToString() + "</span>");
                                stringBuilderHTML.Append("</td>"); //1st Row 2nd Column Close Tag


                                stringBuilderHTML.Append("<td align='left'>"); //1st Row 3rd Column Open Tag   
                                // added  style='width:693px;' for task 540
                                // added by nisha
                                stringBuilderHTML.Append("<textarea   onChange = \"ModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalText" + "','" + "TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"  name=TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + " rows='2' cols='138'  class='form_textareaWithoutWidth'  parentchildcontrols='True' spellcheck='True'>");
                                if (dataRowViewTPNeeds["GoalText"] != DBNull.Value)
                                {
                                    stringBuilderHTML.Append(dataRowViewTPNeeds["GoalText"].ToString().Trim() + "</textarea>");
                                }
                                else
                                {
                                    stringBuilderHTML.Append("</textarea>");
                                }
                                stringBuilderHTML.Append("</td>"); //1st Row 3rd Column Close Tag
                                stringBuilderHTML.Append("</tr>");
                                #endregion 1 TR of TabContent Table


                                //To show difference between the two rows
                                #region 2 TR of TabContent Table
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td colspan='3'>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                //Ended Over here
                                #endregion 2 TR of TabContent Table


                               
                      

                             

                          


                          

                             


                           

               

                                PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                #region Objective Section


                                //Find Objective with respect to there NeedId from TPObjective table
                                #region 16 TR of TabContent Table
                                stringBuilderHTML.Append("<tr>"); //8th Row Open Tag
                                stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style='width:8%;'>&nbsp;</td>");

                                stringBuilderHTML.Append("<td>");

                                #region 1subtable 16 TR
                                stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create

                                #region 1 TR of 1subtable 16 TR
                               // CreateObjective(Convert.ToInt32(dataRowViewTPNeeds["NeedId"]), Convert.ToInt32(dataRowViewTPNeeds["NeedNumber"]), ref dataSetTreatmentPlanHRM);
                                #endregion 1 TR of 1subtable 16 TR

                                stringBuilderHTML = new StringBuilder();
                                //#endregion

                                //#region for objective link
                               


                  
                               

                                PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                                #endregion

                                //#region Intervention Section

                                #region 17 TR of TabContent Table
                                stringBuilderHTML.Append("<tr>"); //8th Row Open Tag
                                stringBuilderHTML.Append("<td style=width:3%>&nbsp;</td><td style='width:8%;'>&nbsp;</td>");
                                stringBuilderHTML.Append("<td>");

                                #region 1 SubTable of TR 17
                                stringBuilderHTML.Append("<table border='0' cellpadding='0' style='width:90%'  cellspacing='0' >"); //Create

                                //stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create
                                #region 1 TR of Sub table 1 of Intervention
                                CreateIntervention(Convert.ToInt32(dataRowViewTPNeeds["NeedId"]), Convert.ToInt32(dataRowViewTPNeeds["NeedNumber"]), ref dataSetTreatmentPlanHRM);
                                #endregion 1 TR of Sub table 1 of Intervention

                                stringBuilderHTML = new StringBuilder();

                                #region 2 TR of Sub table 1 of Intervention
                                stringBuilderHTML.Append("<tr id='InterventionRow_" + Convert.ToInt32(dataRowViewTPNeeds["NeedId"]) + "'>");
                                stringBuilderHTML.Append("<td colspan='3' style='height:2px;'>");
                                stringBuilderHTML.Append("&nbsp;");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion 2 TR of Sub table 1 of Intervention


                                #region 3 TR of Sub table 1 of Intervention
                                stringBuilderHTML.Append("<tr>"); //9th Row Open Tag                               
                                stringBuilderHTML.Append("<td align='left' colspan='3'>"); //9th Row 3rd Column Open Tag
                                #region 9th Row 3rd Column
                                stringBuilderHTML.Append("<table cellpadding='0' border='0' style='width:100%' cellspacing='0'>"); //Create

                                //stringBuilderHTML.Append("<table cellpadding='0' border='0' cellspacing='0' width='100%;'>"); //Create
                                stringBuilderHTML.Append("<tr>"); //1st Row Open Tag

                                stringBuilderHTML.Append("<td style='width:30%;' align='center'>"); //1st Row 1st Col Open Tag                              
                                stringBuilderHTML.Append("<span ParentChildControls='True'  name=Span_AddIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_AddIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"AddIntervention('" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Add Intervention</span>"); //Create
                                stringBuilderHTML.Append("</td>"); //1st Row 1st Col Close Tag

                                stringBuilderHTML.Append("<td align='left'>"); //1st Row 2nd Col Open Tag                             
                                DataRow[] dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId='" + dataRowViewTPNeeds["NeedId"].ToString() + "'");

                                if (dataRowTPInterventionProcedures.Length > 0)
                                {
                                    stringBuilderHTML.Append("<span ParentChildControls='True'  name=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenRenumberTxPlan('" + "TPInterventionProcedures" + "','" + "TPInterventionProcedureId" + "','" + dataRowViewTPNeeds["NeedNumber"].ToString() + "','" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Renumber Intervention</span>"); //Create 
                                }
                                else
                                {
                                    stringBuilderHTML.Append("<span ParentChildControls='True'  name=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_RenumberIntervention_" + dataRowViewTPNeeds["NeedId"].ToString() + " style='text-decoration:underline;color:Black;font-size:11px;' disabled='disabled' onclick=\"OpenRenumberTxPlan('" + "TPInterventionProcedures" + "','" + "TPInterventionProcedureId" + "','" + dataRowViewTPNeeds["NeedNumber"].ToString() + "','" + dataRowViewTPNeeds["NeedId"].ToString() + "');\" >Renumber Intervention</span>"); //Create 
                                }

                                stringBuilderHTML.Append("</td>"); //1st Row 2nd Col Close Tag

                                stringBuilderHTML.Append("</tr>"); //1st Row Close Tag
                                stringBuilderHTML.Append("</table>");

                                #endregion
                                stringBuilderHTML.Append("</td>"); //9th Row 3rd Column Close Tag
                                stringBuilderHTML.Append("</tr>");
                                #endregion 3 TR of Sub table 1 of Intervention

                                stringBuilderHTML.Append("</table>");
                                #endregion 1 SubTable of TR 17
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion 17 TR of TabContent Table


                                stringBuilderHTML.Append("</table>");
                                #endregion TabContent Table
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion 3 TR for Main Table

                                #region 4 TR for Main Table
                                stringBuilderHTML.Append("<tr>");
                                stringBuilderHTML.Append("<td>");
                                stringBuilderHTML.Append("<table cellspacing='0' cellpadding='0' border='0' width='100%'>");
                                stringBuilderHTML.Append("<tr>");

                                stringBuilderHTML.Append("<td width='2' class='right_bottom_cont_bottom_bg'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_left.gif /> ");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td width='100%' class='right_bottom_cont_bottom_bg'>");

                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("<td align='right' width='2' class='right_bottom_cont_bottom_bg'>");
                                stringBuilderHTML.Append("<img style='vertical-align: top' height='7'  alt='' src=" + RelativePath + "App_Themes/Includes/Images/right_bottom_cont_bottom_right.gif />");
                                stringBuilderHTML.Append("</td>");

                                stringBuilderHTML.Append("</tr>");
                                stringBuilderHTML.Append("</table>");
                                stringBuilderHTML.Append("</td>");
                                stringBuilderHTML.Append("</tr>");
                                #endregion 4 TR for Main Table

                                stringBuilderHTML.Append("<tr id='MainGoalEnd_" + dataRowViewTPNeeds["NeedId"].ToString() + "'>");
                                stringBuilderHTML.Append("<td style='width:3%;height:3px;' colspan='3'>&nbsp;</td>");
                                //---start 5 March
                                //stringBuilderHTML.Append("</td>");
                                //---End 5 March
                                stringBuilderHTML.Append("</tr>");


                                //----NewLY Commented 2 JULY
                                //stringBuilderHTML.Append("</table>");
                                //----END NewLY Commented 2 JULY
                                #endregion MainTable
                                PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                stringBuilderHTML = new StringBuilder();
                            }

                            //---Commneted By ashwani on 1 july
                            stringBuilderHTML = new StringBuilder();
                            //---End Commneted By ashwani on 1 july



                            stringBuilderHTML.Append("<tr>"); //8th Row Open Tag                           
                            stringBuilderHTML.Append("<td colspan='3' align='left'>");
                            stringBuilderHTML.Append("<table border='0' cellpadding='0' cellspacing='0' width='90%'>"); //Create
                            stringBuilderHTML.Append("<tr>");

                            stringBuilderHTML.Append("<td width='9%' >");
                            stringBuilderHTML.Append("&nbsp;"); //Create
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("<td align='left'  >");
                            stringBuilderHTML.Append("<span   name=Span_AddGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=Span_AddGoal_" + dataRowViewTPNeeds["NeedId"].ToString() + "  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueHRMTPGoal('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Add Goal" + "');\" >Add Goal</span>"); //Create
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            stringBuilderHTML.Append("</table>");
                            dataSetTreatmentPlanHRM.Tables["TpNeeds"].DefaultView.RowFilter = "";
                            PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Exception exx = new Exception();
                string dxml = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.GetXml().ToString();
                exx = new Exception(ex.Message + ex.StackTrace + dxml);
                throw new Exception(ex.Message + ex.StackTrace + dxml, ex.InnerException);
            }
            finally
            {

            }
        }

        /// <summary>
        /// <Description>This method is used to Read Data from TPObjective and Create Objective Section</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>11th-Sept-2009</CreatedOn>
        /// </summary>
        /// <param name="needId"></param>
        /// <param name="goalNumber"></param>
      
        private void CreateIntervention(int needId, int goalNumber, ref DataSet dataSetTreatmentPlanHRM)
        {
            StringBuilder stringBuilderHTML = null;
            DataRow[] dataRowTPInterventionProcedures = null;         
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionFrequency = null;         
            SHS.CustomControl.DropDownListWithTooltip dropdownListinterVentionProvider = null;

        
            DataRow[] dataRowTPInterventionPObjective = null;
            DataRow dataRowTPProcedures = null;
            DataTable dataTableTPObjective = null;
            bool disableProcedureProvider = false;
            //string agencyName = string.Empty;            
            int siteID = -1;
            string documentCodeId = string.Empty;
            string documentStatus = string.Empty;

            //SHS.UserBusinessServices.Document objectDocuments = null;
            try
            {
                if (dataSetTreatmentPlanHRM.Tables.Contains("TPInterventionProcedures")) //Perform Table contain Check
                {
                    //Below If added to get documentCodeId w.rf to task 190 in Sc web phaseII bugs/Features
                    if (BaseCommonFunctions.CheckRowExists(dataSetTreatmentPlanHRM, "Documents", 0))
                    {
                        documentCodeId = Convert.ToString(dataSetTreatmentPlanHRM.Tables["Documents"].Rows[0]["DocumentCodeId"]);
                        documentStatus = Convert.ToString(dataSetTreatmentPlanHRM.Tables["Documents"].Rows[0]["Status"]);
                    }

                    if (dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Rows.Count > 0)
                    {
                        stringBuilderHTML = new StringBuilder();
                        // dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId='" + needId + "'", "InterventionNumber asc");                
                        dataRowTPInterventionProcedures = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].Select("Isnull(RecordDeleted,'N')<>'Y' and NeedId='" + needId + "'");
                        if (dataRowTPInterventionProcedures.Length > 0)
                        {
                            //dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView.Sort = "InterventionNumber";
                            //dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'and NeedId=" + needId;

                            DataView dataViewTPInterventionProcedures = new DataView(dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"]);
                            dataViewTPInterventionProcedures.Sort = "InterventionNumber";

                            dataViewTPInterventionProcedures.RowFilter = "Isnull(RecordDeleted,'N')<>'Y'and NeedId=" + needId;


                            //stringBuilderHTML = new StringBuilder();

                            #region 1 TR CreateIntervention
                            //To show difference between the two rows
                            stringBuilderHTML.Append("<tr>");
                            stringBuilderHTML.Append("<td colspan='3'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            //Ended Over here
                            #endregion 1 TR CreateIntervention


                            #region 2 TR CreateIntervention
                            stringBuilderHTML.Append("<tr>"); //1st Row Open Tag                    
                            stringBuilderHTML.Append("<td colspan='3' align='left'>");//1st Row 3rd Col Open Tag

                            #region 1Subtable of 2TR CreateIntervention
                            stringBuilderHTML.Append("<table style='width:95%;' border='0' cellpadding='0' cellspacing='3' id='InterventionSection_" + needId + "'>");

                            #region 1 TR of 1Subtable of 2TR CreateIntervention
                            //Ist Row
                            stringBuilderHTML.Append("<tr>");
                            //Ist TD
                            stringBuilderHTML.Append("<td style='width:5%;'>");
                            stringBuilderHTML.Append("&nbsp;");
                            stringBuilderHTML.Append("</td>");

                            //II TD
                            stringBuilderHTML.Append("<td style='width:6%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span  name='SpanObjs' id='SpanObjs'>");
                            stringBuilderHTML.Append("Objs");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");

                            //III TD
                            stringBuilderHTML.Append("<td style='width:32%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span name='SpanInterVentionText' id='SpanInterVentionText'>");
                            stringBuilderHTML.Append("Intervention Text");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");

                            //IV TD
                            stringBuilderHTML.Append("<td style='width:22%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span name='SpanProviderService' id='SpanProviderService'>");
                            stringBuilderHTML.Append("Provider/Service");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");

                            //V TD
                            stringBuilderHTML.Append("<td style='width:22%;color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span name='SpanUnitsFrequency' id='SpanUnitsFrequency'>");
                            stringBuilderHTML.Append("Units/Frequency");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");

                            //VI TD
                            stringBuilderHTML.Append("<td style='color:Black;font-size:11px;' align='center'>");
                            stringBuilderHTML.Append("<span  name='SpanFromTo' id='SpanFromTo'>");
                            stringBuilderHTML.Append("From/To");
                            stringBuilderHTML.Append("</span>");
                            stringBuilderHTML.Append("</td>");
                            stringBuilderHTML.Append("</tr>");
                            #endregion 1 TR of 1Subtable of 2TR CreateIntervention
                            if (dataViewTPInterventionProcedures.Count > 0)
                            {
                                for (int interventionCount = 0; interventionCount < dataViewTPInterventionProcedures.Count; interventionCount++)
                                {
                                    #region 2 TR of 1Subtable of 2TR CreateIntervention
                                    stringBuilderHTML.Append("<tr class='TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'>");
                                    stringBuilderHTML.Append("<td colspan='6' align='left' style='padding-left:5px;color:Black;font-size:11px;'>");
                                    stringBuilderHTML.Append("<span   id=Span_TPInterventionProcedures_InterventionNumber_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ">");
                                    stringBuilderHTML.Append("Intervention " + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InterventionNumber"]));
                                    stringBuilderHTML.Append("</span>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    #endregion 2 TR of 1Subtable of 2TR CreateIntervention

                                    #region 3 TR of 1Subtable of 2TR CreateIntervention
                                    stringBuilderHTML.Append("<tr class='TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'>");

                                    //Ist TD
                                    #region 1 TD of 3 TR of 1 subTable
                                    stringBuilderHTML.Append("<td style='width:5%;color:Black;font-size:11px;' valign='top'>");

                                    //Logic for Deletion of Intervention 
                                    //If Procedure is associated and the below give written logic pass the criteria the deletion can possible
                                    if (dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"] != DBNull.Value)
                                    {
                                        DataRow[] dataRowTPProcedure = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("TPProcedureId=" + dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]);
                                        if (dataRowTPProcedure.Length > 0)
                                        {
                                            //Changed by anuj as documentid not exist in new database 3.1Dev databse
                                            //if (Convert.ToInt32(dataRowTPProcedure[0]["DocumentId"]) == BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentId && dataRowTPProcedure[0]["SourceDocumentId"] == System.DBNull.Value)
                                            //Changes ended over here
                                            if (Convert.ToInt32(dataRowTPProcedure[0]["DocumentVersionId"]) == Convert.ToInt32(BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet.Tables["DocumentVersions"].Rows[0]["DocumentVersionId"]) && dataRowTPProcedure[0]["SourceDocumentId"] == System.DBNull.Value)
                                            {
                                                stringBuilderHTML.Append("<img style='cursor:hand;' id='ImgDelete'    name='ImgDelete' src=" + RelativePath + "App_Themes/Includes/Images/deleteIcon.gif  onClick= \"DeleteIntervention('" + needId + "','" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','" + "false" + "');\" />");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<img style='cursor:hand;' id='ImgDelete'    name='ImgDelete' src=" + RelativePath + "App_Themes/Includes/Images/deleteIcon.gif  onClick= \"DeleteIntervention('" + needId + "','" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','" + "true" + "');\" />");
                                    }
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 1 TD of 3 TR of 1 subTable


                                    //II TD
                                    #region 2 TD of 3 TR of 1 subTable
                                    stringBuilderHTML.Append("<td style='width:8%;' valign='top'>");
                                    stringBuilderHTML.Append("<div id=div_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:100%;'>");
                                    //stringBuilderHTML.Append("<select class='form_textarea'  multiple='multiple' size='2' style='width:100%;'>");
                                    stringBuilderHTML.Append("<select class='form_textarea' multiple='multiple' size='2' style='height: 45px;'>");
                                    dataRowTPProcedures = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Rows.Find(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]);
                                    if (dataRowTPProcedures != null)
                                    {
                                        if (dataRowTPProcedures["SourceDocumentId"] != System.DBNull.Value)
                                        {
                                            //Commented By Anuj as DocumentId Not Exist in New DataBase 3.1Dev
                                            //if (Convert.ToInt32(dataRowTPProcedures["SourceDocumentId"].ToString()) != Convert.ToInt32(dataRowTPProcedures["DocumentId"]))
                                            //Changes Ended Over Here
                                            if (Convert.ToInt32(dataRowTPProcedures["SourceDocumentId"].ToString()) != Convert.ToInt32(dataRowTPProcedures["DocumentVersionId"]))
                                            {
                                                disableProcedureProvider = true;
                                            }
                                        }
                                    }
                                    #region TPIntervention Procedure

                                    dataRowTPInterventionPObjective = dataSetTreatmentPlanHRM.Tables["TPInterventionProcedureObjectives"].Select("Isnull(RecordDeleted,'N')<>'Y' and TPInterventionProcedureId=" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]));
                                    if (dataRowTPInterventionPObjective.Length > 0)
                                    {
                                        dataTableTPObjective = new DataTable("TPObjective");
                                        dataTableTPObjective.Columns.Add("ObjectiveId", typeof(int));
                                        dataTableTPObjective.Columns.Add("ObjectiveNumber", typeof(float));
                                        foreach (DataRow drTPInterventionObjective in dataRowTPInterventionPObjective)
                                        {
                                            DataRow[] dataRowTPObjective = dataSetTreatmentPlanHRM.Tables["TPObjectives"].Select("ObjectiveId=" + Convert.ToInt32(drTPInterventionObjective["ObjectiveId"]) + " and IsNull(RecordDeleted,'N')<>'Y'");
                                            if (dataRowTPObjective.Length > 0)
                                            {
                                                DataRow dRowTPObjective = dataTableTPObjective.NewRow();
                                                dRowTPObjective["ObjectiveId"] = Convert.ToInt32(dataRowTPObjective[0]["ObjectiveId"]);
                                                dRowTPObjective["ObjectiveNumber"] = Convert.ToSingle(dataRowTPObjective[0]["ObjectiveNumber"]);

                                                dataTableTPObjective.Rows.Add(dRowTPObjective);

                                            }
                                        }
                                        for (int objectiveNumber = 0; objectiveNumber < dataTableTPObjective.Rows.Count; objectiveNumber++)
                                        {
                                            stringBuilderHTML.Append("<option value= " + dataTableTPObjective.Rows[objectiveNumber]["ObjectiveId"].ToString() + ">");
                                            stringBuilderHTML.Append(dataTableTPObjective.Rows[objectiveNumber]["ObjectiveNumber"].ToString() + "</option>");
                                        }
                                    }
                                    #endregion

                                    stringBuilderHTML.Append("</select>");
                                    stringBuilderHTML.Append("</div>");
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 2 TD of 3 TR of 1 subTable


                                    //III TD
                                    #region 3 TD of 3 TR of 1 subTable
                                    stringBuilderHTML.Append("<td style='width:22%;' valign='top' >");
                                    //

                                    stringBuilderHTML.Append("<textarea spellcheck='True' class='form_textareaWithoutWidth'  BindAutoSaveEvents ='False'  BindSetFormData='False' name=TextArea_TPInterventionProcedures_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " id=TextArea_TPInterventionProcedures_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " rows='3' cols='40' onChange= \"ModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "InterventionText" + "','" + " TextArea_TPInterventionProcedures_InterventionText_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "');\" >"); //Create                        
                                    if (dataViewTPInterventionProcedures[interventionCount]["InterventionText"] != DBNull.Value)
                                    {
                                        stringBuilderHTML.Append(Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InterventionText"]));
                                    }
                                    stringBuilderHTML.Append("</textarea>");
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 3 TD of 3 TR of 1 subTable

                                    //IV TD
                                    #region 4 TD of 3 TR of 1 subTable
                                    stringBuilderHTML.Append("<td  valign='top' style='width:22%;'>");
                                    #region 1 subtable of 4 TD
                                    stringBuilderHTML.Append("<table style='width:30%;' border='0' cellpadding='0' cellspacing='2'>");
                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td>");

                                    PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                    int tpInterventionProcedureId = Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                    string tpProcedureId = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]);
                                    string authorizationCodeId = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]);
                                    //if (!String.IsNullOrEmpty(Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["SiteId"])))
                                    //    siteID = Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["SiteId"]);
                                    //else
                                    //    siteID = -1;

                                    stringBuilderHTML = new StringBuilder();
                                    dropdownListinterVentionProvider = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionProvider.Width = 180;
                                    dropdownListinterVentionProvider.CssClass = "form_dropdown";

                                    //dropdownListinterVentionProvider.ID = "DropDownList_TPInterventionProvider_" + Convert.ToString(dataSetTreatmentPlanHRM.Tables["TPInterventionProcedures"].DefaultView[interventionCount]["TPInterventionProcedureId"]);
                                    dropdownListinterVentionProvider.ID = "DropDownList_TPInterventionProvider_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                    if (disableProcedureProvider == true) { dropdownListinterVentionProvider.Enabled = false; }
                                    else
                                    {
                                        dropdownListinterVentionProvider.Enabled = true;
                                    }
                                    if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers != null)
                                    {
                                        //objectDocuments = new SHS.UserBusinessServices.Document();
                                        //agencyName = objectDocuments.GetAgencyName();
                                        DataView dataViewProviders = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.Providers);
                                        dataViewProviders.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y' and isnull(RenderingProvider,'N')<>'Y' ";
                                        dropdownListinterVentionProvider.DataTextField = "ProviderName";
                                        dropdownListinterVentionProvider.DataValueField = "SiteId";
                                        dropdownListinterVentionProvider.DataSource = dataViewProviders;
                                        dropdownListinterVentionProvider.DataBind();
                                        dropdownListinterVentionProvider.Items.Insert(0, new ListItem(agencyName, "-1"));
                                        //Uncommented by Mamta Gupta - Ref Task No. 755 - SCWebPhaseII Bugs/Features - To add -2 siteid in InterventionProviders.
                                        dropdownListinterVentionProvider.Items.Insert(1, new ListItem("Community/Natural Support", "-2"));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["SiteId"] != DBNull.Value)
                                    {
                                        siteID = Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["SiteId"]);
                                        dropdownListinterVentionProvider.SelectedValue = Convert.ToString(siteID);
                                    }
                                    else
                                    {
                                        siteID = -1;
                                    }
                                    //dropdownListinterVentionProvider.Attributes.Add("onChange", "ModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "SiteId" + "','" + dropdownListinterVentionProvider.ClientID + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "');SelectedIndexChanged(this,'DropDownList_TPInterventionService_" + tpInterventionProcedureId + "','Span_TPServiceAuthorisationCodes_AuthorisationCodes_" + tpInterventionProcedureId + "','" + tpInterventionProcedureId + "','" + tpProcedureId + "','" + authorizationCodeId + "','" + disableProcedureProvider + "');");
                                    dropdownListinterVentionProvider.Attributes.Add("onChange", "ModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "SiteId" + "','" + dropdownListinterVentionProvider.ClientID + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "',this,'DropDownList_TPInterventionService_" + tpInterventionProcedureId + "','Span_TPServiceAuthorisationCodes_AuthorisationCodes_" + tpInterventionProcedureId + "','" + tpInterventionProcedureId + "','" + tpProcedureId + "','" + authorizationCodeId + "','" + disableProcedureProvider + "');");
                                    dropdownListinterVentionProvider.Attributes.Add("GoalNo", dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString());
                                    dropdownListinterVentionProvider.Attributes.Add("SiteId", siteID.ToString());
                                    //dropdownListinterVentionProvider.Attributes.Add("onChange", "ModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "SiteId" + "','" + dropdownListinterVentionProvider.ClientID + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "');");
                                    dropdownListinterVentionProvider.Attributes.Add("BindAutoSaveEvents", "False");
                                    dropdownListinterVentionProvider.Attributes.Add("BindSetFormData", "False");

                                    PanelTxPlanMain.Controls.Add(dropdownListinterVentionProvider);

                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");

                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td>");
                                    PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                                    stringBuilderHTML = new StringBuilder();
                                    //dropdownListinterVentionService = new DropDownList();
                                    //dropdownListinterVentionService.Width = 180;
                                    //dropdownListinterVentionService.CssClass = "form_dropdown";
                                    //dropdownListinterVentionService.ID = "DropDownList_TPInterventionService_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                    //if (disableProcedureProvider == true) { dropdownListinterVentionService.Enabled = false; }
                                    //else
                                    //{
                                    //    dropdownListinterVentionService.Enabled = true;
                                    //}
                                    if (dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"] != DBNull.Value)
                                    {
                                        //dropdownListinterVentionService.Enabled = false;
                                        dropdownListinterVentionProvider.Enabled = false;
                                    }
                                    else
                                    {
                                        //dropdownListinterVentionService.Enabled = true;
                                        dropdownListinterVentionProvider.Enabled = true;
                                    }
                                    //if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes != null)
                                    //{
                                    //    DataView dataViewAuthorizationCodes = new DataView(SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes);
                                    //    dataViewAuthorizationCodes.RowFilter = "Active='Y' and isnull(RecordDeleted,'N')<>'Y'";
                                    //   // dataViewAuthorizationCodes.Sort = "AuthorizationCodeName";
                                    //    dataViewAuthorizationCodes.Sort = "DisplayAs";
                                    //    dropdownListinterVentionService.DataTextField = "DisplayAs";
                                    //    dropdownListinterVentionService.DataValueField = "AuthorizationCodeId";
                                    //    dropdownListinterVentionService.DataSource = dataViewAuthorizationCodes;
                                    //    dropdownListinterVentionService.DataBind();
                                    //    dropdownListinterVentionService.Items.Insert(0, new ListItem("", ""));
                                    //}
                                    //if (dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"] != DBNull.Value)
                                    //{
                                    //    dropdownListinterVentionService.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]);
                                    //}
                                    //dropdownListinterVentionService.Attributes.Add("onChange", "ModifyGoalValueInDataSet('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"] + "','" + "TPInterventionProcedures" + "','" + "AuthorizationCodeId" + "','" + dropdownListinterVentionService.ClientID + "','" + "Edit" + "','" + "TPInterventionProcedureId" + "');");
                                    //dropdownListinterVentionService.Attributes.Add("BindAutoSaveEvents", "False");
                                    //dropdownListinterVentionService.Attributes.Add("BindSetFormData", "False");

                                    //PanelTxPlanMain.Controls.Add(dropdownListinterVentionService);



                                    //added by shifali in ref to task# 4 of UM Part two on 29 sept,2010

                                    if (dataViewTPInterventionProcedures[interventionCount]["Units"].ToString() != null && dataViewTPInterventionProcedures[interventionCount]["Units"].ToString() != "")
                                    {
                                        dropdownListinterVentionProvider.Enabled = false;
                                        disableProcedureProvider = false;
                                    }
                                    else
                                    {
                                        dropdownListinterVentionProvider.Enabled = true;
                                        disableProcedureProvider = true;
                                    }
                                    stringBuilderHTML.Append("<span id='Span_TPServiceAuthorisationCodes_AuthorisationCodes_" + tpInterventionProcedureId + "' name='Span_TPServiceAuthorisationCodes_AuthorisationCodes'>" + CreateServiceDropDownList(tpInterventionProcedureId, disableProcedureProvider, tpProcedureId, authorizationCodeId, siteID, dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"].ToString()) + "</span>");

                                    // stringBuilderHTML.Append("<span id='Span_TPServiceAuthorisationCodes_AuthorisationCodes' name='Span_TPServiceAuthorisationCodes_AuthorisationCodes'>" + CreateServiceDropDownList(tpInterventionProcedureId, disableProcedureProvider, tpProcedureId, authorizationCodeId) + "</span>");
                                    //code ended by shifali in ref to task# 4 of UM Part two on 29 sept,2010




                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("</table>");
                                    #endregion 1 subtable of 4 TD
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 4 TD of 3 TR of 1 subTable

                                    //V TD
                                    #region 5 TD of 3 TR of 1 subTable
                                    stringBuilderHTML.Append("<td align='left' valign='top' style='width:30%;'>");
                                    #region 1 subtable 5 TD
                                    stringBuilderHTML.Append("<table style='width:100%;' border='0' cellpadding='0' cellspacing='2'>");
                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td style='width:50px;' align='left' valign='top'>");

                                    if (dataViewTPInterventionProcedures[interventionCount]["Units"] == DBNull.Value)
                                    {
                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  class='dateTextBoxWidth form_textbox' BindSetFormData='False' type='text' disabled='disabled'  id='Text_Units_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' style='width:75%;'/>");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  class='dateTextBoxWidth form_textbox' BindSetFormData='False' type='text' disabled='disabled'  id='Text_Units_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' style='width:75%;' value=' " + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["Units"]) + "'/>");
                                    }

                                    //Units
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("<td align='left' class='form_label'>");
                                    stringBuilderHTML.Append("<div id=divEncounter_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='width:95%;'>");


                                    string displayUnitText = DisplayUnitType(dropdownListinterVentionProvider);

                                    if (displayUnitText == string.Empty)
                                    {
                                        stringBuilderHTML.Append("<span  >1 Unit =1 Encounter</span>");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<span>");
                                        stringBuilderHTML.Append(displayUnitText);
                                        stringBuilderHTML.Append("</span>");
                                    }


                                    stringBuilderHTML.Append("</div>");
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td align='left' colspan='2' valign='top'>");
                                    PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));

                                    stringBuilderHTML = new StringBuilder();
                                    //Error Start
                                    dropdownListinterVentionFrequency = new SHS.CustomControl.DropDownListWithTooltip();
                                    dropdownListinterVentionFrequency.Enabled = false;
                                    dropdownListinterVentionFrequency.Width = 180;
                                    dropdownListinterVentionFrequency.CssClass = "form_dropdown";
                                    dropdownListinterVentionFrequency.ID = "DropDownList_GlobalCodes_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]);
                                    using (DataView DataViewGlobalCodes = BaseCommonFunctions.FillDropDown("TPFREQUENCYTYPE", true, "", "SortOrder", false))
                                    {
                                        dropdownListinterVentionFrequency.DataTextField = "CodeName";
                                        dropdownListinterVentionFrequency.DataValueField = "GlobalCodeId";
                                        dropdownListinterVentionFrequency.DataSource = DataViewGlobalCodes;
                                        dropdownListinterVentionFrequency.DataBind();
                                        dropdownListinterVentionFrequency.Items.Insert(0, new ListItem("", ""));
                                    }
                                    if (dataViewTPInterventionProcedures[interventionCount]["FrequencyType"] != DBNull.Value)
                                    {
                                        if (Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["FrequencyType"]) != string.Empty)
                                        {
                                            dropdownListinterVentionFrequency.SelectedValue = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["FrequencyType"]);
                                        }
                                    }
                                    //Error End

                                    PanelTxPlanMain.Controls.Add(dropdownListinterVentionFrequency);
                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("</table>");
                                    #endregion 1 subtable 5 TD
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 5 TD of 3 TR of 1 subTable

                                    //VI TD
                                    #region 6 TD of 3 TR of 1 subTable
                                    stringBuilderHTML.Append("<td valign='top' align='left'>");

                                    #region  1 subTable of 6 TD
                                    stringBuilderHTML.Append("<table style='width:100%;' border='0' cellpadding='0' cellspacing='2'>");
                                    stringBuilderHTML.Append("<tr>");
                                    stringBuilderHTML.Append("<td>");
                                    //StartDate
                                    if (dataViewTPInterventionProcedures[interventionCount]["StartDate"] != DBNull.Value)
                                    {
                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  BindSetFormData='False' type='text' disabled='disabled'  id=Text_From_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "  value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["StartDate"]).ToString("MM/dd/yyyy") + "' class='dateTextBoxWidth form_textbox'/>");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  BindSetFormData='False' type='text' disabled='disabled'  id=Text_From_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "  class='dateTextBoxWidth form_textbox'/>");
                                    }



                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("<tr >");
                                    stringBuilderHTML.Append("<td>");
                                    if (dataViewTPInterventionProcedures[interventionCount]["EndDate"] != DBNull.Value)
                                    {

                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  BindSetFormData='False' type='text' disabled='disabled'  id=Text_To_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "  value='" + Convert.ToDateTime(dataViewTPInterventionProcedures[interventionCount]["EndDate"]).ToString("MM/dd/yyyy") + "' class='dateTextBoxWidth form_textbox'/>");
                                    }
                                    else
                                    {
                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  BindSetFormData='False' type='text' disabled='disabled'  id=Text_To_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " class='dateTextBoxWidth form_textbox'/>");
                                    }


                                    stringBuilderHTML.Append("</td>");
                                    stringBuilderHTML.Append("</tr>");
                                    stringBuilderHTML.Append("</table>");
                                    #endregion  1 subTable of 6 TD
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 6 TD of 3 TR of 1 subTable

                                    stringBuilderHTML.Append("</tr>");
                                    #endregion 3 TR of 1Subtable of 2TR CreateIntervention

                                    #region 4 TR of 1Subtable of 2TR CreateIntervention
                                    stringBuilderHTML.Append("<tr class='TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "'>");

                                    //Ist TD
                                    #region 1 TD of 4 TR
                                    stringBuilderHTML.Append("<td style='width:5%;'>");
                                    stringBuilderHTML.Append("&nbsp;");
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 1 TD of 4 TR

                                    //II TD
                                    #region 2 TD of 4 TR
                                    stringBuilderHTML.Append("<td style='width:6%;'>");
                                    stringBuilderHTML.Append("<span   name='Span_EditInterVention'  id='Span_EditInterVention'  style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueforAssociatedObjective('" + "div_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','" + needId + "','" + Convert.ToInt32(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "')\">Edit</span>");
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 2 TD of 4 TR

                                    //III TD
                                    #region 3 TD of 4 TR
                                    stringBuilderHTML.Append("<td align='left' style='width:10%;'>");
                                    stringBuilderHTML.Append("<span  name='Span_QuickCopy'  id=Span_QuickCopy_TPInterventionProcedures_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"QuickCopyIntervention('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + "','" + needId + "' );\">Quick Copy</span>&nbsp;&nbsp;&nbsp;&nbsp;");
                                    //stringBuilderHTML.Append("</td>");
                                    //#endregion 3 TD of 4 TR

                                    ////IV TD
                                    //#region 4 TD of 4 TR
                                    //stringBuilderHTML.Append("<td align='left' style='width:15%;'>");
                                    stringBuilderHTML.Append("<span   name='Span_QuickInterVention'  id=Span_QuickInterVention_TPInterventionProcedures_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueQuickTxPlan('" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + "','" + "TextArea_TPInterventionProcedures_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','" + "TPQuickInterventions" + "','" + "TPInterventionProcedures" + "');\">Use Quick Intervention</span>");
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 4 TD of 4 TR

                                    //V TD
                                    #region 5 TD of 4 TR
                                    stringBuilderHTML.Append("<td align='left'>");
                                    stringBuilderHTML.Append("<span   name='Span_AddQuickInterVention'  id=Span_AddQuickInterVention_TPInterventionProcedures_" + dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"].ToString() + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenModelDialogueAddQuickTxPlan('" + "TPQuickInterventions" + "','" + "TextArea_TPInterventionProcedures_InterventionText_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "','" + "TPInterventionProcedureId" + "');\">Add this to Quick Interventions</span>");
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 5 TD of 4 TR

                                    //VI TD
                                    #region 6 TD of 4 TR
                                    stringBuilderHTML.Append("<td align='left' colspan='2'>");
                                    //Below If conditon added  w.rf. to task 190
                                    if (dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"] != DBNull.Value && Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"]) == "Y")
                                        stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='40%' align='left' ><tr>");
                                    else
                                        stringBuilderHTML.Append("<table cellpadding='0' cellspacing='0' border='0' width='100%' ><tr>");

                                    //This is used for showing Edit Authorizaion Link Always . When user add intervention
                                    //This is used for showing Edit Authorizaion Link Always . When user add intervention
                                    string TPProcedureID = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]) == "" ? "0" : Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]);
                                    string AuthorizationCodeID = Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]) == "" ? "0" : Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]);
                                    //With Ref to ticket  90 For Enable and Disable Edit and Clear Link base
                                    if (dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"] != DBNull.Value && Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"]) == "Y")
                                    {
                                        stringBuilderHTML.Append("<td width='110'><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_EditAuthorization'  id='Span_EditAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;display:none;'>Edit Authorization</span></td>");
                                    }
                                    else
                                    {
                                        DataRow[] drTPProcedureRows = null;
                                        if (documentCodeId == "503" && BaseCommonFunctions.CheckRowExists(dataSetTreatmentPlanHRM, "TPProcedures", 0) && tpProcedureId != "")
                                        {
                                            drTPProcedureRows = dataSetTreatmentPlanHRM.Tables["TPProcedures"].Select("TPProcedureId=" + tpProcedureId + " and TPProcedurePreviousPlan='Y'");
                                        }
                                        if (drTPProcedureRows != null && drTPProcedureRows.Length > 0 && documentCodeId == "503")
                                            stringBuilderHTML.Append("<td width='110'><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_EditAuthorization'  id='Span_EditAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;display:none;'>Edit Authorization</span></td>");
                                        else
                                            //Changes made By Mamta Gupta-21/Dec/2011-SCWebPhaseII Bugs/Features- Ref Task 351- Remove display:block from style to remove hand from open space
                                            stringBuilderHTML.Append("<td width='110'><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_EditAuthorization'  id='Span_EditAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + "' style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"OpenEditAuthorization(" + TPProcedureID + "," + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["NeedId"]) + "," + AuthorizationCodeID + "," + siteID + "," + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ")\">Edit Authorization</span></td>");                                        
                                    }

                                    if (dataViewTPInterventionProcedures[interventionCount]["Units"].ToString() != null && dataViewTPInterventionProcedures[interventionCount]["Units"].ToString() != "")
                                    {
                                        dropdownListinterVentionProvider.Enabled = false;
                                        if (dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"] != DBNull.Value && Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"]) == "Y")
                                        {
                                            stringBuilderHTML.Append("<td><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_ClearAuthorization'  id=Span_ClearAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;display:none;'>Clear Authorization</span></td>");
                                            //Changes made w.rf. to task 190
                                            if (documentCodeId == "503")
                                            {
                                                stringBuilderHTML.Append("<td align='left'> <table cellpadding='0' cellspacing='0' border='0'> <tr> <td>");
                                                if (dataRowTPProcedures != null && Convert.ToString(dataRowTPProcedures["Inactive"]) == "Y")
                                                {
                                                    if (documentStatus == "22")
                                                    {
                                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  BindSetFormData='False' disabled='disabled' style='cursor:pointer;color:Black;font-size:11px;' type='checkbox' checked = 'true'  onclick=\"ModifyGoalValueInDataSet('" + tpProcedureId + "','" + "TPProcedures" + "','" + "Inactive" + "','" + "CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId.ToString() + "','" + "Edit" + "','" + "TPProcedureId" + "');\"  name=CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "  id='CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "' TPProcedureId='" + tpProcedureId + "' /></td>");
                                                    }
                                                    else
                                                    {
                                                        stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;' type='checkbox' checked = 'true'  onclick=\"ModifyGoalValueInDataSet('" + tpProcedureId + "','" + "TPProcedures" + "','" + "Inactive" + "','" + "CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId.ToString() + "','" + "Edit" + "','" + "TPProcedureId" + "');\"  name=CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "  id='CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "' TPProcedureId='" + tpProcedureId + "' /></td>");
                                                    }
                                                    stringBuilderHTML.Append("<td style='padding-left:2px;'><label for='CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "'>Inactive</label></td>");
                                                    //if effective end date is null then display nothing otherwise display effective end date with ref to task#190
                                                    if (dataRowTPProcedures["EffectiveEndDate"] == null)
                                                    {
                                                        stringBuilderHTML.Append("<td align='left' style='padding-left:5px;' ><input  type='text' style='width: 60px;' class='dateTextBoxWidth form_textbox' datatype='Date' value='' name=Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId + "  id=Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId + "  BindAutoSaveEvents ='False'  BindSetFormData='False' onblur=\"ModifyGoalValueInDataSet('" + tpProcedureId + "','" + "TPProcedures" + "','" + "EffectiveEndDate" + "','" + "Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId.ToString() + "','" + "Edit" + "','" + "TPProcedureId" + "');\" ProcedureId='" + tpProcedureId + "' /></td>");
                                                    }
                                                    else
                                                    {
                                                        stringBuilderHTML.Append("<td align='left' style='padding-left:5px;' ><input  type='text' style='width: 60px;' class='dateTextBoxWidth form_textbox' datatype='Date' value='" + ExtensionMethods.ToFormatedDateString(dataRowTPProcedures["EffectiveEndDate"]) + "'  name=Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId + "  id=Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId + "  BindAutoSaveEvents ='False'  BindSetFormData='False' onblur=\"ModifyGoalValueInDataSet('" + tpProcedureId + "','" + "TPProcedures" + "','" + "EffectiveEndDate" + "','" + "Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId.ToString() + "','" + "Edit" + "','" + "TPProcedureId" + "');\" ProcedureId='" + tpProcedureId + "' /></td>");
                                                    }

                                                }
                                                else
                                                {

                                                    stringBuilderHTML.Append("<input  BindAutoSaveEvents ='False'  BindSetFormData='False' style='cursor:pointer;color:Black;font-size:11px;' type='checkbox'  onclick=\"ModifyGoalValueInDataSet('" + tpProcedureId + "','" + "TPProcedures" + "','" + "Inactive" + "','" + "CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId.ToString() + "','" + "Edit" + "','" + "TPProcedureId" + "');\"  name=CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "  id='CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "' TPProcedureId='" + tpProcedureId + "' /></td>");
                                                    stringBuilderHTML.Append("<td style='padding-left:2px;'><label for='CheckBox_TPProcedures_Inactive_" + tpInterventionProcedureId + "'>Inactive</label></td>");
                                                    stringBuilderHTML.Append("<td align='left' style='padding-left:5px;' ><input  type='text' style='width: 60px;' class='dateTextBoxWidth form_textbox' disabled='disabled' datatype='Date'  name=Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId + "  id=Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId + "  BindAutoSaveEvents ='False'  BindSetFormData='False' onblur=\"ModifyGoalValueInDataSet('" + tpProcedureId + "','" + "TPProcedures" + "','" + "EffectiveEndDate" + "','" + "Text_TPProcedures_EffectiveEndDate_" + tpInterventionProcedureId.ToString() + "','" + "Edit" + "','" + "TPProcedureId" + "');\" ProcedureId='" + tpProcedureId + "' /></td>");

                                                }
                                                stringBuilderHTML.Append("  </tr> </table>  </td>");
                                            }
                                            //Changes end here
                                        }
                                        else
                                            //Changes made By Mamta Gupta-21/Dec/2011-SCWebPhaseII Bugs/Features- Ref Task 351- Remove display:block from style to remove hand from open space
                                            stringBuilderHTML.Append("<td><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_ClearAuthorization'  id=Span_ClearAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;' onclick=\"ClearAuthorization(" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]) + "," + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["NeedId"]) + "," + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["AuthorizationCodeId"]) + "," + siteID + "," + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ")\">Clear Authorization</span></td>");                                        

                                    }
                                    else
                                    {
                                        if (dataRowTPProcedures != null)
                                        {
                                            if (dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"] != DBNull.Value && Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["InitializedFromPreviousPlan"]) == "Y")
                                                stringBuilderHTML.Append("<td><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_ClearAuthorization'  id=Span_ClearAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;display:none;'>Clear Authorization</span></td>");
                                            else
                                                stringBuilderHTML.Append("<td><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_ClearAuthorization'  id=Span_ClearAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;display:none;'\" onclick=\"ClearAuthorization(" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPProcedureId"]) + "," + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["NeedId"]) + "," + Convert.ToString(dataRowTPProcedures["AuthorizationCodeId"]) + "," + siteID + "," + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + ")\">Clear Authorization</span></td>");

                                        }
                                        else
                                        {
                                            stringBuilderHTML.Append("<td><span BindAutoSaveEvents ='False'  BindSetFormData='False' name='Span_ClearAuthorization'  id=Span_ClearAuthorization_TPInterventionProcedures_" + Convert.ToString(dataViewTPInterventionProcedures[interventionCount]["TPInterventionProcedureId"]) + " style='text-decoration:underline;cursor:hand;color:Black;font-size:11px;display:none;'\" >Clear Authorization</span></td>");
                                        }
                                    }

                                    stringBuilderHTML.Append("</tr></table>");
                                    stringBuilderHTML.Append("</td>");
                                    #endregion 6 TD of 4 TR

                                    stringBuilderHTML.Append("</tr>");
                                    #endregion 4 TR of 1Subtable of 2TR CreateIntervention
                                    //stringBuilderHTML.Append("<table>");
                                    // stringBuilderHTML.Append("</td>");
                                    //stringBuilderHTML.Append("</tr>");
                                }
                            }
                            stringBuilderHTML.Append("</table>");
                            #endregion 1Subtable of 2TR CreateIntervention

                            stringBuilderHTML.Append("</td>");//1st Row 3rd Col Close Tag
                            stringBuilderHTML.Append("</tr>");

                            #endregion 2 TR CreateIntervention

                            PanelTxPlanMain.Controls.Add(new LiteralControl(stringBuilderHTML.ToString()));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            finally
            {
                dataRowTPInterventionProcedures = null;
                dataRowTPInterventionPObjective = null;
            }
        }

        /// <summary>
        /// <Description>Method is used to calculate unit on the selection</Description>
        /// <Author>Vikas Vyas</Author>
        /// <CreatedOn>09 Oct,2009</CreatedOn>
        /// </summary>
        private string DisplayUnitType(DropDownList dropdownlistFrequency)
        {
            string selectedValue = string.Empty;
            string strCodeName = string.Empty;
            string[] parameterCollection = null;
            DataSet dataSetAuthorization = null;
            DataSet dataSetTemp = null;
            DataView dataViewAuthorization = null;
            DataRow[] dataRowAuthorizationCodeName = null;
            DataRow[] dataRowGlobalCodes = null;
            Int32 unitTypeValue = 0;
            Int32 units = 0;
            string unitCounterText = string.Empty;
            try
            {
                // selectedValue = Request.Form["selectedValue"];
                char[] cSpilt = new char[1];
                cSpilt[0] = ',';
                if (Request.Form["UnitCount"] != null)
                {
                    parameterCollection = Request.Form["UnitCount"].Split(cSpilt);
                }
                dataRowAuthorizationCodeName = SHS.BaseLayer.SharedTables.ApplicationSharedTables.AuthorizationCodes.Select("Active='Y'", "AuthorizationCodeName");
                dataSetAuthorization = new DataSet();
                dataSetAuthorization.EnforceConstraints = false;//Need to Check Anuj forcefully  enforced constraints false.
                dataSetAuthorization.Merge(dataRowAuthorizationCodeName);

                dataViewAuthorization = new DataView(dataSetAuthorization.Tables[0]);

                dataViewAuthorization.RowFilter = "AuthorizationCodeId=" + Convert.ToInt32(dropdownlistFrequency.SelectedValue);
                if (dataViewAuthorization.Count > 0 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != -1 && Convert.ToInt32(dropdownlistFrequency.SelectedValue) != 0)
                {
                    if (dataViewAuthorization[0]["UnitType"] != null && dataViewAuthorization[0]["UnitType"] != System.DBNull.Value)
                        unitTypeValue = Convert.ToInt32(dataViewAuthorization[0]["UnitType"]);
                    if (dataViewAuthorization[0]["Units"] != null && dataViewAuthorization[0]["Units"] != System.DBNull.Value)
                        units = Convert.ToInt32(dataViewAuthorization[0]["Units"]);

                }

                dataRowGlobalCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.GlobalCodes.Select("GlobalCodeId=" + unitTypeValue);

                dataSetTemp = new DataSet();

                if (dataRowGlobalCodes.Length > 0)
                {
                    dataSetTemp.Merge(dataRowGlobalCodes);

                    if (unitTypeValue == 120 || unitTypeValue == 110)
                    {
                        // modified by Piyush on 6th March 2007 as per comment on "3/2/2007 8:08:07 AM " on task 390
                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 6);
                        if (units != 1)
                            unitCounterText = "(1 Unit = " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit = " + units + " " + strCodeName + ")";
                    }
                    else if (unitTypeValue == 124)
                    {

                        strCodeName = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                        strCodeName = strCodeName.Substring(0, 9);
                        if (units != 1)
                            unitCounterText = "(1 Unit =  " + units + " " + dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString() + ")";
                        else
                            unitCounterText = "(1 Unit =  " + units + " " + strCodeName + ")";
                    }
                    else
                    {
                        unitCounterText = dataSetTemp.Tables[0].Rows[0]["CodeName"].ToString();
                    }
                }

                return unitCounterText;
            }

            finally
            {

                selectedValue = string.Empty;
                strCodeName = string.Empty;
                parameterCollection = null;
                dataSetAuthorization = null;
                dataSetTemp = null;
                dataViewAuthorization = null;
                dataRowAuthorizationCodeName = null;
                dataRowGlobalCodes = null;

            }
        }


        /// <Description>Method is used to Create Service Dropdownlist for 'CreateIntervention' section of TxPlan</Description>
        /// <Author>Shifali</Author>
        /// <Purpose>Added by shifali on 29 sept,2010 in ref to task# 4 of UM - Part two</Purpose>
        /// <ModifiedBy> Rakesh Garg </ModifiedBy>
        /// <ModifiedDate> 23 Nove 2010 </ModifiedDate>
        /// </summary>
        /// <returns></returns>
        private StringBuilder CreateServiceDropDownList(int tPInterventionProcedureId, bool disableProcedureProvider, string tpProcedureId, string authorizationCodeId, int siteID, string InitializedFromPreviousPlan)
        {
            //Will do on monday
            StringBuilder strHtml = new StringBuilder();
            DataSet _dsAuthorizationCodes = null;

            if (_dsAuthorizationCodes == null)
            {
                SHS.UserBusinessServices.TreatmentPlan objectTreatmentPlan = new SHS.UserBusinessServices.TreatmentPlan();
                try
                {
                    _dsAuthorizationCodes = GetAuthorizationCodeTxPlanMain(siteID);
                    _InteractionAuthorizationCodesHRMTxPlan.Add(new InteractionAuthorizationCodesHRMTxPlan() { dsAuthorizationCodes = _dsAuthorizationCodes, siteid = siteID });
                }
                catch (Exception ex)
                {

                }
            }
            if (_dsAuthorizationCodes.Tables.Count > 0 && _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Rows.Count > 0)
            {
                if (disableProcedureProvider == false)
                {
                    strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:20px;color: Black;width:180px;' goalNo='" + goalNo + "' TPProcedureId='" + tpProcedureId + "' SiteId='" + siteID + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");

                    //strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:20px;color: Black;font-size: 12px;width:180px;'>");
                }
                else
                {
                    strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:20px;color: Black;width:180px;'  goalNo='" + goalNo + "' TPProcedureId='" + tpProcedureId + "' SiteId='" + siteID + "' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");

                    //strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:20px;color: Black;font-size: 12px;width:180px;'>");
                }

                //For Filling Core Services
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                DataRow[] drCoreServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Core Services'", "DisplayAs asc");
                for (int loopCounter = 0; loopCounter < drCoreServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {   //By Vikas Vyas in ref. to task #679
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option selected='selected' title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }


                //For Filling Speciality Services
                strHtml.Append("</optgroup>");

                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");

                DataRow[] drSpecialityServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Speciality Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drSpecialityServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option  title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }

                //For Filling Other Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");

                DataRow[] drOtherServices = _dsAuthorizationCodes.Tables["TPServiceAuthorizationCodes"].Select("ServiceCategory= 'Other Services'", "DisplayAs asc");

                for (int loopCounter = 0; loopCounter < drOtherServices.Length; loopCounter++)
                {
                    if (loopCounter == 0)
                    {

                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(authorizationCodeId))
                        {
                            strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                        }
                        else
                        {
                            if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                            else
                            {
                                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
                            }
                        }
                    }
                }
                strHtml.Append("</optgroup>");

                strHtml.Append("</select>");
                return strHtml;
            }
            else
            {
                if (disableProcedureProvider == false)
                {
                    strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:20px;color: Black;width:180px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                }
                else
                {
                    strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:20px;color: Black;width:180px;' InitializedFromPreviousPlan='" + InitializedFromPreviousPlan + "' >");
                }
                strHtml.Append("<option value=''></option>");
                strHtml.Append("<optgroup serviceType='C' label='Core Services'>");
                //For Filling Speciality Services
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("<optgroup serviceType='O' label='Other Services'>");
                strHtml.Append("</optgroup>");
                strHtml.Append("</select>");
            }

            return strHtml;
            #region Commented Code
            //if (SHS.BaseLayer.SharedTables.ApplicationSharedTables.Tables.Contains("TPServiceAuthorisationCodes") && SHS.BaseLayer.SharedTables.ApplicationSharedTables.Tables["TPServiceAuthorisationCodes"].Rows.Count > 0)
            //{
            //    DataTable dataTableTPServiceAuthorisationCodes = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Tables["TPServiceAuthorisationCodes"];

            //    if (disableProcedureProvider == false)
            //    {
            //        //stringBuilderHTML.Append("<textarea  style='width:96%' onChange = \"ModifyGoalValueInDataSet('" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "TPNeeds" + "','" + "GoalText" + "','" + "TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "','" + "Edit" + "','" + "NeedId" + "');\"  name=TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + "  id=TextArea_TPNeeds_GoalText_" + dataRowViewTPNeeds["NeedId"].ToString() + " rows='2' cols='6'  class='form_textarea'  parentchildcontrols='True'>");
            //        strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' disabled='disabled' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:21px;color: Black;font-size: 12px;width:180px;border-left:0px;border-left-color:White'>");
            //    }
            //    else
            //    {
            //        strHtml.Append("<select id=DropDownList_TPInterventionService_" + tPInterventionProcedureId + " class='form_dropdown' BindAutoSaveEvents='False' parentchildcontrols='true' onChange=\"javascript:ModifyGoalValueInDataSet(" + tPInterventionProcedureId + ",'TPInterventionProcedures','AuthorizationCodeId','DropDownList_TPInterventionService_" + tPInterventionProcedureId + "','Edit','TPInterventionProcedureId');\"  style='height:21px;color: Black;font-size: 12px;width:180px;border-left:0px;border-left-color:White'>");
            //    }

            //    //For Filling Core Services
            //    strHtml.Append("<option value=''></option>");
            //    strHtml.Append("<optgroup serviceType='C' label='Core Services'>");

            //    DataRow[] drCoreServices = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Tables["TPServiceAuthorisationCodes"].Select("ServiceCategory='C'", "DisplayAs asc");

            //    for (int loopCounter = 0; loopCounter < drCoreServices.Length; loopCounter++)
            //    {
            //        if (loopCounter == 0)
            //        {
            //            if (string.IsNullOrEmpty(authorizationCodeId))
            //            {
            //                strHtml.Append("<option  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //            }
            //            else
            //            {   //By Vikas Vyas in ref. to task #679
            //                if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
            //                {
            //                    strHtml.Append("<option selected='selected' title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //                else
            //                {
            //                    strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //            }
            //        }
            //        else
            //        {
            //            if (string.IsNullOrEmpty(authorizationCodeId))
            //            {
            //                strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //            }
            //            else
            //            {
            //                if (authorizationCodeId == drCoreServices[loopCounter]["AuthorizationCodeId"].ToString())
            //                {
            //                    strHtml.Append("<option title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //                else
            //                {
            //                    strHtml.Append("<option  title='" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drCoreServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drCoreServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //            }
            //        }
            //    }
            //    //For Filling Speciality Services
            //    strHtml.Append("</optgroup>");

            //    strHtml.Append("<optgroup serviceType='S' label='Speciality Services'>");

            //    DataRow[] drSpecialityServices = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Tables["TPServiceAuthorisationCodes"].Select("ServiceCategory='S'", "DisplayAs asc");

            //    for (int loopCounter = 0; loopCounter < drSpecialityServices.Length; loopCounter++)
            //    {
            //        if (loopCounter == 0)
            //        {

            //            if (string.IsNullOrEmpty(authorizationCodeId))
            //            {
            //                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //            }
            //            else
            //            {
            //                if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
            //                {
            //                    strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //                else
            //                {
            //                    strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //            }
            //        }
            //        else
            //        {
            //            if (string.IsNullOrEmpty(authorizationCodeId))
            //            {
            //                strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "'  value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //            }
            //            else
            //            {
            //                if (authorizationCodeId == drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString())
            //                {
            //                    strHtml.Append("<option title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //                else
            //                {
            //                    strHtml.Append("<option  title='" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drSpecialityServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drSpecialityServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //            }
            //        }
            //    }

            //    //For Filling Other Services
            //    strHtml.Append("</optgroup>");
            //    strHtml.Append("<optgroup serviceType='O' label='Other Services'>");

            //    DataRow[] drOtherServices = SHS.BaseLayer.SharedTables.ApplicationSharedTables.Tables["TPServiceAuthorisationCodes"].Select("ServiceCategory='O'", "DisplayAs asc");

            //    for (int loopCounter = 0; loopCounter < drOtherServices.Length; loopCounter++)
            //    {
            //        if (loopCounter == 0)
            //        {

            //            if (string.IsNullOrEmpty(authorizationCodeId))
            //            {
            //                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //            }
            //            else
            //            {
            //                if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
            //                {
            //                    strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //                else
            //                {
            //                    strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //            }
            //        }
            //        else
            //        {
            //            if (string.IsNullOrEmpty(authorizationCodeId))
            //            {
            //                strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //            }
            //            else
            //            {
            //                if (authorizationCodeId == drOtherServices[loopCounter]["AuthorizationCodeId"].ToString())
            //                {
            //                    strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' selected='selected' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //                else
            //                {
            //                    strHtml.Append("<option title='" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "' value='" + drOtherServices[loopCounter]["AuthorizationCodeId"].ToString() + "'>" + drOtherServices[loopCounter]["DisplayAs"].ToString() + "</option>");
            //                }
            //            }
            //        }
            //    }
            //    strHtml.Append("</optgroup>");
            //}
            //strHtml.Append("</select>");
            //return strHtml;
            #endregion

        }

        public DataSet GetAuthorizationCodeTxPlanMain(int SiteID)
        {
            DataSet dataSetAuthorizationCodeTxPlanMain = null;
            try
            {
                DataSet dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.ScreenInfo.CurrentDocument.DocumentDataSet;
                if (dsCurrentScreen == null)
                    dsCurrentScreen = SHS.BaseLayer.BaseCommonFunctions.GetScreenInfoDataSet();

                int ClientId = 0;
                int DocumentVersionId = 0;
                if (dsCurrentScreen.IsDataTableFound("Documents"))
                {
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("ClientId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["ClientId"].ToString(), out ClientId);
                    if (dsCurrentScreen.Tables["Documents"].Columns.Contains("InProgressDocumentVersionId") && !string.IsNullOrEmpty(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString()))
                        int.TryParse(dsCurrentScreen.Tables["Documents"].Rows[0]["InProgressDocumentVersionId"].ToString(), out DocumentVersionId);
                }
                if (ClientId <= 0)
                    ClientId = SHS.BaseLayer.BaseCommonFunctions.ApplicationInfo.Client.ClientId;

                dataSetAuthorizationCodeTxPlanMain = new DataSet();
                System.Data.SqlClient.SqlParameter[] _objectSqlParmeters = new System.Data.SqlClient.SqlParameter[3];
                _objectSqlParmeters[0] = new System.Data.SqlClient.SqlParameter("@ClientId", ClientId);
                _objectSqlParmeters[1] = new System.Data.SqlClient.SqlParameter("@DocumentVersionId", DocumentVersionId);
                _objectSqlParmeters[2] = new System.Data.SqlClient.SqlParameter("@SiteID", SiteID);
                Microsoft.ApplicationBlocks.Data.SqlHelper.FillDataset(SHS.DataServices.Connection.ConnectionString, CommandType.StoredProcedure, "csp_SCGetTPServiceUMAuthorization", dataSetAuthorizationCodeTxPlanMain, new string[] { "TPServiceAuthorizationCodes" }, _objectSqlParmeters);

            }
            catch
            {

            }
            return dataSetAuthorizationCodeTxPlanMain;
        }
    }
    public class InteractionAuthorizationCodesHRMTxPlan
    {        
        public int siteid { get; set; }
        public DataSet dsAuthorizationCodes { get; set; }
    }
}