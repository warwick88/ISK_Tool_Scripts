﻿var initiallySelectedCheckbox = null;
var newNeedAdded = '';
var sortOrder = 'asc';

//Description:Add  Events  for Pop Up
function AddEventHandlers() {
   
    var GoalId = 0;
    var DomainId = 0;
    var ObjectiveId = 0;

    //-----------------------AddNeeds--------------
    $('input#button_Ok_AddNeeds').unbind('click').bind('click', function() {
        AddNeedPopUp();
    });
    $('input#button_Cancel_AddNeeds').unbind('click').bind('click', function() {
        CheckBeforeClose();
    });
    //-----------------------AssociatedNeeds--------------
    $('input#button_Ok_AssociatedNeeds').unbind('click').bind('click', function() {
        AssociatedNeedPopUp();
    });
    $('input#button_Cancel_AssociatedNeeds').unbind('click').bind('click', function() {
        CheckBeforeClose();
    });
    //-----------------------GoalDescription--------------
    $('input#button_Ok_GoalDescription').unbind('click').bind('click', function() {
        GoalDescriptionPopUp();
    });
    $('input#button_Cancel_GoalDescription').unbind('click').bind('click', function() {
        CheckBeforeClose();
    });
    //-----------------------Objective Description--------------
    $('input#button_Ok_ObjectiveDescription').unbind('click').bind('click', function() {
        ObjectiveDescriptionPopUp();
    });
    $('input#button_Cancel_ObjectiveDescription').unbind('click').bind('click', function() {
        CheckBeforeClose();
    });
    //-----------------------EditViewObjectives--------------
    $('input#button_Ok_EditViewObjectives').unbind('click').bind('click', function() {
        EditViewObjectivesPopUp();
    });
    $('input#button_Cancel_EditViewObjectives').unbind('click').bind('click', function() {
        CheckBeforeClose();
    });
    //------------------Check AssociatedNeeds already exists-------------------
    var $AssociatedNeeds = $('.checkbox_AssociatedNeeds');
    $AssociatedNeeds.unbind('change').bind('change', function () {
        CheckAlreadyAssociatedNeeds(this);
    });
    var $checkedCheckboxs = $('.checkbox_AssociatedNeeds:checked');
    if ($checkedCheckboxs.length > 0) {
        ShowHideDescriptionBoxonLoad($checkedCheckboxs);
    }
    //-------------------Goals Description--------------------------------------------
    $('.radio_Description').unbind('click').bind('click', function () {
        ShowHideDescriptionBox(this, false);
    });

    var $checkedRadioButtons = $('.radio_Description:checked');
    if ($checkedRadioButtons.length > 0) {
        ShowHideDescriptionBoxonLoad($checkedRadioButtons);
    }

    //------------------"Treatment Team" Pop Up --------------------------------
    $('input#button_OK_TreatmentTeam').unbind('click').bind('click', function() {
        AddTreatmentTeam();
    });
    $("input#button_Cancel_TreatmentTeam").unbind("click").bind("click", function() {
        CheckBeforeClose();
    });
    //--------------------"Add Program In Treatmen Team"--------------------------
    $('input#button_OK_AddTreatmenTeamMember').unbind('click').bind('click', function() {
        AddNewTreatmentTeamMember();
    });
    $("input#button_Cancel_AddTreatmenTeamMember").unbind("click").bind("click", function() {
        CheckBeforeClose();
    });
    $("#TextBox_Search").unbind('keyup').bind('keyup', function () {
        var searchText = $(this).val();
        if (searchText.length >= 3) {
            var resultText = "";
            $('table[id*=GridViewCarePlanGoalDescription] span[class=form_label_dfa]').each(function (index, value) {
                resultText = $(value).attr('title');
                if (!resultText) {
                    resultText = $(value).attr('innerHTML');
                }
                if (resultText.toLowerCase().replace(/\s+/g, '').indexOf(searchText.replace(/\s+/g, '').toLowerCase()) == -1) {
                    $(value).closest('tr').hide();
                    $('[id^="textArea_PopupDescription"]').hide();
                }
                else {
                    $(value).closest('tr').show();
                }
            });
        }
        else {
            $('table[id*=GridViewCarePlanGoalDescription] tr').show();
        }
    });
    //for objectives search
    $("#TextBox_Searchobjectives").unbind('keyup').bind('keyup', function () {
        var searchText = $(this).val();
        if (searchText.length >= 3) {
            var resultText = "";
            $('table[id*=GridViewCarePlanObjectiveDescription] span[class=form_label_dfa]').each(function (index, value) {
                resultText = $(value).attr('title');
                if (!resultText) {
                    resultText = $(value).attr('innerHTML');
                }
                if (resultText.toLowerCase().replace(/\s+/g, '').indexOf(searchText.replace(/\s+/g, '').toLowerCase()) == -1) {
                    $(value).closest('tr').hide();
                    $('[id^="textArea_PopupDescription"]').hide();
                }
                else {
                    $(value).closest('tr').show();
                }
            });
        }
        else {
            $('table[id*=GridViewCarePlanObjectiveDescription] tr').show();
        }
    });

    if ($("[id$=hiddenconfigurationkeyvalue]").val() != "Yes") {
        $("#TextBox_Search").hide();
        $("#TextBox_Searchobjectives").hide();

    }
}

//Description:Close  Pop Up on Cancel button click
function CheckBeforeClose() {
   
    parent.CloaseModalPopupWindow();
}

//Description: Show error message if user unselect chechbox of   AssociatedNeeds which already associted
function CheckAlreadyAssociatedNeeds(id) {
    
    var associatedid = $(id).attr('tobeassociated');
    var check = ($(id).attr('checked')) ? "T" : "F";
    if (associatedid == "1" && check == "F") {
        ShowHideErrorMessage("You cannot remove the Need that is directly linked to a selected Goal.<br/>A)cancel this action and remove the goal or<br/>B)reselect the associated need", 'true');
        $('input#button_Ok_AssociatedNeeds').attr('disabled', 'disabled');
    }
    else if (associatedid == "1" && check == "T") {
        ShowHideErrorMessage("", 'false');
        $('input#button_Ok_AssociatedNeeds').removeAttr('disabled');
    }
    ShowHideDescriptionBox(id);    
}

//Description: CarePlan  Add Needs  PopUp select ok button 
function AddNeedPopUp() {
    
    var Needstring = "";
    var Check = "";

    var Checkbox_ShowAddressOnCarePlanID = parent.$('input[id$=Checkbox_ShowAddressOnCarePlan]');
    if ($(Checkbox_ShowAddressOnCarePlanID).length > 0) {
        $(Checkbox_ShowAddressOnCarePlanID).removeAttr('checked');
        parent.GetOnlyAddressOnCarePlan($(Checkbox_ShowAddressOnCarePlanID));
    }

    $('table.dxgvTable input[type=checkbox]').each(function() {
        Check = ($(this).attr('checked')) ? "T" : "F";
        var NeedId = decodeText($(this).attr('id'));
        NeedId = NeedId.split('_');
        if (Check == "T") {
            Needstring += "###" + NeedId[1];
        }
    });
    if (Needstring.length > 2)
        Needstring = Needstring.substring(0, Needstring.length);
    DomainId = $("[id$=_HiddenField_CarePlanDomainId]").val();
    var data = 'CustomAction=AddNeedsPopUp^CarePlanDomainNeedId=' + Needstring + '^CarePlanDomainId=' + DomainId + "^AutoSaveXML=" + encodeText(convert_accented_characters(parent.AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    parent.OpenPage(5763, $('[id$=HiddenField_CarePlanMainScreenId]').val(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    //61223- For QA
    //67013 - For Local
}

//Description: CarePlan  Associated Needs  PopUp select ok button 
function AssociatedNeedPopUp() {
    
    var Needstring = "";
    var Check = "";
    var test = "";
    var needArray = [];

    $('table.dxgvTable input[type=checkbox]').each(function () {
        Check = ($(this).attr('checked')) ? "T" : "F";
        test = $(this).attr('tobeassociated');
        var NeedId = decodeText($(this).attr('id'));
        NeedId = NeedId.split('_');
        var Description = $('#textArea_PopupDescription_' + NeedId[1]).val();
        if (NeedId[1] != "") {
            if (Check == "T") {
                var need = { Id: NeedId[1], Desc: Description };
                needArray.push(need);
            }
        }
    });

    Needstring = JSON.stringify(needArray);
    GoalId = $("[id$=_HiddenField_CarePlanGoalId]").val();
    PopupProcessing();
    $.ajax({
        type: "POST",
        url: "../Modules/CarePlan/CarePlan.aspx?functionName=AddAssociatedNeed",
        data: 'NeedId=' + encodeText(Needstring) + '&GoalId=' + GoalId,
        success: function (result) {
            callbackAddAssociatedNeeds(result, GoalId);
            CreateUnsavedInstanceOnDatasetChange();
        }
    });
}

//Description: CarePlan  Goal Description  PopUp select ok button 
function GoalDescriptionPopUp() {
    
    var goalstring = "";
    var Check = "";
    var test = "";
    var goalArray = [];
    $('table.dxgvTable input[type=radio]').each(function () {
        Check = ($(this).attr('checked')) ? "T" : "F";
        var NeedId = decodeText($(this).attr('id'));
        var NeedText = '';
        NeedId = NeedId.split('_');
        var Description = $('#textArea_PopupDescription_' + NeedId[1]).val();
        if (NeedId[1] != "") {
            if (Check == "T") {
                var need = { Id: NeedId[1], Desc: Description };
                goalArray.push(need);
            }
        }
    });
    goalstring = JSON.stringify(goalArray);
    GoalId = $("[id$=_HiddenField_CarePlanGoalId]").val();
    if ($("[id$=hiddenconfigurationkeyvalue]").val() == "Yes") {
        if (goalstring.indexOf('_') > -1) {
            $("#SpanErrorMessagePopUp").html('&nbsp; Please fill in the blanks');
            $("#SpanErrorMessagePopUp").css("display", "block");
            return;
        }
    }

    var careplanGoals = parent.GetAutoSaveXMLDomNode('CarePlanGoals');
    var itemsGoals = careplanGoals.length > 0 ? $(careplanGoals).XMLExtract() : [];
    var itemsGoals = ArrayHelpers.GetItem(itemsGoals, GoalId, 'CarePlanGoalId');

    var careplanObjectives = parent.GetAutoSaveXMLDomNode('CarePlanObjectives');
    var itemsObjectives = careplanObjectives.length > 0 ? $(careplanObjectives).XMLExtract() : [];
    var itemsObjectives = ArrayHelpers.GetItem(itemsObjectives, GoalId, 'CarePlanGoalId');
    
    if (goalArray.length > 0) {
        if (itemsGoals['CarePlanDomainGoalId'] && itemsGoals['CarePlanDomainGoalId'] != goalArray[0]["Id"] && itemsObjectives) {
            ShowMsgBox('The associated objectives will need to be reentered for the new goal. Do you want to continue?', 'Confirmation Message', MessageBoxButton.OKCancel, MessageBoxIcon.Question, 'UpdateObjectives(\'' + goalstring + '\',\'' + GoalId + '\');', undefined);
        }
        else
            UpdateObjectives(goalstring, GoalId, false);
    }
    else {
        CheckBeforeClose();
    }
}

function UpdateObjectives(goalstring, GoalId, DeleteObjectives) {
   
    PopupProcessing();
    $.ajax({
        type: "POST",
        url: "../Modules/CarePlan/CarePlan.aspx?functionName=EditGoalDescription",
        data: 'DomainGoalId=' + encodeText(goalstring) + '&GoalId=' + GoalId,
        success: function (result) {
            callbackAddAssociatedGoals(result, GoalId, DeleteObjectives);
            CreateUnsavedInstanceOnDatasetChange();
        }
    });
}

//Description: CarePlan  Objectives Description  PopUp select ok button 
function ObjectiveDescriptionPopUp() {
    
    var Needstring = "";
    var Check = "";
    var test = "";
    var objectiveArray = [];

    $('table.dxgvTable input[type=radio]').each(function () {
        Check = ($(this).attr('checked')) ? "T" : "F";
        var NeedId = decodeText($(this).attr('id'));
        var NeedText = '';
        NeedId = NeedId.split('_');
        var Description = $('#textArea_PopupDescription_' + NeedId[1]).val();
        if (NeedId[1] != "") {
            if (Check == "T") {
                var objective = { Id: NeedId[1], Desc: Description };
                objectiveArray.push(objective);
            }
        }
    });
    Needstring = JSON.stringify(objectiveArray);
    if (objectiveArray.length > 0) {
        GoalId = $("[id$=_HiddenField_CarePlanGoalId]").val();
        if ($("[id$=hiddenconfigurationkeyvalue]").val() == "Yes") {
            if (Needstring.indexOf('_') > -1) {
                $("#SpanErrorMessagePopUp").html('&nbsp; Please fill in the blanks');
                $("#SpanErrorMessagePopUp").css("display", "block");
                return;
            }
        }

        ObjectiveId = $("[id$=_HiddenField_CarePlanObjectiveId]").val();
        PopupProcessing();
        $.ajax({
            type: "POST",
            url: "../Modules/CarePlan/CarePlan.aspx?functionName=EditObjectiveDescription",
            data: 'DomainObjectiveId=' + encodeText(Needstring) + '&GoalId=' + GoalId + '&ObjectiveId=' + ObjectiveId,
            success: function (result) {
                callbackAddAssociatedObjectives(result, ObjectiveId);
                CreateUnsavedInstanceOnDatasetChange();
            }
        });
    }
    else {
        CheckBeforeClose();
    }
}

//Description: CarePlan Edit/View Objectives PopUp select ok button 
function EditViewObjectivesPopUp() {
   
    var Objectivestring = "";
    var Check = "";
    var test = "";
    $('table.dxgvTable input[type=checkbox]').each(function() {
        Check = ($(this).attr('checked')) ? "T" : "F";
        test = $(this).attr('tobeassociated');
        var ObjectiveId = decodeText($(this).attr('id'));
        var ObjectiveText = '';
        ObjectiveId = ObjectiveId.split('_');
        if (Check == "T") {
            Objectivestring += "###" + ObjectiveId[1];
        }
    });
    if (Objectivestring.length > 2)
        Objectivestring = Objectivestring.substring(0, Objectivestring.length);
    PrescribedServiceId = $("[id$=_HiddenField_CarePlanPrescribedServiceId]").val();
    var data = 'CustomAction=EditViewObjectivesPopUp^ObjectiveId=' + Objectivestring + '^PrescribedServiceId=' + PrescribedServiceId + "^AutoSaveXML=" + encodeText(convert_accented_characters(parent.AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
    parent.OpenPage(5763, $('[id$=HiddenField_CarePlanMainScreenId]').val(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
}


//Description: Add and Edit Treatment Team
function AddTreatmentTeam() {
    
    var ProgramId = $("select[id$=DropDownList_CarePlanPrograms_ProgramId]");
    var StaffId = $("select[id$=DropDownList_CarePlanPrograms_StaffId]");
    var AssignForContribution = "";
    var ProgramIdVal = "";
    var StaffVal = "";
    var Programname = "";
    var staffName = "";
    var HiddenField_CarePlanTeamId = $('input[id$=HiddenField_CarePlanTeamId][type=hidden]').val();

    if (!ValidateTreatmentTeamPopUp())
        ShowHideErrorMessage("Please select required fields", 'true');
    else {
        if (ProgramId.length > 0 && StaffId.length > 0) {
            $('div#divTreatmentTeam').find('input[type=radio]:checked').each(function() {
                AssignForContribution = $(this).val();
            });

            ProgramIdVal = ProgramId.val();
            StaffVal = StaffId.val();
            Programname = ProgramId.find(":selected").text().trim();
            staffName = StaffId.find(":selected").text().trim();
            var data = 'CustomAction=AddUpdateTreatmentTeamFieldValue^ProgramId=' + ProgramIdVal + "^StaffId=" + StaffVal + "^AssignForContribution=" + AssignForContribution + "^CarePlanTeamId=" + HiddenField_CarePlanTeamId + "^Programname=" + Programname + "^StaffName=" + staffName + "^AutoSaveXML=" + encodeText(convert_accented_characters(parent.AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
            parent.OpenPage(5763, $('[id$=HiddenField_CarePlanMainScreenId]').val(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
        }
    }
}

//Description: Validation on Treatment Team POPUP
function ValidateTreatmentTeamPopUp() {
   
    var skipPageSave = true;
    var ProgramId = $("select[id$=DropDownList_CarePlanPrograms_ProgramId]")
    var StaffId = $("select[id$=DropDownList_CarePlanPrograms_StaffId]");

    if ($(ProgramId).length > 0 && $(StaffId).length > 0 && $('div#divTreatmentTeam').find('input[type=radio]').length > 0) {
        if ($(ProgramId).val() == '' || $(ProgramId).val() == null || $(ProgramId).val() == undefined ||
            $(StaffId).val() == '' || $(StaffId).val() == null || $(StaffId).val() == undefined
            || $('div#divTreatmentTeam').find('input[type=radio]:checked').length == 0 || $(ProgramId).val() == '0' || $(StaffId).val()=='0') {

            skipPageSave = false;
        }
    }
    return skipPageSave;
}

//Description:This function is used to Ajax Call For Supports/Treatment Team Tab,Pop Up When Save Document
// And Create New Row With PrgramId in Table "CarePlanPrograms"
function AddNewTreatmentTeamMember() {
    
    var ProgramId = $("select[id$=DropDownList_DocumentCarePlans_Program]");
    var ProgramIdVal = 0;
    var Programname = "";
    if (!ValidateNewTreatmentTeamMember()) {
        ShowHideErrorMessage("Please select required fields", 'true');
    }
    else {
        ProgramIdVal = ProgramId.val();
        Programname = ProgramId.find(":selected").text().trim();
        var data = 'CustomAction=AddNewTreatmentTeamMember^ProgramId=' + ProgramIdVal + "^Programname=" + Programname + "^AutoSaveXML=" + encodeText(convert_accented_characters(parent.AutoSaveXMLDom[0].xml)) + "^VerboseData=" + encodeText(convert_accented_characters(stringVerboseEvent.replace(/\^/g, "~")));
        parent.OpenPage(5763, $('[id$=HiddenField_CarePlanMainScreenId]').val(), data, null, GetRelativePath(), null, null, pageActionEnum.CustomAjaxCall, null, null, null);
    }
}

//Description: Validation on Treatment Team Program Name DDL On POPUP
function ValidateNewTreatmentTeamMember() {
   
    var skipPageSave = true;
    var ProgramId = $("select[id$=DropDownList_DocumentCarePlans_Program]")
    if (ProgramId.length > 0) {
        if (ProgramId.val() == '' || ProgramId.val() == null) {
            skipPageSave = false;
        }
    }
    return skipPageSave;
}
function GetStaffListByPrograms(DropDownList_CarePlanPrograms_ProgramId) {
    
    PopupProcessing();
    var _CarePlanProgramId = $("[id$=" + DropDownList_CarePlanPrograms_ProgramId + "]").val();
    $.ajax({
        type: "POST",
        async: false,
        url: "../Modules/CarePlan/CarePlan.aspx?functionName=GetStaffListByProgramsId",
        data: 'CarePlanProgramId=' + _CarePlanProgramId,
        success: function (result) {
            CallBackGetStaffListByPrograms(result);
            HidePopupProcessing();
        }
    });
    return false;
}
function CallBackGetStaffListByPrograms(result) {
    try {
        
        var ReferralSubtype = $('select[id$=DropDownList_CarePlanPrograms_StaffId]');
        if (result) {
            var successResult = String(result);
            if (successResult != "") {
                if (ReferralSubtype.length > 0) {
                    ReferralSubtype.html("");
                    ReferralSubtype.html(successResult);
                }
            }
        }
        else {
            ReferralSubtype.html("");
        }
    }
    catch (err) {
        LogClientSideException(err, 'CarePlanPrograms-StaffId');
    }
}

//Description:This function is used to Custom Ajax Request Callback. 
function CustomAjaxRequestCallback(outputHTML, CustomAjaxCall) {
   
    if (outputHTML.indexOf("###StartObjectiveDescriptionPopUp###") >= 0) {
        if (validateGoalObjectiveRepitation(outputHTML)) {
            parent.CloaseModalPopupWindow(outputHTML);
        }
    }
    parent.CustomAjaxRequestCallback(outputHTML, CustomAjaxCall);
}

//Description:This function is used to return Objective exists under Goal true/False.
//Call this function under CustomAjaxRequestCallback()
function validateGoalObjectiveRepitation(response) {
   
    var startIndex = "";
    var endIndex = "";
    var outputHTML = "";
    var splitResponse = "";
    var setObjectiveFlag = "";
    var Objectiveflag = true;

    if (response.indexOf("###StartObjectiveDescriptionPopUp###") >= 0) {
        startIndex = response.indexOf("###StartObjectiveDescriptionPopUp###") + 36;
        endIndex = response.indexOf("###EndObjectiveDescriptionPopUp###");
        outputHTML = response.substr(startIndex, endIndex - startIndex);
        splitResponse = outputHTML.substr(outputHTML.indexOf("ObjectiveId=") + 12).split("$$$");
        setObjectiveFlag = splitResponse[0].split(",")[1];
        if (setObjectiveFlag == "1") {
            Objectiveflag = false;
            ShowHideErrorMessage("Objective already exists under Goal section.", 'true');
        }
    }
    return Objectiveflag;
}
function ShowHideDescriptionBox(obj, showHideDesc) {
   
     if ($(obj).attr("type") == "radio") {
        $('[id^=CarePlantableRow_]').remove();
    }
    var itemChecked = $(obj).attr("checked");
    var $parentobj = $(obj).parent().parent();
    var primarykey = $(obj).attr("primarykey");
    var desc = '';
    if (showHideDesc)
        desc = $(obj).attr("desc");
    if ($("[id$=hiddenconfigurationkeyvalue]").val() == "Yes") {
        // Below codes was commented by Ponnin and it was not used.
        //For Goal Descrption radio selection
        if ($(obj).attr("name") == "radio_Goaldescription") {
            if (!desc) {
                desc = $(obj).parent().parent().find('#Span_CustomCarePlanDomainGoals_GoalDescription > span').attr('title');
                if (!desc) {
                    desc = $(obj).parent().parent().find('#Span_CustomCarePlanDomainGoals_GoalDescription > span').attr('innerHTML')
                    // $(obj).parent().parent().find('#Span_CustomCarePlanDomainGoals_GoalDescription > span').hide();
                }
            }
        }
            //For  Objective description radio selection
        else if ($(obj).attr("name") == "radio_ObjectiveDescription") {
            if (!desc) {
                desc = $(obj).parent().parent().find('#Span_CustomCarePlanDomainObjectives_ObjectiveDescription > span').attr('title');
                if (!desc) {
                    desc = $(obj).parent().parent().find('#Span_CustomCarePlanDomainObjectives_ObjectiveDescription > span').attr('innerHTML')
                    // $(obj).parent().parent().find('#Span_CustomCarePlanDomainObjectives_ObjectiveDescription > span').hide();
                }
            }
        }
    }
    if (primarykey) {
        if (itemChecked) {
            if ($('#CarePlantableRow_' + primarykey).length == 0) {
                $parentobj.after('<tr id="CarePlantableRow_' + primarykey + '"><td style="width: 30px"></td><td style="padding-bottom:2px;padding-top:2px;"><textarea name="FCKeditorLetterTemplates" id="textArea_PopupDescription_' + primarykey + '" rows= "2" cols="104" style="height:30px;float:right; width: 540px" class="form_textareaWithoutWidth">' + desc + '</textarea></td></tr>');
                if ($("[id$=hiddenconfigurationkeyvalue]").val() == "Yes") {
                    var label_value =itemChecked.Description;
                }
            }
        }
        else {
            $(obj).attr("desc", "");
            $('#CarePlantableRow_' + primarykey).remove();
        }
    }
}
function ShowHideDescriptionBoxonLoad(objs) {
        objs.each(function () {
        ShowHideDescriptionBox(this, true);
    });
}
function callbackAddAssociatedNeeds(response, goalId) {
   
    var needtext = response.split("^CarePlanGoalNeedsXML=")[0];// updateAutoSaveXML(response);
    parent.RemoveDeletedXMLNode("CarePlanGoalNeeds", "CarePlanGoalId", goalId);
    parent.AppendNewRowTOAutoSaveXML(response.split("^CarePlanGoalNeedsXML=")[1].split("^")[0]);
    var needtextwithOutDesc = response.split('^')[2];
    parent.$("#Textarea_CarePlanGoalNeeds_" + goalId + "_AssociatedNeeds").val(needtext);
    parent.$("#Textarea_CarePlanGoalNeeds_" + goalId + "_AssociatedNeeds").attr('NeedsWithoutDesc', needtextwithOutDesc);
    parent.CloaseModalPopupWindow('AssociatedNeedPopUp');
    HidePopupProcessing();
}
function callbackAddAssociatedGoals(response, goalId, DeleteObjectives) {
    //debugger;
    var resp = response.split('^');
    var respString = resp[0];// updateAutoSaveXML(response);
    if (resp.length >= 3)
        parent.SetColumnValueInXMLNodeByKeyValue("CarePlanGoals", "CarePlanGoalId", goalId, "CarePlanDomainGoalId", resp[2], parent.AutoSaveXMLDom[0]);
    if (resp.length >= 4)
        parent.SetColumnValueInXMLNodeByKeyValue("CarePlanGoals", "CarePlanGoalId", goalId, "AssociatedGoalDescription", resp[3], parent.AutoSaveXMLDom[0]);
    if (resp.length >= 1)
        parent.SetColumnValueInXMLNodeByKeyValue("CarePlanGoals", "CarePlanGoalId", goalId, "GoalDescription", resp[0], parent.AutoSaveXMLDom[0]);
    if (respString) {
        var goaltext = respString;//.substring(0, respString.indexOf('^'));
        parent.$("#TextArea_CarePlanGoals_" + goalId + "_GoalDescription").val(goaltext);
    }
    parent.CloaseModalPopupWindow("GoalDescription");
    HidePopupProcessing();

    var splitResponse = response.split('^');
    if (DeleteObjectives == true) {
        if (parent.$('#DivGoalObjectiveContainer_' + goalId).length > 0) {
            parent.$('#DivGoalObjectiveContainer_' + goalId).html('');
        }
        parent.GetXMLParentNodeByColumnValue("CarePlanObjectives", "CarePlanGoalId", goalId, parent.AutoSaveXMLDom).each(function () {
            parent.RemoveDeletedXMLNode("CarePlanPrescribedServiceObjectives", "CarePlanObjectiveId", $(this).find("CarePlanObjectiveId").text());
        });
        RemoveDeletedXMLNode("CarePlanObjectives", "CarePlanGoalId", goalId);
    }
}
function callbackAddAssociatedObjectives(response, ObjectiveId) {
    //debugger;
    var resp = response.split('^');
    var objectivetext = resp[0];//updateAutoSaveXML(response);
    if( resp.length >=2)
        parent.SetColumnValueInXMLNodeByKeyValue("CarePlanObjectives", "CarePlanObjectiveId", ObjectiveId, "CarePlanDomainObjectiveId", resp[1], parent.AutoSaveXMLDom[0]);
    if (resp.length >= 4)
        parent.SetColumnValueInXMLNodeByKeyValue("CarePlanObjectives", "CarePlanObjectiveId", ObjectiveId, "ObjectiveDescription", resp[3], parent.AutoSaveXMLDom[0]);
    if (resp.length >= 3)
        parent.SetColumnValueInXMLNodeByKeyValue("CarePlanObjectives", "CarePlanObjectiveId", ObjectiveId, "AssociatedObjectiveDescription", resp[2], parent.AutoSaveXMLDom[0]);
    parent.$("#TextArea_CarePlanObjectives_" + ObjectiveId + "_ObjectiveDescription").val(objectivetext);
    parent.CloaseModalPopupWindow('ObjectiveDescription');
    HidePopupProcessing();
}

function updateAutoSaveXML(response) {
    
    var pageDataSetXml = '';
    var splitPageResponse = response.split("^pageDataSetXML=");
    var outputHTML = splitPageResponse[0];
    pageDataSetXml = splitPageResponse[1];

    if (response != null && response != undefined && response != "") {
        if (pageDataSetXml != "") {
            if (splitPageResponse.length > 0) {
                if (pageDataSetXml != "" && pageDataSetXml.indexOf("</DataSetDocumentMaster>") > 0) {

                    pageDataSetXml = pageDataSetXml.substr(0, pageDataSetXml.indexOf("</DataSetDocumentMaster>") + 24);

                    parent.AutoSaveXMLDom = $.xmlDOM(pageDataSetXml);
                    if (parent.AutoSaveXMLDom[0].childNodes[0].getAttribute("xmlns:xsi") == null) {
                        parent.AutoSaveXMLDom[0].childNodes[0].setAttribute("xmlns:xsi", 'http://www.w3.org/2001/XMLSchema-instance')
                    }
                    $(document).triggerHandler('xmlchange');
                }
            }
        }
    }
    return outputHTML;
}
function AppendNewRowTOAutoSaveXML() {
   
    $(AutoSaveXMLDom).find("DataSetDocumentMaster").append(encodeText(XMLNode));
    var XMLDom = decodeText($(AutoSaveXMLDom).find("DataSetDocumentMaster")[0].xml);
    AutoSaveXMLDom = $.xmlDOM(XMLDom);
    if (AutoSaveXMLDom[0].childNodes[0].getAttribute("xmlns:xsi") == null) {
        AutoSaveXMLDom[0].childNodes[0].setAttribute("xmlns:xsi", 'http://www.w3.org/2001/XMLSchema-instance')
    }
    // trigger the xml update event
    $(document).triggerHandler('xmlchange');
}
function RemoveDeletedXMLNode(tableName, primaryKeyColumnName, primaryKeyValue) {
   
    var xml = GetXMLParentNodeByColumnValue(tableName, primaryKeyColumnName, primaryKeyValue, parent.AutoSaveXMLDom);
    $(xml).each(function () {
        $(this).remove();
    });
}