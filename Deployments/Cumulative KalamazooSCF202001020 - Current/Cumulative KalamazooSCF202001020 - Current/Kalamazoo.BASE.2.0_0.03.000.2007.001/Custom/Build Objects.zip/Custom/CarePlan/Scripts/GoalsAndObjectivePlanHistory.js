﻿
$("#clearImageScreenName").click(function () {
    $("#TextBox_Search").val("");
});

function OnIsErrorUpdate(obj) {    
    var id = $(obj).attr('GoalsAndObjectivesHistoryId');
    var flag = $(obj).attr('GoalsAndObjectivesHistoryType');
    var value = $(obj).val();
    try {
        PopupProcessing();
        $.ajax({
            type: "POST",
            url: "../Modules/CarePlan/CarePlan.aspx?functionName=UpdateIsError",
            data: 'IsError=' + value + '&GoalsAndObjectivesHistoryId=' + id + '&GoalsAndObjectivesHistoryType=' + flag,            
            success: function (result) {
                HidePopupProcessing();                
            }
        });
    }
    catch (ex)
    { }
}
function IncludeRequestParametersValues() {
    var filterString = "";
    filterString += GetFilterValues();
    //Remove # from the begning of the string
    filterString = filterString.substring(1, filterString.length);
    filterString = filterString.replace(/#/gi, "&") + "&ExportUsingPageDataSet=Y"
    return filterString;
}